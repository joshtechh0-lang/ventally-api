/**
 * Email validation
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Password strength validation
 * At least 8 characters, 1 uppercase, 1 lowercase, 1 number
 */
function isValidPassword(password) {
  if (password.length < 8) {
    return {
      valid: false,
      message: "Password must be at least 8 characters long",
    };
  }

  if (!/[A-Z]/.test(password)) {
    return {
      valid: false,
      message: "Password must contain at least one uppercase letter",
    };
  }

  if (!/[a-z]/.test(password)) {
    return {
      valid: false,
      message: "Password must contain at least one lowercase letter",
    };
  }

  if (!/[0-9]/.test(password)) {
    return {
      valid: false,
      message: "Password must contain at least one number",
    };
  }

  return { valid: true };
}

/**
 * Phone number validation (basic)
 */
function isValidPhone(phone) {
  // Basic validation - adjust for specific regions
  const phoneRegex = /^\+?[1-9]\d{1,14}$/;
  return phoneRegex.test(phone.replace(/[\s()-]/g, ""));
}

/**
 * User type validation (all valid types)
 */
function isValidUserType(userType) {
  return ["venter", "listener", "admin", "sub_admin"].includes(userType);
}

/**
 * User type validation for signup (restricted types only)
 */
function isValidSignupUserType(userType) {
  return ["venter", "listener"].includes(userType);
}

/**
 * Sanitize user input
 */
function sanitizeInput(input) {
  if (typeof input !== "string") return input;
  return input.trim();
}

/**
 * Validate biometric public key format
 * Public key should be base64 encoded
 */
function isValidBiometricPublicKey(publicKey) {
  if (!publicKey || typeof publicKey !== "string") {
    return {
      valid: false,
      message: "Public key is required",
    };
  }

  // Check if it's a valid base64 string
  const base64Regex = /^[A-Za-z0-9+/]+=*$/;
  if (!base64Regex.test(publicKey)) {
    return {
      valid: false,
      message: "Public key must be a valid base64 encoded string",
    };
  }

  // Check minimum length (typical public keys are quite long)
  if (publicKey.length < 64) {
    return {
      valid: false,
      message: "Public key appears to be too short",
    };
  }

  return { valid: true };
}

/**
 * Validate device ID
 */
function isValidDeviceId(deviceId) {
  if (!deviceId || typeof deviceId !== "string") {
    return {
      valid: false,
      message: "Device ID is required",
    };
  }

  // Device ID should be alphanumeric and reasonable length
  if (deviceId.length < 10 || deviceId.length > 255) {
    return {
      valid: false,
      message: "Device ID must be between 10 and 255 characters",
    };
  }

  return { valid: true };
}

/**
 * Validate biometric challenge signature
 * The signature is a base64 encoded string
 */
function isValidBiometricSignature(signature) {
  if (!signature || typeof signature !== "string") {
    return {
      valid: false,
      message: "Signature is required",
    };
  }

  const base64Regex = /^[A-Za-z0-9+/]+=*$/;
  if (!base64Regex.test(signature)) {
    return {
      valid: false,
      message: "Signature must be a valid base64 encoded string",
    };
  }

  return { valid: true };
}

/**
 * Validate role array
 * Ensures all roles in the array are valid user types
 */
function isValidRoleArray(roles) {
  if (!Array.isArray(roles)) {
    return {
      valid: false,
      message: "Roles must be an array",
    };
  }

  if (roles.length === 0) {
    return {
      valid: false,
      message: "At least one role is required",
    };
  }

  // Check each role is valid
  for (const role of roles) {
    if (!isValidUserType(role)) {
      return {
        valid: false,
        message: `Invalid role: ${role}. Valid roles are: venter, listener, admin, sub_admin`,
      };
    }
  }

  // Check for duplicates
  const uniqueRoles = [...new Set(roles)];
  if (uniqueRoles.length !== roles.length) {
    return {
      valid: false,
      message: "Duplicate roles are not allowed",
    };
  }

  return { valid: true };
}

/**
 * Validate if user can switch to target role
 * Checks if target role is in user's available roles
 */
function canSwitchToRole(availableRoles, targetRole) {
  if (!Array.isArray(availableRoles)) {
    return {
      valid: false,
      message: "Available roles is not an array",
    };
  }

  if (!isValidUserType(targetRole)) {
    return {
      valid: false,
      message: `${targetRole} is not a valid role`,
    };
  }

  if (!availableRoles.includes(targetRole)) {
    return {
      valid: false,
      message: `You don't have access to ${targetRole} role. Available roles: ${availableRoles.join(", ")}`,
    };
  }

  return { valid: true };
}

module.exports = {
  isValidEmail,
  isValidPassword,
  isValidPhone,
  isValidUserType,
  isValidSignupUserType,
  sanitizeInput,
  isValidBiometricPublicKey,
  isValidDeviceId,
  isValidBiometricSignature,
  isValidRoleArray,
  canSwitchToRole,
};
