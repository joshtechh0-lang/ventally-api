/**
 * Map a Stripe card error to a safe, user-facing message.
 *
 * Server-side off-session charges (PAYG sessions, listener tips) can be declined
 * by Stripe. The raw `error.message` is technical and sometimes confusing to end
 * users (e.g. "…used a known test card."). This helper turns a Stripe error into a
 * clean message + stable code for the client, without leaking fraud-sensitive
 * details.
 *
 * Diagnostics are unaffected — `stripeLogger.failure()` still records the full
 * Stripe error (code, decline_code, requestId, …) for CloudWatch.
 *
 * Per Stripe guidance, fraud-sensitive declines (lost/stolen/test cards, generic
 * declines) are kept intentionally vague and fall through to the default message.
 */

// Keyed by Stripe `decline_code` (granular reason under a card_declined error).
const DECLINE_MESSAGES = {
  insufficient_funds: "Your card has insufficient funds. Please use a different card.",
  expired_card: "Your card has expired. Please update your card details.",
  incorrect_cvc: "Your card's security code is incorrect. Please check and try again.",
  card_velocity_exceeded:
    "Your card has hit its limit. Please try again later or use a different card.",
  // Intentionally NOT mapped (kept generic via the default message):
  // lost_card, stolen_card, pickup_card, do_not_honor, generic_decline,
  // live_mode_test_card, testmode_decline, transaction_not_allowed
};

// Keyed by Stripe `error.code` (used when there is no decline_code match).
const CODE_MESSAGES = {
  expired_card: "Your card has expired. Please update your card details.",
  incorrect_cvc: "Your card's security code is incorrect. Please check and try again.",
  incorrect_number: "Your card number is incorrect. Please check and try again.",
  processing_error: "We couldn't process your card. Please try again in a moment.",
};

const DEFAULT_CARD_MESSAGE =
  "Your card was declined. Please try a different payment method.";

/**
 * @param {object} err - A Stripe error (StripeCardError, etc.).
 * @returns {{ isCardError: boolean, userMessage: string, code: string, declineCode: string|null, statusCode: number }}
 */
function mapStripeCardError(err) {
  const declineCode = err?.decline_code || null;
  const code = err?.code || null;
  const userMessage =
    (declineCode && DECLINE_MESSAGES[declineCode]) ||
    (code && CODE_MESSAGES[code]) ||
    DEFAULT_CARD_MESSAGE;

  return {
    isCardError: err?.type === "StripeCardError",
    userMessage,
    code: code || "card_error",
    declineCode,
    statusCode: 402,
  };
}

module.exports = { mapStripeCardError };
