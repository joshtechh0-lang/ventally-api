function inferDefaultProtocol(rawValue) {
  const value = (rawValue || "").toString().trim().toLowerCase();

  if (
    value.startsWith("localhost") ||
    value.startsWith("127.") ||
    value.startsWith("10.") ||
    value.startsWith("192.168.")
  ) {
    return "http";
  }

  return "https";
}

function normalizeBaseUrl(rawValue) {
  if (!rawValue) {
    return null;
  }

  const trimmed = rawValue.toString().trim();
  if (!trimmed) {
    return null;
  }

  const withProtocol = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : `${inferDefaultProtocol(trimmed)}://${trimmed}`;

  let parsed;
  try {
    parsed = new URL(withProtocol);
  } catch (error) {
    return null;
  }

  if (!["http:", "https:"].includes(parsed.protocol)) {
    return null;
  }

  parsed.hash = "";
  parsed.search = "";
  parsed.pathname =
    parsed.pathname && parsed.pathname !== "/"
      ? parsed.pathname.replace(/\/+$/, "")
      : "/";

  return parsed.toString().replace(/\/$/, "");
}

function getConfiguredPublicBases() {
  const rawBases = [
    process.env.TWILIO_WEBHOOK_BASE_URL,
    process.env.API_BASE_URL,
    process.env.DOMAIN_NAME,
  ];

  const normalizedBases = [];
  for (const rawBase of rawBases) {
    const normalizedBase = normalizeBaseUrl(rawBase);
    if (normalizedBase && !normalizedBases.includes(normalizedBase)) {
      normalizedBases.push(normalizedBase);
    }
  }

  return normalizedBases;
}

function getCanonicalPublicBaseUrl() {
  const bases = getConfiguredPublicBases();
  return bases.length > 0 ? bases[0] : null;
}

function buildPublicUrl(baseUrl, pathWithQuery = "") {
  const normalizedBase = normalizeBaseUrl(baseUrl);
  if (!normalizedBase) {
    return null;
  }

  const url = new URL(normalizedBase);
  const input = (pathWithQuery || "").toString();

  if (!input) {
    return normalizedBase;
  }

  const [rawPath, ...rawQueryParts] = input.split("?");
  const query = rawQueryParts.join("?");

  const normalizedPath = rawPath.startsWith("/") ? rawPath : `/${rawPath}`;
  const basePath = url.pathname && url.pathname !== "/" ? url.pathname : "";

  url.pathname = `${basePath}${normalizedPath}`.replace(/\/{2,}/g, "/");
  url.search = query ? `?${query}` : "";

  return url.toString();
}

module.exports = {
  normalizeBaseUrl,
  getConfiguredPublicBases,
  getCanonicalPublicBaseUrl,
  buildPublicUrl,
};
