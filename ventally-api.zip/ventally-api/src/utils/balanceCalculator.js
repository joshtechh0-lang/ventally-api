/**
 * Balance Calculator Utilities
 * Helper functions for calculating balance, elapsed time, and remaining balance during calls
 */

const { calculateBillableDuration } = require("./gracePeriod");

/**
 * Calculate elapsed billable minutes since call started
 * Takes grace period into account
 * @param {Date|string} startedAt - When call started (became active)
 * @param {number} gracePeriodSeconds - Grace period duration in seconds
 * @returns {Object} {elapsedSeconds: number, billableSeconds: number, billableMinutes: number, isInGracePeriod: boolean}
 */
function calculateElapsedBillableMinutes(startedAt, gracePeriodSeconds = 0) {
  const now = new Date();
  const start = new Date(startedAt);

  // Calculate total elapsed time
  const elapsedMs = now - start;
  const elapsedSeconds = Math.floor(elapsedMs / 1000);

  // Apply grace period
  const billingResult = calculateBillableDuration(
    elapsedSeconds,
    gracePeriodSeconds,
  );

  return {
    elapsedSeconds,
    billableSeconds: billingResult.billableSeconds,
    billableMinutes: billingResult.billableMinutes,
    isInGracePeriod: elapsedSeconds < gracePeriodSeconds,
    gracePeriodRemaining: Math.max(0, gracePeriodSeconds - elapsedSeconds),
  };
}

/**
 * Calculate remaining balance in minutes and currency
 * @param {number} currentBalanceMinutes - Current wallet balance in minutes
 * @param {number} elapsedBillableMinutes - Minutes already elapsed (billable)
 * @param {number} ratePerMinute - Cost per minute
 * @returns {Object} {remainingMinutes: number, remainingCurrency: number, willDeplete: boolean}
 */
function calculateRemainingBalance(
  currentBalanceMinutes,
  elapsedBillableMinutes,
  ratePerMinute,
) {
  // Calculate remaining minutes
  const remainingMinutes = Math.max(
    0,
    currentBalanceMinutes - elapsedBillableMinutes,
  );
  const remainingCurrency = remainingMinutes * ratePerMinute;

  return {
    remainingMinutes: parseFloat(remainingMinutes.toFixed(2)),
    remainingCurrency: parseFloat(remainingCurrency.toFixed(2)),
    willDeplete: remainingMinutes <= 0,
  };
}

/**
 * Determine warning level based on remaining minutes
 * @param {number} remainingMinutes - Minutes remaining
 * @param {number} warningThreshold - Warning threshold in minutes (default 5)
 * @param {number} criticalThreshold - Critical threshold in minutes (default 2)
 * @returns {string} 'none', 'warning', or 'critical'
 */
function determineWarningLevel(
  remainingMinutes,
  warningThreshold = 5,
  criticalThreshold = 2,
) {
  if (remainingMinutes <= 0) {
    return "depleted";
  } else if (remainingMinutes <= criticalThreshold) {
    return "critical";
  } else if (remainingMinutes <= warningThreshold) {
    return "warning";
  }
  return "none";
}

/**
 * Format balance warning message for user
 * @param {string} level - Warning level ('warning', 'critical', 'depleted')
 * @param {number} remainingMinutes - Minutes remaining
 * @returns {string} User-friendly warning message
 */
function formatBalanceWarning(level, remainingMinutes) {
  switch (level) {
    case "warning":
      return `Low balance warning: You have ${remainingMinutes} minutes remaining. Please add funds to continue.`;
    case "critical":
      return `Critical balance warning: Only ${remainingMinutes} minutes remaining! Your call will end soon. Add funds now.`;
    case "depleted":
      return "Your balance has been depleted. This call will end shortly. Please add funds to make another call.";
    default:
      return "";
  }
}

/**
 * Calculate when balance will be depleted
 * @param {number} remainingMinutes - Current remaining minutes
 * @param {number} ratePerMinute - Rate per minute
 * @returns {Object} {depletionTime: Date|null, minutesUntilDepletion: number}
 */
function calculateDepletionTime(remainingMinutes, ratePerMinute) {
  if (remainingMinutes <= 0) {
    return {
      depletionTime: new Date(),
      minutesUntilDepletion: 0,
    };
  }

  const minutesUntilDepletion = remainingMinutes;
  const depletionTime = new Date(
    Date.now() + minutesUntilDepletion * 60 * 1000,
  );

  return {
    depletionTime,
    minutesUntilDepletion: parseFloat(minutesUntilDepletion.toFixed(2)),
  };
}

/**
 * Check if user has sufficient balance for minimum call duration
 * @param {number} balanceMinutes - Current balance in minutes
 * @param {number} minimumMinutes - Minimum required minutes
 * @returns {boolean} True if sufficient balance
 */
function hasSufficientBalance(balanceMinutes, minimumMinutes = 5) {
  return balanceMinutes >= minimumMinutes;
}

module.exports = {
  calculateElapsedBillableMinutes,
  calculateRemainingBalance,
  determineWarningLevel,
  formatBalanceWarning,
  calculateDepletionTime,
  hasSufficientBalance,
};
