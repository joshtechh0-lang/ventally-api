/**
 * Per-step Stripe logging helper (Layer 2).
 *
 * Wraps the Winston logger to emit a consistent, greppable line at each Stripe
 * payment step, carrying business context (userId, sessionId, amount, …) and —
 * on failures — the FULL Stripe error field set needed to diagnose a prod
 * incident from CloudWatch without re-running anything.
 *
 * `step` is a stable, dotted identifier per call site, e.g.
 *   "paymentIntents.create:payg_session"
 *   "transfers.create:listener_payout"
 *   "accountLinks.create:onboarding"
 * so each payment step can be filtered in CloudWatch Logs Insights.
 *
 * Backtracking is done by joining on the IDs Stripe already gives us
 * (paymentIntentId, sessionId, transferId, accountId, webhook eventId, and the
 * Stripe request_id) — these are logged here and on the webhook side.
 */
const logger = require("../utils/logger");

/**
 * Extract every diagnostically useful field from a Stripe error.
 * Stripe errors carry these top-level fields (StripeCardError,
 * StripeInvalidRequestError, StripeConnectionError, etc.).
 */
function extractStripeError(err) {
  if (!err) return {};
  return {
    type: err.type,
    code: err.code,
    declineCode: err.decline_code,
    param: err.param,
    statusCode: err.statusCode,
    requestId: err.requestId,
    message: err.message,
    paymentIntentId: err.payment_intent?.id,
    charge: err.charge,
  };
}

const stripeLogger = {
  /** Log right before a Stripe call. */
  attempt(step, ctx = {}) {
    logger.info(`[STRIPE] ▶ ${step}`, { step, ...ctx });
  },

  /**
   * Log after a successful Stripe call. Pulls key fields off the result plus
   * the Stripe request_id / status from `result.lastResponse`.
   */
  success(step, result = {}, ctx = {}) {
    logger.info(`[STRIPE] ✓ ${step}`, {
      step,
      id: result.id,
      status: result.status,
      amount: result.amount,
      requestId: result.lastResponse?.requestId,
      responseStatus: result.lastResponse?.statusCode,
      ...ctx,
    });
  },

  /** Log a failed Stripe call with the full error field breakdown. */
  failure(step, err, ctx = {}) {
    logger.error(`[STRIPE] ✗ ${step}`, {
      step,
      ...extractStripeError(err),
      ...ctx,
    });
  },
};

stripeLogger.extractStripeError = extractStripeError;

module.exports = stripeLogger;
