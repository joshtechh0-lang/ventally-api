const winston = require("winston");
const path = require("path");
const fs = require("fs");

// Ensure logs directory exists
const logsDir = path.join(process.cwd(), "logs");
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Define log colors
const colors = {
  error: "red",
  warn: "yellow",
  info: "cyan",
  http: "magenta",
  debug: "white",
};

winston.addColors(colors);

// Custom format for console output (with emojis for better readability)
const consoleFormat = winston.format.combine(
  winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  winston.format.errors({ stack: true }),
  winston.format.printf((info) => {
    const emoji = {
      error: "❌",
      warn: "⚠️ ",
      info: "ℹ️ ",
      http: "🌐",
      debug: "🔍",
    };

    let message = `${info.timestamp} ${emoji[info.level] || ""} ${info.level}: ${info.message}`;

    // Add stack trace for errors
    if (info.stack) {
      message += `\n${info.stack}`;
    }

    // Add metadata if present
    const knownKeys = [
      "level",
      "message",
      "timestamp",
      "stack",
      "service",
      "label",
    ];

    const inlineMetadata = Object.keys(info)
      .filter((key) => !knownKeys.includes(key))
      .reduce((acc, key) => {
        acc[key] = info[key];
        return acc;
      }, {});

    if (Object.keys(inlineMetadata).length > 0) {
      message += `\n${JSON.stringify(inlineMetadata, null, 2)}`;
    }

    if (info.metadata && Object.keys(info.metadata).length > 0) {
      message += `\n${JSON.stringify(info.metadata, null, 2)}`;
    }

    return message;
  }),
);

// JSON format for file output
const fileFormat = winston.format.combine(
  winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  winston.format.errors({ stack: true }),
  winston.format.metadata({
    fillExcept: ["message", "level", "timestamp", "label"],
  }),
  winston.format.json(),
);

// Create logger instance
const logger = winston.createLogger({
  level:
    process.env.LOG_LEVEL ||
    (process.env.NODE_ENV === "development" ? "debug" : "info"),
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
  ),
  defaultMeta: { service: "ventally-backend" },
  transports: [
    // Console transport (colored for development)
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize({ all: true }),
        consoleFormat,
      ),
    }),
    // File transport for errors
    new winston.transports.File({
      filename: path.join(logsDir, "error.log"),
      level: "error",
      format: fileFormat,
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
    // File transport for all logs
    new winston.transports.File({
      filename: path.join(logsDir, "combined.log"),
      format: fileFormat,
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
  ],
  // Handle uncaught exceptions and rejections
  exceptionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, "exceptions.log"),
      format: fileFormat,
    }),
  ],
  rejectionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, "rejections.log"),
      format: fileFormat,
    }),
  ],
});

// Create stream object for Morgan (HTTP request logging)
logger.stream = {
  write: (message) => {
    logger.http(message.trim());
  },
};

// Add helper methods for common patterns
logger.database = (message, metadata = {}) => {
  logger.info(`[DATABASE] ${message}`, metadata);
};

logger.auth = (message, metadata = {}) => {
  logger.info(`[AUTH] ${message}`, metadata);
};

logger.payment = (message, metadata = {}) => {
  logger.info(`[PAYMENT] ${message}`, metadata);
};

logger.webhook = (message, metadata = {}) => {
  logger.info(`[WEBHOOK] ${message}`, metadata);
};

logger.email = (message, metadata = {}) => {
  logger.info(`[EMAIL] ${message}`, metadata);
};

logger.redis = (message, metadata = {}) => {
  logger.info(`[REDIS] ${message}`, metadata);
};

module.exports = logger;
