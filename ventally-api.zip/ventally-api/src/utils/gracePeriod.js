/**
 * Grace Period Utility
 * Handles grace period configuration, duration calculation, and rate limiting
 */

/**
 * Get grace period configuration from environment variables
 * @returns {Object} Grace period config {enabled: boolean, minutes: number, seconds: number}
 */
function getGracePeriodConfig() {
  // Grace period force-disabled (2026-06-08). A 10-min per-call grace period
  // stacked on top of the 10-min welcome credit, so calculateBillableDuration()
  // returned billableMinutes=0 for every normal-length call and free/wallet
  // minutes were never deducted. Billing now starts at the first second of every
  // call/session.
  //
  // This intentionally ignores GRACE_PERIOD_ENABLED / GRACE_PERIOD_MINUTES so a
  // stale `GRACE_PERIOD_ENABLED=true` in the prod environment/secrets cannot
  // silently re-enable the feature. To re-enable later, restore the env-driven
  // logic and parse minutes so that 0 is honoured (do NOT use
  // `parseInt(x) || 10`, which coerces 0 -> 10).
  return {
    enabled: false,
    minutes: 0,
    seconds: 0,
  };
}

/**
 * Calculate billable duration after applying grace period
 * @param {number} durationSeconds - Total call duration in seconds
 * @param {number} gracePeriodSeconds - Grace period duration in seconds
 * @returns {Object} {billableSeconds: number, billableMinutes: number, gracePeriodApplied: boolean, gracePeriodSeconds: number}
 */
function calculateBillableDuration(durationSeconds, gracePeriodSeconds) {
  // If grace period is 0 or disabled, bill for full duration
  if (!gracePeriodSeconds || gracePeriodSeconds <= 0) {
    return {
      billableSeconds: durationSeconds,
      billableMinutes: Math.ceil(durationSeconds / 60),
      gracePeriodApplied: false,
      gracePeriodSeconds: 0,
    };
  }

  // Calculate billable duration (subtract grace period, minimum 0)
  const billableSeconds = Math.max(0, durationSeconds - gracePeriodSeconds);
  const billableMinutes =
    billableSeconds > 0 ? Math.ceil(billableSeconds / 60) : 0;
  const gracePeriodApplied = durationSeconds > 0 && gracePeriodSeconds > 0;

  return {
    billableSeconds,
    billableMinutes,
    gracePeriodApplied,
    gracePeriodSeconds,
  };
}

/**
 * Check if user has exceeded grace period rate limit
 * Rate limit: 5 minutes cooldown between calls that use grace period
 * @param {string} userId - User ID to check
 * @param {Object} client - Database client
 * @returns {Promise<Object>} {allowed: boolean, lastUsedAt: Date|null, waitSeconds: number}
 */
async function checkGracePeriodRateLimit(userId, client) {
  const RATE_LIMIT_COOLDOWN_MINUTES = 5;
  const RATE_LIMIT_COOLDOWN_SECONDS = RATE_LIMIT_COOLDOWN_MINUTES * 60;

  try {
    // Check last grace period usage
    const result = await client.query(
      `SELECT last_grace_period_at, grace_period_count 
       FROM grace_period_usage 
       WHERE user_id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      // First time user - allowed
      return {
        allowed: true,
        lastUsedAt: null,
        waitSeconds: 0,
      };
    }

    const lastUsedAt = result.rows[0].last_grace_period_at;
    const now = new Date();
    const timeSinceLastUse = (now - new Date(lastUsedAt)) / 1000; // seconds

    if (timeSinceLastUse < RATE_LIMIT_COOLDOWN_SECONDS) {
      // Rate limit exceeded
      const waitSeconds = Math.ceil(
        RATE_LIMIT_COOLDOWN_SECONDS - timeSinceLastUse,
      );
      return {
        allowed: false,
        lastUsedAt: new Date(lastUsedAt),
        waitSeconds,
      };
    }

    // Cooldown period passed - allowed
    return {
      allowed: true,
      lastUsedAt: new Date(lastUsedAt),
      waitSeconds: 0,
    };
  } catch (error) {
    console.error("Error checking grace period rate limit:", error);
    // On error, allow the call (fail open to not block legitimate users)
    return {
      allowed: true,
      lastUsedAt: null,
      waitSeconds: 0,
      error: error.message,
    };
  }
}

/**
 * Record grace period usage for rate limiting
 * @param {string} userId - User ID
 * @param {Object} client - Database client
 * @returns {Promise<void>}
 */
async function recordGracePeriodUsage(userId, client) {
  try {
    await client.query(
      `INSERT INTO grace_period_usage (user_id, last_grace_period_at, grace_period_count)
       VALUES ($1, NOW(), 1)
       ON CONFLICT (user_id) 
       DO UPDATE SET 
         last_grace_period_at = NOW(),
         grace_period_count = grace_period_usage.grace_period_count + 1`,
      [userId],
    );
  } catch (error) {
    console.error("Error recording grace period usage:", error);
    // Non-fatal error - don't block the call
  }
}

/**
 * Format transaction description with grace period info
 * @param {string} baseDescription - Base description (e.g., "Voice call abc123")
 * @param {number} totalMinutes - Total call duration in minutes
 * @param {number} gracePeriodMinutes - Grace period in minutes
 * @param {number} billedMinutes - Billed duration in minutes
 * @returns {string} Formatted description
 */
function formatTransactionDescription(
  baseDescription,
  totalMinutes,
  gracePeriodMinutes,
  billedMinutes,
) {
  if (gracePeriodMinutes > 0) {
    return `${baseDescription} (Duration: ${totalMinutes}m, Grace: ${gracePeriodMinutes}m, Billed: ${billedMinutes}m)`;
  }
  return `${baseDescription} (Duration: ${totalMinutes}m)`;
}

module.exports = {
  getGracePeriodConfig,
  calculateBillableDuration,
  checkGracePeriodRateLimit,
  recordGracePeriodUsage,
  formatTransactionDescription,
};
