/**
 * Session Helper Utility
 * Provides functions to check for active user sessions (calls and chats)
 * Used primarily for role-switching validation
 */

const { pool } = require("../database/connection");

const ACTIVE_CALL_STATUSES = ["initiated", "ringing", "active", "in-progress"];

const ACTIVE_CHAT_STATUSES = ["active"];

/**
 * Check if a user has any active sessions (voice calls or chat conversations)
 * @param {string} userId - UUID of the user to check
 * @returns {Promise<{hasSession: boolean, sessionType: string|null, sessionId: string|null}>}
 */
async function hasActiveSession(userId) {
  try {
    // Check for active voice calls
    const callQuery = `
      SELECT id, status 
      FROM voice_calls 
      WHERE (venter_id = $1 OR listener_id = $1) 
      AND status = ANY($2::text[])
      AND ended_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1
    `;
    const callResult = await pool.query(callQuery, [
      userId,
      ACTIVE_CALL_STATUSES,
    ]);

    if (callResult.rows.length > 0) {
      return {
        hasSession: true,
        sessionType: "call",
        sessionId: callResult.rows[0].id,
        status: callResult.rows[0].status,
      };
    }

    // Check for active chat conversations
    const chatQuery = `
      SELECT id, status 
      FROM conversations 
      WHERE (venter_id = $1 OR listener_id = $1) 
      AND status = ANY($2::text[])
      AND ended_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1
    `;
    const chatResult = await pool.query(chatQuery, [
      userId,
      ACTIVE_CHAT_STATUSES,
    ]);

    if (chatResult.rows.length > 0) {
      return {
        hasSession: true,
        sessionType: "chat",
        sessionId: chatResult.rows[0].id,
        status: chatResult.rows[0].status,
      };
    }

    // No active sessions found
    return {
      hasSession: false,
      sessionType: null,
      sessionId: null,
      status: null,
    };
  } catch (error) {
    console.error("Error checking active sessions:", error);
    throw error;
  }
}

/**
 * Get all active sessions for a user
 * @param {string} userId - UUID of the user
 * @returns {Promise<Array>} Array of active sessions
 */
async function getActiveSessions(userId) {
  try {
    const sessions = [];

    // Get active voice calls
    const callQuery = `
      SELECT 
        id,
        'call' as type,
        status,
        venter_id,
        listener_id,
        started_at,
        created_at
      FROM voice_calls 
      WHERE (venter_id = $1 OR listener_id = $1) 
      AND status = ANY($2::text[])
      AND ended_at IS NULL
    `;
    const callResult = await pool.query(callQuery, [
      userId,
      ACTIVE_CALL_STATUSES,
    ]);
    sessions.push(...callResult.rows);

    // Get active chat conversations
    const chatQuery = `
      SELECT 
        id,
        'chat' as type,
        status,
        venter_id,
        listener_id,
        started_at,
        created_at
      FROM conversations 
      WHERE (venter_id = $1 OR listener_id = $1) 
      AND status = ANY($2::text[])
      AND ended_at IS NULL
    `;
    const chatResult = await pool.query(chatQuery, [
      userId,
      ACTIVE_CHAT_STATUSES,
    ]);
    sessions.push(...chatResult.rows);

    return sessions;
  } catch (error) {
    console.error("Error getting active sessions:", error);
    throw error;
  }
}

/**
 * Check if user is currently online as a listener
 * @param {string} userId - UUID of the user
 * @returns {Promise<boolean>}
 */
async function isListenerOnline(userId) {
  try {
    const query = `
      SELECT is_online 
      FROM listener_profiles 
      WHERE listener_id = $1
    `;
    const result = await pool.query(query, [userId]);

    if (result.rows.length === 0) {
      return false;
    }

    return result.rows[0].is_online === true;
  } catch (error) {
    console.error("Error checking listener online status:", error);
    throw error;
  }
}

module.exports = {
  ACTIVE_CALL_STATUSES,
  ACTIVE_CHAT_STATUSES,
  hasActiveSession,
  getActiveSessions,
  isListenerOnline,
};
