const { pool } = require("../database/connection");
const { getSetting } = require("../services/settings");
const logger = require("../utils/logger");

/**
 * Get surge pricing configuration from system settings
 * @returns {Promise<Object>} Surge pricing configuration
 */
async function getSurgePricingConfig() {
  try {
    const enabled =
      (await getSetting("surge_pricing_enabled", "true")) === "true";
    const defaultMultiplier = parseFloat(
      await getSetting("surge_default_multiplier", "1.0"),
    );
    const maxMultiplier = parseFloat(
      await getSetting("surge_max_multiplier", "3.0"),
    );
    const applyToSubscribed =
      (await getSetting("surge_apply_to_subscribed", "false")) === "true";

    return {
      enabled,
      defaultMultiplier,
      maxMultiplier,
      applyToSubscribed,
    };
  } catch (error) {
    logger.error("Error getting surge pricing config", {
      error: error.message,
    });
    return {
      enabled: false,
      defaultMultiplier: 1.0,
      maxMultiplier: 3.0,
      applyToSubscribed: false,
    };
  }
}

/**
 * Check if user has an active subscription
 * @param {string} userId - User ID
 * @param {Object} client - Database client (optional)
 * @returns {Promise<boolean>} True if user has active subscription
 */
async function hasActiveSubscription(userId, client = null) {
  try {
    const dbClient = client || pool;
    const result = await dbClient.query(
      `SELECT id FROM user_subscriptions 
       WHERE user_id = $1 AND status IN ('active', 'trialing')
       LIMIT 1`,
      [userId],
    );

    return result.rows.length > 0;
  } catch (error) {
    logger.error("Error checking subscription status", {
      userId,
      error: error.message,
    });
    return false; // Default to false (apply surge) if check fails
  }
}

/**
 * Check if a time range spans midnight
 * @param {string} startTime - Start time (HH:MM:SS)
 * @param {string} endTime - End time (HH:MM:SS)
 * @returns {boolean} True if range spans midnight
 */
function spansMidnight(startTime, endTime) {
  const start = startTime.split(":").map(Number);
  const end = endTime.split(":").map(Number);
  const startMinutes = start[0] * 60 + start[1];
  const endMinutes = end[0] * 60 + end[1];
  return endMinutes < startMinutes;
}

/**
 * Check if current time falls within a time range (handles midnight crossing)
 * @param {Date} now - Current datetime
 * @param {string} startTime - Start time (HH:MM:SS)
 * @param {string} endTime - End time (HH:MM:SS)
 * @returns {boolean} True if current time is within range
 */
function isTimeInRange(now, startTime, endTime) {
  const currentMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();

  const start = startTime.split(":").map(Number);
  const end = endTime.split(":").map(Number);
  const startMinutes = start[0] * 60 + start[1];
  const endMinutes = end[0] * 60 + end[1];

  if (spansMidnight(startTime, endTime)) {
    // Time range spans midnight (e.g., 23:00 - 03:00)
    return currentMinutes >= startMinutes || currentMinutes < endMinutes;
  } else {
    // Normal time range (e.g., 17:00 - 22:00)
    return currentMinutes >= startMinutes && currentMinutes < endMinutes;
  }
}

/**
 * Evaluate a surge pricing rule against current conditions
 * @param {Object} rule - Surge pricing rule
 * @param {Date} now - Current datetime
 * @returns {boolean} True if rule matches current conditions
 */
function evaluateRule(rule, now) {
  // Check if rule is active
  if (!rule.is_active) {
    return false;
  }

  // Check date range if specified
  if (rule.start_date && rule.end_date) {
    const currentDate = now.toISOString().split("T")[0];
    if (currentDate < rule.start_date || currentDate > rule.end_date) {
      return false;
    }
  }

  // Check day of week if specified
  if (rule.days_of_week && rule.days_of_week.length > 0) {
    const currentDay = now.getUTCDay(); // 0 = Sunday, 1 = Monday, etc.
    if (!rule.days_of_week.includes(currentDay)) {
      return false;
    }
  }

  // Check time range if specified
  if (rule.start_time && rule.end_time) {
    if (!isTimeInRange(now, rule.start_time, rule.end_time)) {
      return false;
    }
  }

  // Rule matches all conditions
  return true;
}

/**
 * Get applicable surge pricing multiplier and rule
 * @param {string} userId - User ID (venter)
 * @param {Object} client - Database client (optional)
 * @returns {Promise<Object>} { multiplier, ruleId, ruleName, isSubscribed }
 */
async function getSurgeMultiplier(userId, client = null) {
  try {
    // Get surge pricing configuration
    const config = await getSurgePricingConfig();

    // If surge pricing is disabled, return default
    if (!config.enabled) {
      return {
        multiplier: 1.0,
        ruleId: null,
        ruleName: "No Surge (Disabled)",
        isSubscribed: false,
        surgeApplied: false,
      };
    }

    // Check if user has active subscription
    const isSubscribed = await hasActiveSubscription(userId, client);

    // If user is subscribed and surge doesn't apply to subscribed users, return 1.0
    if (isSubscribed && !config.applyToSubscribed) {
      return {
        multiplier: 1.0,
        ruleId: null,
        ruleName: "No Surge (Subscribed)",
        isSubscribed: true,
        surgeApplied: false,
      };
    }

    // Get all active surge pricing rules, ordered by priority
    const dbClient = client || pool;
    const result = await dbClient.query(
      `SELECT * FROM surge_pricing_rules 
       WHERE is_active = true 
       ORDER BY priority DESC, surge_multiplier DESC`,
    );

    const rules = result.rows;

    if (rules.length === 0) {
      return {
        multiplier: config.defaultMultiplier,
        ruleId: null,
        ruleName: "No Active Rules",
        isSubscribed,
        surgeApplied: false,
      };
    }

    // Evaluate rules to find the first matching one
    const now = new Date();

    for (const rule of rules) {
      if (evaluateRule(rule, now)) {
        // Cap multiplier at max allowed
        const cappedMultiplier = Math.min(
          parseFloat(rule.surge_multiplier),
          config.maxMultiplier,
        );

        logger.info("Surge pricing rule matched", {
          userId,
          ruleId: rule.id,
          ruleName: rule.name,
          multiplier: cappedMultiplier,
          isSubscribed,
        });

        return {
          multiplier: cappedMultiplier,
          ruleId: rule.id,
          ruleName: rule.name,
          isSubscribed,
          surgeApplied: true,
        };
      }
    }

    // No rules matched, return default
    return {
      multiplier: config.defaultMultiplier,
      ruleId: null,
      ruleName: "No Matching Rules",
      isSubscribed,
      surgeApplied: false,
    };
  } catch (error) {
    logger.error("Error calculating surge multiplier", {
      userId,
      error: error.message,
      stack: error.stack,
    });

    // On error, return no surge to avoid blocking calls
    return {
      multiplier: 1.0,
      ruleId: null,
      ruleName: "Error - No Surge Applied",
      isSubscribed: false,
      surgeApplied: false,
    };
  }
}

/**
 * Calculate final cost with surge pricing applied
 * @param {number} baseRate - Base rate per minute
 * @param {number} billableMinutes - Billable minutes (after grace period)
 * @param {number} surgeMultiplier - Surge multiplier (e.g., 1.5)
 * @returns {Object} { baseCost, surgeCost, finalCost, surgeAmount }
 */
function calculateSurgeCost(baseRate, billableMinutes, surgeMultiplier) {
  const baseCost = baseRate * billableMinutes;
  const finalCost = baseCost * surgeMultiplier;
  const surgeAmount = finalCost - baseCost;

  return {
    baseCost: parseFloat(baseCost.toFixed(4)),
    surgeCost: parseFloat(finalCost.toFixed(4)),
    finalCost: parseFloat(finalCost.toFixed(4)),
    surgeAmount: parseFloat(surgeAmount.toFixed(4)),
  };
}

/**
 * Format transaction description with surge pricing info
 * @param {string} baseDescription - Base description (e.g., "Voice call abc123")
 * @param {Object} surgeInfo - Surge pricing information
 * @param {Object} billingInfo - Billing information (minutes, cost)
 * @returns {string} Formatted description
 */
function formatSurgeDescription(baseDescription, surgeInfo, billingInfo) {
  let description = baseDescription;

  if (surgeInfo.surgeApplied && surgeInfo.multiplier > 1.0) {
    const surgePercent = ((surgeInfo.multiplier - 1.0) * 100).toFixed(0);
    description += ` | Surge: ${surgeInfo.multiplier}x (+${surgePercent}%) - ${surgeInfo.ruleName}`;

    if (billingInfo) {
      description += ` | Base: $${billingInfo.baseCost.toFixed(2)} → Final: $${billingInfo.finalCost.toFixed(2)}`;
    }
  } else if (surgeInfo.isSubscribed) {
    description += " | No surge (Subscribed user)";
  } else {
    description += " | No surge applied";
  }

  return description;
}

/**
 * Get surge pricing explanation for users
 * @param {Object} surgeInfo - Surge pricing information
 * @returns {Object} User-friendly explanation
 */
function getSurgeExplanation(surgeInfo) {
  if (!surgeInfo.surgeApplied || surgeInfo.multiplier === 1.0) {
    return {
      hasSurge: false,
      message: surgeInfo.isSubscribed
        ? "No surge pricing - you have an active subscription"
        : "Standard pricing applies",
      multiplier: 1.0,
    };
  }

  const surgePercent = ((surgeInfo.multiplier - 1.0) * 100).toFixed(0);

  return {
    hasSurge: true,
    message: `Surge pricing active: ${surgeInfo.ruleName} (+${surgePercent}%)`,
    multiplier: surgeInfo.multiplier,
    ruleName: surgeInfo.ruleName,
    explanation: `Due to high demand, calls are currently ${surgeInfo.multiplier}x standard rate.`,
    tip: "Subscribe to a plan to avoid surge pricing!",
  };
}

module.exports = {
  getSurgePricingConfig,
  hasActiveSubscription,
  getSurgeMultiplier,
  calculateSurgeCost,
  formatSurgeDescription,
  getSurgeExplanation,
  // Exported for testing
  evaluateRule,
  isTimeInRange,
  spansMidnight,
};
