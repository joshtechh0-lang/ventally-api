const jwt = require("jsonwebtoken");

/**
 * Generate JWT access token
 * @param {string} userId - User ID
 * @param {string} userType - User type (for backward compatibility, equals activeRole)
 * @param {Array<string>} availableRoles - Array of roles user can switch to (optional, defaults to [userType])
 * @param {string} activeRole - Currently active role (optional, defaults to userType)
 */
function generateAccessToken(
  userId,
  userType,
  availableRoles = null,
  activeRole = null,
) {
  const payload = {
    userId,
    userType, // Backward compatibility
    type: "access",
  };

  // Add multi-role fields if provided
  if (availableRoles) {
    payload.availableRoles = availableRoles;
  }

  if (activeRole) {
    payload.activeRole = activeRole;
  }

  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRY || "7d",
  });
}

/**
 * Generate refresh token (longer expiry)
 */
function generateRefreshToken(userId) {
  return jwt.sign(
    {
      userId,
      type: "refresh",
    },
    process.env.JWT_SECRET,
    { expiresIn: "30d" },
  );
}

/**
 * Generate email verification token
 */
function generateVerificationToken(userId, email) {
  return jwt.sign(
    {
      userId,
      email,
      type: "verification",
    },
    process.env.JWT_SECRET,
    { expiresIn: "24h" },
  );
}

/**
 * Generate password reset token
 */
function generatePasswordResetToken(userId, email) {
  return jwt.sign(
    {
      userId,
      email,
      type: "password_reset",
    },
    process.env.JWT_SECRET,
    { expiresIn: "1h" },
  );
}

/**
 * Verify and decode token
 */
function verifyToken(token) {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    throw error;
  }
}

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  generateVerificationToken,
  generatePasswordResetToken,
  verifyToken,
};
