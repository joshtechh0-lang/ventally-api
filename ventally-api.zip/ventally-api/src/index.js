require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const { createServer } = require("http");
const { Server } = require("socket.io");
const swaggerUi = require("swagger-ui-express");
const swaggerSpec = require("./config/swagger");
const asyncApiSpec = require("./config/asyncapi");
const logger = require("./utils/logger");

const { connectDatabase, pool } = require("./database/connection");
const { connectRedis, redisClient } = require("./services/redis");
const { initializeFirebase } = require("./services/fcm");
const { syncSubscriptionPlansWithStripe } = require("./services/stripe-sync");
const {
  initializeDefaults: initializeSettings,
} = require("./services/settings");
const { verifyToken } = require("./utils/jwt");
const { recoverMonitoring } = require("./services/balanceMonitor");
const {
  runBalanceReconciliationOnStartup,
  startBalanceReconciliationScheduler,
  stopBalanceReconciliationScheduler,
} = require("./services/balanceReconciliationScheduler");
const {
  runPendingEarningsReleaseOnStartup,
  startPendingEarningsReleaseScheduler,
  stopPendingEarningsReleaseScheduler,
} = require("./services/earningsReleaseScheduler");
const {
  start: startAbandonedSignupScheduler,
  stop: stopAbandonedSignupScheduler,
} = require("./services/abandonedSignupScheduler");

const app = express();
app.set("trust proxy", true);
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST"],
    credentials: true,
  },
  pingTimeout: 30000,
  pingInterval: 10000,
  transports: ["polling", "websocket"],
  upgradeTimeout: 30000,
  allowEIO3: true,
});

// Middleware
app.use(
  helmet({
    contentSecurityPolicy: false, // Disable for Swagger UI to work
  }),
);
app.use(cors());

// HTTP request logger (Morgan with Winston)
app.use(
  morgan(":method :url :status :res[content-length] - :response-time ms", {
    stream: logger.stream,
  }),
);

// IMPORTANT: Webhook route MUST come BEFORE express.json() middleware
// This is required for Stripe signature verification
const webhookRoutes = require("./routes/webhooks");
app.use("/api/v1/webhooks", webhookRoutes);

// JSON body parser for other routes
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// AsyncAPI Documentation (WebSocket Events) - MUST come before Swagger middleware
app.get("/api-docs/asyncapi", (req, res) => {
  res.json(asyncApiSpec);
});

// Swagger Documentation — restricted to non-production environments
if (process.env.NODE_ENV !== "production") {
  app.use(
    "/api-docs",
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec, {
      explorer: true,
      customCss: ".swagger-ui .topbar { display: none }",
      customSiteTitle: "Ventally API Documentation",
    }),
  );
} else {
  // In production, block /api-docs entirely
  app.use("/api-docs", (req, res) => {
    res.status(404).json({ error: "Not found" });
  });
}

// Health check endpoint
app.get("/health", async (req, res) => {
  try {
    // Check PostgreSQL
    await pool.query("SELECT 1");

    // Check Redis
    await redisClient.ping();

    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      services: {
        postgres: "connected",
        redis: "connected",
      },
    });
  } catch (error) {
    res.status(503).json({
      status: "unhealthy",
      error: error.message,
    });
  }
});

// API Routes with versioning
const apiRoutes = require("./routes");
app.use("/api/v1", apiRoutes);

// Legacy support (redirect to v1)
app.use("/api", (req, res, next) => {
    if (req.path === "/" || req.path === "") {
        return next();
    }
    if (req.path.startsWith("/v1")) {
        return next();
    }
    const queryIndex = req.originalUrl.indexOf("?");
    const queryString = queryIndex >= 0 ? req.originalUrl.slice(queryIndex) : "";
    res.redirect(308, `/api/v1${req.path}${queryString}`);
});

// API info endpoint
app.get("/api", (req, res) => {
  res.json({
    name: "Ventally API",
    version: "1.0.0",
    currentVersion: "v1",
    description: "Emotional support calling platform API",
    endpoints: {
      auth: "/api/v1/auth",
      wallet: "/api/v1/wallet",
      payments: "/api/v1/payments",
      webhooks: "/api/v1/webhooks",
    },
    documentation: "/api-docs",
  });
});

// Swagger JSON endpoint
app.get("/api-docs.json", (req, res) => {
  res.setHeader("Content-Type", "application/json");
  res.send(swaggerSpec);
});

// Root endpoint
app.get("/", (req, res) => {
  res.json({
    app: process.env.APP_NAME || "Ventally",
    version: "1.0.0",
    apiVersion: "v1",
    status: "running",
    api: "/api/v1",
    documentation: "/api-docs",
    openapi: "/api-docs.json",
  });
});

// Socket.io authentication middleware
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    if (!token) return next(new Error("No token"));
    const decoded = verifyToken(token);
    const result = await pool.query(
      "SELECT id, user_type, active_role, is_active FROM users WHERE id = $1",
      [decoded.userId]
    );
    if (!result.rows.length || !result.rows[0].is_active) {
      return next(new Error("User not found"));
    }
    const user = result.rows[0];
    socket.userId = user.id;
    socket.userType = user.user_type;
    socket.activeRole = user.active_role || user.user_type;
    socket.join(String(socket.userId));
    next();
  } catch (err) {
    logger.error("Socket auth error: " + err.message);
    next(new Error("Auth failed"));
  }
});

// Socket.io connection handling
io.on("connection", async (socket) => {
  logger.info("Socket connected: " + socket.id + " user: " + socket.userId + " role: " + socket.activeRole);

  // Store in Redis
  try {
    if (redisClient.isReady) {
      await redisClient.setEx("socket:" + socket.userId, 3600, socket.id);
      logger.info("Stored socket in Redis: " + socket.userId + " -> " + socket.id);
    } else {
      logger.warn("Redis not ready, skipping socket storage for: " + socket.userId);
    }
  } catch (err) {
    logger.error("Redis setEx error: " + err.message);
  }

  // Restore listener presence
  if (socket.userType === "listener" || socket.activeRole === "listener") {
    try {
      const presence = require("./services/presence");
      await presence.restoreListenerPresence(socket.userId);
    } catch (err) {
      logger.error("Restore presence error: " + err.message);
    }
  }

  // Heartbeat
  socket.on("heartbeat", () => {
    socket.emit("heartbeat:ack", { timestamp: Date.now() });
  });

  // Disconnect
  socket.on("disconnect", async (reason) => {
    logger.info("Socket disconnected: " + socket.id + " user: " + socket.userId + " reason: " + reason);
    try {
      if (redisClient.isReady) {
        const stored = await redisClient.get("socket:" + socket.userId);
        if (stored === socket.id) {
          await redisClient.del("socket:" + socket.userId);
          if (socket.userType === "listener" || socket.activeRole === "listener") {
            const presence = require("./services/presence");
            await presence.markListenerDisconnected(socket.userId);
          }
        }
      }
    } catch (err) {
      logger.error("Disconnect error: " + err.message);
    }
  });

  socket.on("error", (err) => {
    logger.error("Socket error for " + socket.userId + ": " + err.message);
  });
});

// Initialize Socket.io handlers
require("./sockets")(io);

// Make io available to routes
app.set("io", io);

// 404 handler for undefined routes
app.use((req, res, next) => {
  logger.warn(`404 - Route not found: ${req.method} ${req.originalUrl}`);
  res.status(404).json({
    error: "Not Found",
    message: "The requested resource does not exist",
    path: req.originalUrl,
    method: req.method,
    timestamp: new Date().toISOString(),
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error(`${err.stack}`);
  res.status(500).json({
    error: "Internal server error",
    message: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

// Initialize and start server
const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    // Connect to PostgreSQL in the background. We don't block server startup on
    // this — otherwise a slow RDS (common right after `db-instance-available`)
    // causes EB to never see a healthy port and the env fails to stabilize.
    // Routes that need DB will surface their own pg pool errors until ready.
    connectDatabase()
      .then(() => logger.info("✓ PostgreSQL connected"))
      .catch((err) =>
        logger.error("PostgreSQL connection failed after retries", {
          error: err.message,
        }),
      );

    // Connect to Redis (non-blocking - continue if Redis fails)
    try {
      await connectRedis();
      logger.info("✓ Redis connected");
    } catch (redisError) {
      logger.warn("Redis connection failed - continuing without cache", {
        error: redisError.message,
      });
      // Application can still run without Redis, but caching won't work
    }

    // Initialize Firebase Cloud Messaging (non-blocking)
    try {
      const firebaseApp = initializeFirebase();
      if (firebaseApp) {
        logger.info("✓ Firebase Cloud Messaging initialized");
      } else {
        logger.info(
          "⚠ Firebase Cloud Messaging not configured - push notifications disabled",
        );
        logger.info("  To enable: Configure Firebase credentials in .env file");
      }
    } catch (firebaseError) {
      logger.warn(
        "⚠ Firebase initialization failed - push notifications disabled",
        {
          error: firebaseError.message,
        },
      );
      logger.info("  To enable: Configure Firebase credentials in .env file");
      // Application can still run without Firebase, but push notifications won't work
    }

    // Sync subscription plans with Stripe (non-blocking)
    try {
      const syncResult = await syncSubscriptionPlansWithStripe();
      if (syncResult && syncResult.synced > 0) {
        logger.info(
          `✓ Synced ${syncResult.synced} subscription plan(s) with Stripe`,
        );
      }
    } catch (stripeSyncError) {
      logger.warn("Stripe plan sync failed - plans will sync on first use", {
        error: stripeSyncError.message,
      });
      // Application can continue - plans will get Stripe prices on first subscription
    }

    // Initialize system settings (non-blocking)
    try {
      await initializeSettings();
      logger.info("✓ System settings initialized");
    } catch (settingsError) {
      logger.warn("Settings initialization failed - using defaults", {
        error: settingsError.message,
      });
    }

    if (
      !process.env.STRIPE_WEBHOOK_SECRET ||
      !process.env.STRIPE_WEBHOOK_SECRET.startsWith("whsec_")
    ) {
      logger.error(
        "STRIPE_WEBHOOK_SECRET is missing or malformed — Stripe webhook signature verification will fail for every event.",
      );
      if (process.env.NODE_ENV === "production") {
        process.exit(1);
      }
    }

    // Start HTTP server
    httpServer.on("error", (error) => {
      if (error.code === "EADDRINUSE") {
        logger.error(`Port ${PORT} is already in use. Stop the existing process or set a different PORT.`);
      } else {
        logger.error(`HTTP server error: ${error.message}`);
      }
      process.exit(1);
    });

    httpServer.listen(PORT, async () => {
      logger.info(`🚀 Ventally server running on port ${PORT}`);
      logger.info(`Environment: ${process.env.NODE_ENV || "development"}`);
      logger.info(`Health check: http://localhost:${PORT}/health`);
      logger.info(`API Docs: http://localhost:${PORT}/api-docs`);

      // Surface grace-period config: when enabled, calls shorter than the grace
      // window bill 0 billable minutes (a suspected cause of "minutes never deducted").
      const { getGracePeriodConfig } = require("./utils/gracePeriod");
      logger.info("[minutes-debug] grace period config", getGracePeriodConfig());

      // Recover balance monitoring for active calls (non-blocking)
      try {
        await recoverMonitoring(io);
        logger.info("✓ Balance monitoring recovery completed");
      } catch (recoveryError) {
        logger.warn("Balance monitoring recovery failed", {
          error: recoveryError.message,
        });
      }

      // Verify recent transactions reflected in wallet balances (non-blocking)
      try {
        await runBalanceReconciliationOnStartup();
        startBalanceReconciliationScheduler();
        logger.info("✓ Balance reconciliation scheduler started");
      } catch (err) {
        logger.warn("Balance reconciliation scheduler init failed", {
          error: err.message,
        });
      }

      // Release matured pending listener earnings to 'available' (non-blocking)
      try {
        await runPendingEarningsReleaseOnStartup();
        startPendingEarningsReleaseScheduler();
        logger.info("✓ Listener earnings release scheduler started");
      } catch (err) {
        logger.warn("Listener earnings release scheduler init failed", {
          error: err.message,
        });
      }

      // Send re-engagement emails to users who abandoned signup (non-blocking)
      try {
        startAbandonedSignupScheduler();
        logger.info("✓ Abandoned signup scheduler started");
      } catch (err) {
        logger.warn("Abandoned signup scheduler init failed", {
          error: err.message,
        });
      }
    });
  } catch (error) {
    logger.error(`Failed to start server: ${error.message}`);
    logger.error(error.stack);
    process.exit(1);
  }
}

// Graceful shutdown
process.on("SIGTERM", async () => {
  logger.info("SIGTERM received, shutting down gracefully...");
  stopBalanceReconciliationScheduler();
  stopPendingEarningsReleaseScheduler();
  stopAbandonedSignupScheduler();
  await pool.end();

  try {
    if (redisClient.isOpen) {
      await redisClient.quit();
    }
  } catch (err) {
    logger.warn("Error closing Redis connection", { error: err.message });
  }
  process.exit(0);
});

process.on("SIGINT", async () => {
  logger.info("SIGINT received, shutting down gracefully...");
  stopBalanceReconciliationScheduler();
  stopPendingEarningsReleaseScheduler();
  stopAbandonedSignupScheduler();
  await pool.end();

  try {
    if (redisClient.isOpen) {
      await redisClient.quit();
    }
  } catch (err) {
    logger.warn("Error closing Redis connection", { error: err.message });
  }

  process.exit(0);
});

startServer();

module.exports = { app, io };
