const logger = require("../utils/logger");

/**
 * Request logging middleware
 * Logs detailed information about incoming requests and responses
 */
const requestLogger = (req, res, next) => {
  const startTime = Date.now();

  // Log request details
  logger.http(`Incoming ${req.method} ${req.path}`, {
    method: req.method,
    path: req.path,
    query: req.query,
    ip: req.ip || req.connection.remoteAddress,
    userAgent: req.get("user-agent"),
  });

  // Capture the original res.json function
  const originalJson = res.json.bind(res);
  const originalSend = res.send.bind(res);

  // Override res.json to log response
  res.json = function (body) {
    logResponse(body);
    return originalJson(body);
  };

  // Override res.send to log response
  res.send = function (body) {
    logResponse(body);
    return originalSend(body);
  };

  function logResponse(body) {
    const duration = Date.now() - startTime;
    const logLevel =
      res.statusCode >= 500 ? "error" : res.statusCode >= 400 ? "warn" : "http";

    logger[logLevel](`${req.method} ${req.path} ${res.statusCode}`, {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip || req.connection.remoteAddress,
    });
  }

  // Handle response finish event for cases where json/send isn't called
  res.on("finish", () => {
    if (!res.headersSent) {
      return;
    }

    const duration = Date.now() - startTime;
    if (duration > 0 && !res.logged) {
      const logLevel =
        res.statusCode >= 500
          ? "error"
          : res.statusCode >= 400
            ? "warn"
            : "http";

      logger[logLevel](`${req.method} ${req.path} ${res.statusCode}`, {
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        duration: `${duration}ms`,
      });
    }
  });

  next();
};

module.exports = requestLogger;
