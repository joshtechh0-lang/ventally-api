const crypto = require("crypto");
const logger = require("../utils/logger");

function safeEqual(a, b) {
  const left = Buffer.from(String(a || ""));
  const right = Buffer.from(String(b || ""));

  if (left.length !== right.length) {
    return false;
  }

  return crypto.timingSafeEqual(left, right);
}

function normalizeSignature(signature) {
  return String(signature || "")
    .trim()
    .replace(/^sha256=/i, "");
}

function validateAgoraSignature(req, res, next) {
  try {
    const secret = process.env.AGORA_WEBHOOK_SECRET;

    if (!secret) {
      logger.error("Agora webhook secret not configured", {
        expectedEnvVar: "AGORA_WEBHOOK_SECRET",
      });

      return res.status(500).json({
        error: "Configuration error",
        message: "Agora webhook authentication not configured",
      });
    }

    const providedHeader =
      req.headers["x-agora-signature"] ||
      req.headers["agora-signature"] ||
      req.headers["x-signature"];

    if (!providedHeader) {
      return res.status(403).json({
        error: "Forbidden",
        message: "Missing Agora signature",
      });
    }

    const rawBody =
      req.rawBody ||
      (req.body && Object.keys(req.body).length > 0
        ? JSON.stringify(req.body)
        : "{}");

    const expectedHex = crypto
      .createHmac("sha256", secret)
      .update(rawBody)
      .digest("hex");
    const expectedBase64 = crypto
      .createHmac("sha256", secret)
      .update(rawBody)
      .digest("base64");

    const providedNormalized = normalizeSignature(providedHeader);
    const valid =
      safeEqual(providedNormalized, expectedHex) ||
      safeEqual(providedNormalized, expectedBase64);

    if (!valid) {
      logger.warn("Agora webhook signature validation failed", {
        path: req.originalUrl,
        method: req.method,
      });

      return res.status(403).json({
        error: "Forbidden",
        message: "Invalid Agora signature",
      });
    }

    next();
  } catch (error) {
    logger.error("Agora signature validation error", {
      error: error.message,
      stack: error.stack,
    });

    return res.status(500).json({
      error: "Internal server error",
      message: "Error validating webhook signature",
    });
  }
}

module.exports = {
  validateAgoraSignature,
};
