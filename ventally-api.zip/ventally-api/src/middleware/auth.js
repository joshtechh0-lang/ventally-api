const jwt = require("jsonwebtoken");
const { pool } = require("../database/connection");

/**
 * Middleware to verify JWT token and attach user to request
 */
async function authenticateToken(req, res, next) {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        error: "Access denied",
        message: "No token provided",
      });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Get user from database with multi-role fields
    const result = await pool.query(
      `SELECT id, email, phone, user_type, available_roles, active_role, is_verified, is_active 
       FROM users WHERE id = $1`,
      [decoded.userId],
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        error: "Invalid token",
        message: "User not found",
      });
    }

    const user = result.rows[0];

    // Add backward compatibility: if active_role or available_roles are null,
    // fallback to user_type (for databases mid-migration)
    user.activeRole = user.active_role || user.user_type;
    user.availableRoles = user.available_roles || [user.user_type];

    // Verify active_role in token matches database (if token has activeRole field)
    if (decoded.activeRole && decoded.activeRole !== user.activeRole) {
      return res.status(401).json({
        error: "Invalid token",
        message: "Role mismatch - please login again",
      });
    }

    // Check if user is active
    if (!user.is_active) {
      return res.status(403).json({
        error: "Account disabled",
        message: "Your account has been deactivated",
      });
    }

    // Attach user to request
    req.user = user;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        error_type: "token_expired",
        message: "Authentication token has expired",
        action_required: "refresh_token",
      });
    }
    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({
        error: "Invalid token",
        message: "Authentication failed",
      });
    }
    console.error("Auth middleware error:", error);
    return res.status(500).json({
      error: "Authentication error",
      message: "Internal server error",
    });
  }
}

/**
 * Middleware to check if user has specific role
 * Checks active_role (or falls back to user_type for backward compatibility)
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: "Unauthorized",
        message: "Please login first",
      });
    }

    // Check active_role first, fallback to user_type for backward compatibility
    const currentRole =
      req.user.activeRole || req.user.active_role || req.user.user_type;

    if (!allowedRoles.includes(currentRole)) {
      return res.status(403).json({
        error: "Forbidden",
        message: `This action requires ${allowedRoles.join(" or ")} role. Your current role is ${currentRole}`,
      });
    }

    next();
  };
}

function requireAdminFeaturePermission(...requiredPermissions) {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        error: "Unauthorized",
        message: "Please login first",
      });
    }

    const currentRole =
      req.user.activeRole || req.user.active_role || req.user.user_type;

    if (currentRole === "admin") {
      return next();
    }

    if (currentRole !== "sub_admin") {
      return res.status(403).json({
        error: "Forbidden",
        message: "This action requires admin or sub-admin access",
      });
    }

    try {
      const permissionResult = await pool.query(
        `SELECT permissions, status
         FROM sub_admin_permissions
         WHERE user_id = $1`,
        [req.user.id],
      );

      if (permissionResult.rows.length === 0) {
        return res.status(403).json({
          error: "Forbidden",
          message: "Sub-admin profile not configured",
        });
      }

      const permissionRow = permissionResult.rows[0];

      if (permissionRow.status !== "active") {
        return res.status(403).json({
          error: "Forbidden",
          message: "Sub-admin account is not active",
        });
      }

      const permissions = permissionRow.permissions || {};
      const missing = requiredPermissions.filter((key) => !permissions[key]);

      if (missing.length > 0) {
        return res.status(403).json({
          error: "Forbidden",
          message: "Insufficient permissions",
          missingPermissions: missing,
        });
      }

      req.subAdminPermissions = permissions;
      return next();
    } catch (error) {
      console.error("Permission middleware error:", error);
      return res.status(500).json({
        error: "Internal server error",
        message: "Failed to validate permissions",
      });
    }
  };
}

/**
 * Middleware to require email verification
 */
function requireVerified(req, res, next) {
  if (!req.user) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Please login first",
    });
  }

  if (!req.user.is_verified) {
    return res.status(403).json({
      error: "Email not verified",
      message: "Please verify your email address to continue",
    });
  }

  next();
}

/**
 * Optional authentication - doesn't fail if no token
 */
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const result = await pool.query(
        `SELECT id, email, phone, user_type, available_roles, active_role, is_verified, is_active 
         FROM users WHERE id = $1 AND is_active = true`,
        [decoded.userId],
      );

      if (result.rows.length > 0) {
        const user = result.rows[0];
        // Add backward compatibility fields
        user.activeRole = user.active_role || user.user_type;
        user.availableRoles = user.available_roles || [user.user_type];
        req.user = user;
      }
    }
    next();
  } catch (error) {
    // Silently fail for optional auth
    next();
  }
}

module.exports = {
  authenticateToken,
  requireRole,
  requireAdminFeaturePermission,
  requireVerified,
  optionalAuth,
};
