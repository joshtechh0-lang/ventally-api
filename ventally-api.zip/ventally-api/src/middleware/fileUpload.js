const multer = require("multer");
const path = require("path");

// File size limit (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB in bytes
const MAX_VERIFICATION_DOC_SIZE = 10 * 1024 * 1024; // 10MB in bytes

// Allowed MIME types for signatures
const ALLOWED_MIME_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/svg+xml",
];

// Allowed file extensions
const ALLOWED_EXTENSIONS = [".png", ".jpg", ".jpeg", ".svg"];

const ALLOWED_VERIFICATION_DOC_MIME_TYPES = [
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
];

const ALLOWED_VERIFICATION_DOC_EXTENSIONS = [".pdf", ".png", ".jpg", ".jpeg"];

const ALLOWED_APPEAL_DOC_MIME_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

const ALLOWED_APPEAL_DOC_EXTENSIONS = [".pdf", ".doc", ".docx"];

// Configure multer with memory storage (for direct S3 upload)
const storage = multer.memoryStorage();

/**
 * File filter to validate uploaded files
 */
const createFileFilter = ({
  allowedMimeTypes,
  allowedExtensions,
  typeLabel,
}) => {
  return (req, file, cb) => {
    // Check MIME type
    if (!allowedMimeTypes.includes(file.mimetype)) {
      return cb(
        new Error(
          `Invalid file type for ${typeLabel}. Received: ${file.mimetype}`,
        ),
        false,
      );
    }

    // Check file extension
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExtensions.includes(ext)) {
      return cb(
        new Error(`Invalid file extension for ${typeLabel}. Received: ${ext}`),
        false,
      );
    }

    // Additional security: Check for double extensions (e.g., file.svg.js)
    const filename = file.originalname.toLowerCase();
    const dangerousExtensions = [
      ".exe",
      ".bat",
      ".cmd",
      ".sh",
      ".js",
      ".php",
      ".html",
      ".htm",
    ];
    for (const dangerousExt of dangerousExtensions) {
      if (filename.includes(dangerousExt)) {
        return cb(
          new Error(
            `File name contains forbidden extension: ${file.originalname}`,
          ),
          false,
        );
      }
    }

    // Sanitize filename (remove special characters except dots and dashes)
    file.originalname = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");

    cb(null, true);
  };
};

const fileFilter = createFileFilter({
  allowedMimeTypes: ALLOWED_MIME_TYPES,
  allowedExtensions: ALLOWED_EXTENSIONS,
  typeLabel: "signature",
});

const verificationDocumentFileFilter = createFileFilter({
  allowedMimeTypes: ALLOWED_VERIFICATION_DOC_MIME_TYPES,
  allowedExtensions: ALLOWED_VERIFICATION_DOC_EXTENSIONS,
  typeLabel: "verification document",
});

const uploadVerificationDoc = multer({
  storage: storage,
  limits: {
    fileSize: MAX_VERIFICATION_DOC_SIZE,
    files: 1,
  },
  fileFilter: verificationDocumentFileFilter,
});

const appealDocumentFileFilter = createFileFilter({
  allowedMimeTypes: ALLOWED_APPEAL_DOC_MIME_TYPES,
  allowedExtensions: ALLOWED_APPEAL_DOC_EXTENSIONS,
  typeLabel: "appeal document",
});

const uploadAppealDoc = multer({
  storage: storage,
  limits: {
    fileSize: MAX_VERIFICATION_DOC_SIZE,
    files: 1,
  },
  fileFilter: appealDocumentFileFilter,
});

const uploadVerificationDocumentFile = (req, res, next) => {
  const uploadSingle = uploadVerificationDoc.single("document");

  uploadSingle(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json({
          error: "File too large",
          message: `File size must not exceed ${MAX_VERIFICATION_DOC_SIZE / 1024 / 1024}MB`,
        });
      }
      if (err.code === "LIMIT_UNEXPECTED_FILE") {
        return res.status(400).json({
          error: "Unexpected field",
          message: 'File field must be named "document"',
        });
      }
      return res.status(400).json({
        error: "Upload error",
        message: err.message,
      });
    }

    if (err) {
      return res.status(400).json({
        error: "Invalid file",
        message: err.message,
      });
    }

    if (!req.file) {
      return res.status(400).json({
        error: "No file uploaded",
        message: "Please provide a verification document file",
      });
    }

    next();
  });
};

const uploadAppealDocumentFile = (req, res, next) => {
  const uploadSingle = uploadAppealDoc.single("document");

  uploadSingle(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json({
          error: "File too large",
          message: `File size must not exceed ${MAX_VERIFICATION_DOC_SIZE / 1024 / 1024}MB`,
        });
      }
      if (err.code === "LIMIT_UNEXPECTED_FILE") {
        return res.status(400).json({
          error: "Unexpected field",
          message: 'File field must be named "document"',
        });
      }
      return res.status(400).json({
        error: "Upload error",
        message: err.message,
      });
    }

    if (err) {
      return res.status(400).json({
        error: "Invalid file",
        message: err.message,
      });
    }

    if (!req.file) {
      return res.status(400).json({
        error: "No file uploaded",
        message: "Please provide an appeal document file",
      });
    }

    next();
  });
};

// Configure multer upload
const upload = multer({
  storage: storage,
  limits: {
    fileSize: MAX_FILE_SIZE,
    files: 1, // Only one file at a time
  },
  fileFilter: fileFilter,
});

/**
 * Middleware for single signature file upload
 * Usage: router.post('/upload', uploadSignatureFile, controller)
 */
const uploadSignatureFile = (req, res, next) => {
  const uploadSingle = upload.single("signature");

  uploadSingle(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      // Multer-specific errors
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json({
          error: "File too large",
          message: `File size must not exceed ${MAX_FILE_SIZE / 1024 / 1024}MB`,
        });
      }
      if (err.code === "LIMIT_UNEXPECTED_FILE") {
        return res.status(400).json({
          error: "Unexpected field",
          message: 'File field must be named "signature"',
        });
      }
      return res.status(400).json({
        error: "Upload error",
        message: err.message,
      });
    } else if (err) {
      // Custom errors from fileFilter
      return res.status(400).json({
        error: "Invalid file",
        message: err.message,
      });
    }

    // Check if file was uploaded
    if (!req.file) {
      return res.status(400).json({
        error: "No file uploaded",
        message: "Please provide a signature file",
      });
    }

    // File validation passed
    next();
  });
};

module.exports = {
  uploadSignatureFile,
  uploadVerificationDocumentFile,
  uploadAppealDocumentFile,
  MAX_FILE_SIZE,
  MAX_VERIFICATION_DOC_SIZE,
  ALLOWED_MIME_TYPES,
  ALLOWED_EXTENSIONS,
  ALLOWED_VERIFICATION_DOC_MIME_TYPES,
  ALLOWED_VERIFICATION_DOC_EXTENSIONS,
  ALLOWED_APPEAL_DOC_MIME_TYPES,
  ALLOWED_APPEAL_DOC_EXTENSIONS,
};
