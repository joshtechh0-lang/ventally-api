-- Seed data for Ventally

-- Insert default subscription plans
INSERT INTO subscription_plans (
	name,
	price_monthly,
	included_minutes,
	included_messages_monthly,
	overage_rate,
	trial_days,
	features,
	stripe_price_id,
	stripe_price_id_annual,
	is_active
) VALUES
('Free Trial', 0.00, 10, 30, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, NULL, true),
('Light Support', 34.99, 30, 150, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, NULL, true),
('Balanced Support', 64.99, 60, 300, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, NULL, true),
('Consistent Care', 119.99, 120, 600, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, NULL, true),
('High Support', 219.99, 240, 1200, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, NULL, true)
ON CONFLICT (name) DO UPDATE
SET price_monthly = EXCLUDED.price_monthly,
	included_minutes = EXCLUDED.included_minutes,
	included_messages_monthly = EXCLUDED.included_messages_monthly,
	overage_rate = EXCLUDED.overage_rate,
	trial_days = EXCLUDED.trial_days,
	features = EXCLUDED.features,
	stripe_price_id = COALESCE(subscription_plans.stripe_price_id, EXCLUDED.stripe_price_id),
	stripe_price_id_annual = COALESCE(subscription_plans.stripe_price_id_annual, EXCLUDED.stripe_price_id_annual),
	is_active = EXCLUDED.is_active,
	updated_at = NOW();

-- Insert sample promo codes
INSERT INTO promo_codes (code, discount_type, discount_value, free_minutes, max_uses, valid_from, valid_until, is_active) VALUES
('WELCOME10', 'percentage', 10, NULL, 1000, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '30 days', true),
('FIRST30', 'free_minutes', NULL, 30, 500, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '60 days', true),
('LAUNCH50', 'percentage', 50, NULL, 100, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '7 days', true)
ON CONFLICT DO NOTHING;

COMMIT;
