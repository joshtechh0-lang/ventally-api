-- Ventally Database Schema
-- Based on payment strategy and per-minute calling requirements

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash VARCHAR(255),
    user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('venter', 'listener', 'admin')),
    available_roles TEXT[] NOT NULL DEFAULT ARRAY['venter'],
    active_role VARCHAR(20) NOT NULL DEFAULT 'venter' CHECK (active_role IN ('venter', 'listener', 'admin')),
    twilio_client_id VARCHAR(255),
    google_id VARCHAR(255) UNIQUE,
    is_verified BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    verification_otp VARCHAR(4),
    otp_expires_at TIMESTAMP,
    otp_attempts INTEGER DEFAULT 0,
    reset_otp VARCHAR(4),
    reset_otp_expires_at TIMESTAMP,
    reset_otp_attempts INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT active_role_in_available_roles CHECK (active_role = ANY(available_roles))
);

-- Indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_active_role ON users(id, active_role);
CREATE INDEX IF NOT EXISTS idx_users_available_roles ON users USING GIN(available_roles);

-- User wallets for prepaid credits
CREATE TABLE IF NOT EXISTS user_wallets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    balance_minutes DECIMAL(10,2) DEFAULT 0,
    balance_currency DECIMAL(10,2) DEFAULT 0,
    currency_code VARCHAR(3) DEFAULT 'USD',
    auto_recharge_enabled BOOLEAN DEFAULT false,
    auto_recharge_threshold INTEGER DEFAULT 10,
    auto_recharge_amount DECIMAL(10,2),
    stripe_customer_id VARCHAR(255),
    default_payment_method VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

-- Subscription plans
CREATE TABLE IF NOT EXISTS subscription_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    price_monthly DECIMAL(10,2) NOT NULL,
    included_minutes INTEGER NOT NULL,
    included_messages_monthly INTEGER NOT NULL DEFAULT 0,
    overage_rate DECIMAL(6,4) NOT NULL,
    trial_days INTEGER NOT NULL DEFAULT 0,
    features JSONB,
    is_active BOOLEAN DEFAULT true,
    stripe_price_id VARCHAR(255),
    stripe_price_id_annual VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User subscriptions
CREATE TABLE IF NOT EXISTS user_subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    plan_id UUID REFERENCES subscription_plans(id),
    status VARCHAR(20) NOT NULL CHECK (status IN ('active', 'past_due', 'canceled', 'trialing', 'paused')),
    included_minutes INTEGER NOT NULL,
    used_minutes DECIMAL(10,2) DEFAULT 0,
    included_messages INTEGER NOT NULL DEFAULT 0,
    used_messages INTEGER DEFAULT 0,
    overage_rate DECIMAL(6,4) NOT NULL,
    trial_start_at TIMESTAMP,
    trial_end_at TIMESTAMP,
    billing_cycle_start DATE NOT NULL,
    billing_cycle_end DATE NOT NULL,
    stripe_subscription_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Call logs
CREATE TABLE IF NOT EXISTS call_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    listener_id UUID REFERENCES users(id),
    twilio_call_sid VARCHAR(255) UNIQUE,
    from_number VARCHAR(20),
    to_number VARCHAR(20),
    duration_seconds INTEGER DEFAULT 0,
    status VARCHAR(20),
    direction VARCHAR(20),
    recording_url TEXT,
    transcription_url TEXT,
    crisis_escalated BOOLEAN DEFAULT false,
    started_at TIMESTAMP,
    ended_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Call costs tracking (legacy - kept for historical data)
CREATE TABLE IF NOT EXISTS call_costs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    call_log_id UUID REFERENCES call_logs(id) ON DELETE CASCADE,
    voice_call_id UUID,
    user_id UUID REFERENCES users(id),
    duration_seconds INTEGER NOT NULL,
    cost_per_minute DECIMAL(6,4) NOT NULL,
    total_cost DECIMAL(10,4) NOT NULL,
    charged_from VARCHAR(20) CHECK (charged_from IN ('subscription', 'prepaid', 'overage', 'grace', 'promo')),
    twilio_cost DECIMAL(10,4),
    margin DECIMAL(10,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Wallet transactions ledger
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    transaction_type VARCHAR(50) NOT NULL,
    amount_minutes DECIMAL(10,2),
    amount_currency DECIMAL(10,2),
    balance_after_minutes DECIMAL(10,2),
    balance_after_currency DECIMAL(10,2),
    related_call_id UUID REFERENCES call_logs(id),
    stripe_payment_intent_id VARCHAR(255),
    description TEXT,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contacts
CREATE TABLE IF NOT EXISTS contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(255),
    tags JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Crisis events log
CREATE TABLE IF NOT EXISTS crisis_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    call_log_id UUID REFERENCES call_logs(id),
    voice_call_id UUID,
    session_type VARCHAR(20) CHECK (session_type IS NULL OR session_type IN ('call', 'chat')),
    session_id UUID,
    user_id UUID REFERENCES users(id),
    trigger_type VARCHAR(50),
    risk_category VARCHAR(50),
    detected_phrases TEXT[],
    action_taken VARCHAR(100),
    manual_trigger BOOLEAN DEFAULT false,
    triggered_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Promo codes
CREATE TABLE IF NOT EXISTS promo_codes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(50) UNIQUE NOT NULL,
    discount_type VARCHAR(20) CHECK (discount_type IN ('percentage', 'fixed', 'free_minutes')),
    discount_value DECIMAL(10,2),
    free_minutes INTEGER,
    max_uses INTEGER,
    current_uses INTEGER DEFAULT 0,
    valid_from TIMESTAMP,
    valid_until TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Promo code usage
CREATE TABLE IF NOT EXISTS promo_code_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    promo_code_id UUID REFERENCES promo_codes(id),
    user_id UUID REFERENCES users(id),
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(promo_code_id, user_id)
);

-- Stripe webhook events log (for idempotency and debugging)
CREATE TABLE IF NOT EXISTS stripe_webhook_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id VARCHAR(255) UNIQUE NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    processed BOOLEAN DEFAULT false,
    processed_at TIMESTAMP,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_wallet_user ON user_wallets(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_status ON user_subscriptions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_call_logs_user ON call_logs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_logs_listener ON call_logs(listener_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_logs_twilio_sid ON call_logs(twilio_call_sid);
CREATE INDEX IF NOT EXISTS idx_call_costs_user ON call_costs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON wallet_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_crisis_events_voice_call ON crisis_events(voice_call_id);
CREATE INDEX IF NOT EXISTS idx_crisis_events_call ON crisis_events(call_log_id);
CREATE INDEX IF NOT EXISTS idx_crisis_events_session_type_created ON crisis_events(session_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_crisis_events_session_id ON crisis_events(session_id);
CREATE INDEX IF NOT EXISTS idx_crisis_events_action_created ON crisis_events(action_taken, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_crisis_events_user ON crisis_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stripe_webhook_events_event_id ON stripe_webhook_events(event_id);
CREATE INDEX IF NOT EXISTS idx_stripe_webhook_events_processed ON stripe_webhook_events(processed, created_at DESC);

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to tables with updated_at
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_user_wallets_updated_at ON user_wallets;
CREATE TRIGGER update_user_wallets_updated_at BEFORE UPDATE ON user_wallets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_subscription_plans_updated_at ON subscription_plans;
CREATE TRIGGER update_subscription_plans_updated_at BEFORE UPDATE ON subscription_plans
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_user_subscriptions_updated_at ON user_subscriptions;
CREATE TRIGGER update_user_subscriptions_updated_at BEFORE UPDATE ON user_subscriptions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_contacts_updated_at ON contacts;
CREATE TRIGGER update_contacts_updated_at BEFORE UPDATE ON contacts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
