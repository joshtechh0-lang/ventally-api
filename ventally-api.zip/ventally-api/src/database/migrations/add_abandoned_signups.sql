-- Feature 3: Abandoned Signup Capture
-- Stores emails captured before a user completes registration
-- A scheduled job reads this table and sends re-engagement emails

CREATE TABLE IF NOT EXISTS abandoned_signups (
  id            SERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL,
  user_type     VARCHAR(50)  DEFAULT NULL,   -- 'venter' | 'listener' | null
  step          VARCHAR(100) DEFAULT 'email_entered',
  platform      VARCHAR(50)  DEFAULT 'mobile',
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  email_sent_at TIMESTAMPTZ  DEFAULT NULL,   -- NULL = not yet sent
  CONSTRAINT abandoned_signups_email_key UNIQUE (email)
);

-- Index for the scheduler query (unsent rows older than 30 min)
CREATE INDEX IF NOT EXISTS idx_abandoned_signups_unsent
  ON abandoned_signups (email_sent_at, created_at)
  WHERE email_sent_at IS NULL;

COMMENT ON TABLE abandoned_signups IS
  'Emails captured mid-signup; scheduler sends re-engagement email after 30 min if user never verified';
