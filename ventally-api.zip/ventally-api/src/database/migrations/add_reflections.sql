-- Add reflections table for tracking daily reflection entries linked to moods
-- Each user can have one reflection per day

CREATE TABLE IF NOT EXISTS reflections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mood_log_id UUID REFERENCES mood_logs(id) ON DELETE SET NULL,
    reflection_text TEXT NOT NULL,
    reflection_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- Ensure only one reflection per user per day
    UNIQUE(user_id, reflection_date)
);

-- Indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_reflections_user_date ON reflections(user_id, reflection_date DESC);
CREATE INDEX IF NOT EXISTS idx_reflections_user ON reflections(user_id);
CREATE INDEX IF NOT EXISTS idx_reflections_mood_log ON reflections(mood_log_id);

-- Apply update trigger
DROP TRIGGER IF EXISTS update_reflections_updated_at ON reflections;
CREATE TRIGGER update_reflections_updated_at BEFORE UPDATE ON reflections
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comments for documentation
COMMENT ON TABLE reflections IS 'Stores daily reflection entries for users. Limited to one entry per user per day, optionally linked to mood_logs.';
COMMENT ON COLUMN reflections.reflection_text IS 'The text content of the user''s reflection';
COMMENT ON COLUMN reflections.mood_log_id IS 'Optional reference to the mood log for the same day';
COMMENT ON COLUMN reflections.reflection_date IS 'The date for which this reflection is logged (defaults to today)';
