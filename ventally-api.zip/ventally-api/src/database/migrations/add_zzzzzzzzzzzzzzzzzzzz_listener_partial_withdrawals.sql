-- Migration: Listener partial withdrawals support
-- Date: 2026-03-15
-- Description: Adds paid_amount tracking and payout allocations for exact custom withdrawal amounts

ALTER TABLE listener_earnings
  ADD COLUMN IF NOT EXISTS paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0;

-- Backfill paid rows so existing data remains consistent with the new model.
UPDATE listener_earnings
SET paid_amount = net_amount
WHERE status = 'paid'
  AND COALESCE(paid_amount, 0) = 0;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'listener_earnings_paid_amount_check'
  ) THEN
    ALTER TABLE listener_earnings
      ADD CONSTRAINT listener_earnings_paid_amount_check
      CHECK (paid_amount >= 0 AND paid_amount <= net_amount);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS listener_payout_allocations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payout_id UUID NOT NULL REFERENCES listener_payouts(id) ON DELETE CASCADE,
  earning_id UUID NOT NULL REFERENCES listener_earnings(id) ON DELETE CASCADE,
  allocated_amount DECIMAL(10,2) NOT NULL CHECK (allocated_amount > 0),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (payout_id, earning_id)
);

CREATE INDEX IF NOT EXISTS idx_listener_payout_allocations_payout
  ON listener_payout_allocations(payout_id);

CREATE INDEX IF NOT EXISTS idx_listener_payout_allocations_earning
  ON listener_payout_allocations(earning_id);
