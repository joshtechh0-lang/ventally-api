-- Add explicit session participants on reports for moderation auditability.

ALTER TABLE user_reports
  ADD COLUMN IF NOT EXISTS session_venter_id UUID REFERENCES users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS session_listener_id UUID REFERENCES users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_user_reports_session_venter
  ON user_reports(session_venter_id);

CREATE INDEX IF NOT EXISTS idx_user_reports_session_listener
  ON user_reports(session_listener_id);
