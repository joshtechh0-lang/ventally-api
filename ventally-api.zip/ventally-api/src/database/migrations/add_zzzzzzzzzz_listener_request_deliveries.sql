-- Migration: Track listener request deliveries and acknowledgments

CREATE TABLE IF NOT EXISTS listener_request_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_type VARCHAR(20) NOT NULL CHECK (request_type IN ('chat', 'call')),
  request_id UUID NOT NULL,
  request_group_id UUID,
  venter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'sent'
    CHECK (status IN ('sent', 'acknowledged', 'expired', 'cancelled')),
  delivered_at TIMESTAMP NOT NULL DEFAULT NOW(),
  acknowledged_at TIMESTAMP,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(request_type, request_id, listener_id)
);

CREATE INDEX IF NOT EXISTS idx_listener_request_deliveries_listener_status
ON listener_request_deliveries(listener_id, status, expires_at DESC);

CREATE INDEX IF NOT EXISTS idx_listener_request_deliveries_group
ON listener_request_deliveries(request_group_id);

CREATE INDEX IF NOT EXISTS idx_listener_request_deliveries_request
ON listener_request_deliveries(request_type, request_id);
