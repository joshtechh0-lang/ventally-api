-- Add unique constraint on subscription plan names to prevent duplicates
-- This will prevent the seed file from creating duplicate plans

-- First, check if constraint already exists
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'subscription_plans_name_key'
    ) THEN
        -- Add the unique constraint on name field
        ALTER TABLE subscription_plans 
        ADD CONSTRAINT subscription_plans_name_key UNIQUE (name);
        
        RAISE NOTICE 'Added unique constraint on subscription_plans.name';
    ELSE
        RAISE NOTICE 'Unique constraint on subscription_plans.name already exists';
    END IF;
END $$;
