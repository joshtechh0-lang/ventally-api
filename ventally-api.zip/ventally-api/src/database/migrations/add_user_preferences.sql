-- Add user preferences and demographic fields for profile customization
-- Based on mobile app design requirements

ALTER TABLE users
ADD COLUMN IF NOT EXISTS gender_identity VARCHAR(50),
ADD COLUMN IF NOT EXISTS cultural_background VARCHAR(50),
ADD COLUMN IF NOT EXISTS ethnicity VARCHAR(50),
ADD COLUMN IF NOT EXISTS age_group VARCHAR(20),
ADD COLUMN IF NOT EXISTS lgbtq_identity VARCHAR(50),
ADD COLUMN IF NOT EXISTS special_topics TEXT[], -- Array of topics
ADD COLUMN IF NOT EXISTS faith_or_belief VARCHAR(50),
ADD COLUMN IF NOT EXISTS preferred_language VARCHAR(20) DEFAULT 'en';

-- Create indexes for filtering and searching
CREATE INDEX IF NOT EXISTS idx_users_gender_identity ON users(gender_identity);
CREATE INDEX IF NOT EXISTS idx_users_cultural_background ON users(cultural_background);
CREATE INDEX IF NOT EXISTS idx_users_ethnicity ON users(ethnicity);
CREATE INDEX IF NOT EXISTS idx_users_age_group ON users(age_group);
CREATE INDEX IF NOT EXISTS idx_users_lgbtq_identity ON users(lgbtq_identity);
CREATE INDEX IF NOT EXISTS idx_users_faith_or_belief ON users(faith_or_belief);
CREATE INDEX IF NOT EXISTS idx_users_preferred_language ON users(preferred_language);

-- Add comments for documentation
COMMENT ON COLUMN users.gender_identity IS 'User''s gender identity: Man, Woman, Non-binary, Gender non-conforming, Questioning, Prefer not to say';
COMMENT ON COLUMN users.cultural_background IS 'User''s cultural/racial background: Black, White, Asian, Native Indian, Pacific Islander, Middle Eastern, North African, Multiracial, Other';
COMMENT ON COLUMN users.ethnicity IS 'User''s ethnicity: African Diaspora, Caribbean, North African, Hispanic, Pacific Islander, Middle Eastern, Asian, Indigenous, European, Multiple, Other, Prefer not to say';
COMMENT ON COLUMN users.age_group IS 'User''s age range: 18-24, 25-34, 35-44, 45-54, 55-64, 65+, Prefer not to say';
COMMENT ON COLUMN users.lgbtq_identity IS 'User''s LGBTQ+ identity: Gay, Lesbian, Bisexual, Pansexual, Asexual, Queer, Questioning, Straight/Heterosexual, Prefer not to say';
COMMENT ON COLUMN users.special_topics IS 'Array of special topics user is interested in: Mental Health, Life & Identity, Relationships, Work & Money, Health & Medical, Work & Finances';
COMMENT ON COLUMN users.faith_or_belief IS 'User''s faith or belief: Christian, Muslim, Sikh, Hindu, Buddhist, Jewish, No religion, Spiritual (not religious), Other';
COMMENT ON COLUMN users.preferred_language IS 'User''s preferred language code: en, pt, es, fr, etc.';
