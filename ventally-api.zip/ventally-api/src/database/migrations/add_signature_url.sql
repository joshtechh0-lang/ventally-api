-- Add signature_url field for user signatures
-- Users can upload and store their signature images (PNG, JPEG, SVG)

ALTER TABLE users
ADD COLUMN IF NOT EXISTS signature_url TEXT;

-- Add comment for documentation
COMMENT ON COLUMN users.signature_url IS 'URL to user''s signature image stored in S3 (PNG, JPEG, or SVG format)';

-- Rollback migration
-- To rollback: ALTER TABLE users DROP COLUMN IF EXISTS signature_url;
