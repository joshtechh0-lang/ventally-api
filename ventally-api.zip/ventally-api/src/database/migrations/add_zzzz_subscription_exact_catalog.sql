-- Migration: Enforce exact subscription catalog values
-- Description: Ensures subscription plans match product-approved names/pricing/limits and keeps legacy plans inactive
-- Date: 2026-02-25

-- Keep non-catalog plans inactive
UPDATE subscription_plans
SET is_active = false,
    updated_at = NOW()
WHERE name NOT IN (
    'Free Trial',
    'Light Support',
    'Balanced Support',
    'Consistent Care',
    'High Support'
);

-- Upsert exact approved catalog
INSERT INTO subscription_plans (
    name,
    price_monthly,
    included_minutes,
    included_messages_monthly,
    overage_rate,
    trial_days,
    features,
    stripe_price_id,
    is_active
) VALUES
('Free Trial', 0.00, 10, 30, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('Light Support', 34.99, 30, 150, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('Balanced Support', 64.99, 60, 300, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('Consistent Care', 119.99, 120, 600, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('High Support', 219.99, 240, 1200, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true)
ON CONFLICT (name) DO UPDATE
SET price_monthly = EXCLUDED.price_monthly,
    included_minutes = EXCLUDED.included_minutes,
    included_messages_monthly = EXCLUDED.included_messages_monthly,
    overage_rate = EXCLUDED.overage_rate,
    trial_days = EXCLUDED.trial_days,
    features = EXCLUDED.features,
    stripe_price_id = COALESCE(subscription_plans.stripe_price_id, EXCLUDED.stripe_price_id),
    is_active = EXCLUDED.is_active,
    updated_at = NOW();
