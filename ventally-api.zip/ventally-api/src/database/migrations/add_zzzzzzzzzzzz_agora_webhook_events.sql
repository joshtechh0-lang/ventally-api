-- Migration: Add Agora webhook event tracking for idempotency

CREATE TABLE IF NOT EXISTS agora_webhook_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_id VARCHAR(255) NOT NULL UNIQUE,
    event_type VARCHAR(100) NOT NULL,
    channel_name VARCHAR(255),
    session_id VARCHAR(255),
    status VARCHAR(100),
    payload JSONB NOT NULL,
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_agora_webhook_events_channel
    ON agora_webhook_events(channel_name);

CREATE INDEX IF NOT EXISTS idx_agora_webhook_events_session
    ON agora_webhook_events(session_id);

CREATE INDEX IF NOT EXISTS idx_agora_webhook_events_processed_at
    ON agora_webhook_events(processed_at DESC);

COMMENT ON TABLE agora_webhook_events IS 'Tracks Agora webhook events to prevent duplicate processing';
COMMENT ON COLUMN agora_webhook_events.event_id IS 'Composite event key for webhook idempotency';
