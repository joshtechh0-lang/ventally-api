-- Listener verification documents
-- Listeners upload verification files for admin review.

CREATE TABLE IF NOT EXISTS listener_verification_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'verified', 'rejected')),
  s3_key TEXT NOT NULL,
  file_url TEXT NOT NULL,
  original_file_name TEXT,
  mime_type VARCHAR(100) NOT NULL,
  file_size_bytes BIGINT,
  admin_notes TEXT,
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMP,
  s3_deleted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_listener_verification_documents_listener
  ON listener_verification_documents(listener_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_listener_verification_documents_status
  ON listener_verification_documents(status, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS uniq_listener_pending_verification
  ON listener_verification_documents(listener_id)
  WHERE status = 'pending';

COMMENT ON TABLE listener_verification_documents IS
  'Listener uploaded verification documents requiring admin approval';