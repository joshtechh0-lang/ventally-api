-- Add annual Stripe price support for direct annual subscription checkout

ALTER TABLE subscription_plans
  ADD COLUMN IF NOT EXISTS stripe_price_id_annual VARCHAR(255);

ALTER TABLE checkout_sessions
  ADD COLUMN IF NOT EXISTS billing_cycle VARCHAR(20);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'checkout_sessions_billing_cycle_check'
  ) THEN
    ALTER TABLE checkout_sessions
      ADD CONSTRAINT checkout_sessions_billing_cycle_check
      CHECK (billing_cycle IS NULL OR billing_cycle IN ('monthly', 'annual'));
  END IF;
END $$;

UPDATE checkout_sessions
SET billing_cycle = 'monthly'
WHERE mode = 'subscription' AND billing_cycle IS NULL;

CREATE INDEX IF NOT EXISTS idx_checkout_sessions_subscription_cycle
  ON checkout_sessions(user_id, plan_id, billing_cycle, status, created_at DESC);
