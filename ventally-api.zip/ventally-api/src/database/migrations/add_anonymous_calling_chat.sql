-- Migration: Add Anonymous Calling and Chat System
-- Date: 2026-02-08
-- Description: Adds listener marketplace, anonymous voice calls, chat, and earnings

-- ============================================================================
-- ANONYMOUS NAME PARTS (for generating dummy identities)
-- ============================================================================

CREATE TABLE IF NOT EXISTS anonymous_name_parts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  part_type VARCHAR(20) NOT NULL CHECK (part_type IN ('adjective', 'noun')),
  value VARCHAR(50) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_anonymous_parts_type ON anonymous_name_parts(part_type);

-- ============================================================================
-- SESSION IDENTITIES (anonymous per session)
-- ============================================================================

CREATE TABLE IF NOT EXISTS session_identities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_type VARCHAR(20) NOT NULL CHECK (session_type IN ('call', 'chat')),
  session_id UUID NOT NULL,
  anonymous_name VARCHAR(100) NOT NULL,
  avatar_seed VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(session_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_session_identities_lookup ON session_identities(session_id, session_type);
CREATE INDEX IF NOT EXISTS idx_session_identities_user ON session_identities(user_id);

-- ============================================================================
-- LISTENER PROFILES (availability, rates, earnings)
-- ============================================================================

CREATE TABLE IF NOT EXISTS listener_profiles (
  listener_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  is_online BOOLEAN DEFAULT false,
  is_busy BOOLEAN DEFAULT false,
  rate_per_minute DECIMAL(6,2) DEFAULT 0.50 CHECK (rate_per_minute >= 0),
  total_sessions INTEGER DEFAULT 0,
  total_reviews INTEGER DEFAULT 0,
  average_rating DECIMAL(3,2) DEFAULT 0.00 CHECK (average_rating >= 0 AND average_rating <= 5),
  bio_anonymous TEXT,
  specialties TEXT[],
  stripe_connect_account_id VARCHAR(255),
  stripe_account_status VARCHAR(50),
  payout_enabled BOOLEAN DEFAULT false,
  last_online_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_listener_profiles_online ON listener_profiles(is_online, is_busy) WHERE is_online = true;

-- ============================================================================
-- CONVERSATIONS (chat sessions)
-- ============================================================================

CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' 
    CHECK (status IN ('pending', 'active', 'ended', 'declined')),
  rate_per_minute DECIMAL(6,2) NOT NULL,
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  duration_minutes INTEGER,
  total_cost DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT NOW(),
  CHECK (venter_id != listener_id)
);

CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(status);
CREATE INDEX IF NOT EXISTS idx_conversations_venter ON conversations(venter_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversations_listener ON conversations(listener_id, created_at DESC);

-- ============================================================================
-- MESSAGES (chat content)
-- ============================================================================

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  delivered_at TIMESTAMP,
  read_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_unread ON messages(conversation_id, read_at) WHERE read_at IS NULL;

-- ============================================================================
-- VOICE CALLS (Twilio in-app calls)
-- ============================================================================

CREATE TABLE IF NOT EXISTS voice_calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'requesting'
    CHECK (status IN ('requesting', 'ringing', 'active', 'ended', 'declined', 'failed', 'cancelled')),
  twilio_room_name VARCHAR(255) UNIQUE,
  rate_per_minute DECIMAL(6,2) NOT NULL,
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  duration_seconds INTEGER,
  total_cost DECIMAL(10,2),
  recording_url TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  CHECK (venter_id != listener_id)
);

CREATE INDEX IF NOT EXISTS idx_voice_calls_status ON voice_calls(status);
CREATE INDEX IF NOT EXISTS idx_voice_calls_venter ON voice_calls(venter_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_voice_calls_listener ON voice_calls(listener_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_voice_calls_room ON voice_calls(twilio_room_name) WHERE twilio_room_name IS NOT NULL;

-- ============================================================================
-- LISTENER EARNINGS (per-session earnings ledger)
-- ============================================================================

CREATE TABLE IF NOT EXISTS listener_earnings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_type VARCHAR(20) NOT NULL CHECK (session_type IN ('call', 'chat')),
  session_id UUID NOT NULL,
  gross_amount DECIMAL(10,2) NOT NULL CHECK (gross_amount >= 0),
  platform_fee DECIMAL(10,2) NOT NULL CHECK (platform_fee >= 0),
  net_amount DECIMAL(10,2) NOT NULL CHECK (net_amount >= 0),
  platform_fee_percentage DECIMAL(5,4) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' 
    CHECK (status IN ('pending', 'available', 'paid', 'cancelled')),
  payout_id UUID,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_listener_earnings_listener ON listener_earnings(listener_id, status);
CREATE INDEX IF NOT EXISTS idx_listener_earnings_session ON listener_earnings(session_type, session_id);
CREATE INDEX IF NOT EXISTS idx_listener_earnings_payout ON listener_earnings(payout_id) WHERE payout_id IS NOT NULL;

-- ============================================================================
-- LISTENER PAYOUTS (payout history)
-- ============================================================================

CREATE TABLE IF NOT EXISTS listener_payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
  stripe_transfer_id VARCHAR(255),
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')),
  failure_reason TEXT,
  processed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_listener_payouts_listener ON listener_payouts(listener_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_listener_payouts_status ON listener_payouts(status);

-- Add foreign key for earnings -> payouts (idempotent)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_listener_earnings_payout'
  ) THEN
    ALTER TABLE listener_earnings 
    ADD CONSTRAINT fk_listener_earnings_payout 
    FOREIGN KEY (payout_id) REFERENCES listener_payouts(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ============================================================================
-- SESSION REVIEWS (anonymous mutual ratings)
-- ============================================================================

CREATE TABLE IF NOT EXISTS session_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_type VARCHAR(20) NOT NULL CHECK (session_type IN ('call', 'chat')),
  session_id UUID NOT NULL,
  reviewer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reviewee_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(session_id, reviewer_id, reviewee_id),
  CHECK (reviewer_id != reviewee_id)
);

CREATE INDEX IF NOT EXISTS idx_session_reviews_reviewee ON session_reviews(reviewee_id, rating);
CREATE INDEX IF NOT EXISTS idx_session_reviews_session ON session_reviews(session_type, session_id);

-- ============================================================================
-- USER REPORTS (safety reporting system)
-- ============================================================================

CREATE TABLE IF NOT EXISTS user_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reported_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_type VARCHAR(20) CHECK (session_type IN ('call', 'chat')),
  session_id UUID,
  reason VARCHAR(50) NOT NULL 
    CHECK (reason IN ('disruptive_behavior', 'harassment', 'inappropriate_content', 
                      'danger_to_self_or_others', 'spam', 'other')),
  description TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'reviewing', 'resolved', 'dismissed')),
  admin_notes TEXT,
  reviewed_by UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  CHECK (reporter_id != reported_id)
);

CREATE INDEX IF NOT EXISTS idx_user_reports_status ON user_reports(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_reports_reporter ON user_reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_user_reports_reported ON user_reports(reported_id);

-- ============================================================================
-- BLOCKED USERS (user blocking)
-- ============================================================================

CREATE TABLE IF NOT EXISTS blocked_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(blocker_id, blocked_id),
  CHECK (blocker_id != blocked_id)
);

CREATE INDEX IF NOT EXISTS idx_blocked_users_blocker ON blocked_users(blocker_id);
CREATE INDEX IF NOT EXISTS idx_blocked_users_blocked ON blocked_users(blocked_id);

-- ============================================================================
-- SYSTEM SETTINGS (configurable platform settings)
-- ============================================================================

CREATE TABLE IF NOT EXISTS system_settings (
  key VARCHAR(100) PRIMARY KEY,
  value TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Add created_at column if it doesn't exist (for existing tables)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'system_settings' AND column_name = 'created_at'
  ) THEN
    ALTER TABLE system_settings ADD COLUMN created_at TIMESTAMP DEFAULT NOW();
  END IF;
END $$;

-- ============================================================================
-- SEED DATA
-- ============================================================================

-- Seed anonymous name parts (Adjectives)
INSERT INTO anonymous_name_parts (part_type, value) VALUES
  ('adjective', 'Swift'),
  ('adjective', 'Brave'),
  ('adjective', 'Calm'),
  ('adjective', 'Wise'),
  ('adjective', 'Kind'),
  ('adjective', 'Gentle'),
  ('adjective', 'Bright'),
  ('adjective', 'Noble'),
  ('adjective', 'Silent'),
  ('adjective', 'Golden'),
  ('adjective', 'Silver'),
  ('adjective', 'Peaceful'),
  ('adjective', 'Serene'),
  ('adjective', 'Bold'),
  ('adjective', 'Quiet'),
  ('adjective', 'Happy'),
  ('adjective', 'Joyful'),
  ('adjective', 'Hopeful'),
  ('adjective', 'Strong'),
  ('adjective', 'Caring')
ON CONFLICT (value) DO NOTHING;

-- Seed anonymous name parts (Nouns)
INSERT INTO anonymous_name_parts (part_type, value) VALUES
  ('noun', 'Fox'),
  ('noun', 'Owl'),
  ('noun', 'Deer'),
  ('noun', 'Wolf'),
  ('noun', 'Eagle'),
  ('noun', 'Dolphin'),
  ('noun', 'Lion'),
  ('noun', 'Phoenix'),
  ('noun', 'Dragon'),
  ('noun', 'Bear'),
  ('noun', 'Tiger'),
  ('noun', 'Hawk'),
  ('noun', 'Raven'),
  ('noun', 'Swan'),
  ('noun', 'Panda'),
  ('noun', 'Falcon'),
  ('noun', 'Turtle'),
  ('noun', 'Butterfly'),
  ('noun', 'Sparrow'),
  ('noun', 'Whale')
ON CONFLICT (value) DO NOTHING;

-- Seed default system settings
INSERT INTO system_settings (key, value, description) VALUES
  ('platform_fee_percentage', '0.20', 'Platform fee as decimal (0.20 = 20%, listener gets 80%)'),
  ('listener_default_rate', '0.50', 'Default listener rate per minute in USD'),
  ('min_payout_threshold', '50.00', 'Minimum balance required for payout in USD'),
  ('payout_schedule', 'weekly', 'Payout schedule: weekly, biweekly, monthly'),
  ('call_max_duration_minutes', '120', 'Maximum call duration in minutes'),
  ('chat_idle_timeout_minutes', '30', 'Auto-end chat after idle period'),
  ('min_call_balance_minutes', '5', 'Minimum wallet balance to start call')
ON CONFLICT (key) DO UPDATE SET 
  value = EXCLUDED.value,
  description = EXCLUDED.description,
  updated_at = NOW();

-- ============================================================================
-- UPDATE EXISTING TABLES TO LINK WITH VOICE_CALLS
-- ============================================================================

-- Ensure voice_call_id column exists in crisis_events before adding FK
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'crisis_events' AND column_name = 'voice_call_id'
  ) THEN
    ALTER TABLE crisis_events ADD COLUMN voice_call_id UUID;
  END IF;
END $$;

-- Add foreign key constraint for crisis_events.voice_call_id if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'crisis_events_voice_call_id_fkey'
  ) THEN
    ALTER TABLE crisis_events
    ADD CONSTRAINT crisis_events_voice_call_id_fkey
    FOREIGN KEY (voice_call_id) REFERENCES voice_calls(id);
  END IF;
END $$;

-- Ensure voice_call_id column exists in call_costs before adding FK
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'call_costs' AND column_name = 'voice_call_id'
  ) THEN
    ALTER TABLE call_costs ADD COLUMN voice_call_id UUID;
  END IF;
END $$;

-- Add foreign key constraint for call_costs.voice_call_id if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'call_costs_voice_call_id_fkey'
  ) THEN
    ALTER TABLE call_costs
    ADD CONSTRAINT call_costs_voice_call_id_fkey
    FOREIGN KEY (voice_call_id) REFERENCES voice_calls(id);
  END IF;
END $$;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update listener_profiles.updated_at on UPDATE
CREATE OR REPLACE FUNCTION update_listener_profiles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_listener_profiles_updated_at ON listener_profiles;
CREATE TRIGGER trigger_listener_profiles_updated_at
  BEFORE UPDATE ON listener_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_listener_profiles_updated_at();

-- Update system_settings.updated_at on UPDATE
CREATE OR REPLACE FUNCTION update_system_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_system_settings_updated_at ON system_settings;
CREATE TRIGGER trigger_system_settings_updated_at
  BEFORE UPDATE ON system_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_system_settings_updated_at();