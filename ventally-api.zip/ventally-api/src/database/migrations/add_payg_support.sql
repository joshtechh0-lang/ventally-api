-- Migration: Pay-as-you-go (PAYG) support
-- Description: Adds payg_rates config table, payment_mode + PAYG charge fields on sessions, and PAYG opt-in fields on user_wallets.
-- Date: 2026-05-24

-- 1. PAYG rate configuration (single active row)
CREATE TABLE IF NOT EXISTS payg_rates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    voice_rate_per_minute DECIMAL(6,4) NOT NULL,
    chat_rate_per_minute DECIMAL(6,4) NOT NULL,
    min_charge_cents INTEGER NOT NULL DEFAULT 50,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_payg_rates_active
    ON payg_rates(is_active) WHERE is_active = true;

INSERT INTO payg_rates (voice_rate_per_minute, chat_rate_per_minute, min_charge_cents, is_active)
SELECT 1.7500, 1.7500, 50, true
WHERE NOT EXISTS (SELECT 1 FROM payg_rates WHERE is_active = true);

-- 2. Session tables: payment_mode + PAYG charge tracking
ALTER TABLE voice_calls
    ADD COLUMN IF NOT EXISTS payment_mode VARCHAR(20) NOT NULL DEFAULT 'prepaid'
        CHECK (payment_mode IN ('subscription', 'prepaid', 'payg')),
    ADD COLUMN IF NOT EXISTS payg_charge_status VARCHAR(20)
        CHECK (payg_charge_status IS NULL OR payg_charge_status IN ('pending', 'succeeded', 'failed', 'refunded')),
    ADD COLUMN IF NOT EXISTS payg_payment_intent_id VARCHAR(255);

ALTER TABLE conversations
    ADD COLUMN IF NOT EXISTS payment_mode VARCHAR(20) NOT NULL DEFAULT 'prepaid'
        CHECK (payment_mode IN ('subscription', 'prepaid', 'payg')),
    ADD COLUMN IF NOT EXISTS payg_charge_status VARCHAR(20)
        CHECK (payg_charge_status IS NULL OR payg_charge_status IN ('pending', 'succeeded', 'failed', 'refunded')),
    ADD COLUMN IF NOT EXISTS payg_payment_intent_id VARCHAR(255);

CREATE INDEX IF NOT EXISTS idx_voice_calls_payg_pi
    ON voice_calls(payg_payment_intent_id)
    WHERE payg_payment_intent_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_conversations_payg_pi
    ON conversations(payg_payment_intent_id)
    WHERE payg_payment_intent_id IS NOT NULL;

-- 3. user_wallets: PAYG opt-in state
ALTER TABLE user_wallets
    ADD COLUMN IF NOT EXISTS payg_enabled BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS payg_locked_at TIMESTAMP;
