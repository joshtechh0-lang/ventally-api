-- Optimize voice_calls table for conference-based tracking
-- Remove ambiguous twilio_call_sid, use twilio_conference_sid instead
-- Migration: 20260210_optimize_voice_calls_tracking.sql

-- Rename column to be explicit about what we're tracking (idempotent)
DO $$ 
BEGIN
  -- Check if old column exists and needs renaming
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_call_sid'
  ) THEN
    -- Rename the old column
    ALTER TABLE voice_calls 
      RENAME COLUMN twilio_call_sid TO twilio_conference_sid;
  ELSIF NOT EXISTS (
    -- If old column doesn't exist, ensure new column exists
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_conference_sid'
  ) THEN
    -- Neither column exists, create the new one
    ALTER TABLE voice_calls 
      ADD COLUMN twilio_conference_sid VARCHAR(255);
  END IF;
END $$;

-- Add comment to clarify usage
COMMENT ON COLUMN voice_calls.twilio_conference_sid IS 
  'Twilio Conference SID (CFxxxxxx format) - tracks the conference room for this 1:1 call, not individual participant CallSids';

-- Update index name
DROP INDEX IF EXISTS idx_voice_calls_twilio_call_sid;
CREATE INDEX IF NOT EXISTS idx_voice_calls_twilio_conference_sid 
  ON voice_calls(twilio_conference_sid) 
  WHERE twilio_conference_sid IS NOT NULL;

-- Add partial unique constraint - one conference per active call
-- This prevents the same conference from being tracked in multiple call records
DROP INDEX IF EXISTS idx_voice_calls_unique_conference; -- Drop first for idempotency
CREATE UNIQUE INDEX IF NOT EXISTS idx_voice_calls_unique_conference 
  ON voice_calls(twilio_conference_sid) 
  WHERE status IN ('active', 'ringing') AND twilio_conference_sid IS NOT NULL;

-- Update any references in other tables (if they exist)
-- Check if sessions table has similar column and update it too
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'twilio_call_sid'
  ) THEN
    -- Keep sessions table as-is for legacy PSTN calls
    COMMENT ON COLUMN sessions.twilio_call_sid IS 
      'Legacy: Individual CallSid for PSTN-based sessions. For voice_calls, see twilio_conference_sid instead.';
  END IF;
END $$;
