-- Add user profile fields for mobile app
-- Fields: first_name, last_name, display_name, profile_picture_url, bio, date_of_birth

ALTER TABLE users
ADD COLUMN IF NOT EXISTS first_name VARCHAR(100),
ADD COLUMN IF NOT EXISTS last_name VARCHAR(100),
ADD COLUMN IF NOT EXISTS display_name VARCHAR(200),
ADD COLUMN IF NOT EXISTS profile_picture_url TEXT,
ADD COLUMN IF NOT EXISTS bio TEXT,
ADD COLUMN IF NOT EXISTS date_of_birth DATE;

-- Create index for display name searches
CREATE INDEX IF NOT EXISTS idx_users_display_name ON users(display_name);

-- Add comments for documentation
COMMENT ON COLUMN users.first_name IS 'User''s first name';
COMMENT ON COLUMN users.last_name IS 'User''s last name';
COMMENT ON COLUMN users.display_name IS 'Public display name (defaults to first_name + last_name)';
COMMENT ON COLUMN users.profile_picture_url IS 'URL to user''s profile picture (S3 or external)';
COMMENT ON COLUMN users.bio IS 'User biography or description';
COMMENT ON COLUMN users.date_of_birth IS 'User''s date of birth for age verification';
