-- Migration: Add message quota + trial support for subscription plans
-- Description: Adds plan/user message counters, trial metadata, and aligns default plans with current product catalog
-- Date: 2026-02-25

ALTER TABLE subscription_plans
ADD COLUMN IF NOT EXISTS included_messages_monthly INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS trial_days INTEGER NOT NULL DEFAULT 0;

ALTER TABLE user_subscriptions
ADD COLUMN IF NOT EXISTS included_messages INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS used_messages INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS trial_start_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS trial_end_at TIMESTAMP;

-- Backfill user subscription message limits from linked plan
UPDATE user_subscriptions us
SET included_messages = COALESCE(sp.included_messages_monthly, 0)
FROM subscription_plans sp
WHERE us.plan_id = sp.id
  AND us.included_messages = 0;

-- Deactivate old plans so only the current catalog is returned as active
UPDATE subscription_plans
SET is_active = false,
    updated_at = NOW()
WHERE is_active = true;

-- Upsert current subscription catalog
INSERT INTO subscription_plans (
    name,
    price_monthly,
    included_minutes,
    included_messages_monthly,
    overage_rate,
    trial_days,
    features,
    stripe_price_id,
    is_active
) VALUES
('Free Trial', 0.00, 10, 30, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('Light Support', 34.99, 30, 150, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('Balanced Support', 64.99, 60, 300, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('Consistent Care', 119.99, 120, 600, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true),
('High Support', 219.99, 240, 1200, 0.10, 0, '{"emotional_wellness_tools": true}', NULL, true)
ON CONFLICT (name) DO UPDATE
SET price_monthly = EXCLUDED.price_monthly,
    included_minutes = EXCLUDED.included_minutes,
    included_messages_monthly = EXCLUDED.included_messages_monthly,
    overage_rate = EXCLUDED.overage_rate,
    trial_days = EXCLUDED.trial_days,
    features = EXCLUDED.features,
  stripe_price_id = COALESCE(subscription_plans.stripe_price_id, EXCLUDED.stripe_price_id),
    is_active = EXCLUDED.is_active,
    updated_at = NOW();
