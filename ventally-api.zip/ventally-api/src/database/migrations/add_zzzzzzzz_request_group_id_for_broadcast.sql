-- Migration: Add request_group_id to conversations and voice_calls for broadcast requests

ALTER TABLE conversations
ADD COLUMN IF NOT EXISTS request_group_id UUID;

ALTER TABLE voice_calls
ADD COLUMN IF NOT EXISTS request_group_id UUID;

CREATE INDEX IF NOT EXISTS idx_conversations_request_group_status
ON conversations(request_group_id, status)
WHERE request_group_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_voice_calls_request_group_status
ON voice_calls(request_group_id, status)
WHERE request_group_id IS NOT NULL;
