-- Migration: Add persistent socket broadcast requests queue

CREATE TABLE IF NOT EXISTS socket_broadcast_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_type VARCHAR(20) NOT NULL CHECK (request_type IN ('chat', 'call')),
  venter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'open'
    CHECK (status IN ('open', 'claimed', 'expired', 'cancelled')),
  expires_at TIMESTAMP NOT NULL,
  claimed_listener_id UUID REFERENCES users(id) ON DELETE SET NULL,
  claimed_request_id UUID,
  claimed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_socket_broadcast_requests_status_exp
ON socket_broadcast_requests(status, expires_at);

CREATE INDEX IF NOT EXISTS idx_socket_broadcast_requests_venter
ON socket_broadcast_requests(venter_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_socket_broadcast_requests_created
ON socket_broadcast_requests(created_at DESC);
