-- Migration: Add provider-neutral call tracking columns for Agora migration

ALTER TABLE voice_calls
ADD COLUMN IF NOT EXISTS call_provider VARCHAR(50) DEFAULT 'twilio';

ALTER TABLE voice_calls
ADD COLUMN IF NOT EXISTS voice_channel_name VARCHAR(255);

ALTER TABLE voice_calls
ADD COLUMN IF NOT EXISTS voice_session_sid VARCHAR(255);

-- Backfill from legacy Twilio columns where possible.
UPDATE voice_calls
SET call_provider = COALESCE(call_provider, 'twilio')
WHERE call_provider IS NULL;

UPDATE voice_calls
SET voice_channel_name = twilio_room_name
WHERE voice_channel_name IS NULL
  AND twilio_room_name IS NOT NULL;

UPDATE voice_calls
SET voice_session_sid = twilio_conference_sid
WHERE voice_session_sid IS NULL
  AND twilio_conference_sid IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_voice_calls_provider_status
ON voice_calls(call_provider, status);

CREATE INDEX IF NOT EXISTS idx_voice_calls_voice_channel
ON voice_calls(voice_channel_name)
WHERE voice_channel_name IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_voice_calls_voice_session_sid
ON voice_calls(voice_session_sid)
WHERE voice_session_sid IS NOT NULL;

COMMENT ON COLUMN voice_calls.call_provider IS
  'Active RTC provider used for this call (e.g., agora, twilio)';

COMMENT ON COLUMN voice_calls.voice_channel_name IS
  'Provider-neutral channel/room name used for RTC connection';

COMMENT ON COLUMN voice_calls.voice_session_sid IS
  'Provider-neutral session/conference identifier for webhooks and tracing';
