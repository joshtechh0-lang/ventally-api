-- Add mood logs table for tracking daily mood entries
-- Each user can have one mood entry per day

CREATE TABLE IF NOT EXISTS mood_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mood_type VARCHAR(20) NOT NULL CHECK (mood_type IN ('Happy', 'Neutral', 'Sad', 'Anxious')),
    category VARCHAR(20) CHECK (category IN ('Work', 'Family', 'Health', 'Unknown')),
    notes TEXT,
    logged_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- Ensure only one mood entry per user per day
    UNIQUE(user_id, logged_date)
);

-- Index for efficient queries
CREATE INDEX IF NOT EXISTS idx_mood_logs_user_date ON mood_logs(user_id, logged_date DESC);
CREATE INDEX IF NOT EXISTS idx_mood_logs_user ON mood_logs(user_id);

-- Apply update trigger
DROP TRIGGER IF EXISTS update_mood_logs_updated_at ON mood_logs;
CREATE TRIGGER update_mood_logs_updated_at BEFORE UPDATE ON mood_logs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Comment for documentation
COMMENT ON TABLE mood_logs IS 'Stores daily mood check-ins for venter profiles. Limited to one entry per user per day.';
COMMENT ON COLUMN mood_logs.mood_type IS 'The mood selected by the user: Happy, Neutral, Sad, or Anxious';
COMMENT ON COLUMN mood_logs.category IS 'Optional category indicating the context: Work, Family, Health, or Unknown';
COMMENT ON COLUMN mood_logs.notes IS 'Optional text notes from the user about their mood';
COMMENT ON COLUMN mood_logs.logged_date IS 'The date for which this mood is logged (defaults to today)';
