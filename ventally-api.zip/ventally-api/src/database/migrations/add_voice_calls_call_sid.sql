-- Migration: Add Twilio Call SID tracking to voice_calls table
-- Purpose: Link voice calls to Twilio call records for webhook processing
-- Created: 2026-02-09
-- Note: This column was later renamed to twilio_conference_sid in add_zzz_voice_conference_sid_tracking.sql

-- Add twilio_call_sid ONLY if twilio_conference_sid doesn't already exist
-- (twilio_conference_sid is the renamed version from a later migration)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_conference_sid'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_call_sid'
  ) THEN
    ALTER TABLE voice_calls ADD COLUMN twilio_call_sid VARCHAR(255);
  END IF;
END $$;

-- Only add twilio_room_name if it doesn't already exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_room_name'
  ) THEN
    ALTER TABLE voice_calls ADD COLUMN twilio_room_name VARCHAR(255);
  END IF;
END $$;

-- Create index only if the column exists (may have been renamed already)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_call_sid'
  ) THEN
    CREATE INDEX IF NOT EXISTS idx_voice_calls_twilio_call_sid
      ON voice_calls(twilio_call_sid);
    COMMENT ON COLUMN voice_calls.twilio_call_sid IS 'Twilio Call SID for linking webhook events (renamed to twilio_conference_sid in later migration)';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'voice_calls' AND column_name = 'twilio_room_name'
  ) THEN
    COMMENT ON COLUMN voice_calls.twilio_room_name IS 'Twilio Voice SDK room name (format: ventally-voice-{callId})';
  END IF;
END $$;
