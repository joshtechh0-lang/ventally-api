-- ============================================================================
-- Allow "Mad" mood type in mood_logs
-- Date: 2026-02-18
-- ============================================================================

-- Replace mood_type check constraint to include "Mad"
ALTER TABLE mood_logs
  DROP CONSTRAINT IF EXISTS mood_logs_mood_type_check;

ALTER TABLE mood_logs
  ADD CONSTRAINT mood_logs_mood_type_check
  CHECK (mood_type IN ('Happy', 'Neutral', 'Sad', 'Anxious', 'Mad'));

-- Update comment for documentation
COMMENT ON COLUMN mood_logs.mood_type IS 'The mood selected by the user: Happy, Neutral, Sad, Anxious, or Mad';
