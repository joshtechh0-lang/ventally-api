-- Extend listener_tips to support both call and chat session tipping.

ALTER TABLE listener_tips
  ADD COLUMN IF NOT EXISTS session_type VARCHAR(20),
  ADD COLUMN IF NOT EXISTS session_id UUID;

-- Backfill existing call tips into the new polymorphic session fields.
UPDATE listener_tips
SET session_type = COALESCE(session_type, 'call'),
    session_id = COALESCE(session_id, call_id)
WHERE session_type IS NULL OR session_id IS NULL;

ALTER TABLE listener_tips
  ALTER COLUMN session_type SET NOT NULL,
  ALTER COLUMN session_id SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'listener_tips_session_type_check'
  ) THEN
    ALTER TABLE listener_tips
      ADD CONSTRAINT listener_tips_session_type_check
      CHECK (session_type IN ('call', 'chat'));
  END IF;
END $$;

-- Allow null call_id for chat tips, but enforce call linkage for call tips.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'listener_tips_call_id_for_call_check'
  ) THEN
    ALTER TABLE listener_tips
      ADD CONSTRAINT listener_tips_call_id_for_call_check
      CHECK (
        (session_type = 'call' AND call_id IS NOT NULL)
        OR (session_type = 'chat' AND call_id IS NULL)
      );
  END IF;
END $$;

ALTER TABLE listener_tips
  ALTER COLUMN call_id DROP NOT NULL;

DROP INDEX IF EXISTS idx_listener_tips_call_venter_unique;

CREATE UNIQUE INDEX IF NOT EXISTS idx_listener_tips_session_venter_unique
  ON listener_tips(session_id, session_type, venter_id);

CREATE INDEX IF NOT EXISTS idx_listener_tips_session_lookup
  ON listener_tips(session_type, session_id);
