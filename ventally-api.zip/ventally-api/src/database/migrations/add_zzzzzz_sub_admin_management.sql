DO $$
BEGIN
  ALTER TABLE users DROP CONSTRAINT IF EXISTS users_user_type_check;
  ALTER TABLE users DROP CONSTRAINT IF EXISTS users_active_role_check;
  ALTER TABLE users DROP CONSTRAINT IF EXISTS active_role_in_available_roles;
EXCEPTION
  WHEN undefined_table THEN
    NULL;
END $$;

DO $$
BEGIN
  -- Normalize existing role data before recreating constraints
  UPDATE users
  SET active_role = CASE LOWER(BTRIM(COALESCE(active_role, user_type, '')))
      WHEN 'venter' THEN 'venter'
      WHEN 'user' THEN 'venter'
      WHEN 'customer' THEN 'venter'
      WHEN 'listener' THEN 'listener'
      WHEN 'provider' THEN 'listener'
      WHEN 'counselor' THEN 'listener'
      WHEN 'admin' THEN 'admin'
      WHEN 'sub_admin' THEN 'sub_admin'
      WHEN 'subadmin' THEN 'sub_admin'
      ELSE 'venter'
    END,
    user_type = CASE LOWER(BTRIM(COALESCE(user_type, active_role, '')))
      WHEN 'venter' THEN 'venter'
      WHEN 'user' THEN 'venter'
      WHEN 'customer' THEN 'venter'
      WHEN 'listener' THEN 'listener'
      WHEN 'provider' THEN 'listener'
      WHEN 'counselor' THEN 'listener'
      WHEN 'admin' THEN 'admin'
      WHEN 'sub_admin' THEN 'sub_admin'
      WHEN 'subadmin' THEN 'sub_admin'
      ELSE 'venter'
    END;

  UPDATE users u
  SET available_roles = COALESCE(
    ARRAY(
      SELECT DISTINCT mapped_role
      FROM (
        SELECT CASE LOWER(BTRIM(COALESCE(raw_role, '')))
          WHEN 'venter' THEN 'venter'
          WHEN 'user' THEN 'venter'
          WHEN 'customer' THEN 'venter'
          WHEN 'listener' THEN 'listener'
          WHEN 'provider' THEN 'listener'
          WHEN 'counselor' THEN 'listener'
          WHEN 'admin' THEN 'admin'
          WHEN 'sub_admin' THEN 'sub_admin'
          WHEN 'subadmin' THEN 'sub_admin'
          ELSE NULL
        END AS mapped_role
        FROM unnest(COALESCE(u.available_roles, ARRAY[]::TEXT[])) AS role_value(raw_role)
      ) mapped
      WHERE mapped_role IS NOT NULL
    ),
    ARRAY[]::TEXT[]
  );

  UPDATE users
  SET available_roles = ARRAY[active_role]
  WHERE available_roles IS NULL OR COALESCE(array_length(available_roles, 1), 0) = 0;

  UPDATE users
  SET available_roles = array_append(available_roles, active_role)
  WHERE NOT (active_role = ANY(available_roles));
END $$;

DO $$
BEGIN
  ALTER TABLE users
    ADD CONSTRAINT users_user_type_check
    CHECK (user_type IN ('venter', 'listener', 'admin', 'sub_admin'));

  ALTER TABLE users
    ADD CONSTRAINT users_active_role_check
    CHECK (active_role IN ('venter', 'listener', 'admin', 'sub_admin'));

  ALTER TABLE users
    ADD CONSTRAINT active_role_in_available_roles
    CHECK (active_role = ANY(available_roles));
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;

CREATE TABLE IF NOT EXISTS sub_admin_permissions (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'suspended')),
  permissions JSONB NOT NULL DEFAULT '{"view": false, "edit": false, "delete": false, "suspend": false, "accessAdminPanel": false}'::jsonb,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sub_admin_permissions_status
  ON sub_admin_permissions(status, created_at DESC);

DROP TRIGGER IF EXISTS update_sub_admin_permissions_updated_at ON sub_admin_permissions;
CREATE TRIGGER update_sub_admin_permissions_updated_at
  BEFORE UPDATE ON sub_admin_permissions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

INSERT INTO sub_admin_permissions (user_id, status, permissions, created_by)
SELECT u.id,
       'active',
       '{"view": true, "edit": true, "delete": true, "suspend": true, "accessAdminPanel": true}'::jsonb,
       NULL
FROM users u
LEFT JOIN sub_admin_permissions p ON p.user_id = u.id
WHERE p.user_id IS NULL
  AND (
    u.user_type = 'sub_admin'
    OR u.active_role = 'sub_admin'
    OR 'sub_admin' = ANY(u.available_roles)
  );
