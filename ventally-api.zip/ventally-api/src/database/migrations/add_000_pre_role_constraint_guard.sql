-- Migration: Pre-role constraint guard for legacy databases
-- Description: Drops role check constraints early and normalizes role fields
-- so subsequent migrations can run safely on production data.

DO $$
BEGIN
  -- If users table doesn't exist yet, nothing to do
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name = 'users'
  ) THEN
    RAISE NOTICE 'Users table not found, skipping pre-role guard migration';
    RETURN;
  END IF;

  -- Drop role constraints early to avoid row-level violations during legacy data updates
  ALTER TABLE users DROP CONSTRAINT IF EXISTS active_role_in_available_roles;
  ALTER TABLE users DROP CONSTRAINT IF EXISTS users_active_role_check;
  ALTER TABLE users DROP CONSTRAINT IF EXISTS users_user_type_check;

  -- Normalize user_type when column exists
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'users'
      AND column_name = 'user_type'
  ) THEN
    UPDATE users
    SET user_type = CASE LOWER(BTRIM(COALESCE(user_type, '')))
      WHEN 'venter' THEN 'venter'
      WHEN 'user' THEN 'venter'
      WHEN 'customer' THEN 'venter'
      WHEN 'listener' THEN 'listener'
      WHEN 'provider' THEN 'listener'
      WHEN 'counselor' THEN 'listener'
      WHEN 'admin' THEN 'admin'
      WHEN 'sub_admin' THEN 'admin'
      WHEN 'subadmin' THEN 'admin'
      ELSE 'venter'
    END;
  END IF;

  -- Normalize active_role and available_roles when both columns exist
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'users'
      AND column_name = 'active_role'
  ) AND EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'users'
      AND column_name = 'available_roles'
  ) THEN
    UPDATE users
    SET active_role = CASE LOWER(BTRIM(COALESCE(active_role, user_type, '')))
      WHEN 'venter' THEN 'venter'
      WHEN 'user' THEN 'venter'
      WHEN 'customer' THEN 'venter'
      WHEN 'listener' THEN 'listener'
      WHEN 'provider' THEN 'listener'
      WHEN 'counselor' THEN 'listener'
      WHEN 'admin' THEN 'admin'
      WHEN 'sub_admin' THEN 'admin'
      WHEN 'subadmin' THEN 'admin'
      ELSE 'venter'
    END;

    UPDATE users u
    SET available_roles = COALESCE(
      ARRAY(
        SELECT DISTINCT mapped_role
        FROM (
          SELECT CASE LOWER(BTRIM(COALESCE(raw_role, '')))
            WHEN 'venter' THEN 'venter'
            WHEN 'user' THEN 'venter'
            WHEN 'customer' THEN 'venter'
            WHEN 'listener' THEN 'listener'
            WHEN 'provider' THEN 'listener'
            WHEN 'counselor' THEN 'listener'
            WHEN 'admin' THEN 'admin'
            WHEN 'sub_admin' THEN 'admin'
            WHEN 'subadmin' THEN 'admin'
            ELSE NULL
          END AS mapped_role
          FROM unnest(COALESCE(u.available_roles, ARRAY[]::TEXT[])) AS role_value(raw_role)
        ) mapped
        WHERE mapped_role IS NOT NULL
      ),
      ARRAY[]::TEXT[]
    );

    UPDATE users
    SET available_roles = ARRAY[active_role]
    WHERE available_roles IS NULL OR COALESCE(array_length(available_roles, 1), 0) = 0;

    UPDATE users
    SET available_roles = array_append(available_roles, active_role)
    WHERE NOT (active_role = ANY(available_roles));
  END IF;

  RAISE NOTICE 'Pre-role guard migration completed';
END $$;
