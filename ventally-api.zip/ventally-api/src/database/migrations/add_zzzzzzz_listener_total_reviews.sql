-- Migration: Add total_reviews to listener_profiles
-- Date: 2026-03-03

ALTER TABLE listener_profiles
ADD COLUMN IF NOT EXISTS total_reviews INTEGER DEFAULT 0;

UPDATE listener_profiles lp
SET total_reviews = COALESCE(review_counts.total_reviews, 0)
FROM (
  SELECT reviewee_id, COUNT(*)::INTEGER AS total_reviews
  FROM session_reviews
  GROUP BY reviewee_id
) review_counts
WHERE lp.listener_id = review_counts.reviewee_id;

UPDATE listener_profiles
SET total_reviews = 0
WHERE total_reviews IS NULL;

ALTER TABLE listener_profiles
ALTER COLUMN total_reviews SET DEFAULT 0;

ALTER TABLE listener_profiles
ALTER COLUMN total_reviews SET NOT NULL;