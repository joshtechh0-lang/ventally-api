-- Add listener tipping support (venter -> listener)

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS listener_tips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id UUID NOT NULL REFERENCES voice_calls(id) ON DELETE CASCADE,
  venter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listener_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount_currency DECIMAL(10,2) NOT NULL CHECK (amount_currency > 0),
  currency VARCHAR(3) NOT NULL DEFAULT 'USD',
  message TEXT,
  payment_source VARCHAR(20) NOT NULL CHECK (payment_source IN ('wallet', 'stripe')),
  stripe_payment_intent_id VARCHAR(255) UNIQUE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  failure_reason TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  CHECK (venter_id != listener_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_listener_tips_call_venter_unique
  ON listener_tips(call_id, venter_id);

CREATE INDEX IF NOT EXISTS idx_listener_tips_listener_created
  ON listener_tips(listener_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_listener_tips_venter_created
  ON listener_tips(venter_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_listener_tips_status_created
  ON listener_tips(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_listener_tips_payment_intent
  ON listener_tips(stripe_payment_intent_id)
  WHERE stripe_payment_intent_id IS NOT NULL;

ALTER TABLE listener_earnings
  DROP CONSTRAINT IF EXISTS listener_earnings_session_type_check;

ALTER TABLE listener_earnings
  ADD CONSTRAINT listener_earnings_session_type_check
  CHECK (session_type IN ('call', 'chat', 'tip'));

CREATE UNIQUE INDEX IF NOT EXISTS idx_listener_earnings_tip_session_unique
  ON listener_earnings(session_id)
  WHERE session_type = 'tip';
