-- Migration: Add AI Admin Settings
-- Description: Seeds configurable AI settings for Admin Settings > AI controls

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'system_settings'
  ) THEN
    INSERT INTO system_settings (key, value, description, created_at, updated_at)
    VALUES
      (
        'ai_enabled',
        'false',
        'Enable or disable AI features platform-wide',
        NOW(),
        NOW()
      ),
      (
        'ai_crisis_detection_enabled',
        'false',
        'Enable AI-assisted crisis signal detection',
        NOW(),
        NOW()
      ),
      (
        'ai_crisis_sensitivity',
        '0.7',
        'AI crisis detection sensitivity threshold from 0.0 to 1.0',
        NOW(),
        NOW()
      ),
      (
        'ai_auto_escalation_enabled',
        'false',
        'Enable automatic escalation when AI detects high-risk content',
        NOW(),
        NOW()
      )
    ON CONFLICT (key) DO NOTHING;
  END IF;
END $$;
