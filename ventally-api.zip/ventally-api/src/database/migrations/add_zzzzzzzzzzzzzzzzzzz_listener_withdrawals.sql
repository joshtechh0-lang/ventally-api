-- Migration: Listener manual withdrawal support
-- Date: 2026-03-15
-- Description: Adds payout request lifecycle fields and indexes for listener withdrawals

ALTER TABLE listener_payouts
  ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(100);

ALTER TABLE listener_payouts
  ADD COLUMN IF NOT EXISTS requested_at TIMESTAMP DEFAULT NOW();

ALTER TABLE listener_payouts
  ADD COLUMN IF NOT EXISTS request_source VARCHAR(30) DEFAULT 'listener_manual';

ALTER TABLE listener_payouts
  ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}'::jsonb;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'listener_payouts_request_source_check'
  ) THEN
    ALTER TABLE listener_payouts
      ADD CONSTRAINT listener_payouts_request_source_check
      CHECK (request_source IN ('listener_manual', 'system_auto', 'admin_manual'));
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_listener_payouts_idempotency_key
  ON listener_payouts(idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_listener_payouts_listener_status_created
  ON listener_payouts(listener_id, status, created_at DESC);
