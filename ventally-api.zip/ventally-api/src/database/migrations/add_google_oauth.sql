-- Migration: Add Google OAuth support
-- Date: 2026-01-28
-- Description: Add google_id column to users table and make password_hash nullable for OAuth users

-- Add google_id column for Google OAuth
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS google_id VARCHAR(255) UNIQUE;

-- Make password_hash nullable to support OAuth-only accounts
ALTER TABLE users 
ALTER COLUMN password_hash DROP NOT NULL;

-- Add comment for documentation
COMMENT ON COLUMN users.google_id IS 'Google OAuth user identifier (sub claim from ID token)';
COMMENT ON COLUMN users.password_hash IS 'Nullable - users can authenticate via OAuth without password';

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_users_google_id ON users(google_id);
