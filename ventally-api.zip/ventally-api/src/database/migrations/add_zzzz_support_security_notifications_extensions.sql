-- Extend notification settings, add 2FA settings, and add support feature tables
-- Created: 2026-02-25

ALTER TABLE user_notification_preferences
ADD COLUMN IF NOT EXISTS activity_status BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS listener_reply_notifications BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS mood_log_notifications BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS reflection_log_notifications BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS wellness_nudges BOOLEAN DEFAULT true;

COMMENT ON COLUMN user_notification_preferences.activity_status IS
  'Whether the user activity status is visible to others';
COMMENT ON COLUMN user_notification_preferences.listener_reply_notifications IS
  'Whether listener reply notifications are enabled';
COMMENT ON COLUMN user_notification_preferences.mood_log_notifications IS
  'Whether mood log notifications are enabled';
COMMENT ON COLUMN user_notification_preferences.reflection_log_notifications IS
  'Whether reflection log notifications are enabled';
COMMENT ON COLUMN user_notification_preferences.wellness_nudges IS
  'Whether wellness reminder nudges are enabled';

ALTER TABLE users
ADD COLUMN IF NOT EXISTS two_factor_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS two_factor_method VARCHAR(30);

ALTER TABLE users
DROP CONSTRAINT IF EXISTS users_two_factor_method_check;

ALTER TABLE users
ADD CONSTRAINT users_two_factor_method_check CHECK (
  two_factor_method IS NULL OR two_factor_method IN ('sms', 'email', 'authenticator_app')
);

COMMENT ON COLUMN users.two_factor_enabled IS
  'Whether two-factor authentication is enabled';
COMMENT ON COLUMN users.two_factor_method IS
  'Single active 2FA method: sms, email, or authenticator_app';

CREATE TABLE IF NOT EXISTS user_appeals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason VARCHAR(120) NOT NULL,
  description TEXT,
  attachments JSONB DEFAULT '[]'::jsonb,
  status VARCHAR(20) NOT NULL DEFAULT 'submitted'
    CHECK (status IN ('submitted', 'under_review', 'resolved', 'rejected')),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_appeals_user_id
  ON user_appeals(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_appeals_status
  ON user_appeals(status, created_at DESC);

DROP TRIGGER IF EXISTS update_user_appeals_updated_at ON user_appeals;
CREATE TRIGGER update_user_appeals_updated_at
  BEFORE UPDATE ON user_appeals
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE user_appeals IS
  'User appeals submitted to platform support';

CREATE TABLE IF NOT EXISTS user_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_feedback_user_id
  ON user_feedback(user_id, created_at DESC);

COMMENT ON TABLE user_feedback IS
  'General platform feedback submitted by users';
