-- Migration: Add Balance Monitoring Settings
-- Description: Adds system settings for real-time balance monitoring during calls
-- Date: 2026-02-09

-- Balance update interval (how often to check and send balance updates)
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
    'balance_update_interval_seconds',
    '60',
    'Interval in seconds for checking and sending balance updates during active calls',
    NOW(),
    NOW()
)
ON CONFLICT (key) DO NOTHING;

-- Warning threshold (when to send low balance warning)
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
    'balance_warning_threshold_minutes',
    '5',
    'Remaining balance threshold in minutes to trigger warning alert',
    NOW(),
    NOW()
)
ON CONFLICT (key) DO NOTHING;

-- Critical threshold (when to send critical balance warning)
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
    'balance_critical_threshold_minutes',
    '2',
    'Remaining balance threshold in minutes to trigger critical alert',
    NOW(),
    NOW()
)
ON CONFLICT (key) DO NOTHING;

-- Auto-disconnect on zero balance
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
    'balance_disconnect_on_zero',
    'true',
    'Automatically disconnect call when balance reaches zero',
    NOW(),
    NOW()
)
ON CONFLICT (key) DO NOTHING;

-- Grace period before disconnection
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
    'balance_disconnect_grace_seconds',
    '10',
    'Grace period in seconds before auto-disconnecting call due to zero balance',
    NOW(),
    NOW()
)
ON CONFLICT (key) DO NOTHING;

-- Add comment
COMMENT ON TABLE system_settings IS 'System-wide configuration settings with Redis caching';
