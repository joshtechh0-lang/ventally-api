-- Discount Integration Hub
-- Centralizes discount rules synced from Stripe, VerifyPass, and referrals

CREATE TABLE IF NOT EXISTS discounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  source VARCHAR(50) NOT NULL DEFAULT 'manual',
  -- source: 'stripe', 'verifypass', 'referral', 'manual'
  discount_type VARCHAR(20) NOT NULL DEFAULT 'percentage',
  -- discount_type: 'percentage', 'fixed'
  discount_value NUMERIC(10,2) NOT NULL,
  -- For percentage: 0-100. For fixed: dollar amount.
  currency VARCHAR(10) DEFAULT 'usd',
  eligibility_type VARCHAR(50) DEFAULT 'all',
  -- eligibility_type: 'all', 'community_verified', 'referral', 'manual'
  community_type VARCHAR(50) DEFAULT NULL,
  -- If eligibility_type = 'community_verified', filter by community_type (or NULL = any)
  stripe_coupon_id VARCHAR(255) UNIQUE DEFAULT NULL,
  stripe_promotion_code_id VARCHAR(255) UNIQUE DEFAULT NULL,
  is_active BOOLEAN DEFAULT true,
  applies_to VARCHAR(50) DEFAULT 'subscription',
  -- applies_to: 'subscription', 'credit_pack', 'both'
  max_uses INTEGER DEFAULT NULL,
  uses_count INTEGER DEFAULT 0,
  valid_from TIMESTAMPTZ DEFAULT NOW(),
  valid_until TIMESTAMPTZ DEFAULT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Track which discounts are applied to which users
CREATE TABLE IF NOT EXISTS user_discounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  discount_id UUID NOT NULL REFERENCES discounts(id) ON DELETE CASCADE,
  stripe_coupon_id VARCHAR(255),
  applied_at TIMESTAMPTZ DEFAULT NOW(),
  applied_to VARCHAR(50) DEFAULT 'subscription',
  -- applied_to: 'subscription', 'credit_pack'
  stripe_session_id VARCHAR(255),
  stripe_subscription_id VARCHAR(255),
  status VARCHAR(20) DEFAULT 'active',
  -- status: 'active', 'used', 'expired', 'cancelled'
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, discount_id, applied_to)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_discounts_source ON discounts(source);
CREATE INDEX IF NOT EXISTS idx_discounts_active ON discounts(is_active);
CREATE INDEX IF NOT EXISTS idx_discounts_stripe_coupon ON discounts(stripe_coupon_id);
CREATE INDEX IF NOT EXISTS idx_user_discounts_user ON user_discounts(user_id);
CREATE INDEX IF NOT EXISTS idx_user_discounts_status ON user_discounts(status);

-- Seed the VerifyPass community discount (20% off subscriptions)
-- stripe_coupon_id will be populated by the discount service on first use
INSERT INTO discounts (
  name, description, source, discount_type, discount_value,
  eligibility_type, applies_to, is_active
) VALUES (
  'Community Member Discount',
  '20% off subscription for verified community members (students, teachers, military, veterans, healthcare workers, and nonprofits)',
  'verifypass',
  'percentage',
  20,
  'community_verified',
  'subscription',
  true
) ON CONFLICT DO NOTHING;

COMMENT ON TABLE discounts IS 'Centralized discount rules synced from Stripe, VerifyPass, and referral system';
COMMENT ON TABLE user_discounts IS 'Tracks discount applications per user per checkout';
