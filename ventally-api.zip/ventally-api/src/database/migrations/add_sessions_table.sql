-- Migration: Add sessions table for call session management
-- Creates sessions table to track active calls between venters and listeners

CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    venter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    listener_id UUID REFERENCES users(id) ON DELETE SET NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'active', 'ended', 'cancelled', 'failed')),
    
    -- Call details
    twilio_call_sid VARCHAR(255) UNIQUE,
    duration_seconds INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    accepted_at TIMESTAMP,
    started_at TIMESTAMP,
    ended_at TIMESTAMP,
    
    -- Pricing
    rate_per_minute DECIMAL(6,4) DEFAULT 0.50,
    estimated_cost DECIMAL(10,4),
    final_cost DECIMAL(10,4),
    
    -- Session metadata
    metadata JSONB DEFAULT '{}'::jsonb,
    
    -- Indexes for performance
    CONSTRAINT sessions_venter_listener_check CHECK (venter_id != listener_id)
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_sessions_venter ON sessions(venter_id, status);
CREATE INDEX IF NOT EXISTS idx_sessions_listener ON sessions(listener_id, status);
CREATE INDEX IF NOT EXISTS idx_sessions_status ON sessions(status);
CREATE INDEX IF NOT EXISTS idx_sessions_twilio_sid ON sessions(twilio_call_sid);
CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON sessions(created_at DESC);

-- Add comment
COMMENT ON TABLE sessions IS 'Tracks active and historical call sessions between venters and listeners';
