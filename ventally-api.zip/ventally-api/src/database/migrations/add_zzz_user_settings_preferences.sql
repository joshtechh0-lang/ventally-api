-- Migration: Add user notification preferences and contact change OTP records
-- Created: 2026-02-20

CREATE TABLE IF NOT EXISTS user_notification_preferences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    all_notifications BOOLEAN DEFAULT true,
    message_notifications BOOLEAN DEFAULT true,
    call_notifications BOOLEAN DEFAULT true,
    reminder_notifications BOOLEAN DEFAULT true,
    sound_vibration BOOLEAN DEFAULT true,
    in_app_alerts BOOLEAN DEFAULT true,
    reminder_time_utc TIME DEFAULT '20:00:00',
    quiet_hours_start_utc TIME,
    quiet_hours_end_utc TIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_user_notification_preferences_user_id
    ON user_notification_preferences(user_id);

DROP TRIGGER IF EXISTS update_user_notification_preferences_updated_at ON user_notification_preferences;
CREATE TRIGGER update_user_notification_preferences_updated_at
    BEFORE UPDATE ON user_notification_preferences
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE user_notification_preferences IS 'Stores notification preferences for each user';
COMMENT ON COLUMN user_notification_preferences.reminder_time_utc IS 'Daily reminder time in UTC (HH:MM:SS)';
COMMENT ON COLUMN user_notification_preferences.quiet_hours_start_utc IS 'Quiet hours start time in UTC';
COMMENT ON COLUMN user_notification_preferences.quiet_hours_end_utc IS 'Quiet hours end time in UTC';

CREATE TABLE IF NOT EXISTS user_contact_change_otps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    purpose VARCHAR(30) NOT NULL CHECK (purpose IN ('email_change', 'phone_change')),
    new_email VARCHAR(255),
    new_phone VARCHAR(20),
    otp VARCHAR(4) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    attempts INTEGER DEFAULT 0,
    verified_at TIMESTAMP,
    used_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT contact_change_target_check CHECK (
        (purpose = 'email_change' AND new_email IS NOT NULL AND new_phone IS NULL)
        OR
        (purpose = 'phone_change' AND new_phone IS NOT NULL AND new_email IS NULL)
    ),
    CONSTRAINT contact_change_otp_format CHECK (otp ~ '^[0-9]{4}$')
);

CREATE INDEX IF NOT EXISTS idx_user_contact_change_otps_user_purpose
    ON user_contact_change_otps(user_id, purpose);

CREATE UNIQUE INDEX IF NOT EXISTS idx_user_contact_change_otps_active
    ON user_contact_change_otps(user_id, purpose)
    WHERE used_at IS NULL;

DROP TRIGGER IF EXISTS update_user_contact_change_otps_updated_at ON user_contact_change_otps;
CREATE TRIGGER update_user_contact_change_otps_updated_at
    BEFORE UPDATE ON user_contact_change_otps
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE user_contact_change_otps IS 'Stores OTP verification attempts for authenticated email/phone changes';