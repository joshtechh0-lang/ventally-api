-- Add biometric authentication support
-- This migration adds fields for Face ID and Fingerprint authentication

-- Add biometric authentication columns to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS biometric_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS biometric_public_key TEXT,
ADD COLUMN IF NOT EXISTS biometric_device_id VARCHAR(255),
ADD COLUMN IF NOT EXISTS biometric_device_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS biometric_registered_at TIMESTAMP;

-- Create index for faster biometric lookups
CREATE INDEX IF NOT EXISTS idx_users_biometric_enabled ON users(biometric_enabled);
CREATE INDEX IF NOT EXISTS idx_users_biometric_device_id ON users(biometric_device_id);

-- Add comment for documentation
COMMENT ON COLUMN users.biometric_enabled IS 'Whether biometric authentication (Face ID/Fingerprint) is enabled for this user';
COMMENT ON COLUMN users.biometric_public_key IS 'Public key used for biometric challenge verification';
COMMENT ON COLUMN users.biometric_device_id IS 'Unique device identifier for biometric authentication';
COMMENT ON COLUMN users.biometric_device_name IS 'Device name/model for tracking';
COMMENT ON COLUMN users.biometric_registered_at IS 'Timestamp when biometric auth was registered';
