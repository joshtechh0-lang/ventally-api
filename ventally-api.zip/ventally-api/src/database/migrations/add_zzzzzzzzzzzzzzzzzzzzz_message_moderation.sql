CREATE TABLE IF NOT EXISTS message_moderation (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id      UUID        NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  conversation_id UUID        NOT NULL,
  sender_id       INTEGER     NOT NULL,
  content         TEXT        NOT NULL,
  level           INTEGER     NOT NULL CHECK (level BETWEEN 1 AND 4),
  tags            TEXT[]      NOT NULL DEFAULT '{}',
  reason          TEXT,
  method          TEXT        NOT NULL CHECK (method IN ('rule-based', 'ai')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS message_moderation_conversation_id_idx ON message_moderation (conversation_id);
CREATE INDEX IF NOT EXISTS message_moderation_level_idx           ON message_moderation (level);
CREATE INDEX IF NOT EXISTS message_moderation_created_at_idx      ON message_moderation (created_at DESC);
