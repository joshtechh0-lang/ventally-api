-- Add listener appeal form fields and uploaded document metadata
-- Created: 2026-02-25

ALTER TABLE user_appeals
ADD COLUMN IF NOT EXISTS contact_info VARCHAR(255),
ADD COLUMN IF NOT EXISTS report_id VARCHAR(120),
ADD COLUMN IF NOT EXISTS summary TEXT,
ADD COLUMN IF NOT EXISTS document_url TEXT,
ADD COLUMN IF NOT EXISTS document_s3_key TEXT,
ADD COLUMN IF NOT EXISTS document_original_file_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS document_mime_type VARCHAR(120),
ADD COLUMN IF NOT EXISTS document_size_bytes INTEGER;

CREATE INDEX IF NOT EXISTS idx_user_appeals_report_id
  ON user_appeals(report_id);
