-- Migration: Add Grace Period Tracking
-- Description: Adds columns to track grace period usage in calls/sessions and rate limiting table
-- Date: 2026-02-09

-- Add grace period tracking columns to voice_calls table
ALTER TABLE voice_calls 
ADD COLUMN IF NOT EXISTS grace_period_seconds INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS grace_period_applied BOOLEAN DEFAULT false;

-- Add grace period tracking columns to sessions table
ALTER TABLE sessions 
ADD COLUMN IF NOT EXISTS grace_period_seconds INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS grace_period_applied BOOLEAN DEFAULT false;

-- Create grace period usage tracking table for rate limiting
CREATE TABLE IF NOT EXISTS grace_period_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_grace_period_at TIMESTAMP NOT NULL DEFAULT NOW(),
    grace_period_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    CONSTRAINT unique_user_grace_period UNIQUE (user_id)
);

-- Create index for faster lookups by user_id
CREATE INDEX IF NOT EXISTS idx_grace_period_usage_user_id ON grace_period_usage(user_id);

-- Add comment to document purpose
COMMENT ON TABLE grace_period_usage IS 'Tracks grace period usage for rate limiting to prevent abuse';
COMMENT ON COLUMN voice_calls.grace_period_seconds IS 'Grace period duration applied to this call in seconds';
COMMENT ON COLUMN voice_calls.grace_period_applied IS 'Whether grace period was applied to billing calculation';
COMMENT ON COLUMN sessions.grace_period_seconds IS 'Grace period duration applied to this session in seconds';
COMMENT ON COLUMN sessions.grace_period_applied IS 'Whether grace period was applied to billing calculation';
