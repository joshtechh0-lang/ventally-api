-- ============================================================================
-- SURGE PRICING FEATURE
-- ============================================================================
-- This migration adds surge pricing support with configurable rules
-- Surge pricing applies ONLY to non-subscribed users

-- ============================================================================
-- SURGE PRICING RULES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS surge_pricing_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  rule_type VARCHAR(20) NOT NULL CHECK (rule_type IN ('time_based', 'day_based', 'demand_based', 'special_event')),
  surge_multiplier DECIMAL(4,2) NOT NULL CHECK (surge_multiplier >= 1.0 AND surge_multiplier <= 10.0),
  priority INTEGER DEFAULT 0, -- Higher priority rules evaluated first
  
  -- Time-based conditions (UTC)
  start_time TIME, -- e.g., '08:00:00' for 8 AM
  end_time TIME,   -- e.g., '22:00:00' for 10 PM
  
  -- Day-based conditions
  days_of_week INTEGER[], -- 0=Sunday, 1=Monday, ..., 6=Saturday
  
  -- Date range conditions
  start_date DATE,
  end_date DATE,
  
  -- Demand-based conditions (future enhancement)
  min_active_calls INTEGER, -- Activate surge when active calls >= this threshold
  
  -- Metadata for special events
  metadata JSONB,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_surge_rules_active ON surge_pricing_rules(is_active, priority DESC);
CREATE INDEX IF NOT EXISTS idx_surge_rules_type ON surge_pricing_rules(rule_type);

-- ============================================================================
-- UPDATE CALL TABLES TO TRACK SURGE PRICING
-- ============================================================================

-- Add surge_multiplier column to voice_calls table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'voice_calls' AND column_name = 'surge_multiplier'
  ) THEN
    ALTER TABLE voice_calls ADD COLUMN surge_multiplier DECIMAL(4,2) DEFAULT 1.0;
  END IF;
END $$;

-- Add surge_rule_id to track which rule was applied
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'voice_calls' AND column_name = 'surge_rule_id'
  ) THEN
    ALTER TABLE voice_calls ADD COLUMN surge_rule_id UUID REFERENCES surge_pricing_rules(id);
  END IF;
END $$;

-- Add surge_multiplier column to sessions table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'surge_multiplier'
  ) THEN
    ALTER TABLE sessions ADD COLUMN surge_multiplier DECIMAL(4,2) DEFAULT 1.0;
  END IF;
END $$;

-- Add surge_rule_id to sessions table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'sessions' AND column_name = 'surge_rule_id'
  ) THEN
    ALTER TABLE sessions ADD COLUMN surge_rule_id UUID REFERENCES surge_pricing_rules(id);
  END IF;
END $$;

-- ============================================================================
-- SYSTEM SETTINGS FOR SURGE PRICING
-- ============================================================================

-- Enable/disable surge pricing globally
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
  'surge_pricing_enabled',
  'true',
  'Enable or disable surge pricing globally',
  NOW(),
  NOW()
)
ON CONFLICT (key) DO UPDATE SET
  description = EXCLUDED.description,
  updated_at = NOW();

-- Default surge multiplier when no rules match
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
  'surge_default_multiplier',
  '1.0',
  'Default surge multiplier when no rules are active (1.0 = no surge)',
  NOW(),
  NOW()
)
ON CONFLICT (key) DO UPDATE SET
  description = EXCLUDED.description,
  updated_at = NOW();

-- Maximum allowed surge multiplier
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
  'surge_max_multiplier',
  '3.0',
  'Maximum surge multiplier allowed (cap for all rules)',
  NOW(),
  NOW()
)
ON CONFLICT (key) DO UPDATE SET
  description = EXCLUDED.description,
  updated_at = NOW();

-- Whether to apply surge to subscribed users (should be false)
INSERT INTO system_settings (key, value, description, created_at, updated_at)
VALUES (
  'surge_apply_to_subscribed',
  'false',
  'Whether surge pricing applies to users with active subscriptions (should be false)',
  NOW(),
  NOW()
)
ON CONFLICT (key) DO UPDATE SET
  description = EXCLUDED.description,
  updated_at = NOW();

-- ============================================================================
-- SEED DEFAULT SURGE PRICING RULES
-- ============================================================================

-- Peak Hours: Weekday Evenings (5 PM - 10 PM)
INSERT INTO surge_pricing_rules (
  name,
  description,
  is_active,
  rule_type,
  surge_multiplier,
  priority,
  start_time,
  end_time,
  days_of_week
) VALUES (
  'Peak Hours - Weekday Evenings',
  'Surge pricing during weekday evening hours (5 PM - 10 PM) when demand is typically highest',
  true,
  'time_based',
  1.5,
  100,
  '17:00:00',
  '22:00:00',
  ARRAY[1, 2, 3, 4, 5] -- Monday through Friday
)
ON CONFLICT DO NOTHING;

-- Weekend Afternoons (12 PM - 6 PM)
INSERT INTO surge_pricing_rules (
  name,
  description,
  is_active,
  rule_type,
  surge_multiplier,
  priority,
  start_time,
  end_time,
  days_of_week
) VALUES (
  'Weekend Afternoons',
  'Moderate surge pricing during weekend afternoons',
  true,
  'time_based',
  1.3,
  90,
  '12:00:00',
  '18:00:00',
  ARRAY[0, 6] -- Sunday and Saturday
)
ON CONFLICT DO NOTHING;

-- Late Night Premium (11 PM - 3 AM)
INSERT INTO surge_pricing_rules (
  name,
  description,
  is_active,
  rule_type,
  surge_multiplier,
  priority,
  start_time,
  end_time
) VALUES (
  'Late Night Premium',
  'Higher surge for late night hours when listener availability is lower',
  true,
  'time_based',
  2.0,
  110,
  '23:00:00',
  '03:00:00'
)
ON CONFLICT DO NOTHING;

-- ============================================================================
-- TRIGGER FOR UPDATED_AT
-- ============================================================================

CREATE OR REPLACE FUNCTION update_surge_rules_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_surge_rules_updated_at ON surge_pricing_rules;
CREATE TRIGGER trigger_surge_rules_updated_at
  BEFORE UPDATE ON surge_pricing_rules
  FOR EACH ROW
  EXECUTE FUNCTION update_surge_rules_updated_at();

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE surge_pricing_rules IS 'Configurable surge pricing rules (applies only to non-subscribed users)';
COMMENT ON COLUMN surge_pricing_rules.surge_multiplier IS 'Price multiplier (e.g., 1.5 = 50% increase, 2.0 = 100% increase)';
COMMENT ON COLUMN surge_pricing_rules.priority IS 'Higher priority rules evaluated first when multiple rules match';
COMMENT ON COLUMN surge_pricing_rules.days_of_week IS 'Array of day numbers: 0=Sunday, 1=Monday, ..., 6=Saturday';
COMMENT ON COLUMN voice_calls.surge_multiplier IS 'Applied surge pricing multiplier (1.0 = no surge)';
COMMENT ON COLUMN voice_calls.surge_rule_id IS 'ID of the surge rule that was applied';
COMMENT ON COLUMN sessions.surge_multiplier IS 'Applied surge pricing multiplier (1.0 = no surge)';
COMMENT ON COLUMN sessions.surge_rule_id IS 'ID of the surge rule that was applied';
