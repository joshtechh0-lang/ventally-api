-- Create billing_snapshots table for tracking per-minute billing during active calls
-- This provides an audit trail and helps with billing accuracy verification

CREATE TABLE IF NOT EXISTS billing_snapshots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    voice_call_id UUID REFERENCES voice_calls(id) ON DELETE CASCADE,
    snapshot_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    elapsed_seconds INTEGER NOT NULL,
    billable_minutes DECIMAL(10,2) NOT NULL DEFAULT 0,
    cost_snapshot DECIMAL(10,2) NOT NULL DEFAULT 0,
    wallet_balance_after DECIMAL(10,2),
    rate_per_minute DECIMAL(10,2),
    surge_multiplier DECIMAL(5,2) DEFAULT 1.0,
    grace_period_active BOOLEAN DEFAULT false,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Prevent duplicate snapshots for same call at same time
    UNIQUE(voice_call_id, snapshot_time)
);

-- Index for efficient queries by call
CREATE INDEX IF NOT EXISTS idx_billing_snapshots_voice_call_id 
    ON billing_snapshots(voice_call_id);

-- Index for time-based queries
CREATE INDEX IF NOT EXISTS idx_billing_snapshots_snapshot_time 
    ON billing_snapshots(snapshot_time DESC);

-- Index for audit queries (find snapshots by call and time range)
CREATE INDEX IF NOT EXISTS idx_billing_snapshots_call_time 
    ON billing_snapshots(voice_call_id, snapshot_time);

COMMIT;
