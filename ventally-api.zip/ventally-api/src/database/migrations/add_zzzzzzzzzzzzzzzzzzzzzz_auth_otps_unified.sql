-- Unified OTP storage supporting multiple simultaneously active OTPs per
-- (user, flow), independent 2-hour expiry per row, and hashed code storage.
--
-- Replaces the per-flow OTP columns on users (verification_otp, reset_otp, ...)
-- and the single-active-OTP constraint on user_contact_change_otps. Legacy
-- columns and the user_contact_change_otps table are retained for one release
-- as a read-only fallback; a follow-up migration will drop them.

CREATE TABLE IF NOT EXISTS auth_otps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    flow VARCHAR(40) NOT NULL CHECK (flow IN (
        'email_verification',
        'password_reset',
        'email_change',
        'phone_change'
    )),
    otp_hash VARCHAR(255) NOT NULL,
    target_email VARCHAR(255),
    target_phone VARCHAR(20),
    attempts INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 5,
    expires_at TIMESTAMP NOT NULL,
    consumed_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT auth_otps_target_consistency CHECK (
        (flow = 'email_change' AND target_email IS NOT NULL AND target_phone IS NULL)
        OR (flow = 'phone_change' AND target_phone IS NOT NULL AND target_email IS NULL)
        OR (flow IN ('email_verification', 'password_reset')
            AND target_email IS NULL AND target_phone IS NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_auth_otps_lookup
    ON auth_otps(user_id, flow, consumed_at, expires_at);

CREATE INDEX IF NOT EXISTS idx_auth_otps_expires_active
    ON auth_otps(expires_at) WHERE consumed_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_auth_otps_target_email
    ON auth_otps(target_email) WHERE target_email IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_auth_otps_target_phone
    ON auth_otps(target_phone) WHERE target_phone IS NOT NULL;

DROP TRIGGER IF EXISTS update_auth_otps_updated_at ON auth_otps;
CREATE TRIGGER update_auth_otps_updated_at
    BEFORE UPDATE ON auth_otps
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE auth_otps IS
    'Unified store for OTPs across auth flows. Multiple unexpired rows may coexist for the same (user_id, flow); verification matches any active row. OTPs hashed with bcrypt.';

-- Allow multiple active contact-change OTPs for the same (user, purpose).
DROP INDEX IF EXISTS idx_user_contact_change_otps_active;
