-- Migration: Durable Agora token reuse across endpoints/instances

CREATE TABLE IF NOT EXISTS voice_call_tokens (
  call_id UUID NOT NULL REFERENCES voice_calls(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  uid BIGINT NOT NULL,
  join_mode VARCHAR(20) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  PRIMARY KEY (call_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_voice_call_tokens_expires_at
ON voice_call_tokens(expires_at);

-- Keep updated_at fresh on upsert-style updates
CREATE OR REPLACE FUNCTION set_voice_call_tokens_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'trg_voice_call_tokens_updated_at'
  ) THEN
    CREATE TRIGGER trg_voice_call_tokens_updated_at
    BEFORE UPDATE ON voice_call_tokens
    FOR EACH ROW
    EXECUTE FUNCTION set_voice_call_tokens_updated_at();
  END IF;
END $$;
