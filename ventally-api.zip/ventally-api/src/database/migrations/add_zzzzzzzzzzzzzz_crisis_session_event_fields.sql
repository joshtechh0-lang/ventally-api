-- ============================================================================
-- Add session-aware crisis event fields for unified chat/call analytics
-- Date: 2026-03-13
-- ============================================================================

ALTER TABLE crisis_events
  ADD COLUMN IF NOT EXISTS session_type VARCHAR(20),
  ADD COLUMN IF NOT EXISTS session_id UUID;

ALTER TABLE crisis_events
  DROP CONSTRAINT IF EXISTS crisis_events_session_type_check;

ALTER TABLE crisis_events
  ADD CONSTRAINT crisis_events_session_type_check
  CHECK (session_type IS NULL OR session_type IN ('call', 'chat'));

-- Backfill historical call crisis events for consistent analytics queries.
UPDATE crisis_events
SET
  session_type = COALESCE(session_type, 'call'),
  session_id = COALESCE(session_id, voice_call_id)
WHERE voice_call_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_crisis_events_session_type_created
  ON crisis_events(session_type, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_crisis_events_session_id
  ON crisis_events(session_id);

CREATE INDEX IF NOT EXISTS idx_crisis_events_action_created
  ON crisis_events(action_taken, created_at DESC);
