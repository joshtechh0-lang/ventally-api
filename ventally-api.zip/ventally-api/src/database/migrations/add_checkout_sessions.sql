-- Add checkout_sessions table to track Stripe checkout sessions
-- This allows us to return session details to users and map webhook events

CREATE TABLE IF NOT EXISTS checkout_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Stripe identifiers
    stripe_session_id VARCHAR(255) UNIQUE NOT NULL,
    stripe_payment_intent_id VARCHAR(255),
    stripe_subscription_id VARCHAR(255),
    
    -- User and context
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    -- Session details
    checkout_url TEXT NOT NULL,
    mode VARCHAR(20) NOT NULL CHECK (mode IN ('payment', 'subscription')),
    status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'expired', 'failed')),
    
    -- Payment details
    amount_total INTEGER, -- Amount in cents
    currency VARCHAR(3) DEFAULT 'usd',
    
    -- Metadata from Stripe
    metadata JSONB,
    
    -- For one-time payments (credits)
    credits_minutes INTEGER,
    pack_type VARCHAR(50),
    
    -- For subscriptions
    plan_id UUID REFERENCES subscription_plans(id),
    
    -- Success/cancel URLs for reference
    success_url TEXT,
    cancel_url TEXT,
    
    -- Webhook processing
    completed_at TIMESTAMP,
    expires_at TIMESTAMP, -- Stripe checkout sessions expire after 24 hours
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_stripe_session_id ON checkout_sessions(stripe_session_id);
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_user_id ON checkout_sessions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_status ON checkout_sessions(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_payment_intent ON checkout_sessions(stripe_payment_intent_id);
CREATE INDEX IF NOT EXISTS idx_checkout_sessions_subscription ON checkout_sessions(stripe_subscription_id);

-- Add updated_at trigger
DROP TRIGGER IF EXISTS update_checkout_sessions_updated_at ON checkout_sessions;
CREATE TRIGGER update_checkout_sessions_updated_at BEFORE UPDATE ON checkout_sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE checkout_sessions IS 'Tracks Stripe checkout sessions for payments and subscriptions';
COMMENT ON COLUMN checkout_sessions.stripe_session_id IS 'Stripe checkout session ID (cs_...)';
COMMENT ON COLUMN checkout_sessions.stripe_payment_intent_id IS 'Associated payment intent ID for one-time payments (pi_...)';
COMMENT ON COLUMN checkout_sessions.stripe_subscription_id IS 'Associated subscription ID for recurring payments (sub_...)';
COMMENT ON COLUMN checkout_sessions.checkout_url IS 'Full Stripe checkout URL for user redirection';
COMMENT ON COLUMN checkout_sessions.status IS 'Current status: pending (created), completed (paid), expired (timeout), failed (payment error)';
COMMENT ON COLUMN checkout_sessions.expires_at IS 'Stripe checkout sessions expire 24 hours after creation';
