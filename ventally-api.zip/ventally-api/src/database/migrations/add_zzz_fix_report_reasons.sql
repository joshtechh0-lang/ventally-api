-- ============================================================================
-- Fix report reasons to match mobile UI specifications
-- Date: 2026-02-10
-- ============================================================================

-- Drop existing constraint
ALTER TABLE user_reports 
  DROP CONSTRAINT IF EXISTS user_reports_reason_check;

-- Add new constraint with correct reasons matching UI
ALTER TABLE user_reports 
  ADD CONSTRAINT user_reports_reason_check 
  CHECK (reason IN (
    'disruptive_behavior',
    'bullying_or_harassment',
    'danger_to_self_or_others',
    'inappropriate_or_unsafe_response'
  ));

-- Update any existing records with old reason values (if any)
UPDATE user_reports SET reason = 'bullying_or_harassment' WHERE reason = 'harassment';
UPDATE user_reports SET reason = 'inappropriate_or_unsafe_response' WHERE reason = 'inappropriate_content';
UPDATE user_reports SET reason = 'inappropriate_or_unsafe_response' WHERE reason = 'spam';
UPDATE user_reports SET reason = 'inappropriate_or_unsafe_response' WHERE reason = 'other';

-- Add comment for documentation
COMMENT ON COLUMN user_reports.reason IS 'Report reason: disruptive_behavior, bullying_or_harassment, danger_to_self_or_others, inappropriate_or_unsafe_response';
