-- Safety guard: ensure VerifyPass columns exist on users table.
-- add_verifypass.sql may have been recorded in schema_migrations before
-- the columns were actually applied on this instance.

ALTER TABLE users
ADD COLUMN IF NOT EXISTS is_community_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS community_type VARCHAR(50) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS community_verified_at TIMESTAMPTZ DEFAULT NULL,
ADD COLUMN IF NOT EXISTS verifypass_token VARCHAR(255) DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_users_community_verified ON users(is_community_verified);
