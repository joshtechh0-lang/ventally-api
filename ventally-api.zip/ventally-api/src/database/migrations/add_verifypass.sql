-- VerifyPass community discount verification
-- Adds community verification status to users table

ALTER TABLE users
ADD COLUMN IF NOT EXISTS is_community_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS community_type VARCHAR(50) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS community_verified_at TIMESTAMPTZ DEFAULT NULL,
ADD COLUMN IF NOT EXISTS verifypass_token VARCHAR(255) DEFAULT NULL;

-- community_type values: 'student_teacher', 'military_veteran', 'healthcare_nonprofit'

COMMENT ON COLUMN users.is_community_verified IS 'True if user has verified community status via VerifyPass';
COMMENT ON COLUMN users.community_type IS 'Type of community verified: student_teacher, military_veteran, healthcare_nonprofit';
COMMENT ON COLUMN users.community_verified_at IS 'Timestamp of VerifyPass verification';
COMMENT ON COLUMN users.verifypass_token IS 'VerifyPass verification token (for reference only, not for auth)';

CREATE INDEX IF NOT EXISTS idx_users_community_verified ON users(is_community_verified);
