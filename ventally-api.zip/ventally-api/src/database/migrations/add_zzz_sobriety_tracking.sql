-- Add sobriety tracking tables for venter progress home summary

CREATE TABLE IF NOT EXISTS sobriety_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    sober_start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    last_relapse_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (last_relapse_date IS NULL OR sober_start_date >= last_relapse_date)
);

CREATE TABLE IF NOT EXISTS sobriety_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_type VARCHAR(20) NOT NULL CHECK (event_type IN ('start', 'relapse', 'adjustment')),
    event_date DATE NOT NULL,
    restart_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (restart_date IS NULL OR restart_date >= event_date)
);

CREATE INDEX IF NOT EXISTS idx_sobriety_profiles_user ON sobriety_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_sobriety_events_user_date ON sobriety_events(user_id, event_date DESC);

DROP TRIGGER IF EXISTS update_sobriety_profiles_updated_at ON sobriety_profiles;
CREATE TRIGGER update_sobriety_profiles_updated_at BEFORE UPDATE ON sobriety_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

COMMENT ON TABLE sobriety_profiles IS 'Current sobriety tracking profile for a venter user.';
COMMENT ON TABLE sobriety_events IS 'Event log for sobriety timeline changes (start, relapse, adjustments).';
COMMENT ON COLUMN sobriety_profiles.sober_start_date IS 'Current sobriety streak start date.';
COMMENT ON COLUMN sobriety_profiles.last_relapse_date IS 'Most recent relapse date, if any.';