BEGIN;

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'referrals' AND column_name = 'referee_id'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'referrals' AND column_name = 'referred_id'
  ) THEN
    ALTER TABLE referrals RENAME COLUMN referee_id TO referred_id;
  END IF;
END $$;

ALTER TABLE referrals ADD COLUMN IF NOT EXISTS referred_id UUID REFERENCES users(id) ON DELETE CASCADE;

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'referrals' AND column_name = 'referrer_reward_minutes'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'referrals' AND column_name = 'reward_value'
  ) THEN
    ALTER TABLE referrals RENAME COLUMN referrer_reward_minutes TO reward_value;
  END IF;
END $$;

ALTER TABLE referrals ADD COLUMN IF NOT EXISTS reward_value INTEGER NOT NULL DEFAULT 5;
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS reward_type VARCHAR(20) NOT NULL DEFAULT 'minutes';

DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'referrals_referee_id_key'
  ) THEN
    ALTER TABLE referrals DROP CONSTRAINT referrals_referee_id_key;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'referrals_referred_id_key'
  ) THEN
    ALTER TABLE referrals ADD CONSTRAINT referrals_referred_id_key UNIQUE (referred_id);
  END IF;
END $$;

DROP INDEX IF EXISTS idx_referrals_referee_id;
CREATE INDEX IF NOT EXISTS idx_referrals_referred_id ON referrals(referred_id);

COMMIT;
