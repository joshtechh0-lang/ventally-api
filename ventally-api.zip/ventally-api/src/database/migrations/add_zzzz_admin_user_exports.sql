-- Migration: Admin user export status tracking
-- Description: Adds table to track export/integration status per non-privileged user in admin panel

CREATE TABLE IF NOT EXISTS admin_user_exports (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  exported BOOLEAN NOT NULL DEFAULT false,
  exported_at TIMESTAMP,
  exported_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_admin_user_exports_exported
  ON admin_user_exports(exported, updated_at DESC);

DROP TRIGGER IF EXISTS update_admin_user_exports_updated_at ON admin_user_exports;
CREATE TRIGGER update_admin_user_exports_updated_at
  BEFORE UPDATE ON admin_user_exports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
