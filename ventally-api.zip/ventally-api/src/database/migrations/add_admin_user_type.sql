-- Migration: Add admin user type
-- Description: Adds 'admin' to the allowed user_type values
-- Date: 2024

-- Normalize existing rows first so re-adding the constraint is safe in legacy DBs.
-- Security-first fallback: unknown/invalid values are downgraded to 'venter'.
UPDATE users
SET user_type = CASE LOWER(BTRIM(COALESCE(user_type, '')))
  WHEN 'venter' THEN 'venter'
  WHEN 'user' THEN 'venter'
  WHEN 'customer' THEN 'venter'
  WHEN 'listener' THEN 'listener'
  WHEN 'provider' THEN 'listener'
  WHEN 'counselor' THEN 'listener'
  WHEN 'admin' THEN 'admin'
  WHEN 'sub_admin' THEN 'admin'
  WHEN 'subadmin' THEN 'admin'
  ELSE 'venter'
END
WHERE user_type IS DISTINCT FROM CASE LOWER(BTRIM(COALESCE(user_type, '')))
  WHEN 'venter' THEN 'venter'
  WHEN 'user' THEN 'venter'
  WHEN 'customer' THEN 'venter'
  WHEN 'listener' THEN 'listener'
  WHEN 'provider' THEN 'listener'
  WHEN 'counselor' THEN 'listener'
  WHEN 'admin' THEN 'admin'
  WHEN 'sub_admin' THEN 'admin'
  WHEN 'subadmin' THEN 'admin'
  ELSE 'venter'
END;

-- Drop existing constraint
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_user_type_check;

-- Add new constraint with admin included
ALTER TABLE users ADD CONSTRAINT users_user_type_check 
  CHECK (user_type IN ('venter', 'listener', 'admin'));

-- Note: Admin users cannot be created via the public signup API
-- They must be created manually via database or through a separate admin creation endpoint
