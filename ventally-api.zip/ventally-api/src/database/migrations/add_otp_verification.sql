-- Migration: Add OTP verification fields
-- Add OTP columns to users table for email verification and password reset

ALTER TABLE users ADD COLUMN IF NOT EXISTS verification_otp VARCHAR(4);
ALTER TABLE users ADD COLUMN IF NOT EXISTS otp_expires_at TIMESTAMP;
ALTER TABLE users ADD COLUMN IF NOT EXISTS otp_attempts INTEGER DEFAULT 0;

-- Password reset OTP fields
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_otp VARCHAR(4);
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_otp_expires_at TIMESTAMP;
ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_otp_attempts INTEGER DEFAULT 0;

-- Create indexes for faster OTP lookups
CREATE INDEX IF NOT EXISTS idx_users_verification_otp ON users(email, verification_otp) WHERE verification_otp IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_reset_otp ON users(email, reset_otp) WHERE reset_otp IS NOT NULL;
