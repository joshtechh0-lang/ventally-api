-- Migration: Add Multi-Role Support
-- Date: 2026-02-11
-- Description: Adds available_roles and active_role columns to support role switching
-- Safe for: Both fresh databases and existing databases (idempotent)

-- ============================================================================
-- Add available_roles column (array of roles user can access)
-- ============================================================================

DO $$ 
BEGIN
  -- Check if column doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'users' 
    AND column_name = 'available_roles'
  ) THEN
    -- Add column without NOT NULL first
    ALTER TABLE users ADD COLUMN available_roles TEXT[];
    
    -- Populate for all existing users (single role based on current user_type)
    UPDATE users SET available_roles = ARRAY[user_type] WHERE available_roles IS NULL;
    
    -- Now set NOT NULL constraint
    ALTER TABLE users ALTER COLUMN available_roles SET NOT NULL;
    
    -- Set default for future inserts
    ALTER TABLE users ALTER COLUMN available_roles SET DEFAULT ARRAY['venter'];
    
    RAISE NOTICE 'Added available_roles column and populated from user_type';
  ELSE
    RAISE NOTICE 'Column available_roles already exists, skipping';
  END IF;
END $$;

-- ============================================================================
-- Add active_role column (currently active role)
-- ============================================================================

DO $$ 
BEGIN
  -- Check if column doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'users' 
    AND column_name = 'active_role'
  ) THEN
    -- Add column without NOT NULL first
    ALTER TABLE users ADD COLUMN active_role VARCHAR(20);
    
    -- Populate for all existing users (match current user_type)
    UPDATE users SET active_role = user_type WHERE active_role IS NULL;
    
    -- Now set NOT NULL constraint
    ALTER TABLE users ALTER COLUMN active_role SET NOT NULL;
    
    -- Set default for future inserts
    ALTER TABLE users ALTER COLUMN active_role SET DEFAULT 'venter';
    
    RAISE NOTICE 'Added active_role column and populated from user_type';
  ELSE
    RAISE NOTICE 'Column active_role already exists, skipping';
  END IF;
END $$;

-- ============================================================================
-- Add CHECK constraint for active_role values
-- ============================================================================

DO $$
BEGIN
  -- Normalize active_role/user_type values before adding constraints
  UPDATE users
  SET active_role = CASE LOWER(BTRIM(COALESCE(active_role, user_type, '')))
      WHEN 'venter' THEN 'venter'
      WHEN 'user' THEN 'venter'
      WHEN 'customer' THEN 'venter'
      WHEN 'listener' THEN 'listener'
      WHEN 'provider' THEN 'listener'
      WHEN 'counselor' THEN 'listener'
      WHEN 'admin' THEN 'admin'
      WHEN 'sub_admin' THEN 'admin'
      WHEN 'subadmin' THEN 'admin'
      ELSE 'venter'
    END,
    user_type = CASE LOWER(BTRIM(COALESCE(active_role, user_type, '')))
      WHEN 'venter' THEN 'venter'
      WHEN 'user' THEN 'venter'
      WHEN 'customer' THEN 'venter'
      WHEN 'listener' THEN 'listener'
      WHEN 'provider' THEN 'listener'
      WHEN 'counselor' THEN 'listener'
      WHEN 'admin' THEN 'admin'
      WHEN 'sub_admin' THEN 'admin'
      WHEN 'subadmin' THEN 'admin'
      ELSE 'venter'
    END;

  -- Sanitize available_roles to only valid values for this migration stage
  UPDATE users u
  SET available_roles = COALESCE(
    ARRAY(
      SELECT DISTINCT mapped_role
      FROM (
        SELECT CASE LOWER(BTRIM(COALESCE(raw_role, '')))
          WHEN 'venter' THEN 'venter'
          WHEN 'user' THEN 'venter'
          WHEN 'customer' THEN 'venter'
          WHEN 'listener' THEN 'listener'
          WHEN 'provider' THEN 'listener'
          WHEN 'counselor' THEN 'listener'
          WHEN 'admin' THEN 'admin'
          WHEN 'sub_admin' THEN 'admin'
          WHEN 'subadmin' THEN 'admin'
          ELSE NULL
        END AS mapped_role
        FROM unnest(COALESCE(u.available_roles, ARRAY[]::TEXT[])) AS role_value(raw_role)
      ) mapped
      WHERE mapped_role IS NOT NULL
    ),
    ARRAY[]::TEXT[]
  );

  -- Ensure non-empty and consistent with active_role
  UPDATE users
  SET available_roles = ARRAY[active_role]
  WHERE available_roles IS NULL OR COALESCE(array_length(available_roles, 1), 0) = 0;

  UPDATE users
  SET available_roles = array_append(available_roles, active_role)
  WHERE NOT (active_role = ANY(available_roles));

  RAISE NOTICE 'Normalized role data before adding active role constraints';
END $$;

DO $$
BEGIN
  -- Drop old constraint if exists (to avoid conflicts)
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'users_active_role_check'
    AND table_name = 'users'
  ) THEN
    ALTER TABLE users DROP CONSTRAINT users_active_role_check;
  END IF;
  
  -- Add CHECK constraint for valid role values
  ALTER TABLE users ADD CONSTRAINT users_active_role_check 
    CHECK (active_role IN ('venter', 'listener', 'admin'));
  
  RAISE NOTICE 'Added active_role CHECK constraint';
END $$;

-- ============================================================================
-- Add CHECK constraint: active_role must be in available_roles
-- ============================================================================

DO $$
BEGIN
  -- Drop old constraint if exists
  IF EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'active_role_in_available_roles'
    AND table_name = 'users'
  ) THEN
    ALTER TABLE users DROP CONSTRAINT active_role_in_available_roles;
  END IF;
  
  -- Add constraint ensuring active_role is in available_roles array
  ALTER TABLE users ADD CONSTRAINT active_role_in_available_roles 
    CHECK (active_role = ANY(available_roles));
  
  RAISE NOTICE 'Added active_role_in_available_roles CHECK constraint';
END $$;

-- ============================================================================
-- Create indexes for performance
-- ============================================================================

-- Index on (id, active_role) for queries filtering by active role
CREATE INDEX IF NOT EXISTS idx_users_active_role ON users(id, active_role);

-- GIN index on available_roles array for querying users with specific roles
CREATE INDEX IF NOT EXISTS idx_users_available_roles ON users USING GIN(available_roles);

-- ============================================================================
-- Sync existing data (ensure consistency)
-- ============================================================================

DO $$
BEGIN
  -- Ensure user_type matches active_role for backward compatibility
  UPDATE users SET user_type = active_role WHERE user_type != active_role;
  
  -- Ensure all users have at least their current role in available_roles
  UPDATE users 
  SET available_roles = array_append(available_roles, user_type)
  WHERE NOT (user_type = ANY(available_roles));
  
  RAISE NOTICE 'Synchronized user_type and active_role for all users';
END $$;

-- ============================================================================
-- Migration complete
-- ============================================================================

DO $$
BEGIN
  RAISE NOTICE '✅ Multi-role support migration completed successfully';
  RAISE NOTICE 'Users can now have multiple roles and switch between them';
END $$;
