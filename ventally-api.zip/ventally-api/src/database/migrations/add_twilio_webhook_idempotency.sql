-- Migration: Add Twilio webhook event tracking for idempotency
-- Purpose: Prevent duplicate processing of Twilio webhook events
-- Created: 2026-02-09

-- Create table to track processed webhook events
CREATE TABLE IF NOT EXISTS twilio_webhook_events (
    id SERIAL PRIMARY KEY,
    event_id VARCHAR(255) UNIQUE NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    call_sid VARCHAR(255),
    conference_sid VARCHAR(255),
    recording_sid VARCHAR(255),
    session_id UUID,
    status VARCHAR(50),
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payload JSONB,
    CONSTRAINT twilio_webhook_events_event_id_unique UNIQUE (event_id)
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_twilio_webhook_events_call_sid 
    ON twilio_webhook_events(call_sid);

CREATE INDEX IF NOT EXISTS idx_twilio_webhook_events_session_id 
    ON twilio_webhook_events(session_id);

CREATE INDEX IF NOT EXISTS idx_twilio_webhook_events_processed_at 
    ON twilio_webhook_events(processed_at DESC);

-- Add comment
COMMENT ON TABLE twilio_webhook_events IS 'Tracks Twilio webhook events to prevent duplicate processing';
COMMENT ON COLUMN twilio_webhook_events.event_id IS 'Composite key: CallSid + EventType + Timestamp for idempotency';
