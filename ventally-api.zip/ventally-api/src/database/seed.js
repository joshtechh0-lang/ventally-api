require("dotenv").config();
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcrypt");

const SALT_ROUNDS = 10;

const pool = new Pool({
  host: process.env.POSTGRES_HOST || "localhost",
  port: process.env.POSTGRES_PORT || 5432,
  database: process.env.POSTGRES_DB || "ventally",
  user: process.env.POSTGRES_USER || "ventally_user",
  password: process.env.POSTGRES_PASSWORD,
  // Connection pool settings for stability
  max: 5,
  min: 1,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  // Query timeout
  query_timeout: 30000,
  statement_timeout: 30000,
  // SSL configuration for RDS (if NODE_ENV is production)
  ssl:
    process.env.NODE_ENV === "production"
      ? { rejectUnauthorized: false }
      : false,
  // Keepalive settings for stable connections
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
});

// Handle pool errors
pool.on("error", (err) => {
  console.error("Unexpected pool error:", err);
});

async function runSeed() {
  const maxRetries = 5;
  const baseDelay = 2000; // 2 seconds

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    let client;
    try {
      console.log(
        `🌱 Starting database seeding (attempt ${attempt}/${maxRetries})...`,
      );

      // Try to connect with timeout
      client = await pool.connect();
      console.log("✓ Database connection established");

      // Verify connection
      const result = await client.query(
        "SELECT NOW() as time, current_database() as db, current_user as user",
      );
      console.log("✓ Connection verified:", {
        time: result.rows[0].time,
        database: result.rows[0].db,
        user: result.rows[0].user,
      });

      // Read and execute seed data
      const seedPath = path.join(__dirname, "init", "02_seed.sql");
      const seed = fs.readFileSync(seedPath, "utf8");

      await client.query("BEGIN");
      console.log("🔄 Executing seed data...");
      await client.query(seed);
      await client.query("COMMIT");

      console.log("✅ Seed data inserted successfully");

      // Create admin user
      const adminEmail =
        process.env.ADMIN_EMAIL || "brittaniabrown011@gmail.com";
      const adminPassword = process.env.ADMIN_PASSWORD || "Admin@123";
      const adminPhone = process.env.ADMIN_PHONE || "+1234567890";

      console.log("\n🔄 Creating admin user...");
      const adminPasswordHash = await bcrypt.hash(adminPassword, SALT_ROUNDS);

      const existingAdmin = await client.query(
        "SELECT id, email FROM users WHERE email = $1",
        [adminEmail],
      );

      if (existingAdmin.rows.length > 0) {
        console.log(`⚠️  Admin user already exists: ${adminEmail}`);
      } else {
        const adminResult = await client.query(
          `INSERT INTO users (email, password_hash, user_type, available_roles, active_role, phone, is_verified, is_active)
           VALUES ($1, $2, 'admin', ARRAY['admin'], 'admin', $3, true, true)
           RETURNING id, email, user_type, active_role`,
          [adminEmail, adminPasswordHash, adminPhone],
        );

        console.log("✅ Admin user created successfully:");
        console.log(`   - Email: ${adminResult.rows[0].email}`);
        console.log(`   - ID: ${adminResult.rows[0].id}`);
        console.log(`   - Role: ${adminResult.rows[0].active_role}`);
      }

      // Show seeded data
      const plans = await client.query(
        "SELECT name, price_monthly FROM subscription_plans ORDER BY price_monthly",
      );
      console.log("\n📋 Subscription Plans:");
      plans.rows.forEach((plan) => {
        console.log(`   - ${plan.name}: $${plan.price_monthly}/month`);
      });

      const promos = await client.query(
        "SELECT code, discount_type, discount_value FROM promo_codes WHERE is_active = true",
      );
      console.log("\n🎟️  Active Promo Codes:");
      promos.rows.forEach((promo) => {
        const value =
          promo.discount_type === "percentage"
            ? `${promo.discount_value}%`
            : `$${promo.discount_value}`;
        console.log(`   - ${promo.code}: ${value} off`);
      });

      return; // Success - exit retry loop
    } catch (error) {
      if (client) {
        try {
          await client.query("ROLLBACK");
        } catch (rollbackError) {
          console.error("⚠ Rollback error:", rollbackError.message);
        }
      }

      console.error(`❌ Seeding attempt ${attempt} failed:`, error.message);
      console.error("Error details:", {
        code: error.code,
        severity: error.severity,
        host: process.env.POSTGRES_HOST,
        port: process.env.POSTGRES_PORT,
        database: process.env.POSTGRES_DB,
        user: process.env.POSTGRES_USER,
      });

      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt - 1); // Exponential backoff
        console.log(`⏳ Retrying in ${delay}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        throw error; // Max retries reached
      }
    } finally {
      if (client) {
        try {
          client.release();
        } catch (releaseError) {
          console.error("⚠ Client release error:", releaseError.message);
        }
      }
    }
  }
}

runSeed()
  .then(() => {
    console.log("\n✅ Seeding completed successfully");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Seeding process failed:", error);
    process.exit(1);
  });
