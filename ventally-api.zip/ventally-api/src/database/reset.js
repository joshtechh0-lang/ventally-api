require("dotenv").config();
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");

const pool = new Pool({
  host: process.env.POSTGRES_HOST || "localhost",
  port: process.env.POSTGRES_PORT || 5432,
  database: process.env.POSTGRES_DB || "ventally",
  user: process.env.POSTGRES_USER || "ventally_user",
  password: process.env.POSTGRES_PASSWORD,
  max: 5,
  min: 1,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  query_timeout: 30000,
  statement_timeout: 30000,
  ssl:
    process.env.NODE_ENV === "production"
      ? { rejectUnauthorized: false }
      : false,
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
});

pool.on("error", (err) => {
  console.error("Unexpected pool error:", err);
});

async function resetDatabase() {
  const maxRetries = 5;
  const baseDelay = 2000;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    let client;
    try {
      console.log(
        `🔄 Resetting database (attempt ${attempt}/${maxRetries})...`,
      );

      client = await pool.connect();
      console.log("✓ Database connection established");

      // Verify connection
      const result = await client.query("SELECT version()");
      console.log(`✓ PostgreSQL version: ${result.rows[0].version}`);

      // Drop all tables (CASCADE will handle dependencies)
      console.log("\n🗑️  Dropping all existing tables...");

      // Get all tables in the public schema
      const existingTablesResult = await client.query(`
        SELECT tablename 
        FROM pg_tables 
        WHERE schemaname = 'public'
      `);

      const existingTables = existingTablesResult.rows.map(
        (row) => row.tablename,
      );

      if (existingTables.length > 0) {
        // Drop all tables at once with CASCADE
        const dropStatement = `DROP TABLE IF EXISTS ${existingTables.join(", ")} CASCADE`;
        await client.query(dropStatement);
        console.log(`✓ Dropped ${existingTables.length} tables`);
      } else {
        console.log("✓ No tables to drop");
      }

      console.log("✓ All tables dropped");

      // Run schema migration (01_schema.sql)
      console.log("\n📋 Creating database schema...");
      const schemaPath = path.join(__dirname, "init", "01_schema.sql");
      const schemaSql = fs.readFileSync(schemaPath, "utf8");

      // Execute the entire schema as one statement
      // PostgreSQL can handle multiple statements in a single query
      await client.query(schemaSql);
      console.log("✓ Schema created successfully");

      // Run seed data (02_seed.sql)
      console.log("\n🌱 Seeding database with initial data...");
      try {
        const seedPath = path.join(__dirname, "init", "02_seed.sql");
        const seedSql = fs.readFileSync(seedPath, "utf8");

        // Execute the entire seed as one statement
        await client.query(seedSql);
        console.log("✓ Database seeded successfully");
      } catch (seedError) {
        console.warn("⚠️  Skipping seed: ", seedError.message);
        console.log("✓ Schema created (seeding skipped)");
      }

      // Verify tables were created
      const tables = await client.query(`
        SELECT tablename 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        ORDER BY tablename;
      `);

      console.log(
        `\n✅ Database reset complete! Created ${tables.rows.length} tables:`,
      );
      tables.rows.forEach((row) => {
        console.log(`   - ${row.tablename}`);
      });

      client.release();
      await pool.end();
      process.exit(0);
    } catch (err) {
      console.error(`❌ Error on attempt ${attempt}:`, err.message);
      console.error("Full error:", err);

      if (client) {
        client.release();
      }

      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt - 1);
        console.log(`⏳ Retrying in ${delay / 1000} seconds...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        console.error("❌ Failed to reset database after all retries");
        await pool.end();
        process.exit(1);
      }
    }
  }
}

// Run if called directly
if (require.main === module) {
  resetDatabase().catch((err) => {
    console.error("Fatal error:", err);
    process.exit(1);
  });
}

module.exports = { resetDatabase };
