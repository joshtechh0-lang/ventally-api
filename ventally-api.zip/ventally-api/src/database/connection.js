const { Pool } = require("pg");
const logger = require("../utils/logger");

const pool = new Pool({
  host: process.env.POSTGRES_HOST || "localhost",
  port: process.env.POSTGRES_PORT || 5432,
  database: process.env.POSTGRES_DB || "ventally",
  user: process.env.POSTGRES_USER || "ventally_user",
  password: process.env.POSTGRES_PASSWORD,
  // Connection pool settings for stability
  max: 20,
  min: 2, // Keep minimum connections alive
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000, // Increased from 2s to 10s
  // Query timeouts
  query_timeout: 30000, // 30 seconds
  statement_timeout: 30000,
  // SSL configuration
  ssl:
    process.env.NODE_ENV === "production"
      ? { rejectUnauthorized: false }
      : false,
  // Keepalive settings for stable EC2 connections
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
});

// Handle pool errors to prevent crashes
pool.on("error", (err, client) => {
  logger.error("Unexpected pool error on idle client", {
    error: err.message,
    stack: err.stack,
  });
  // Don't exit process, just log the error
});

// Graceful shutdown handler
process.on("SIGINT", async () => {
  logger.info("Gracefully shutting down database pool...");
  await pool.end();
  logger.info("Database pool closed");
  process.exit(0);
});

process.on("SIGTERM", async () => {
  logger.info("Gracefully shutting down database pool...");
  await pool.end();
  logger.info("Database pool closed");
  process.exit(0);
});

async function connectDatabase(maxRetries = 5) {
  const baseDelay = 2000; // 2 seconds

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    let client;
    try {
      logger.database(
        `Connecting to database (attempt ${attempt}/${maxRetries})...`,
      );
      client = await pool.connect();

      const result = await client.query(
        "SELECT NOW() as time, version() as version, current_database() as db",
      );

      logger.database("Database connected successfully", {
        time: result.rows[0].time,
        database: result.rows[0].db,
        host: process.env.POSTGRES_HOST || "localhost",
        port: process.env.POSTGRES_PORT || 5432,
      });

      client.release();
      return pool;
    } catch (error) {
      if (client) {
        try {
          client.release();
        } catch (releaseError) {
          logger.warn("Client release error", { error: releaseError.message });
        }
      }

      logger.error(`Database connection attempt ${attempt} failed`, {
        error: error.message,
        code: error.code,
        severity: error.severity,
        detail: error.detail,
        host: process.env.POSTGRES_HOST || "localhost",
        port: process.env.POSTGRES_PORT || 5432,
        database: process.env.POSTGRES_DB || "ventally",
        user: process.env.POSTGRES_USER || "ventally_user",
        ssl: process.env.NODE_ENV === "production" ? "enabled" : "disabled",
      });

      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt - 1); // Exponential backoff
        logger.database(`Retrying connection in ${delay}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        throw error; // Max retries reached
      }
    }
  }
}

module.exports = {
  pool,
  connectDatabase,
};
