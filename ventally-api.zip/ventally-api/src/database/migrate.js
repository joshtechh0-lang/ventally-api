require("dotenv").config();
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");

const pool = new Pool({
  host: process.env.POSTGRES_HOST || "localhost",
  port: process.env.POSTGRES_PORT || 5432,
  database: process.env.POSTGRES_DB || "ventally",
  user: process.env.POSTGRES_USER || "ventally_user",
  password: process.env.POSTGRES_PASSWORD,
  max: 5,
  min: 1,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  query_timeout: 30000,
  statement_timeout: 30000,
  ssl:
    process.env.NODE_ENV === "production"
      ? { rejectUnauthorized: false }
      : false,
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
});

pool.on("error", (err) => {
  console.error("Unexpected pool error:", err);
});

async function runMigrations() {
  const maxRetries = 5;
  const baseDelay = 2000;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    let client;
    try {
      console.log(`🔄 Starting database migrations (attempt ${attempt}/${maxRetries})...`);
      client = await pool.connect();
      console.log("✓ Database connection established");

      const result = await client.query(
        "SELECT NOW() as time, current_database() as db, current_user as user",
      );
      console.log("✓ Connection verified:", {
        time: result.rows[0].time,
        database: result.rows[0].db,
        user: result.rows[0].user,
      });

      await client.query(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
          filename TEXT PRIMARY KEY,
          applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
      `);
      console.log("✓ schema_migrations tracking table ready");

      const checkTable = await client.query(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables
          WHERE table_schema = 'public'
          AND table_name = 'users'
        ) as table_exists;
      `);

      const isExistingDb = checkTable.rows[0].table_exists;

      if (!isExistingDb) {
        console.log("🆕 Fresh database detected - initializing schema...");
        const schemaPath = path.join(__dirname, "init", "01_schema.sql");
        const schema = fs.readFileSync(schemaPath, "utf8");
        await client.query("BEGIN");
        await client.query(schema);
        await client.query("COMMIT");
        console.log("✅ Schema migration completed successfully");
      } else {
        console.log("📋 Existing database detected - running incremental migrations only");
      }

      const migrationsDir = path.join(__dirname, "migrations");

      if (fs.existsSync(migrationsDir)) {
        const migrationFiles = fs
          .readdirSync(migrationsDir)
          .filter((file) => file.endsWith(".sql"))
          .sort();

        const appliedResult = await client.query("SELECT filename FROM schema_migrations");
        const applied = new Set(appliedResult.rows.map((r) => r.filename));

        const pending = migrationFiles.filter((f) => !applied.has(f));
        console.log(`🔄 ${pending.length} pending migration(s) out of ${migrationFiles.length} total...`);

        for (const file of pending) {
          const migrationPath = path.join(migrationsDir, file);
          const migration = fs.readFileSync(migrationPath, "utf8");
          console.log(`  ↳ Running migration: ${file}`);
          await client.query("BEGIN");
          try {
            await client.query(migration);
            await client.query("INSERT INTO schema_migrations (filename) VALUES ($1)", [file]);
            await client.query("COMMIT");
            console.log(`  ✓ Completed: ${file}`);
          } catch (migErr) {
            await client.query("ROLLBACK");
            console.error(`  ❌ Failed: ${file} — ${migErr.message}`);
            throw migErr;
          }
        }

        console.log("✅ All pending migrations completed successfully");
      }

      return;
    } catch (error) {
      console.error(`❌ Migration attempt ${attempt} failed:`, error.message);
      console.error("Error details:", {
        code: error.code,
        severity: error.severity,
        host: process.env.POSTGRES_HOST,
        port: process.env.POSTGRES_PORT,
        database: process.env.POSTGRES_DB,
        user: process.env.POSTGRES_USER,
      });

      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt - 1);
        console.log(`⏳ Retrying in ${delay}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        throw error;
      }
    } finally {
      if (client) {
        try { client.release(); } catch (e) { console.error("⚠ Client release error:", e.message); }
      }
    }
  }
}

runMigrations()
  .then(() => { console.log("✅ All migrations completed"); process.exit(0); })
  .catch((error) => { console.error("❌ Migration process failed:", error); process.exit(1); });
