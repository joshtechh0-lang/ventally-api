const { pool } = require("../database/connection");
const { redisClient } = require("./redis");
const logger = require("../utils/logger");

const REDIS_SETTINGS_PREFIX = "settings:";
const SETTINGS_TTL = 3600; // 1 hour

/**
 * Get a system setting by key
 * @param {string} key - Setting key
 * @param {any} defaultValue - Default value if not found
 * @returns {Promise<any>} Setting value
 */
async function getSetting(key, defaultValue = null) {
  try {
    // Try cache first
    const cacheKey = `${REDIS_SETTINGS_PREFIX}${key}`;
    const cached = await redisClient.get(cacheKey);

    if (cached !== null) {
      return parseSettingValue(cached);
    }

    // Query database
    const result = await pool.query(
      "SELECT value FROM system_settings WHERE key = $1",
      [key],
    );

    if (result.rows.length === 0) {
      return defaultValue;
    }

    const value = result.rows[0].value;

    // Cache for future requests
    await redisClient.setEx(cacheKey, SETTINGS_TTL, value);

    return parseSettingValue(value);
  } catch (error) {
    logger.error(`Error getting setting ${key}: ${error.message}`);
    return defaultValue;
  }
}

/**
 * Set a system setting
 * @param {string} key - Setting key
 * @param {any} value - Setting value
 * @param {string} description - Setting description
 * @returns {Promise<boolean>} Success status
 */
async function setSetting(key, value, description = null) {
  try {
    const stringValue = String(value);

    await pool.query(
      `INSERT INTO system_settings (key, value, description)
       VALUES ($1, $2, $3)
       ON CONFLICT (key) 
       DO UPDATE SET value = EXCLUDED.value, 
                     description = COALESCE(EXCLUDED.description, system_settings.description),
                     updated_at = NOW()`,
      [key, stringValue, description],
    );

    // Invalidate cache
    const cacheKey = `${REDIS_SETTINGS_PREFIX}${key}`;
    await redisClient.del(cacheKey);

    logger.info(`Updated setting ${key} = ${stringValue}`);
    return true;
  } catch (error) {
    logger.error(`Error setting ${key}: ${error.message}`);
    return false;
  }
}

/**
 * Get all system settings
 * @returns {Promise<Object>} Key-value pairs of all settings
 */
async function getAllSettings() {
  try {
    const result = await pool.query(
      "SELECT key, value, description FROM system_settings ORDER BY key",
    );

    const settings = {};
    for (const row of result.rows) {
      settings[row.key] = {
        value: parseSettingValue(row.value),
        description: row.description,
      };
    }

    return settings;
  } catch (error) {
    logger.error(`Error getting all settings: ${error.message}`);
    return {};
  }
}

/**
 * Initialize default settings if they don't exist
 */
async function initializeDefaults() {
  const defaults = {
    platform_fee_percentage: {
      value: "0.20",
      description: "Platform fee as decimal (0.20 = 20%, listener gets 80%)",
    },
    listener_default_rate: {
      value: "0.50",
      description: "Default listener rate per minute in USD",
    },
    min_payout_threshold: {
      value: "50.00",
      description: "Minimum balance required for payout in USD",
    },
    payout_schedule: {
      value: "weekly",
      description: "Payout schedule: weekly, biweekly, monthly",
    },
    call_max_duration_minutes: {
      value: "120",
      description: "Maximum call duration in minutes",
    },
    chat_idle_timeout_minutes: {
      value: "30",
      description: "Auto-end chat after idle period",
    },
    session_idle_timeout_minutes: {
      value: "30",
      description: "Auto-end active sessions after idle period",
    },
    min_call_balance_minutes: {
      value: "5",
      description: "Minimum wallet balance to start call",
    },
  };

  try {
    for (const [key, config] of Object.entries(defaults)) {
      const exists = await pool.query(
        "SELECT 1 FROM system_settings WHERE key = $1",
        [key],
      );

      if (exists.rows.length === 0) {
        await setSetting(key, config.value, config.description);
        logger.info(`Initialized default setting: ${key}`);
      }
    }

    logger.info("System settings initialization complete");
  } catch (error) {
    logger.error(`Error initializing default settings: ${error.message}`);
  }
}

/**
 * Parse setting value to appropriate type
 * @param {string} value - String value from database
 * @returns {any} Parsed value
 */
function parseSettingValue(value) {
  // Try to parse as number
  if (!isNaN(value) && value.trim() !== "") {
    return parseFloat(value);
  }

  // Try to parse as boolean
  if (value.toLowerCase() === "true") return true;
  if (value.toLowerCase() === "false") return false;

  // Return as string
  return value;
}

/**
 * Clear all settings cache
 */
async function clearSettingsCache() {
  try {
    const pattern = `${REDIS_SETTINGS_PREFIX}*`;
    const keys = await redisClient.keys(pattern);

    if (keys.length > 0) {
      await redisClient.del(keys);
      logger.info(`Cleared ${keys.length} settings cache entries`);
    }
  } catch (error) {
    logger.error(`Error clearing settings cache: ${error.message}`);
  }
}

module.exports = {
  getSetting,
  setSetting,
  getAllSettings,
  initializeDefaults,
  clearSettingsCache,
};
