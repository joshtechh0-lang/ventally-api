const { pool } = require("../database/connection");
const { redisClient } = require("./redis");
const { emitListenerStatusUpdate } = require("./realtimeEvents");
const logger = require("../utils/logger");

const LISTENERS_ONLINE_KEY = "listeners:online";
const LISTENER_SESSION_PREFIX = "listener:session:";
const PRESENCE_TTL = 90; // 90 seconds for heartbeat

/**
 * Get listener's active session from database
 * @param {string} listenerId - Listener user ID
 * @returns {Promise<{sessionId: string, sessionType: string} | null>}
 */
async function getActiveListenerSession(listenerId) {
  try {
    const callResult = await pool.query(
      `SELECT id
       FROM voice_calls
       WHERE listener_id = $1
         AND status IN ('ringing', 'active')
       ORDER BY created_at DESC
       LIMIT 1`,
      [listenerId],
    );

    if (callResult.rows.length > 0) {
      return {
        sessionId: callResult.rows[0].id,
        sessionType: "call",
      };
    }

    const chatResult = await pool.query(
      `SELECT id
       FROM conversations
       WHERE listener_id = $1
         AND status = 'active'
       ORDER BY created_at DESC
       LIMIT 1`,
      [listenerId],
    );

    if (chatResult.rows.length > 0) {
      return {
        sessionId: chatResult.rows[0].id,
        sessionType: "chat",
      };
    }

    return null;
  } catch (error) {
    logger.error(`Error checking active listener session: ${error.message}`);
    return null;
  }
}

/**
 * Mark listener as online
 * @param {string} listenerId - Listener user ID
 */
async function setListenerOnline(listenerId) {
  try {
    const timestamp = Date.now();

    // Add to Redis sorted set with timestamp as score
    await redisClient.zAdd(LISTENERS_ONLINE_KEY, {
      score: timestamp,
      value: listenerId,
    });

    // Update database
    await pool.query(
      `UPDATE listener_profiles 
       SET is_online = true, last_online_at = NOW()
       WHERE listener_id = $1`,
      [listenerId],
    );

    emitListenerStatusUpdate({
      listenerId,
      isOnline: true,
      isBusy: false,
      status: "online",
    });

    logger.info(`Listener ${listenerId} is now online`);
  } catch (error) {
    logger.error(`Error setting listener online: ${error.message}`);
    throw error;
  }
}

/**
 * Mark listener as offline
 * @param {string} listenerId - Listener user ID
 */
async function setListenerOffline(
  listenerId,
  options = { preserveBusyIfActiveSession: false },
) {
  try {
    const preserveBusyIfActiveSession =
      options?.preserveBusyIfActiveSession === true;

    const activeSession = preserveBusyIfActiveSession
      ? await getActiveListenerSession(listenerId)
      : null;

    // Remove from Redis sorted set
    await redisClient.zRem(LISTENERS_ONLINE_KEY, listenerId);

    if (activeSession) {
      // Keep busy marker while session is still active to avoid double-assignment.
      await redisClient.setEx(
        `${LISTENER_SESSION_PREFIX}${listenerId}`,
        3600,
        activeSession.sessionId,
      );

      await pool.query(
        `UPDATE listener_profiles
         SET is_online = false, is_busy = true
         WHERE listener_id = $1`,
        [listenerId],
      );

      emitListenerStatusUpdate({
        listenerId,
        isOnline: false,
        isBusy: true,
        status: "offline",
        sessionId: activeSession.sessionId,
      });

      logger.info(
        `Listener ${listenerId} went offline while active in ${activeSession.sessionType} ${activeSession.sessionId}`,
      );

      return { preservedBusy: true, activeSession };
    }

    // Clear busy session if any
    await redisClient.del(`${LISTENER_SESSION_PREFIX}${listenerId}`);

    // Update database
    await pool.query(
      `UPDATE listener_profiles 
       SET is_online = false, is_busy = false
       WHERE listener_id = $1`,
      [listenerId],
    );

    emitListenerStatusUpdate({
      listenerId,
      isOnline: false,
      isBusy: false,
      status: "offline",
    });

    logger.info(`Listener ${listenerId} is now offline`);

    return { preservedBusy: false, activeSession: null };
  } catch (error) {
    logger.error(`Error setting listener offline: ${error.message}`);

    return { preservedBusy: false, activeSession: null };
  }
}

/**
 * Restore listener online presence in Redis and emit status.
 * @param {string} listenerId - Listener user ID
 * @param {{ forceOnline?: boolean }} options
 * @returns {Promise<{restored: boolean, isBusy?: boolean, sessionId?: string}>}
 */
async function restoreListenerPresence(listenerId, options = {}) {
  try {
    const forceOnline = options?.forceOnline === true;
    const profileResult = await pool.query(
      `SELECT is_online, is_busy
       FROM listener_profiles
       WHERE listener_id = $1`,
      [listenerId],
    );

    if (profileResult.rows.length === 0) {
      return { restored: false };
    }

    const profile = profileResult.rows[0];
    const shouldRestore = forceOnline || profile.is_online;

    if (!shouldRestore) {
      return { restored: false };
    }

    if (forceOnline && !profile.is_online) {
      await pool.query(
        `UPDATE listener_profiles
         SET is_online = true, last_online_at = NOW()
         WHERE listener_id = $1`,
        [listenerId],
      );
    }

    await redisClient.zAdd(LISTENERS_ONLINE_KEY, {
      score: Date.now(),
      value: listenerId,
    });

    let sessionId;
    if (profile.is_busy) {
      const activeSession = await getActiveListenerSession(listenerId);
      if (activeSession) {
        sessionId = activeSession.sessionId;
        await redisClient.setEx(
          `${LISTENER_SESSION_PREFIX}${listenerId}`,
          3600,
          sessionId,
        );
      }
    }

    emitListenerStatusUpdate({
      listenerId,
      isOnline: true,
      isBusy: profile.is_busy,
      status: profile.is_busy ? "busy" : "online",
      sessionId,
    });

    logger.info(
      `Listener ${listenerId} presence restored (busy=${profile.is_busy})`,
    );

    return { restored: true, isBusy: profile.is_busy, sessionId };
  } catch (error) {
    logger.error(`Error restoring listener presence: ${error.message}`);
    return { restored: false };
  }
}

/**
 * Mark listener as busy (in a session)
 * @param {string} listenerId - Listener user ID
 * @param {string} sessionId - Session ID
 */
async function setListenerBusy(listenerId, sessionId) {
  try {
    // Store session ID in Redis
    await redisClient.setEx(
      `${LISTENER_SESSION_PREFIX}${listenerId}`,
      3600, // 1 hour TTL
      sessionId,
    );

    // Update database
    await pool.query(
      `UPDATE listener_profiles 
       SET is_busy = true
       WHERE listener_id = $1`,
      [listenerId],
    );

    emitListenerStatusUpdate({
      listenerId,
      isOnline: true,
      isBusy: true,
      status: "busy",
      sessionId,
    });

    logger.info(`Listener ${listenerId} is now busy with session ${sessionId}`);
  } catch (error) {
    logger.error(`Error setting listener busy: ${error.message}`);
    throw error;
  }
}

/**
 * Clear listener busy status
 * @param {string} listenerId - Listener user ID
 */
async function clearListenerBusy(listenerId) {
  let redisCleared = false;
  let dbCleared = false;

  try {
    // Best-effort Redis cleanup; do not block DB cleanup on Redis issues.
    await redisClient.del(`${LISTENER_SESSION_PREFIX}${listenerId}`);
    redisCleared = true;
  } catch (error) {
    logger.error(
      `Error clearing listener busy session key in Redis: ${error.message}`,
    );
  }

  try {
    await pool.query(
      `UPDATE listener_profiles 
       SET is_busy = false
       WHERE listener_id = $1`,
      [listenerId],
    );
    dbCleared = true;
  } catch (error) {
    logger.error(`Error clearing listener busy state in DB: ${error.message}`);
  }

  if (dbCleared) {
    emitListenerStatusUpdate({
      listenerId,
      isOnline: true,
      isBusy: false,
      status: "available",
    });

    logger.info(`Listener ${listenerId} is no longer busy`);
  }

  if (!redisCleared && !dbCleared) {
    logger.error(
      `Failed to clear busy state for listener ${listenerId} in both Redis and DB`,
    );
  }
}

/**
 * Mark listener as disconnected (socket dropped).
 *
 * Removes only the ephemeral Redis presence so a disconnected listener is no
 * longer routed new requests, while preserving the listener's persisted
 * availability preference (`listener_profiles.is_online`) and any active
 * busy/session marker. The toggle the listener sees (driven by `is_online`)
 * must change only on an explicit go-offline or admin suspend, never on a
 * transient socket disconnect such as the post-session navigation reconnect.
 *
 * Presence is restored on the next connect via {@link restoreListenerPresence}.
 *
 * @param {string} listenerId - Listener user ID
 */
async function markListenerDisconnected(listenerId) {
  try {
    // Drop ephemeral presence; do NOT touch is_online or the session key.
    await redisClient.zRem(LISTENERS_ONLINE_KEY, listenerId);

    // Venter-facing presence broadcast only: the discovery bridge recomputes
    // each subscriber's available-listener list from getAvailableListeners
    // (authoritative) and emits listener:status to the subscriber room — it
    // never reaches the listener's own toggle, which reads persisted is_online.
    const activeSession = await getActiveListenerSession(listenerId);

    emitListenerStatusUpdate({
      listenerId,
      isOnline: false,
      isBusy: !!activeSession,
      status: "offline",
      ...(activeSession ? { sessionId: activeSession.sessionId } : {}),
    });

    logger.info(`Listener ${listenerId} disconnected (presence dropped)`);
  } catch (error) {
    logger.error(`Error marking listener disconnected: ${error.message}`);
  }
}

/**
 * Update listener heartbeat timestamp
 * @param {string} listenerId - Listener user ID
 */
async function heartbeat(listenerId) {
  try {
    const timestamp = Date.now();

    // Update score in sorted set
    await redisClient.zAdd(LISTENERS_ONLINE_KEY, {
      score: timestamp,
      value: listenerId,
    });

    return { success: true, timestamp };
  } catch (error) {
    logger.error(`Error updating heartbeat: ${error.message}`);
    throw error;
  }
}

/**
 * Get available listeners (online, not busy, not blocked)
 * @param {string} venterId - Venter user ID (to check blocks)
 * @returns {Promise<Array>} Array of available listener profiles
 */
async function getAvailableListeners(venterId) {
  try {
    const result = await pool.query(
      `SELECT
         lp.listener_id,
         lp.rate_per_minute,
         lp.total_sessions,
         lp.average_rating,
         lp.bio_anonymous,
         lp.specialties,
         lp.is_busy
       FROM listener_profiles lp
       INNER JOIN users u ON u.id = lp.listener_id
       WHERE lp.is_online = true
         AND lp.is_busy = false
         AND lp.listener_id != $1
         AND u.is_active = true
         AND u.is_verified = true
         AND NOT EXISTS (
           SELECT 1 FROM blocked_users
           WHERE (blocker_id = $1 AND blocked_id = lp.listener_id)
              OR (blocker_id = lp.listener_id AND blocked_id = $1)
         )
       ORDER BY lp.average_rating DESC, lp.total_sessions DESC`,
      [venterId],
    );
    return result.rows.map((row) => ({
      listenerId: row.listener_id,
      ratePerMinute: parseFloat(row.rate_per_minute),
      totalSessions: row.total_sessions,
      averageRating: parseFloat(row.average_rating),
      bioAnonymous: row.bio_anonymous,
      specialties: row.specialties || [],
    }));
  } catch (error) {
    logger.error(`Error getting available listeners: ${error.message}`);
    return [];
  }
}

/**
 * Check if a specific listener is available
 * @param {string} listenerId - Listener user ID
 * @returns {Promise<boolean>} Whether listener is available
 */
async function isListenerAvailable(listenerId) {
  try {
    // Check Redis first (faster)
    const score = await redisClient.zScore(LISTENERS_ONLINE_KEY, listenerId);

    if (!score) {
      return false;
    }

    // Check if not stale
    const now = Date.now();
    const staleThreshold = now - PRESENCE_TTL * 1000;

    if (score < staleThreshold) {
      return false;
    }

    // Check if busy
    const busySession = await redisClient.get(
      `${LISTENER_SESSION_PREFIX}${listenerId}`,
    );

    if (busySession) {
      // Self-heal stale busy keys when there is no active session in DB.
      const activeSession = await getActiveListenerSession(listenerId);
      if (activeSession) {
        return false;
      }

      await redisClient.del(`${LISTENER_SESSION_PREFIX}${listenerId}`);
      await pool.query(
        `UPDATE listener_profiles
         SET is_busy = false
         WHERE listener_id = $1`,
        [listenerId],
      );

      logger.warn(
        `Cleared stale busy session marker for listener ${listenerId}: ${busySession}`,
      );
    }

    // Double-check database
    const result = await pool.query(
      `SELECT lp.is_online, lp.is_busy
       FROM listener_profiles lp
       INNER JOIN users u ON u.id = lp.listener_id
       WHERE lp.listener_id = $1
         AND u.is_active = true
         AND u.is_verified = true`,
      [listenerId],
    );

    if (result.rows.length === 0) {
      return false;
    }

    return result.rows[0].is_online && !result.rows[0].is_busy;
  } catch (error) {
    logger.error(`Error checking listener availability: ${error.message}`);
    return false;
  }
}

/**
 * Get listener's current session ID if busy
 * @param {string} listenerId - Listener user ID
 * @returns {Promise<string|null>} Session ID or null
 */
async function getListenerCurrentSession(listenerId) {
  try {
    const sessionId = await redisClient.get(
      `${LISTENER_SESSION_PREFIX}${listenerId}`,
    );
    return sessionId;
  } catch (error) {
    logger.error(`Error getting listener current session: ${error.message}`);
    return null;
  }
}

/**
 * Clean up stale online listeners
 */
async function cleanupStaleListeners() {
  try {
    const now = Date.now();
    const staleThreshold = now - PRESENCE_TTL * 1000;

    // Remove stale entries from Redis
    const removed = await redisClient.zRemRangeByScore(
      LISTENERS_ONLINE_KEY,
      0,
      staleThreshold,
    );

    if (removed > 0) {
      logger.info(`Cleaned up ${removed} stale listener presence entries`);
    }
  } catch (error) {
    logger.error(`Error cleaning up stale listeners: ${error.message}`);
  }
}

module.exports = {
  getActiveListenerSession,
  setListenerOnline,
  setListenerOffline,
  restoreListenerPresence,
  setListenerBusy,
  clearListenerBusy,
  markListenerDisconnected,
  heartbeat,
  getAvailableListeners,
  isListenerAvailable,
  getListenerCurrentSession,
  cleanupStaleListeners,
};
