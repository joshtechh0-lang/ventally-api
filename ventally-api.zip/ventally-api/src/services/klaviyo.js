const https = require("https");
const logger = require("../utils/logger");

const KLAVIYO_BASE = "a.klaviyo.com";
const REVISION = "2024-10-15";

if (!process.env.KLAVIYO_SECRET) {
  logger.warn(
    "Klaviyo: KLAVIYO_SECRET not set — all tracking calls will be no-ops",
  );
}

function klaviyoRequest(method, apiPath, body) {
  if (!process.env.KLAVIYO_SECRET) return Promise.resolve();

  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const options = {
      hostname: KLAVIYO_BASE,
      path: apiPath,
      method,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Klaviyo-API-Key ${process.env.KLAVIYO_SECRET}`,
        revision: REVISION,
        "Content-Length": Buffer.byteLength(payload),
      },
    };

    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ status: res.statusCode });
        } else {
          reject(
            new Error(
              `Klaviyo ${method} ${apiPath} → ${res.statusCode}: ${data}`,
            ),
          );
        }
      });
    });

    req.on("error", reject);
    req.write(payload);
    req.end();
  });
}

function upsertProfile({ email, firstName, lastName, userType, phone }) {
  return klaviyoRequest("POST", "/api/profiles/", {
    data: {
      type: "profile",
      attributes: {
        email,
        first_name: firstName || undefined,
        last_name: lastName || undefined,
        phone_number: phone || undefined,
        properties: {
          user_type: userType,
        },
      },
    },
  });
}

function subscribeEmail(email) {
  const listId = process.env.KLAVIYO_LIST_ID || "T89P2J";
  return klaviyoRequest("POST", "/api/profile-subscription-bulk-create-jobs/", {
    data: {
      type: "profile-subscription-bulk-create-job",
      attributes: {
        profiles: {
          data: [{
            type: "profile",
            attributes: {
              email,
              subscriptions: {
                email: { marketing: { consent: "SUBSCRIBED" } },
              },
            },
          }],
        },
      },
      relationships: {
        list: { data: { type: "list", id: listId } },
      },
    },
  });
}

function sendKlaviyoEvent({ email, metricName, properties, uniqueId }) {
  return klaviyoRequest("POST", "/api/events/", {
    data: {
      type: "event",
      attributes: {
        properties,
        metric: { data: { type: "metric", attributes: { name: metricName } } },
        profile: { data: { type: "profile", attributes: { email } } },
        unique_id: uniqueId || `${metricName}-${email}-${Date.now()}`,
        time: new Date().toISOString(),
      },
    },
  });
}

function trackEvent(email, eventName, properties) {
  return sendKlaviyoEvent({ email, metricName: eventName, properties });
}

function fireAndLog(promise, label, email) {
  promise.catch((err) =>
    logger.error(`Klaviyo ${label} failed: ${err.message}`, { email }),
  );
}

// --- Public fire-and-forget exports ---

function trackUserRegistered({ email, firstName, userType, welcomeMinutes }) {
  upsertProfile({ email, firstName, userType }).catch((err) =>
    logger.error(`Klaviyo upsertProfile failed: ${err.message}`, { email }),
  );

  subscribeEmail(email).catch((err) =>
    logger.error(`Klaviyo subscribeEmail failed: ${err.message}`, { email }),
  );

  trackEvent(email, "Register", {
    first_name: firstName,
    user_type: userType,
    welcome_minutes: welcomeMinutes,
  }).catch((err) =>
    logger.error(`Klaviyo trackUserRegistered failed: ${err.message}`, {
      email,
    }),
  );
}

function trackSessionCompleted({
  email,
  sessionType,
  durationSeconds,
  totalCost,
}) {
  trackEvent(email, "Session Completed", {
    session_type: sessionType,
    duration_seconds: durationSeconds,
    total_cost: totalCost,
  }).catch((err) =>
    logger.error(`Klaviyo trackSessionCompleted failed: ${err.message}`, {
      email,
    }),
  );
}

function trackCreditsPurchased({
  email,
  minutesPurchased,
  amountPaid,
  newBalance,
  pricePerMinute,
}) {
  trackEvent(email, "Credits Purchased", {
    minutes_purchased: minutesPurchased,
    amount_paid: amountPaid,
    new_balance: newBalance,
    price_per_minute: pricePerMinute,
  }).catch((err) =>
    logger.error(`Klaviyo trackCreditsPurchased failed: ${err.message}`, {
      email,
    }),
  );
}

function trackSubscriptionActivated({
  email,
  planName,
  monthlyPrice,
  includedMinutes,
  nextPayment,
}) {
  trackEvent(email, "Subscription Activated", {
    plan_name: planName,
    monthly_price: monthlyPrice,
    included_minutes: includedMinutes,
    next_payment: nextPayment,
  }).catch((err) =>
    logger.error(`Klaviyo trackSubscriptionActivated failed: ${err.message}`, {
      email,
    }),
  );
}

function trackCrisisSessionEnded({ email, sessionType, actionTaken }) {
  trackEvent(email, "Crisis Session Ended", {
    session_type: sessionType,
    action_taken: actionTaken,
  }).catch((err) =>
    logger.error(`Klaviyo trackCrisisSessionEnded failed: ${err.message}`, {
      email,
    }),
  );
}

function trackEmailVerificationRequested({ email, otp, firstName, expiryMinutes }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Email Verification Requested",
      properties: { otp, first_name: firstName, expiry_minutes: expiryMinutes },
      uniqueId: `email-verification-${email}-${otp}`,
    }),
    "trackEmailVerificationRequested",
    email,
  );
}

function trackPasswordResetRequested({ email, otp, firstName, expiryMinutes }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Password Reset Requested",
      properties: { otp, first_name: firstName, expiry_minutes: expiryMinutes },
      uniqueId: `password-reset-${email}-${otp}`,
    }),
    "trackPasswordResetRequested",
    email,
  );
}

function trackEmailChangeOtpRequested({ email, otp, firstName, expiryMinutes }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Email Change OTP Requested",
      properties: { otp, first_name: firstName, expiry_minutes: expiryMinutes },
      uniqueId: `email-change-otp-${email}-${otp}`,
    }),
    "trackEmailChangeOtpRequested",
    email,
  );
}

function trackPhoneChangeOtpRequested({ email, otp, firstName, expiryMinutes }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Phone Change OTP Requested",
      properties: { otp, first_name: firstName, expiry_minutes: expiryMinutes },
      uniqueId: `phone-change-otp-${email}-${otp}`,
    }),
    "trackPhoneChangeOtpRequested",
    email,
  );
}

function trackTwoFactorCodeRequested({ email, code, firstName }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Two Factor Code Requested",
      properties: { code, first_name: firstName },
      uniqueId: `two-factor-${email}-${code}`,
    }),
    "trackTwoFactorCodeRequested",
    email,
  );
}

function trackListenerSignupSubmitted({ email, firstName }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Listener Signup Submitted",
      properties: { first_name: firstName },
    }),
    "trackListenerSignupSubmitted",
    email,
  );
}

function trackListenerApproved({ email, firstName }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Listener Approved",
      properties: { first_name: firstName },
    }),
    "trackListenerApproved",
    email,
  );
}

function trackListenerDenied({ email, firstName }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Listener Denied",
      properties: { first_name: firstName },
    }),
    "trackListenerDenied",
    email,
  );
}

function trackAppealReceived({ email, firstName }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Appeal Received",
      properties: { first_name: firstName },
    }),
    "trackAppealReceived",
    email,
  );
}

function trackCrisisCallFollowUp({ email }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Crisis Call Follow Up",
      properties: {},
    }),
    "trackCrisisCallFollowUp",
    email,
  );
}

function trackCreditPurchaseConfirmed({
  email,
  minutesPurchased,
  amountPaid,
  newBalance,
  pricePerMinute,
  uniqueId,
}) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Credit Purchase Confirmed",
      properties: {
        minutes_purchased: minutesPurchased,
        amount_paid: amountPaid,
        new_balance: newBalance,
        price_per_minute: pricePerMinute,
      },
      uniqueId,
    }),
    "trackCreditPurchaseConfirmed",
    email,
  );
}

function trackPaymentFailed({ email, firstName, amount, attemptCount, uniqueId }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Payment Failed",
      properties: {
        first_name: firstName,
        amount,
        attempt_count: attemptCount,
      },
      uniqueId,
    }),
    "trackPaymentFailed",
    email,
  );
}

function trackPlanCancelled({
  email,
  firstName,
  planName,
  includedMinutes,
  monthlyPrice,
  nextPayment,
  uniqueId,
}) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Plan Cancelled",
      properties: {
        first_name: firstName,
        plan_name: planName,
        included_minutes: includedMinutes,
        monthly_price: monthlyPrice,
        next_payment: nextPayment,
      },
      uniqueId,
    }),
    "trackPlanCancelled",
    email,
  );
}

function trackRefundConfirmed({
  email,
  firstName,
  amount,
  minutesPurchased,
  pricePerMinute,
  uniqueId,
}) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Refund Confirmed",
      properties: {
        first_name: firstName,
        amount,
        minutes_purchased: minutesPurchased,
        price_per_minute: pricePerMinute,
      },
      uniqueId,
    }),
    "trackRefundConfirmed",
    email,
  );
}

function trackSupportTicketReceived({ email, ticketId }) {
  fireAndLog(
    sendKlaviyoEvent({
      email,
      metricName: "Support Ticket Received",
      properties: {},
      uniqueId: ticketId ? `support-ticket-${ticketId}` : undefined,
    }),
    "trackSupportTicketReceived",
    email,
  );
}

module.exports = {
  trackUserRegistered,
  trackSessionCompleted,
  trackCreditsPurchased,
  trackSubscriptionActivated,
  trackCrisisSessionEnded,
  trackEmailVerificationRequested,
  trackPasswordResetRequested,
  trackEmailChangeOtpRequested,
  trackPhoneChangeOtpRequested,
  trackTwoFactorCodeRequested,
  trackListenerSignupSubmitted,
  trackListenerApproved,
  trackListenerDenied,
  trackAppealReceived,
  trackCrisisCallFollowUp,
  trackCreditPurchaseConfirmed,
  trackPaymentFailed,
  trackPlanCancelled,
  trackRefundConfirmed,
  trackSupportTicketReceived,
};
