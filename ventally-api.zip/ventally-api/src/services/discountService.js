/**
 * Discount Integration Hub Service
 *
 * Manages discounts synced from Stripe, VerifyPass, and referrals.
 * - Ensures a Stripe coupon exists for each discount rule
 * - Resolves which discounts apply to a given user
 * - Applies coupons to Stripe checkout sessions
 * - Syncs inbound Stripe coupons to the discounts table
 */

const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Get or create the Stripe coupon for a discount rule.
 * Idempotent: if the coupon already exists in Stripe and is recorded in DB, returns it.
 */
async function ensureStripeCoupon(discount) {
  if (discount.stripe_coupon_id) {
    // Verify coupon still exists and is valid in Stripe
    try {
      const coupon = await stripe.coupons.retrieve(discount.stripe_coupon_id);
      if (coupon && coupon.valid) {
        return coupon.id;
      }
    } catch (err) {
      logger.warn(`Stripe coupon ${discount.stripe_coupon_id} not found, recreating: ${err.message}`);
    }
  }

  // Create a new Stripe coupon
  const couponParams = {
    name: discount.name,
    metadata: {
      discount_id: discount.id,
      source: discount.source,
      eligibility_type: discount.eligibility_type,
    },
  };

  if (discount.discount_type === "percentage") {
    couponParams.percent_off = Number(discount.discount_value);
  } else {
    couponParams.amount_off = Math.round(Number(discount.discount_value) * 100);
    couponParams.currency = discount.currency || "usd";
  }

  if (discount.valid_until) {
    couponParams.redeem_by = Math.floor(new Date(discount.valid_until).getTime() / 1000);
  }

  if (discount.max_uses) {
    couponParams.max_redemptions = discount.max_uses;
  }

  const coupon = await stripe.coupons.create(couponParams);

  // Persist coupon ID back to DB
  await pool.query(
    `UPDATE discounts SET stripe_coupon_id = $1, updated_at = NOW() WHERE id = $2`,
    [coupon.id, discount.id]
  );

  logger.info(`Created Stripe coupon ${coupon.id} for discount "${discount.name}"`);
  return coupon.id;
}

/**
 * Resolve applicable discounts for a user for a given context (subscription checkout).
 * Returns an array of discount objects the user qualifies for.
 */
async function resolveUserDiscounts(userId, context = "subscription") {
  const client = await pool.connect();
  try {
    // Get user's verification status and referral info
    const userResult = await client.query(
      `SELECT id, is_community_verified, community_type FROM users WHERE id = $1`,
      [userId]
    );
    if (userResult.rows.length === 0) return [];
    const user = userResult.rows[0];

    // Fetch all active discounts that apply to this context
    const discountResult = await client.query(
      `SELECT * FROM discounts
       WHERE is_active = true
         AND applies_to IN ($1, 'both')
         AND (valid_from IS NULL OR valid_from <= NOW())
         AND (valid_until IS NULL OR valid_until > NOW())
       ORDER BY discount_value DESC`,
      [context]
    );

    const applicable = [];
    for (const discount of discountResult.rows) {
      if (discount.eligibility_type === "all") {
        applicable.push(discount);
      } else if (discount.eligibility_type === "community_verified") {
        if (user.is_community_verified) {
          // If community_type is specified, match it; null = any verified type
          if (!discount.community_type || discount.community_type === user.community_type) {
            applicable.push(discount);
          }
        }
      }
      // referral and manual handled separately
    }

    return applicable;
  } finally {
    client.release();
  }
}

/**
 * Get the best single Stripe coupon ID to apply for a user's checkout.
 * Picks the highest-value discount. Returns null if none apply.
 */
async function getBestCouponForUser(userId, context = "subscription") {
  try {
    const discounts = await resolveUserDiscounts(userId, context);
    if (discounts.length === 0) return null;

    // Pick highest value discount (already sorted DESC)
    const best = discounts[0];
    const couponId = await ensureStripeCoupon(best);

    logger.info(`Applying discount "${best.name}" (${best.discount_value}% off) for user ${userId}`);
    return { couponId, discount: best };
  } catch (err) {
    logger.error(`Error resolving discount for user ${userId}:`, err);
    return null;
  }
}

/**
 * Record a discount application for a user (after checkout created).
 */
async function recordUserDiscount(userId, discountId, options = {}) {
  try {
    await pool.query(
      `INSERT INTO user_discounts (user_id, discount_id, stripe_coupon_id, applied_to, stripe_session_id, stripe_subscription_id, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'active')
       ON CONFLICT (user_id, discount_id, applied_to) DO UPDATE
         SET stripe_session_id = EXCLUDED.stripe_session_id,
             stripe_subscription_id = EXCLUDED.stripe_subscription_id,
             applied_at = NOW()`,
      [
        userId,
        discountId,
        options.couponId || null,
        options.appliedTo || "subscription",
        options.sessionId || null,
        options.subscriptionId || null,
      ]
    );
  } catch (err) {
    logger.error(`Error recording user discount for user ${userId}:`, err);
  }
}

/**
 * Sync an inbound Stripe coupon into the discounts table.
 * Called from the Stripe webhook handler on coupon.created events.
 */
async function syncStripeCouponToDb(stripeCoupon) {
  try {
    // Check if we already have this coupon
    const existing = await pool.query(
      `SELECT id FROM discounts WHERE stripe_coupon_id = $1`,
      [stripeCoupon.id]
    );
    if (existing.rows.length > 0) {
      logger.info(`Stripe coupon ${stripeCoupon.id} already in discounts table`);
      return;
    }

    // Determine discount type and value
    const discountType = stripeCoupon.percent_off ? "percentage" : "fixed";
    const discountValue = stripeCoupon.percent_off
      ? stripeCoupon.percent_off
      : (stripeCoupon.amount_off || 0) / 100;

    await pool.query(
      `INSERT INTO discounts (
        name, description, source, discount_type, discount_value, currency,
        stripe_coupon_id, is_active, applies_to, max_uses,
        valid_until
       ) VALUES ($1, $2, 'stripe', $3, $4, $5, $6, $7, 'both', $8, $9)
       ON CONFLICT (stripe_coupon_id) DO NOTHING`,
      [
        stripeCoupon.name || stripeCoupon.id,
        `Synced from Stripe: ${stripeCoupon.id}`,
        discountType,
        discountValue,
        stripeCoupon.currency || "usd",
        stripeCoupon.id,
        stripeCoupon.valid,
        stripeCoupon.max_redemptions || null,
        stripeCoupon.redeem_by ? new Date(stripeCoupon.redeem_by * 1000) : null,
      ]
    );

    logger.info(`Synced Stripe coupon ${stripeCoupon.id} into discounts table`);
  } catch (err) {
    logger.error(`Error syncing Stripe coupon ${stripeCoupon.id}:`, err);
  }
}

/**
 * Get all active discounts (for admin panel).
 */
async function getAllDiscounts() {
  const result = await pool.query(
    `SELECT d.*,
       COUNT(ud.id) AS applied_count
     FROM discounts d
     LEFT JOIN user_discounts ud ON ud.discount_id = d.id AND ud.status = 'active'
     GROUP BY d.id
     ORDER BY d.created_at DESC`
  );
  return result.rows;
}

/**
 * Get discounts applicable to a specific user (for display in mobile app).
 */
async function getUserDiscountSummary(userId) {
  const discounts = await resolveUserDiscounts(userId, "subscription");
  return discounts.map((d) => ({
    id: d.id,
    name: d.name,
    description: d.description,
    discountType: d.discount_type,
    discountValue: d.discount_value,
    source: d.source,
    appliesTo: d.applies_to,
  }));
}

module.exports = {
  ensureStripeCoupon,
  resolveUserDiscounts,
  getBestCouponForUser,
  recordUserDiscount,
  syncStripeCouponToDb,
  getAllDiscounts,
  getUserDiscountSummary,
};
