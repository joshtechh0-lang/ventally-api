const crypto = require("crypto");
const bcrypt = require("bcrypt");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");

const OTP_TTL_MINUTES = 120;
const OTP_BCRYPT_ROUNDS = 8;
const DEFAULT_MAX_ATTEMPTS = 5;
const CLEANUP_GRACE_HOURS = 24 * 7;

const FLOWS = Object.freeze({
  EMAIL_VERIFICATION: "email_verification",
  PASSWORD_RESET: "password_reset",
  EMAIL_CHANGE: "email_change",
  PHONE_CHANGE: "phone_change",
  PHONE_VERIFICATION: "phone_verification",
});

const VALID_FLOWS = new Set(Object.values(FLOWS));

function generateCode() {
  return crypto.randomInt(1000, 10000).toString();
}

function assertValidFlow(flow) {
  if (!VALID_FLOWS.has(flow)) {
    throw new Error(`otpService: unknown flow "${flow}"`);
  }
}

function runner(client) {
  return client || pool;
}

async function createOtp({
  userId,
  flow,
  targetEmail = null,
  targetPhone = null,
  client = null,
  ttlMinutes = OTP_TTL_MINUTES,
  maxAttempts = DEFAULT_MAX_ATTEMPTS,
}) {
  assertValidFlow(flow);
  if (!userId) {
    throw new Error("otpService.createOtp: userId is required");
  }
  if (flow === FLOWS.EMAIL_CHANGE && !targetEmail) {
    throw new Error("otpService.createOtp: targetEmail required for email_change");
  }
  if (flow === FLOWS.PHONE_CHANGE && !targetPhone) {
    throw new Error("otpService.createOtp: targetPhone required for phone_change");
  }

  const code = generateCode();
  const hash = await bcrypt.hash(code, OTP_BCRYPT_ROUNDS);
  const expiresAt = new Date(Date.now() + ttlMinutes * 60 * 1000);

  const result = await runner(client).query(
    `INSERT INTO auth_otps
       (user_id, flow, otp_hash, target_email, target_phone, max_attempts, expires_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id, user_id, flow, target_email, target_phone, attempts, max_attempts, expires_at, created_at`,
    [userId, flow, hash, targetEmail, targetPhone, maxAttempts, expiresAt],
  );

  return { otp: code, record: result.rows[0] };
}

// Failed verify increments attempts on every currently active row for the
// (user, flow [, target]) tuple — not per row — so resending OTPs doesn't
// amplify the lockout window.
async function verifyOtp({
  userId,
  flow,
  code,
  targetEmail = null,
  targetPhone = null,
  client = null,
}) {
  assertValidFlow(flow);
  if (!userId || !code) {
    return { ok: false, reason: "invalid" };
  }

  const cleanCode = String(code).trim();
  if (!/^\d{4}$/.test(cleanCode)) {
    return { ok: false, reason: "malformed" };
  }

  const db = runner(client);

  const filterClauses = ["user_id = $1", "flow = $2"];
  const params = [userId, flow];
  if (targetEmail !== null) {
    params.push(targetEmail);
    filterClauses.push(`target_email = $${params.length}`);
  }
  if (targetPhone !== null) {
    params.push(targetPhone);
    filterClauses.push(`target_phone = $${params.length}`);
  }
  const filter = filterClauses.join(" AND ");

  const candidates = await db.query(
    `SELECT id, otp_hash, attempts, max_attempts, expires_at, consumed_at
       FROM auth_otps
      WHERE ${filter}
      ORDER BY created_at DESC`,
    params,
  );

  if (candidates.rows.length === 0) {
    return { ok: false, reason: "not_found" };
  }

  const now = new Date();
  const active = candidates.rows.filter(
    (row) =>
      row.consumed_at === null &&
      new Date(row.expires_at) > now &&
      row.attempts < row.max_attempts,
  );

  if (active.length === 0) {
    const hasUnconsumedExpired = candidates.rows.some(
      (row) => row.consumed_at === null && new Date(row.expires_at) <= now,
    );
    const hasLocked = candidates.rows.some(
      (row) => row.consumed_at === null && row.attempts >= row.max_attempts,
    );
    if (hasLocked) {
      return { ok: false, reason: "rate_limited" };
    }
    if (hasUnconsumedExpired) {
      return { ok: false, reason: "expired" };
    }
    return { ok: false, reason: "consumed" };
  }

  for (const row of active) {
    // eslint-disable-next-line no-await-in-loop
    const matches = await bcrypt.compare(cleanCode, row.otp_hash);
    if (!matches) {
      continue;
    }

    const consumed = await db.query(
      `UPDATE auth_otps
          SET consumed_at = CURRENT_TIMESTAMP,
              updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
          AND consumed_at IS NULL
          AND expires_at > CURRENT_TIMESTAMP
          AND attempts < max_attempts
        RETURNING id, user_id, flow, target_email, target_phone, expires_at, consumed_at`,
      [row.id],
    );

    if (consumed.rows.length === 0) {
      return { ok: false, reason: "consumed" };
    }

    return { ok: true, record: consumed.rows[0] };
  }

  const ids = active.map((row) => row.id);
  const bumped = await db.query(
    `UPDATE auth_otps
        SET attempts = attempts + 1,
            updated_at = CURRENT_TIMESTAMP
      WHERE id = ANY($1::uuid[])
      RETURNING id, attempts, max_attempts`,
    [ids],
  );

  const minRemaining = bumped.rows.reduce(
    (acc, row) => Math.min(acc, row.max_attempts - row.attempts),
    Number.POSITIVE_INFINITY,
  );
  const remaining = Math.max(0, Number.isFinite(minRemaining) ? minRemaining : 0);

  return {
    ok: false,
    reason: remaining === 0 ? "rate_limited" : "invalid",
    remainingAttempts: remaining,
  };
}

async function invalidateOtpsForUser({ userId, flow, client = null }) {
  assertValidFlow(flow);
  await runner(client).query(
    `UPDATE auth_otps
        SET consumed_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
      WHERE user_id = $1
        AND flow = $2
        AND consumed_at IS NULL`,
    [userId, flow],
  );
}

async function cleanupExpiredOtps({ graceHours = CLEANUP_GRACE_HOURS } = {}) {
  const result = await pool.query(
    `DELETE FROM auth_otps
      WHERE expires_at < CURRENT_TIMESTAMP - ($1 || ' hours')::interval
      RETURNING id`,
    [String(graceHours)],
  );
  logger.info(`otpService.cleanupExpiredOtps removed ${result.rowCount} rows`);
  return result.rowCount;
}

module.exports = {
  FLOWS,
  OTP_TTL_MINUTES,
  DEFAULT_MAX_ATTEMPTS,
  createOtp,
  verifyOtp,
  invalidateOtpsForUser,
  cleanupExpiredOtps,
};
