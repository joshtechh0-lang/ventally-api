const admin = require("firebase-admin");
const logger = require("../utils/logger");
const path = require("path");
const fs = require("fs");
const { pool } = require("../database/connection");

const DEAD_TOKEN_CODES = new Set([
  "messaging/registration-token-not-registered",
  "messaging/invalid-registration-token",
]);

const purgeDeadTokens = async (tokens, responses) => {
  const dead = [];
  responses.forEach((resp, idx) => {
    if (!resp.success && DEAD_TOKEN_CODES.has(resp.error?.code)) {
      dead.push(tokens[idx]);
    }
  });
  if (dead.length === 0) return;
  try {
    const res = await pool.query(
      'UPDATE device_tokens SET is_active = false WHERE token = ANY($1) RETURNING id',
      [dead],
    );
    logger.info('Purged ' + res.rowCount + ' dead FCM token(s) from DB');
  } catch (err) {
    logger.warn('Failed to purge dead tokens from DB:', { error: err.message });
  }
};

let firebaseApp = null;

/**
 * Initialize Firebase Admin SDK
 */
const initializeFirebase = () => {
  try {
    // Check if already initialized
    if (firebaseApp) {
      return firebaseApp;
    }

    // Option 1: Use service account file (recommended for production)
    if (process.env.FIREBASE_SERVICE_ACCOUNT_PATH) {
      const serviceAccountPath = path.resolve(
        process.env.FIREBASE_SERVICE_ACCOUNT_PATH,
      );

      if (fs.existsSync(serviceAccountPath)) {
        const serviceAccount = require(serviceAccountPath);
        firebaseApp = admin.initializeApp({
          credential: admin.credential.cert(serviceAccount),
        });
        logger.info("Firebase initialized with service account file");
      } else {
        logger.error(`Service account file not found at ${serviceAccountPath}`);
        throw new Error("Firebase service account file not found");
      }
    }
    // Option 2: Use environment variables
    else if (
      process.env.FIREBASE_PROJECT_ID &&
      process.env.FIREBASE_PRIVATE_KEY &&
      process.env.FIREBASE_CLIENT_EMAIL
    ) {
      firebaseApp = admin.initializeApp({
        credential: admin.credential.cert({
          projectId: process.env.FIREBASE_PROJECT_ID,
          privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
          clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        }),
      });
      logger.info("Firebase initialized with environment variables");
    }
    // Option 3: Use default credentials (for GCP environments)
    else if (process.env.NODE_ENV === "production") {
      firebaseApp = admin.initializeApp({
        credential: admin.credential.applicationDefault(),
      });
      logger.info("Firebase initialized with default credentials");
    } else {
      logger.warn(
        "Firebase not initialized - missing credentials. FCM features will be disabled.",
      );
      return null;
    }

    return firebaseApp;
  } catch (error) {
    logger.error("Error initializing Firebase:", error);
    throw error;
  }
};

/**
 * Send a notification to a single device
 * @param {string} token - Device FCM token
 * @param {Object} notification - Notification payload
 * @param {Object} data - Data payload (optional)
 * @returns {Promise<string>} - Message ID
 */
const sendNotificationToDevice = async (token, notification, data = {}) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - cannot send notification");
      return null;
    }

    const message = {
      token,
      notification: {
        title: notification.title,
        body: notification.body,
        ...(notification.imageUrl && { imageUrl: notification.imageUrl }),
      },
      data: {
        ...data,
        timestamp: new Date().toISOString(),
      },
      android: {
        priority: "high",
        notification: {
          sound: "default",
          channelId: "ventally_default",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
            badge: 1,
            "content-available": 1,
            "mutable-content": 1,
          },
        },
      },
    };

    const response = await admin.messaging().send(message);
    logger.info(`Notification sent successfully to device: ${token}`, {
      messageId: response,
    });
    return response;
  } catch (error) {
    logger.error("Error sending notification to device:", error);
    throw error;
  }
};

/**
 * Send notifications to multiple devices
 * @param {string[]} tokens - Array of device FCM tokens
 * @param {Object} notification - Notification payload
 * @param {Object} data - Data payload (optional)
 * @returns {Promise<Object>} - Batch response
 */
const sendNotificationToMultipleDevices = async (
  tokens,
  notification,
  data = {},
) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - cannot send notifications");
      return { successCount: 0, failureCount: tokens.length, responses: [] };
    }

    if (!tokens || tokens.length === 0) {
      throw new Error("No tokens provided");
    }

    const message = {
      notification: {
        title: notification.title,
        body: notification.body,
        ...(notification.imageUrl && { imageUrl: notification.imageUrl }),
      },
      data: {
        ...data,
        timestamp: new Date().toISOString(),
      },
      android: {
        priority: "high",
        notification: {
          sound: "default",
          channelId: "ventally_default",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
            badge: 1,
            "content-available": 1,
            "mutable-content": 1,
          },
        },
      },
      tokens,
    };

    const response = await admin.messaging().sendEachForMulticast(message);
    logger.info(`Notifications sent to ${tokens.length} devices`, {
      successCount: response.successCount,
      failureCount: response.failureCount,
    });

    // Log failed tokens
    if (response.failureCount > 0) {
      const failedTokens = [];
      response.responses.forEach((resp, idx) => {
        if (!resp.success) {
          failedTokens.push({
            token: tokens[idx],
            error: resp.error,
          });
        }
      });
      logger.warn("Failed to send to some devices:", { failedTokens });
      purgeDeadTokens(tokens, response.responses).catch(() => {});
    }

    return {
      successCount: response.successCount,
      failureCount: response.failureCount,
      responses: response.responses,
    };
  } catch (error) {
    logger.error("Error sending notifications to multiple devices:", error);
    throw error;
  }
};

/**
 * Send notification to a topic
 * @param {string} topic - Topic name
 * @param {Object} notification - Notification payload
 * @param {Object} data - Data payload (optional)
 * @returns {Promise<string>} - Message ID
 */
const sendNotificationToTopic = async (topic, notification, data = {}) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - cannot send topic notification");
      return null;
    }

    const message = {
      topic,
      notification: {
        title: notification.title,
        body: notification.body,
        ...(notification.imageUrl && { imageUrl: notification.imageUrl }),
      },
      data: {
        ...data,
        timestamp: new Date().toISOString(),
      },
      android: {
        priority: "high",
        notification: {
          sound: "default",
          channelId: "ventally_default",
        },
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
            badge: 1,
            "content-available": 1,
            "mutable-content": 1,
          },
        },
      },
    };

    const response = await admin.messaging().send(message);
    logger.info(`Notification sent to topic: ${topic}`, {
      messageId: response,
    });
    return response;
  } catch (error) {
    logger.error("Error sending notification to topic:", error);
    throw error;
  }
};

/**
 * Subscribe tokens to a topic
 * @param {string[]} tokens - Array of device FCM tokens
 * @param {string} topic - Topic name
 * @returns {Promise<Object>} - Subscription response
 */
const subscribeToTopic = async (tokens, topic) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - cannot subscribe to topic");
      return { successCount: 0, failureCount: tokens.length };
    }

    const response = await admin.messaging().subscribeToTopic(tokens, topic);
    logger.info(
      `Subscribed ${response.successCount} devices to topic: ${topic}`,
    );
    return response;
  } catch (error) {
    logger.error("Error subscribing to topic:", error);
    throw error;
  }
};

/**
 * Unsubscribe tokens from a topic
 * @param {string[]} tokens - Array of device FCM tokens
 * @param {string} topic - Topic name
 * @returns {Promise<Object>} - Unsubscription response
 */
const unsubscribeFromTopic = async (tokens, topic) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - cannot unsubscribe from topic");
      return { successCount: 0, failureCount: tokens.length };
    }

    const response = await admin
      .messaging()
      .unsubscribeFromTopic(tokens, topic);
    logger.info(
      `Unsubscribed ${response.successCount} devices from topic: ${topic}`,
    );
    return response;
  } catch (error) {
    logger.error("Error unsubscribing from topic:", error);
    throw error;
  }
};

/**
 * Validate and verify a device token
 * @param {string} token - Device FCM token
 * @returns {Promise<boolean>} - True if token is valid
 */
const verifyToken = async (token) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - skipping token verification");
      return true; // Allow token registration even without Firebase
    }

    // Try to send a dry-run message
    const message = {
      token,
      data: { test: "true" },
    };

    // await admin.messaging().send(message, true); // TEMP: skip dry-run validation
    return true;
  } catch (error) {
    logger.warn(`Invalid token: ${token}`, { error: error.message });
    return false;
  }
};


/**
 * Send a DATA-ONLY message to multiple devices (no notification block).
 * Use for session_request pushes so getInitialNotification() works on cold start.
 */
const sendDataOnlyNotificationToMultipleDevices = async (tokens, data = {}, notificationPayload = null) => {
  try {
    if (!firebaseApp) {
      logger.warn("Firebase not initialized - cannot send data-only notification");
      return { successCount: 0, failureCount: tokens.length, responses: [] };
    }
    if (!tokens || tokens.length === 0) {
      throw new Error("No tokens provided");
    }
    const stringData = {};
    for (const [k, v] of Object.entries(data)) {
      stringData[k] = v == null ? '' : String(v);
    }
    stringData.timestamp = new Date().toISOString();
    const message = {
      ...(notificationPayload ? { notification: { title: notificationPayload.title, body: notificationPayload.body } } : {}),
      data: stringData,
      android: {
        priority: "high",
        ...(notificationPayload ? { notification: { sound: "session_request", channelId: "ventally_incoming_v2" } } : {}),
      },
      apns: {
        payload: { aps: { "content-available": 1, ...(notificationPayload ? { sound: "session_request.wav" } : {}) } },
        headers: {
          "apns-push-type": notificationPayload ? "alert" : "background",
          "apns-priority": notificationPayload ? "10" : "5",
          "apns-topic": "com.ventally",
        },
      },
      tokens,
    };
    const response = await admin.messaging().sendEachForMulticast(message);
    logger.info(`Data-only notification sent to ${tokens.length} devices`, {
      successCount: response.successCount,
      failureCount: response.failureCount,
    });
    if (response.failureCount > 0) {
      const failedTokens = [];
      response.responses.forEach((resp, idx) => {
        if (!resp.success) failedTokens.push({ token: tokens[idx], error: resp.error });
      });
      logger.warn("Failed to send data-only notification to some devices:", { failedTokens });
      purgeDeadTokens(tokens, response.responses).catch(() => {});
    }
    return { successCount: response.successCount, failureCount: response.failureCount, responses: response.responses };
  } catch (error) {
    logger.error("Error sending data-only notifications:", error);
    throw error;
  }
};

module.exports = {
  initializeFirebase,
  sendNotificationToDevice,
  sendNotificationToMultipleDevices,
  sendNotificationToTopic,
  subscribeToTopic,
  unsubscribeFromTopic,
  verifyToken,
  sendDataOnlyNotificationToMultipleDevices,
};








