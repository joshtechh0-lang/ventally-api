const logger = require("../utils/logger");
const agoraService = require("./agora");

function getProviderName() {
  return "agora";
}

function createVoiceRoomName(callId) {
  return agoraService.createVoiceChannelName(callId);
}

function generateVoiceToken(identity, roomName, options = {}) {
  return agoraService.generateVoiceToken(identity, roomName, options);
}

function resolveVoiceJoinIdentity(identity) {
  return agoraService.resolveAgoraJoinIdentity(identity);
}

async function endVoiceRoom(roomName) {
  if (!roomName) {
    return { success: true, provider: getProviderName(), roomName: null };
  }

  return agoraService.endVoiceChannel(roomName);
}

logger.info(`Call provider initialized: ${getProviderName()}`);

module.exports = {
  getProviderName,
  createVoiceRoomName,
  generateVoiceToken,
  resolveVoiceJoinIdentity,
  endVoiceRoom,
};
