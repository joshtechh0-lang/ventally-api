const crypto = require("crypto");
const { RtcTokenBuilder, RtcRole } = require("agora-token");
const logger = require("../utils/logger");

const appId = process.env.AGORA_APP_ID;
const appCertificate = process.env.AGORA_APP_CERTIFICATE;
const tokenTtlSeconds = Number(process.env.AGORA_TOKEN_TTL_SECONDS || 3600);
const MAX_TOKEN_TTL_SECONDS = 24 * 60 * 60;
const allowInsecureDevToken =
  String(process.env.AGORA_ALLOW_INSECURE_DEV_TOKEN || "false") === "true";
const useWildcardUidToken =
  String(process.env.AGORA_UID_ZERO_MODE || "false") === "true";
const venterRoleSetting = String(
  process.env.AGORA_TOKEN_ROLE_VENTER || "publisher",
).toLowerCase();
const listenerRoleSetting = String(
  process.env.AGORA_TOKEN_ROLE_LISTENER || "publisher",
).toLowerCase();
const usePrivilegeTokens =
  String(process.env.AGORA_USE_PRIVILEGE_TOKENS || "false") === "true";
const joinPrivilegeTtlSeconds = process.env.AGORA_PRIVILEGE_JOIN_TTL_SECONDS;
const publishAudioPrivilegeTtlSeconds =
  process.env.AGORA_PRIVILEGE_PUBLISH_AUDIO_TTL_SECONDS;
const publishVideoPrivilegeTtlSeconds =
  process.env.AGORA_PRIVILEGE_PUBLISH_VIDEO_TTL_SECONDS;
const publishDataPrivilegeTtlSeconds =
  process.env.AGORA_PRIVILEGE_PUBLISH_DATA_TTL_SECONDS;

const ALLOWED_ROLE_SETTINGS = ["publisher", "subscriber"];
const MAX_AGORA_UID = 4294967295;

function detectAgoraTokenCompatibility() {
  const hasUidBuilder =
    typeof RtcTokenBuilder?.buildTokenWithUid === "function";
  const hasRolePublisher = typeof RtcRole?.PUBLISHER !== "undefined";

  if (hasUidBuilder && hasRolePublisher) {
    return { compatible: true };
  }

  let installedVersion = "unknown";
  try {
    installedVersion = require("agora-token/package.json").version || "unknown";
  } catch (_error) {
    // Ignore package.json lookup failures and log unknown version.
  }

  return {
    compatible: false,
    installedVersion,
    hasUidBuilder,
    hasRolePublisher,
  };
}

const agoraTokenCompatibility = detectAgoraTokenCompatibility();

function isAgoraKeyFormatValid(value) {
  return /^[0-9a-fA-F]{32}$/.test(String(value || "").trim());
}

function validateRoleSetting(envVarName, value) {
  if (ALLOWED_ROLE_SETTINGS.includes(value)) {
    return;
  }

  throw new Error(
    `Invalid ${envVarName} value: '${value}'. Allowed values: ${ALLOWED_ROLE_SETTINGS.join(", ")}.`,
  );
}

if (!agoraTokenCompatibility.compatible) {
  logger.error("Incompatible agora-token package detected at startup", {
    installedVersion: agoraTokenCompatibility.installedVersion,
    expectedApi: "RtcTokenBuilder.buildTokenWithUid + RtcRole.PUBLISHER",
    hasUidBuilder: agoraTokenCompatibility.hasUidBuilder,
    hasRolePublisher: agoraTokenCompatibility.hasRolePublisher,
    fix: "Install a compatible agora-token version (for example: npm i agora-token@^2)",
  });
}

validateRoleSetting("AGORA_TOKEN_ROLE_VENTER", venterRoleSetting);
validateRoleSetting("AGORA_TOKEN_ROLE_LISTENER", listenerRoleSetting);

if (useWildcardUidToken) {
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "AGORA_UID_ZERO_MODE=true is not allowed in production. Disable it to enforce strict UID-bound tokens.",
    );
  }

  logger.warn("Agora UID wildcard token mode enabled (uid=0)", {
    envVar: "AGORA_UID_ZERO_MODE",
    note: "Use for integration troubleshooting; disable in production for strict UID binding.",
  });
}

function validateAgoraConfig() {
  const missing = [];

  if (!appId) {
    missing.push("AGORA_APP_ID");
  }

  if (!appCertificate) {
    missing.push("AGORA_APP_CERTIFICATE");
  }

  if (missing.length > 0) {
    throw new Error(
      `Agora voice calling not configured. Missing: ${missing.join(", ")}`,
    );
  }

  const invalid = [];
  if (!isAgoraKeyFormatValid(appId)) {
    invalid.push("AGORA_APP_ID");
  }

  if (!isAgoraKeyFormatValid(appCertificate)) {
    invalid.push("AGORA_APP_CERTIFICATE");
  }

  if (invalid.length > 0) {
    throw new Error(
      `Invalid Agora credentials format for: ${invalid.join(", ")}. Expected 32-character hex strings from Agora Console.`,
    );
  }
}

function hasAgoraCredentials() {
  return Boolean(appId && appCertificate);
}

function canUseInsecureDevToken() {
  return process.env.NODE_ENV !== "production" && allowInsecureDevToken;
}

function sanitizeTokenTtlSeconds(value) {
  const parsed = Number(value);

  if (!Number.isFinite(parsed) || parsed <= 0) {
    logger.warn("Invalid AGORA_TOKEN_TTL_SECONDS; using default", {
      providedValue: value,
      fallback: 3600,
    });
    return 3600;
  }

  const ttl = Math.floor(parsed);

  if (ttl > MAX_TOKEN_TTL_SECONDS) {
    logger.warn("AGORA_TOKEN_TTL_SECONDS exceeds Agora max; clamping", {
      providedValue: ttl,
      maxAllowed: MAX_TOKEN_TTL_SECONDS,
    });
    return MAX_TOKEN_TTL_SECONDS;
  }

  return ttl;
}

function sanitizeOptionalPrivilegeTtl(value, fallbackTtlSeconds, envVarName) {
  if (value === undefined || value === null || String(value).trim() === "") {
    return fallbackTtlSeconds;
  }

  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) {
    throw new Error(
      `Invalid ${envVarName} value: '${value}'. Use a non-negative integer number of seconds.`,
    );
  }

  const ttl = Math.floor(parsed);
  if (ttl > MAX_TOKEN_TTL_SECONDS) {
    logger.warn(`${envVarName} exceeds Agora max; clamping`, {
      providedValue: ttl,
      maxAllowed: MAX_TOKEN_TTL_SECONDS,
    });
    return MAX_TOKEN_TTL_SECONDS;
  }

  return ttl;
}

function validateChannelName(channelName) {
  const value = String(channelName || "").trim();

  if (!value) {
    throw new Error("Channel name is required for Agora token generation");
  }

  if (Buffer.byteLength(value, "utf8") > 64) {
    throw new Error("Agora channel name must be 64 bytes or fewer");
  }

  return value;
}

function sanitizeUid(uid) {
  const numericUid = Number(uid);
  if (
    !Number.isInteger(numericUid) ||
    numericUid < 0 ||
    numericUid > MAX_AGORA_UID
  ) {
    throw new Error("Agora uid must be an integer between 0 and 4294967295");
  }

  return numericUid;
}

function sanitizeExpirationSeconds(value, { allowZero = false, envVarName }) {
  const parsed = Number(value);
  const lowerBound = allowZero ? 0 : 1;

  if (!Number.isFinite(parsed) || parsed < lowerBound) {
    throw new Error(
      `Invalid ${envVarName} value: '${value}'. Use ${allowZero ? "a non-negative" : "a positive"} integer number of seconds.`,
    );
  }

  const ttl = Math.floor(parsed);
  if (ttl > MAX_TOKEN_TTL_SECONDS) {
    return MAX_TOKEN_TTL_SECONDS;
  }

  return ttl;
}

function resolveRtcRoleFromNumeric(value) {
  return Number(value) === 2 ? RtcRole.SUBSCRIBER : RtcRole.PUBLISHER;
}

function mapRtcRole(roleSetting) {
  return roleSetting === "subscriber" ? RtcRole.SUBSCRIBER : RtcRole.PUBLISHER;
}

function resolveRtcRole(participantType) {
  if (participantType === "listener") {
    return mapRtcRole(listenerRoleSetting);
  }

  return mapRtcRole(venterRoleSetting);
}

function resolvePrivilegeExpiries(effectiveTtlSeconds, rtcRole) {
  const joinChannelPrivilegeExpire = sanitizeOptionalPrivilegeTtl(
    joinPrivilegeTtlSeconds,
    effectiveTtlSeconds,
    "AGORA_PRIVILEGE_JOIN_TTL_SECONDS",
  );

  const defaultPublishPrivilegeTtl =
    rtcRole === RtcRole.SUBSCRIBER ? 0 : effectiveTtlSeconds;

  const pubAudioPrivilegeExpire = sanitizeOptionalPrivilegeTtl(
    publishAudioPrivilegeTtlSeconds,
    defaultPublishPrivilegeTtl,
    "AGORA_PRIVILEGE_PUBLISH_AUDIO_TTL_SECONDS",
  );

  const pubVideoPrivilegeExpire = sanitizeOptionalPrivilegeTtl(
    publishVideoPrivilegeTtlSeconds,
    defaultPublishPrivilegeTtl,
    "AGORA_PRIVILEGE_PUBLISH_VIDEO_TTL_SECONDS",
  );

  const pubDataPrivilegeExpire = sanitizeOptionalPrivilegeTtl(
    publishDataPrivilegeTtlSeconds,
    defaultPublishPrivilegeTtl,
    "AGORA_PRIVILEGE_PUBLISH_DATA_TTL_SECONDS",
  );

  return {
    joinChannelPrivilegeExpire,
    pubAudioPrivilegeExpire,
    pubVideoPrivilegeExpire,
    pubDataPrivilegeExpire,
  };
}

function buildInsecureDevToken(identity, channelName) {
  const currentTimestamp = Math.floor(Date.now() / 1000);
  const privilegeExpireTs = currentTimestamp + tokenTtlSeconds;

  // This token is ONLY for local backend flow testing without Agora credentials.
  return `dev-agora-token.${Buffer.from(String(identity)).toString("base64")}.${Buffer.from(String(channelName)).toString("base64")}.${privilegeExpireTs}`;
}

function createVoiceChannelName(callId) {
  return `ventally-call-${callId}`;
}

function deriveDeterministicUid(identity) {
  const hash = crypto.createHash("sha256").update(String(identity)).digest();
  const uid = hash.readUInt32BE(0);

  // Keep uid > 0 for broad SDK compatibility.
  return uid === 0 ? 1 : uid;
}

function resolveAgoraJoinIdentity(identity) {
  const normalizedIdentity = String(identity || "").trim();

  if (!normalizedIdentity) {
    throw new Error("Invalid identity for Agora token generation");
  }

  const numeric = Number(normalizedIdentity);
  const canUseUid =
    Number.isInteger(numeric) && numeric > 0 && numeric <= 4294967295;

  if (canUseUid) {
    return {
      joinMode: "uid",
      uid: useWildcardUidToken ? 0 : numeric,
      userAccount: null,
      normalizedIdentity,
    };
  }

  return {
    joinMode: "uid",
    uid: useWildcardUidToken ? 0 : deriveDeterministicUid(normalizedIdentity),
    userAccount: null,
    normalizedIdentity,
  };
}

function maskIdentity(identity) {
  const value = String(identity || "");
  if (!value) {
    return "";
  }

  if (value.length <= 4) {
    return `${value[0] || ""}***${value[value.length - 1] || ""}`;
  }

  return `${value.slice(0, 2)}***${value.slice(-2)}`;
}

function generateVoiceToken(identity, channelName, options = {}) {
  if (!identity) {
    throw new Error("Invalid identity for Agora voice token");
  }

  const normalizedChannelName = validateChannelName(channelName);

  if (!agoraTokenCompatibility.compatible) {
    throw new Error(
      `Incompatible agora-token package installed (version: ${agoraTokenCompatibility.installedVersion}). Expected RtcTokenBuilder.buildTokenWithUid and RtcRole.PUBLISHER.`,
    );
  }

  const joinIdentity = resolveAgoraJoinIdentity(identity);
  const participantType =
    options.participantType === "listener" ? "listener" : "venter";
  const rtcRole = resolveRtcRole(participantType);

  // Validate credentials exactly once before token generation.
  validateAgoraConfig();

  if (!hasAgoraCredentials()) {
    if (canUseInsecureDevToken()) {
      logger.warn(
        "Agora credentials missing; using insecure development token fallback",
      );
      logger.debug("Agora token issuance (insecure dev fallback)", {
        channelName: normalizedChannelName,
        joinMode: joinIdentity.joinMode,
        identity: maskIdentity(joinIdentity.normalizedIdentity),
        uid: joinIdentity.uid,
      });
      return buildInsecureDevToken(identity, normalizedChannelName);
    }
  }

  // agora-token v2 expects relative expiry in seconds, not unix timestamps.
  const effectiveTtlSeconds = sanitizeTokenTtlSeconds(tokenTtlSeconds);

  let token;
  let privilegeExpiries = null;

  if (usePrivilegeTokens) {
    privilegeExpiries = resolvePrivilegeExpiries(effectiveTtlSeconds, rtcRole);
    token = RtcTokenBuilder.buildTokenWithUidAndPrivilege(
      appId,
      appCertificate,
      normalizedChannelName,
      joinIdentity.uid,
      effectiveTtlSeconds,
      privilegeExpiries.joinChannelPrivilegeExpire,
      privilegeExpiries.pubAudioPrivilegeExpire,
      privilegeExpiries.pubVideoPrivilegeExpire,
      privilegeExpiries.pubDataPrivilegeExpire,
    );
  } else {
    token = RtcTokenBuilder.buildTokenWithUid(
      appId,
      appCertificate,
      normalizedChannelName,
      joinIdentity.uid,
      rtcRole,
      effectiveTtlSeconds,
      effectiveTtlSeconds,
    );
  }

  if (!token || typeof token !== "string" || !token.startsWith("007")) {
    throw new Error(
      "Failed to generate Agora token. Verify AGORA_APP_ID and AGORA_APP_CERTIFICATE values from Agora Console.",
    );
  }

  logger.debug("Agora token issued", {
    channelName: normalizedChannelName,
    joinMode: joinIdentity.joinMode,
    uid: joinIdentity.uid,
    privilegeMode: usePrivilegeTokens ? "advanced" : "basic",
    rtcRole: rtcRole === RtcRole.SUBSCRIBER ? "subscriber" : "publisher",
    ttlSeconds: effectiveTtlSeconds,
    privilegeExpiries,
    tokenLength: token.length,
    identity: maskIdentity(joinIdentity.normalizedIdentity),
  });

  return token;
}

function generateTokenWithUid(params = {}) {
  if (!agoraTokenCompatibility.compatible) {
    throw new Error(
      `Incompatible agora-token package installed (version: ${agoraTokenCompatibility.installedVersion}). Expected RtcTokenBuilder.buildTokenWithUid and RtcRole.PUBLISHER.`,
    );
  }

  validateAgoraConfig();

  const channelName = validateChannelName(params.channelName);
  const uid = sanitizeUid(params.uid);
  const tokenExpireSeconds = sanitizeExpirationSeconds(params.tokenExpireTs, {
    allowZero: false,
    envVarName: "tokenExpireTs",
  });
  const privilegeExpireSeconds = sanitizeExpirationSeconds(
    params.privilegeExpireTs,
    {
      allowZero: true,
      envVarName: "privilegeExpireTs",
    },
  );
  const rtcRole = resolveRtcRoleFromNumeric(params.role);

  const token = RtcTokenBuilder.buildTokenWithUid(
    appId,
    appCertificate,
    channelName,
    uid,
    rtcRole,
    tokenExpireSeconds,
    privilegeExpireSeconds,
  );

  if (!token || typeof token !== "string" || !token.startsWith("007")) {
    throw new Error(
      "Failed to generate Agora token. Verify AGORA_APP_ID and AGORA_APP_CERTIFICATE values from Agora Console.",
    );
  }

  return {
    token,
    channelName,
    uid,
    role: rtcRole === RtcRole.SUBSCRIBER ? 2 : 1,
    tokenExpireTs: tokenExpireSeconds,
    privilegeExpireTs: privilegeExpireSeconds,
  };
}

async function endVoiceChannel(channelName) {
  logger.info("Agora channel end requested", {
    channelName,
    note: "Agora RTC channels end when users leave; explicit teardown not required",
  });

  return {
    success: true,
    provider: "agora",
    channelName,
  };
}

module.exports = {
  createVoiceChannelName,
  resolveAgoraJoinIdentity,
  generateVoiceToken,
  generateTokenWithUid,
  endVoiceChannel,
};
