/**
 * Balance Monitoring Service
 * Real-time balance monitoring and warnings during active calls
 */

const { pool } = require("../database/connection");
const { redisClient } = require("./redis");
const { getSetting } = require("./settings");
const presence = require("./presence");
const { getGracePeriodConfig } = require("../utils/gracePeriod");
const {
  calculateElapsedBillableMinutes,
  calculateRemainingBalance,
  determineWarningLevel,
  formatBalanceWarning,
  calculateDepletionTime,
} = require("../utils/balanceCalculator");
const logger = require("../utils/logger");

// Store active monitoring intervals
// Map<callId, { intervalId, userId, ratePerMinute, startedAt, lastWarningLevel, gracePeriodSeconds }>
const activeMonitors = new Map();

/**
 * Start balance monitoring for an active call
 * @param {string} callId - Call ID
 * @param {string} userId - User ID (venter/payer)
 * @param {number} ratePerMinute - Cost per minute
 * @param {Date|string} startedAt - When call became active
 * @param {Object} io - Socket.io instance
 */
async function startBalanceMonitoring(
  callId,
  userId,
  ratePerMinute,
  startedAt,
  io,
) {
  try {
    // Check if already monitoring this call
    if (activeMonitors.has(callId)) {
      logger.warn(`Balance monitoring already active for call ${callId}`);
      return;
    }

    // Get configuration
    const updateInterval = await getSetting(
      "balance_update_interval_seconds",
      60,
    );
    const warningThreshold = await getSetting(
      "balance_warning_threshold_minutes",
      5,
    );
    const criticalThreshold = await getSetting(
      "balance_critical_threshold_minutes",
      2,
    );
    const gracePeriodConfig = getGracePeriodConfig();
    const gracePeriodSeconds = gracePeriodConfig.enabled
      ? gracePeriodConfig.seconds
      : 0;

    logger.info(`Starting balance monitoring for call ${callId}`, {
      userId,
      ratePerMinute,
      updateInterval,
      warningThreshold,
      criticalThreshold,
      gracePeriodSeconds,
    });

    // Store monitoring state in Redis for recovery
    await redisClient.setEx(
      `balance_monitor:${callId}`,
      7200, // 2 hour TTL
      JSON.stringify({
        userId,
        ratePerMinute,
        startedAt: startedAt.toString(),
        lastWarningLevel: "none",
        gracePeriodSeconds,
      }),
    );

    // Initialize monitoring state
    const monitorState = {
      userId,
      ratePerMinute,
      startedAt: new Date(startedAt),
      lastWarningLevel: "none",
      gracePeriodSeconds,
      intervalId: null,
    };

    // Start monitoring interval
    const intervalId = setInterval(async () => {
      await checkAndUpdateBalance(
        callId,
        monitorState,
        io,
        warningThreshold,
        criticalThreshold,
      );
    }, updateInterval * 1000);

    monitorState.intervalId = intervalId;
    activeMonitors.set(callId, monitorState);

    // Do immediate check
    await checkAndUpdateBalance(
      callId,
      monitorState,
      io,
      warningThreshold,
      criticalThreshold,
    );

    logger.info(`Balance monitoring started for call ${callId}`);
  } catch (error) {
    logger.error(
      `Error starting balance monitoring for call ${callId}:`,
      error,
    );
  }
}

/**
 * Check balance and send updates/warnings
 * @param {string} callId - Call ID
 * @param {Object} monitorState - Monitor state object
 * @param {Object} io - Socket.io instance
 * @param {number} warningThreshold - Warning threshold in minutes
 * @param {number} criticalThreshold - Critical threshold in minutes
 */
async function checkAndUpdateBalance(
  callId,
  monitorState,
  io,
  warningThreshold,
  criticalThreshold,
) {
  const client = await pool.connect();

  try {
    const { userId, ratePerMinute, startedAt, gracePeriodSeconds } =
      monitorState;

    // Get current wallet balance
    const walletResult = await client.query(
      "SELECT balance_minutes FROM user_wallets WHERE user_id = $1",
      [userId],
    );

    if (walletResult.rows.length === 0) {
      logger.error(`Wallet not found for user ${userId} in call ${callId}`);
      return;
    }

    const walletBalanceMinutes = parseFloat(
      walletResult.rows[0].balance_minutes,
    );

    // Get subscription remaining minutes — subscription minutes are consumed
    // before wallet minutes, so they extend the effective call budget.
    const subResult = await client.query(
      `SELECT GREATEST(0, included_minutes - used_minutes) AS remaining_minutes
       FROM user_subscriptions
       WHERE user_id = $1 AND status IN ('active', 'trialing')
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId],
    );

    const subscriptionRemainingMinutes =
      subResult.rows.length > 0
        ? parseFloat(subResult.rows[0].remaining_minutes)
        : 0;

    // Effective balance = subscription minutes (used first) + wallet minutes (overage)
    const currentBalanceMinutes =
      subscriptionRemainingMinutes + walletBalanceMinutes;

    // Calculate elapsed billable time
    const elapsed = calculateElapsedBillableMinutes(
      startedAt,
      gracePeriodSeconds,
    );

    // Calculate remaining balance
    const remaining = calculateRemainingBalance(
      currentBalanceMinutes,
      elapsed.billableMinutes,
      ratePerMinute,
    );
    const elapsedSeconds = Number.isFinite(elapsed.elapsedSeconds)
      ? elapsed.elapsedSeconds
      : 0;

    // Create billing snapshot for audit trail
    try {
      // billing_snapshots.voice_call_id references voice_calls.id
      const callResult = await client.query(
        `SELECT surge_multiplier
         FROM voice_calls
         WHERE id = $1
         LIMIT 1`,
        [callId],
      );

      if (callResult.rows.length > 0) {
        const surgeMultiplier = parseFloat(
          callResult.rows[0].surge_multiplier || 1.0,
        );
        const costSnapshot = elapsed.billableMinutes * ratePerMinute;

        // Insert snapshot (ignore if duplicate due to timing)
        await client.query(
          `INSERT INTO billing_snapshots 
           (voice_call_id, elapsed_seconds, billable_minutes, cost_snapshot, 
            wallet_balance_after, rate_per_minute, surge_multiplier, 
            grace_period_active, metadata)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
           ON CONFLICT (voice_call_id, snapshot_time) DO NOTHING`,
          [
            callId,
            elapsedSeconds,
            elapsed.billableMinutes,
            costSnapshot,
            remaining.remainingMinutes,
            ratePerMinute,
            surgeMultiplier,
            elapsed.isInGracePeriod,
            JSON.stringify({
              timestamp: new Date().toISOString(),
              grace_period_remaining: elapsed.gracePeriodRemaining,
            }),
          ],
        );
      }
    } catch (snapshotError) {
      // Log but don't fail the balance monitoring if snapshot creation fails
      logger.error(
        `Error creating billing snapshot for call ${callId}:`,
        snapshotError,
      );
    }

    // Determine warning level
    const currentWarningLevel = determineWarningLevel(
      remaining.remainingMinutes,
      warningThreshold,
      criticalThreshold,
    );

    // Calculate depletion time
    const depletion = calculateDepletionTime(
      remaining.remainingMinutes,
      ratePerMinute,
    );

    // Emit balance update to call room
    const updatePayload = {
      callId,
      remainingMinutes: remaining.remainingMinutes,
      remainingCurrency: remaining.remainingCurrency,
      ratePerMinute,
      elapsedMinutes: elapsed.billableMinutes,
      isInGracePeriod: elapsed.isInGracePeriod,
      gracePeriodRemaining: Math.floor(elapsed.gracePeriodRemaining / 60),
      warningLevel: currentWarningLevel,
      estimatedDepletionTime: depletion.depletionTime,
      timestamp: new Date().toISOString(),
    };

    io.to(`call:${callId}`).emit("balance:update", updatePayload);

    // Emit warning if level changed and is not 'none'
    if (
      currentWarningLevel !== monitorState.lastWarningLevel &&
      currentWarningLevel !== "none"
    ) {
      const warningMessage = formatBalanceWarning(
        currentWarningLevel,
        remaining.remainingMinutes,
      );

      const warningPayload = {
        callId,
        level: currentWarningLevel,
        remainingMinutes: remaining.remainingMinutes,
        remainingCurrency: remaining.remainingCurrency,
        message: warningMessage,
        estimatedDepletionTime: depletion.depletionTime,
        timestamp: new Date().toISOString(),
      };

      if (currentWarningLevel === "depleted") {
        io.to(`call:${callId}`).emit("balance:depleted", warningPayload);
        logger.warn(
          `Balance depleted for call ${callId}. Auto-disconnect initiated.`,
        );

        // Auto-disconnect after grace period
        await handleBalanceDepletion(callId, userId, io);
      } else if (currentWarningLevel === "critical") {
        io.to(`call:${callId}`).emit("balance:critical", warningPayload);
        logger.warn(
          `Critical balance warning for call ${callId}: ${remaining.remainingMinutes} minutes remaining`,
        );
      } else if (currentWarningLevel === "warning") {
        io.to(`call:${callId}`).emit("balance:warning", warningPayload);
        logger.info(
          `Balance warning for call ${callId}: ${remaining.remainingMinutes} minutes remaining`,
        );
      }

      // Update last warning level
      monitorState.lastWarningLevel = currentWarningLevel;

      // Update Redis state
      await redisClient.setEx(
        `balance_monitor:${callId}`,
        7200,
        JSON.stringify({
          userId,
          ratePerMinute,
          startedAt: startedAt.toString(),
          lastWarningLevel: currentWarningLevel,
          gracePeriodSeconds,
        }),
      );
    }

    logger.debug(`Balance check for call ${callId}:`, {
      remainingMinutes: remaining.remainingMinutes,
      elapsedMinutes: elapsed.billableMinutes,
      warningLevel: currentWarningLevel,
    });
  } catch (error) {
    logger.error(`Error checking balance for call ${callId}:`, error);
  } finally {
    client.release();
  }
}

/**
 * Handle balance depletion - auto-disconnect call
 * @param {string} callId - Call ID
 * @param {string} userId - User ID
 * @param {Object} io - Socket.io instance
 */
async function handleBalanceDepletion(callId, userId, io) {
  try {
    const disconnectGraceSeconds = await getSetting(
      "balance_disconnect_grace_seconds",
      10,
    );
    const disconnectEnabled = await getSetting(
      "balance_disconnect_on_zero",
      true,
    );

    if (!disconnectEnabled) {
      logger.info(`Auto-disconnect disabled for call ${callId}`);
      return;
    }

    // Wait grace period before disconnecting
    logger.info(
      `Waiting ${disconnectGraceSeconds} seconds before auto-disconnect for call ${callId}`,
    );

    setTimeout(async () => {
      try {
        // Check if call is still active
        const client = await pool.connect();
        try {
          const callResult = await client.query(
            "SELECT status FROM voice_calls WHERE id = $1",
            [callId],
          );

          if (
            callResult.rows.length > 0 &&
            callResult.rows[0].status === "active"
          ) {
            // End the call
            const endResult = await client.query(
              `UPDATE voice_calls SET status = 'ended', ended_at = NOW(), 
               metadata = jsonb_set(COALESCE(metadata, '{}'), '{disconnectReason}', '"balance_depleted"')
               WHERE id = $1
               RETURNING listener_id`,
              [callId],
            );

            const listenerId = endResult.rows?.[0]?.listener_id;
            if (listenerId) {
              // Ensure listener can receive new requests immediately after forced call end.
              await presence.clearListenerBusy(listenerId);
            }

            // Stop monitoring
            await stopBalanceMonitoring(callId);

            // Notify via socket
            io.to(`call:${callId}`).emit("call:ended", {
              callId,
              reason: "balance_depleted",
              message: "Call ended due to insufficient balance",
              timestamp: new Date().toISOString(),
            });

            logger.info(
              `Call ${callId} auto-disconnected due to balance depletion`,
            );
          }
        } finally {
          client.release();
        }
      } catch (error) {
        logger.error(`Error auto-disconnecting call ${callId}:`, error);
      }
    }, disconnectGraceSeconds * 1000);
  } catch (error) {
    logger.error(`Error handling balance depletion for call ${callId}:`, error);
  }
}

/**
 * Stop balance monitoring for a call
 * @param {string} callId - Call ID
 */
async function stopBalanceMonitoring(callId) {
  try {
    const monitor = activeMonitors.get(callId);

    if (monitor) {
      // Clear interval
      if (monitor.intervalId) {
        clearInterval(monitor.intervalId);
      }

      // Remove from active monitors
      activeMonitors.delete(callId);

      logger.info(`Balance monitoring stopped for call ${callId}`);
    }

    // Remove from Redis
    await redisClient.del(`balance_monitor:${callId}`);
  } catch (error) {
    logger.error(
      `Error stopping balance monitoring for call ${callId}:`,
      error,
    );
  }
}

/**
 * Recover monitoring after server restart
 * Called on server startup to resume monitoring for active calls
 * @param {Object} io - Socket.io instance
 */
async function recoverMonitoring(io) {
  const client = await pool.connect();

  try {
    logger.info("Recovering balance monitoring for active calls...");

    // Get all active calls
    const activeCallsResult = await client.query(
      `SELECT id, venter_id, rate_per_minute, started_at 
       FROM voice_calls 
       WHERE status = 'active' AND started_at IS NOT NULL`,
    );

    for (const call of activeCallsResult.rows) {
      // Check if monitoring state exists in Redis
      const monitorState = await redisClient.get(`balance_monitor:${call.id}`);

      if (monitorState) {
        const state = JSON.parse(monitorState);

        logger.info(`Recovering monitoring for call ${call.id}`);

        // Restart monitoring
        await startBalanceMonitoring(
          call.id,
          call.venter_id,
          parseFloat(call.rate_per_minute),
          call.started_at,
          io,
        );
      }
    }

    logger.info(
      `Recovered monitoring for ${activeCallsResult.rows.length} active calls`,
    );
  } catch (error) {
    logger.error("Error recovering balance monitoring:", error);
  } finally {
    client.release();
  }
}

/**
 * Get active monitoring count (for metrics)
 * @returns {number} Number of active monitors
 */
function getActiveMonitorCount() {
  return activeMonitors.size;
}

/**
 * Get monitoring state for a call
 * @param {string} callId - Call ID
 * @returns {Object|null} Monitor state or null
 */
function getMonitorState(callId) {
  return activeMonitors.get(callId) || null;
}

module.exports = {
  startBalanceMonitoring,
  stopBalanceMonitoring,
  recoverMonitoring,
  getActiveMonitorCount,
  getMonitorState,
};
