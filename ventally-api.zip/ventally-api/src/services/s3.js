const {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { Upload } = require("@aws-sdk/lib-storage");
const { v4: uuidv4 } = require("uuid");

// Configure AWS SDK credentials
let s3ClientConfig = {
  region: process.env.S3_BUCKET_REGION || process.env.AWS_REGION || "us-east-1",
};

if (process.env.NODE_ENV === "development") {
  // LocalStack configuration for development
  s3ClientConfig.endpoint = process.env.AWS_ENDPOINT_URL;
  s3ClientConfig.credentials = {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "test",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "test",
  };
  s3ClientConfig.forcePathStyle = true; // Required for LocalStack
} else if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
  // Production: Use explicit credentials if provided
  s3ClientConfig.credentials = {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  };
}
// else: Production will use IAM instance role (default AWS SDK behavior)

const s3Client = new S3Client(s3ClientConfig);

const BUCKET_NAME = process.env.S3_BUCKET_NAME || "ventally-uploads";

/**
 * Upload a file to S3
 * @param {Object} options - Upload options
 * @param {Buffer|Stream} options.fileBuffer - File buffer or stream
 * @param {string} options.fileName - Original file name
 * @param {string} options.mimeType - File MIME type
 * @param {string} options.folder - Optional folder/prefix in bucket
 * @returns {Promise<Object>} - Upload result with file URL and key
 */
async function uploadFile({
  fileBuffer,
  fileName,
  mimeType,
  folder = "uploads",
}) {
  try {
    const fileExtension = fileName.split(".").pop();
    const uniqueFileName = `${uuidv4()}.${fileExtension}`;
    const key = folder ? `${folder}/${uniqueFileName}` : uniqueFileName;

    const upload = new Upload({
      client: s3Client,
      // Keep uploads within our document limits (<=10MB) as a single PutObject so
      // the SSE header travels with the object write. Multipart UploadPart requests
      // omit that header and get rejected by a deny-unencrypted-uploads bucket policy.
      partSize: 1024 * 1024 * 16,
      params: {
        Bucket: BUCKET_NAME,
        Key: key,
        Body: fileBuffer,
        ContentType: mimeType,
        ServerSideEncryption: "AES256", // Required by bucket policy
      },
    });

    await upload.done();

    // Generate URL based on environment
    const fileUrl =
      process.env.NODE_ENV === "development"
        ? `${process.env.AWS_ENDPOINT_URL}/${BUCKET_NAME}/${key}`
        : `https://${BUCKET_NAME}.s3.${process.env.S3_BUCKET_REGION}.amazonaws.com/${key}`;

    console.log(`File uploaded successfully: ${key}`);

    return {
      success: true,
      key,
      url: fileUrl,
      fileName: uniqueFileName,
      originalFileName: fileName,
      mimeType,
    };
  } catch (error) {
    console.error("Error uploading file to S3:", error);
    throw new Error(`Failed to upload file: ${error.message}`);
  }
}

/**
 * Get a file from S3
 * @param {string} key - S3 object key
 * @returns {Promise<Object>} - File data and metadata
 */
async function getFile(key) {
  try {
    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    });

    const response = await s3Client.send(command);

    // Convert stream to buffer
    const streamToBuffer = async (stream) => {
      const chunks = [];
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      return Buffer.concat(chunks);
    };

    const buffer = await streamToBuffer(response.Body);

    return {
      success: true,
      buffer,
      contentType: response.ContentType,
      contentLength: response.ContentLength,
      lastModified: response.LastModified,
    };
  } catch (error) {
    console.error("Error getting file from S3:", error);
    throw new Error(`Failed to get file: ${error.message}`);
  }
}

/**
 * Delete a file from S3
 * @param {string} key - S3 object key
 * @returns {Promise<Object>}
 */
async function deleteFile(key) {
  try {
    const command = new DeleteObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    });

    await s3Client.send(command);

    console.log(`File deleted successfully: ${key}`);

    return {
      success: true,
      key,
    };
  } catch (error) {
    console.error("Error deleting file from S3:", error);
    throw new Error(`Failed to delete file: ${error.message}`);
  }
}

/**
 * Check if a file exists in S3
 * @param {string} key - S3 object key
 * @returns {Promise<boolean>}
 */
async function fileExists(key) {
  try {
    const command = new HeadObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    });

    await s3Client.send(command);
    return true;
  } catch (error) {
    if (error.name === "NotFound") {
      return false;
    }
    console.error("Error checking file existence:", error);
    throw new Error(`Failed to check file existence: ${error.message}`);
  }
}

/**
 * Upload profile picture
 * @param {Buffer} fileBuffer - Image buffer
 * @param {string} fileName - Original file name
 * @param {string} userId - User ID
 * @returns {Promise<Object>}
 */
async function uploadProfilePicture(fileBuffer, fileName, userId) {
  return uploadFile({
    fileBuffer,
    fileName,
    mimeType: "image/jpeg",
    folder: `profiles/${userId}`,
  });
}

/**
 * Upload user signature
 * @param {Buffer} fileBuffer - Image buffer
 * @param {string} fileName - Original file name
 * @param {string} userId - User ID
 * @param {string} mimeType - MIME type (image/png, image/jpeg, image/svg+xml)
 * @returns {Promise<Object>}
 */
async function uploadSignature(fileBuffer, fileName, userId, mimeType) {
  return uploadFile({
    fileBuffer,
    fileName,
    mimeType: mimeType || "image/png",
    folder: `signatures/${userId}`,
  });
}

/**
 * Upload call recording
 * @param {Buffer} fileBuffer - Audio buffer
 * @param {string} fileName - Original file name
 * @param {string} callId - Call ID
 * @returns {Promise<Object>}
 */
async function uploadCallRecording(fileBuffer, fileName, callId) {
  return uploadFile({
    fileBuffer,
    fileName,
    mimeType: "audio/mpeg",
    folder: `recordings/${callId}`,
  });
}

/**
 * Upload listener verification document
 * @param {Buffer} fileBuffer - File buffer
 * @param {string} fileName - Original file name
 * @param {string} listenerId - Listener user ID
 * @param {string} mimeType - MIME type
 * @returns {Promise<Object>}
 */
async function uploadListenerVerificationDocument(
  fileBuffer,
  fileName,
  listenerId,
  mimeType,
) {
  return uploadFile({
    fileBuffer,
    fileName,
    mimeType,
    folder: `listener-verifications/${listenerId}`,
  });
}

/**
 * Upload listener appeal document
 * @param {Buffer} fileBuffer - File buffer
 * @param {string} fileName - Original file name
 * @param {string} userId - Listener user ID
 * @param {string} mimeType - MIME type
 * @returns {Promise<Object>}
 */
async function uploadListenerAppealDocument(
  fileBuffer,
  fileName,
  userId,
  mimeType,
) {
  return uploadFile({
    fileBuffer,
    fileName,
    mimeType,
    folder: `support-appeals/${userId}`,
  });
}

/**
 * Generate presigned GET URL for S3 object
 * @param {string} key - S3 object key
 * @param {number} expiresInSeconds - URL expiry in seconds (default 15 minutes)
 * @returns {Promise<string>}
 */
async function getPresignedGetUrl(key, expiresInSeconds = 900) {
  const command = new GetObjectCommand({
    Bucket: BUCKET_NAME,
    Key: key,
  });

  return getSignedUrl(s3Client, command, { expiresIn: expiresInSeconds });
}

/**
 * Get file URL (for LocalStack, returns direct URL)
 * @param {string} key - S3 object key
 * @returns {string} - File URL
 */
function getFileUrl(key) {
  if (process.env.NODE_ENV === "development") {
    return `${process.env.AWS_ENDPOINT_URL}/${BUCKET_NAME}/${key}`;
  }
  return `https://${BUCKET_NAME}.s3.${process.env.S3_BUCKET_REGION}.amazonaws.com/${key}`;
}

module.exports = {
  uploadFile,
  getFile,
  deleteFile,
  fileExists,
  uploadProfilePicture,
  uploadSignature,
  uploadCallRecording,
  uploadListenerVerificationDocument,
  uploadListenerAppealDocument,
  getFileUrl,
  getPresignedGetUrl,
};
