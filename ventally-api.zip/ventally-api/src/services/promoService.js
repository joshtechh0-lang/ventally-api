const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const { v4: uuidv4 } = require("uuid");

/**
 * Validate a promo code
 * @param {string} code - Promo code string
 * @param {string} userId - User ID (optional, to check if already used)
 * @returns {Promise<Object>} Promo code details or null if invalid
 */
async function validatePromoCode(code, userId = null) {
  const client = await pool.connect();

  try {
    // Get promo code
    const result = await client.query(
      `SELECT * FROM promo_codes 
       WHERE UPPER(code) = UPPER($1)`,
      [code],
    );

    if (result.rows.length === 0) {
      return { valid: false, error: "Code not found" };
    }

    const promo = result.rows[0];

    // Check if active
    if (!promo.is_active) {
      return { valid: false, error: "Code is inactive" };
    }

    // Check dates
    const now = new Date();
    if (promo.valid_from && new Date(promo.valid_from) > now) {
      return { valid: false, error: "Code not yet valid" };
    }
    if (promo.valid_until && new Date(promo.valid_until) < now) {
      return { valid: false, error: "Code has expired" };
    }

    // Check max uses
    if (promo.max_uses && promo.current_uses >= promo.max_uses) {
      return { valid: false, error: "Code usage limit reached" };
    }

    // Check if user already used this code
    if (userId) {
      const usageResult = await client.query(
        `SELECT id FROM promo_code_usage 
         WHERE promo_code_id = $1 AND user_id = $2`,
        [promo.id, userId],
      );

      if (usageResult.rows.length > 0) {
        return { valid: false, error: "Code already used by this user" };
      }
    }

    return {
      valid: true,
      promo: {
        id: promo.id,
        code: promo.code,
        discountType: promo.discount_type,
        discountValue: parseFloat(promo.discount_value) || 0,
        freeMinutes: promo.free_minutes || 0,
        validUntil: promo.valid_until,
      },
    };
  } finally {
    client.release();
  }
}

/**
 * Apply a promo code to a user (record usage)
 * @param {string} promoCodeId - Promo code ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Usage record
 */
async function applyPromoCode(promoCodeId, userId) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Record usage
    const usageId = uuidv4();
    const usageResult = await client.query(
      `INSERT INTO promo_code_usage (id, promo_code_id, user_id) 
       VALUES ($1, $2, $3) 
       RETURNING *`,
      [usageId, promoCodeId, userId],
    );

    // Increment current uses
    await client.query(
      `UPDATE promo_codes 
       SET current_uses = current_uses + 1 
       WHERE id = $1`,
      [promoCodeId],
    );

    await client.query("COMMIT");

    logger.info(`Promo code applied: ${promoCodeId} by user ${userId}`);

    return usageResult.rows[0];
  } catch (error) {
    await client.query("ROLLBACK");
    // If unique constraint violation, user already used this code
    if (error.code === "23505") {
      throw new Error("Code already used by this user");
    }
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Calculate discount amount for a given price
 * @param {Object} promo - Promo code object
 * @param {number} originalPrice - Original price in cents
 * @returns {Object} Discount details
 */
function calculateDiscount(promo, originalPrice) {
  let discountAmount = 0;
  let freeMinutes = 0;

  if (promo.discountType === "percentage") {
    discountAmount = Math.round((originalPrice * promo.discountValue) / 100);
  } else if (promo.discountType === "fixed") {
    discountAmount = Math.round(promo.discountValue * 100); // Convert to cents
    // Don't exceed original price
    if (discountAmount > originalPrice) {
      discountAmount = originalPrice;
    }
  } else if (promo.discountType === "free_minutes") {
    freeMinutes = promo.freeMinutes;
    // No price discount, just bonus minutes
  }

  const finalPrice = Math.max(0, originalPrice - discountAmount);

  return {
    originalPrice,
    discountAmount,
    finalPrice,
    freeMinutes,
    discountType: promo.discountType,
  };
}

/**
 * Get promo code by ID
 * @param {string} promoCodeId - Promo code ID
 * @returns {Promise<Object>} Promo code
 */
async function getPromoCodeById(promoCodeId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      "SELECT * FROM promo_codes WHERE id = $1",
      [promoCodeId],
    );

    return result.rows.length > 0 ? result.rows[0] : null;
  } finally {
    client.release();
  }
}

/**
 * Get user's promo code usage history
 * @param {string} userId - User ID
 * @returns {Promise<Array>} Promo codes used by user
 */
async function getUserPromoHistory(userId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT pc.code, pc.discount_type, pc.discount_value, pc.free_minutes,
              pcu.applied_at
       FROM promo_code_usage pcu
       JOIN promo_codes pc ON pc.id = pcu.promo_code_id
       WHERE pcu.user_id = $1
       ORDER BY pcu.applied_at DESC`,
      [userId],
    );

    return result.rows;
  } finally {
    client.release();
  }
}

module.exports = {
  validatePromoCode,
  applyPromoCode,
  calculateDiscount,
  getPromoCodeById,
  getUserPromoHistory,
};
