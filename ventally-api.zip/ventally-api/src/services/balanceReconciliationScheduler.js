const { pool } = require("../database/connection");
const logger = require("../utils/logger");

const DEFAULT_ENABLED = true;
const DEFAULT_INTERVAL_MINUTES = 60;
const DEFAULT_LOOKBACK_HOURS = 72;
const DEFAULT_EPSILON = 0.01;
const DEFAULT_AUTOFIX = false;

let reconcileTimer = null;
let runInProgress = false;

function parseBoolean(value, fallback) {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }

  const normalized = String(value).trim().toLowerCase();
  return ["1", "true", "yes", "on"].includes(normalized);
}

function parseNonNegativeInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return fallback;
  }

  return parsed;
}

function parseNonNegativeFloat(value, fallback) {
  const parsed = Number.parseFloat(value);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return fallback;
  }

  return parsed;
}

function getSchedulerConfig() {
  const enabled = parseBoolean(
    process.env.BALANCE_RECONCILE_ENABLED,
    DEFAULT_ENABLED,
  );
  const intervalMinutes = Math.max(
    1,
    parseNonNegativeInteger(
      process.env.BALANCE_RECONCILE_INTERVAL_MINUTES,
      DEFAULT_INTERVAL_MINUTES,
    ),
  );
  const lookbackHours = Math.max(
    1,
    parseNonNegativeInteger(
      process.env.BALANCE_RECONCILE_LOOKBACK_HOURS,
      DEFAULT_LOOKBACK_HOURS,
    ),
  );
  const epsilon = parseNonNegativeFloat(
    process.env.BALANCE_RECONCILE_EPSILON,
    DEFAULT_EPSILON,
  );
  const autoFix = parseBoolean(
    process.env.BALANCE_RECONCILE_AUTOFIX,
    DEFAULT_AUTOFIX,
  );

  return {
    enabled,
    intervalMinutes,
    lookbackHours,
    epsilon,
    autoFix,
  };
}

/**
 * Repair a single drifted wallet so its balance matches the ledger snapshot.
 *
 * Done inside a DB transaction: set balance_minutes to the expected value and
 * write a `reconciliation_adjustment` row whose amount_minutes is the diff that
 * was missing, mirroring how the credit-purchase handler snapshots balances.
 */
async function repairWalletBalance({
  userId,
  transactionId,
  expectedMinutes,
  diff,
}) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `UPDATE user_wallets
       SET balance_minutes = $1, updated_at = NOW()
       WHERE user_id = $2`,
      [expectedMinutes, userId],
    );

    const metadata = {
      reconciled_from_transaction_id: transactionId,
      detected_diff_minutes: diff,
    };

    await client.query(
      `INSERT INTO wallet_transactions
        (user_id, transaction_type, amount_minutes, balance_after_minutes,
         description, metadata)
       VALUES ($1, 'reconciliation_adjustment', $2, $3, $4, $5::jsonb)`,
      [
        userId,
        diff,
        expectedMinutes,
        "Auto-reconciled wallet to match ledger snapshot",
        JSON.stringify(metadata),
      ],
    );

    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Verify that customers with recent transactions have a wallet balance that
 * matches the ledger. For each user with a balance snapshot in the lookback
 * window, the most recent wallet_transactions.balance_after_minutes must equal
 * the current user_wallets.balance_minutes (the invariant broken by the
 * "paid but minutes not credited" bug). Discrepancies are logged; when autoFix
 * is enabled the wallet is repaired to the snapshot value.
 */
async function reconcileRecentBalances({
  lookbackHours,
  autoFix,
  epsilon,
  source = "manual",
} = {}) {
  const config = getSchedulerConfig();
  const effectiveLookback = lookbackHours ?? config.lookbackHours;
  const effectiveEpsilon = epsilon ?? config.epsilon;
  const effectiveAutoFix = autoFix ?? config.autoFix;

  const { rows } = await pool.query(
    `WITH recent_users AS (
       SELECT DISTINCT user_id
       FROM wallet_transactions
       WHERE balance_after_minutes IS NOT NULL
         AND created_at >= NOW() - ($1::int * INTERVAL '1 hour')
     ),
     latest_snapshot AS (
       SELECT DISTINCT ON (wt.user_id)
         wt.user_id, wt.id AS transaction_id,
         wt.balance_after_minutes, wt.created_at, wt.transaction_type
       FROM wallet_transactions wt
       JOIN recent_users ru ON ru.user_id = wt.user_id
       WHERE wt.balance_after_minutes IS NOT NULL
       ORDER BY wt.user_id, wt.created_at DESC, wt.id DESC
     )
     SELECT ls.user_id, ls.transaction_id, ls.transaction_type,
            ls.balance_after_minutes AS expected_minutes,
            uw.balance_minutes       AS actual_minutes,
            (ls.balance_after_minutes - uw.balance_minutes) AS diff
     FROM latest_snapshot ls
     JOIN user_wallets uw ON uw.user_id = ls.user_id
     WHERE ABS(ls.balance_after_minutes - uw.balance_minutes) > $2::numeric`,
    [effectiveLookback, effectiveEpsilon],
  );

  const discrepancies = [];
  let repaired = 0;

  for (const row of rows) {
    const expectedMinutes = parseFloat(row.expected_minutes);
    const actualMinutes = parseFloat(row.actual_minutes);
    const diff = parseFloat(row.diff);

    const detail = {
      userId: row.user_id,
      transactionId: row.transaction_id,
      transactionType: row.transaction_type,
      expectedMinutes,
      actualMinutes,
      diff,
      source,
    };

    logger.warn("[balance-reconcile] mismatch", detail);
    discrepancies.push(detail);

    if (effectiveAutoFix) {
      try {
        await repairWalletBalance({
          userId: row.user_id,
          transactionId: row.transaction_id,
          expectedMinutes,
          diff,
        });
        repaired += 1;
        logger.info("[balance-reconcile] repaired", detail);
      } catch (error) {
        logger.error("[balance-reconcile] repair failed", {
          ...detail,
          error: error.message,
        });
      }
    }
  }

  const summary = {
    source,
    lookbackHours: effectiveLookback,
    autoFix: effectiveAutoFix,
    checked: rows.length,
    discrepancies: discrepancies.length,
    repaired,
  };
  logger.info("[balance-reconcile] run complete", summary);

  return { ...summary, rows: discrepancies };
}

async function runReconciliationTick(source) {
  if (runInProgress) {
    return;
  }

  runInProgress = true;
  try {
    await reconcileRecentBalances({ source });
  } catch (error) {
    logger.error("Failed to reconcile wallet balances", {
      source,
      error: error.message,
    });
  } finally {
    runInProgress = false;
  }
}

async function runBalanceReconciliationOnStartup() {
  await runReconciliationTick("startup");
}

function startBalanceReconciliationScheduler() {
  const { enabled, intervalMinutes, lookbackHours, autoFix } =
    getSchedulerConfig();

  if (!enabled) {
    logger.info("Balance reconciliation scheduler disabled", {
      intervalMinutes,
      lookbackHours,
      autoFix,
    });
    return;
  }

  if (reconcileTimer) {
    return;
  }

  reconcileTimer = setInterval(
    () => {
      runReconciliationTick("interval");
    },
    intervalMinutes * 60 * 1000,
  );

  if (typeof reconcileTimer.unref === "function") {
    reconcileTimer.unref();
  }

  logger.info("Balance reconciliation scheduler started", {
    intervalMinutes,
    lookbackHours,
    autoFix,
  });
}

function stopBalanceReconciliationScheduler() {
  if (!reconcileTimer) {
    return;
  }

  clearInterval(reconcileTimer);
  reconcileTimer = null;
  logger.info("Balance reconciliation scheduler stopped");
}

module.exports = {
  getSchedulerConfig,
  reconcileRecentBalances,
  runBalanceReconciliationOnStartup,
  startBalanceReconciliationScheduler,
  stopBalanceReconciliationScheduler,
};
