const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const stripeLogger = require("../utils/stripeLogger");
const { mapStripeCardError } = require("../utils/stripeCardError");
const { resolvePaymentMethod } = require("./tipService");
const { calculateInclusiveTax } = require("./stripeTaxService");

const RATE_CACHE_TTL_MS = 60_000;
let cachedRates = null;
let cachedAt = 0;

async function getPaygRates({ forceRefresh = false } = {}) {
  const now = Date.now();
  if (!forceRefresh && cachedRates && now - cachedAt < RATE_CACHE_TTL_MS) {
    return cachedRates;
  }

  const result = await pool.query(
    `SELECT voice_rate_per_minute, chat_rate_per_minute, min_charge_cents, is_active
     FROM payg_rates
     WHERE is_active = true
     ORDER BY updated_at DESC
     LIMIT 1`,
  );

  if (result.rows.length === 0) {
    cachedRates = {
      voiceRatePerMinute: 0,
      chatRatePerMinute: 0,
      minChargeCents: 50,
      isActive: false,
    };
  } else {
    const row = result.rows[0];
    cachedRates = {
      voiceRatePerMinute: parseFloat(row.voice_rate_per_minute),
      chatRatePerMinute: parseFloat(row.chat_rate_per_minute),
      minChargeCents: parseInt(row.min_charge_cents, 10),
      isActive: row.is_active,
    };
  }

  cachedAt = now;
  return cachedRates;
}

class PaygError extends Error {
  constructor(code, message, meta = {}) {
    super(message);
    this.code = code;
    this.meta = meta;
  }
}

/**
 * Charge the user's saved payment method for a completed PAYG session.
 * Writes wallet_transactions + updates the session row's payg_* fields
 * via the provided dbClient (transactional caller).
 *
 * On Stripe failure, marks payg_locked_at on the wallet and records a
 * failed wallet_transactions row, then throws PaygError. The caller
 * decides whether to surface or swallow.
 */
async function chargePaygSession({
  userId,
  sessionType,
  sessionId,
  billableMinutes,
  discountPercent = 0,
  dbClient,
}) {
  if (!dbClient) throw new Error("chargePaygSession requires dbClient");
  if (!["call", "chat"].includes(sessionType)) {
    throw new Error(`Invalid sessionType: ${sessionType}`);
  }

  const rates = await getPaygRates();
  if (!rates.isActive) {
    throw new PaygError("PAYG_INACTIVE", "PAYG rates are not configured");
  }

  const ratePerMinute =
    sessionType === "call" ? rates.voiceRatePerMinute : rates.chatRatePerMinute;

  const rawCents = Math.round(billableMinutes * ratePerMinute * 100);
  const discountedRawCents = discountPercent > 0 ? Math.round(rawCents * (1 - discountPercent / 100)) : rawCents;
  const amountCents = Math.max(discountedRawCents, rates.minChargeCents);
  const amountDollars = amountCents / 100;

  const walletResult = await dbClient.query(
    `SELECT stripe_customer_id, default_payment_method, payg_locked_at
     FROM user_wallets WHERE user_id = $1
     FOR UPDATE`,
    [userId],
  );

  if (walletResult.rows.length === 0) {
    throw new PaygError("WALLET_MISSING", "Wallet not found");
  }
  const wallet = walletResult.rows[0];
  if (!wallet.stripe_customer_id) {
    throw new PaygError("NO_STRIPE_CUSTOMER", "No Stripe customer on file");
  }

  const paymentMethodId = await resolvePaymentMethod(
    wallet.stripe_customer_id,
    wallet.default_payment_method,
  );
  if (!paymentMethodId) {
    throw new PaygError("NO_PAYMENT_METHOD", "No saved payment method");
  }

  const sessionTable = sessionType === "call" ? "voice_calls" : "conversations";

  const paygStepCtx = { userId, sessionType, sessionId, amountCents };

  // Stripe Tax (inclusive): compute the embedded tax up front so we can record a
  // tax transaction after the charge. Inclusive => the charged amount is
  // unchanged. Best-effort: a null calculation just means we charge untaxed.
  const taxCalculation = await calculateInclusiveTax({
    customerId: wallet.stripe_customer_id,
    amountCents,
    currency: "usd",
    reference: `payg:${sessionId}`,
  });

  let paymentIntent;
  try {
    stripeLogger.attempt("paymentIntents.create:payg_session", paygStepCtx);
    paymentIntent = await stripe.paymentIntents.create(
      {
        amount: amountCents,
        currency: "usd",
        customer: wallet.stripe_customer_id,
        payment_method: paymentMethodId,
        off_session: true,
        confirm: true,
        metadata: {
          kind: "payg_session",
          session_type: sessionType,
          session_id: sessionId,
          user_id: userId,
          billable_minutes: String(billableMinutes),
          ...(taxCalculation ? { tax_calculation: taxCalculation.id } : {}),
        },
      },
      { idempotencyKey: `payg:${sessionId}` },
    );
    stripeLogger.success(
      "paymentIntents.create:payg_session",
      paymentIntent,
      paygStepCtx,
    );
  } catch (stripeErr) {
    const declineCode = stripeErr.code || stripeErr.decline_code || "stripe_error";
    stripeLogger.failure("paymentIntents.create:payg_session", stripeErr, {
      ...paygStepCtx,
      declineCode,
    });

    await dbClient.query(
      `UPDATE user_wallets
       SET payg_locked_at = NOW(), updated_at = NOW()
       WHERE user_id = $1`,
      [userId],
    );

    await dbClient.query(
      `UPDATE ${sessionTable}
       SET payg_charge_status = 'failed',
           payg_payment_intent_id = COALESCE($2, payg_payment_intent_id)
       WHERE id = $1`,
      [sessionId, stripeErr.payment_intent?.id || null],
    );

    await dbClient.query(
      `INSERT INTO wallet_transactions
        (user_id, transaction_type, amount_minutes, amount_currency,
         stripe_payment_intent_id, description, metadata)
       VALUES ($1, 'payg_charge', 0, $2, $3, $4, $5::jsonb)`,
      [
        userId,
        -amountDollars,
        stripeErr.payment_intent?.id || null,
        `PAYG ${sessionType} ${sessionId.substring(0, 8)} — DECLINED (${declineCode})`,
        JSON.stringify({
          status: "failed",
          decline_code: declineCode,
          session_type: sessionType,
          session_id: sessionId,
          billable_minutes: billableMinutes,
        }),
      ],
    );

    const mapped = mapStripeCardError(stripeErr);
    throw new PaygError("CHARGE_DECLINED", mapped.userMessage, {
      declineCode: mapped.declineCode || declineCode,
      code: mapped.code,
    });
  }

  await dbClient.query(
    `UPDATE ${sessionTable}
     SET payg_charge_status = 'succeeded',
         payg_payment_intent_id = $2
     WHERE id = $1`,
    [sessionId, paymentIntent.id],
  );

  await dbClient.query(
    `INSERT INTO wallet_transactions
      (user_id, transaction_type, amount_minutes, amount_currency,
       stripe_payment_intent_id, description, metadata)
     VALUES ($1, 'payg_charge', 0, $2, $3, $4, $5::jsonb)
     ON CONFLICT DO NOTHING`,
    [
      userId,
      -amountDollars,
      paymentIntent.id,
      `PAYG ${sessionType} ${sessionId.substring(0, 8)} (${billableMinutes} min @ $${ratePerMinute.toFixed(2)})`,
      JSON.stringify({
        status: "succeeded",
        session_type: sessionType,
        session_id: sessionId,
        billable_minutes: billableMinutes,
        rate_per_minute: ratePerMinute,
      }),
    ],
  );

  logger.info("PAYG charge succeeded", {
    userId,
    sessionType,
    sessionId,
    amountCents,
    paymentIntentId: paymentIntent.id,
  });

  return {
    paymentIntentId: paymentIntent.id,
    amountCents,
    amountDollars,
    ratePerMinute,
  };
}

module.exports = {
  getPaygRates,
  chargePaygSession,
  PaygError,
};
