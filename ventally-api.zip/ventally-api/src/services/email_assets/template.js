const fs = require("fs");
const path = require("path");

const EMAIL_TEMPLATES_DIR = path.join(__dirname, "..", "email_templates");

/**
 * Load an HTML email template from the email_templates directory.
 */
function loadTemplate(templateName) {
  const templatePath = path.join(EMAIL_TEMPLATES_DIR, templateName);
  if (!fs.existsSync(templatePath)) {
    throw new Error(`Template not found: ${templatePath}`);
  }
  return fs.readFileSync(templatePath, "utf-8");
}

/**
 * Replace {{VARIABLE}} placeholders in an HTML template.
 * Variable names may contain spaces (e.g. {{First Name}}).
 */
function replaceVariables(html, variables) {
  let result = html;
  for (const [key, value] of Object.entries(variables)) {
    const placeholder = new RegExp(`{{${key}}}`, "g");
    result = result.replace(placeholder, value);
  }
  return result;
}

/**
 * Render a template with the given variables.
 * {{YEAR}} is always injected automatically.
 */
function renderTemplate(templateName, variables = {}) {
  const html = loadTemplate(templateName);
  return replaceVariables(html, {
    YEAR: new Date().getFullYear().toString(),
    ...variables,
  });
}

// ---------------------------------------------------------------------------
// Existing email generators (updated to new templates)
// ---------------------------------------------------------------------------

function getVerificationEmailHtml({ firstName, otp, expiryMinutes } = {}) {
  return renderTemplate("Confirm Your Email.html", {
    "First Name": firstName || "there",
    OTP: otp || "",
    EXPIRY_MINUTES: expiryMinutes != null ? String(expiryMinutes) : "",
  });
}

function getPasswordResetEmailHtml({ firstName, otp, expiryMinutes } = {}) {
  return renderTemplate("Password Reset.html", {
    "First Name": firstName || "there",
    OTP: otp || "",
    EXPIRY_MINUTES: expiryMinutes != null ? String(expiryMinutes) : "",
  });
}

function getEmailChangeOtpHtml({ firstName, otp, expiryMinutes } = {}) {
  return renderTemplate("Email Change.html", {
    "First Name": firstName || "there",
    OTP: otp || "",
    EXPIRY_MINUTES: expiryMinutes != null ? String(expiryMinutes) : "",
  });
}

function getEmailUpdatedEmailHtml() {
  return renderTemplate("Email Change.html");
}

function getCrisisCallFollowUpEmailHtml() {
  return renderTemplate("Crisis Call Follow Up.html");
}

function getPhoneUpdatedEmailHtml() {
  return renderTemplate("Phone Number Confirmation.html");
}

function getCreditPurchaseEmailHtml() {
  return renderTemplate("Minutes Purchased.html");
}

function getSubscriptionActivationEmailHtml() {
  return renderTemplate("Plan Purchase.html");
}

// ---------------------------------------------------------------------------
// New email generators
// ---------------------------------------------------------------------------

function getTwoFactorAuthEmailHtml({ firstName, code }) {
  return renderTemplate("Two Factor Authorization.html", {
    "First Name": firstName || "there",
    CODE: code || "",
  });
}

function getAppealReceivedEmailHtml({ firstName }) {
  return renderTemplate("Appeal Received.html", {
    "First Name": firstName || "there",
  });
}

function getListenerApprovalEmailHtml({ firstName }) {
  return renderTemplate("Listener Approval.html", {
    "First Name": firstName || "there",
  });
}

function getListenerDeniedEmailHtml({ firstName }) {
  return renderTemplate("Listener Denied.html", {
    "First Name": firstName || "there",
  });
}

function getListenerSignUpConfirmationEmailHtml({ firstName }) {
  return renderTemplate("Listener Sign Up Confirmation.html", {
    "First Name": firstName || "there",
  });
}

function getPaymentFailedEmailHtml({ firstName }) {
  return renderTemplate("Payment Failed.html", {
    "First Name": firstName || "there",
  });
}

function getPlanCancelledEmailHtml({ firstName }) {
  return renderTemplate("Plan Cancelled.html", {
    "First Name": firstName || "there",
  });
}

function getRefundConfirmationEmailHtml({ firstName }) {
  return renderTemplate("Refund Confirmation.html", {
    "First Name": firstName || "there",
  });
}

function getSupportTicketReceivedEmailHtml() {
  return renderTemplate("Support Ticket Received.html");
}

function getAbandonedSignupEmailHtml({ signupUrl } = {}) {
  return renderTemplate("Abandoned Signup.html", {
    SIGNUP_URL: signupUrl || "https://ventally.co/signup",
  });
}

module.exports = {
  getVerificationEmailHtml,
  getPasswordResetEmailHtml,
  getEmailChangeOtpHtml,
  getEmailUpdatedEmailHtml,
  getCrisisCallFollowUpEmailHtml,
  getPhoneUpdatedEmailHtml,
  getCreditPurchaseEmailHtml,
  getSubscriptionActivationEmailHtml,
  getTwoFactorAuthEmailHtml,
  getAppealReceivedEmailHtml,
  getListenerApprovalEmailHtml,
  getListenerDeniedEmailHtml,
  getListenerSignUpConfirmationEmailHtml,
  getPaymentFailedEmailHtml,
  getPlanCancelledEmailHtml,
  getRefundConfirmationEmailHtml,
  getSupportTicketReceivedEmailHtml,
  getAbandonedSignupEmailHtml,
};
