const { pool } = require("../database/connection");
const logger = require("../utils/logger");

const DEFAULT_ENABLED = true;
const DEFAULT_HOLD_HOURS = 0;
const DEFAULT_INTERVAL_MINUTES = 10;

let releaseTimer = null;
let runInProgress = false;

function parseBoolean(value, fallback) {
  if (value === undefined || value === null || value === "") {
    return fallback;
  }

  const normalized = String(value).trim().toLowerCase();
  return ["1", "true", "yes", "on"].includes(normalized);
}

function parseNonNegativeInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return fallback;
  }

  return parsed;
}

function getSchedulerConfig() {
  const enabled = parseBoolean(
    process.env.LISTENER_EARNINGS_RELEASE_ENABLED,
    DEFAULT_ENABLED,
  );
  const holdHours = parseNonNegativeInteger(
    process.env.LISTENER_EARNINGS_HOLD_HOURS,
    DEFAULT_HOLD_HOURS,
  );
  const intervalMinutes = Math.max(
    1,
    parseNonNegativeInteger(
      process.env.LISTENER_EARNINGS_RELEASE_INTERVAL_MINUTES,
      DEFAULT_INTERVAL_MINUTES,
    ),
  );

  return {
    enabled,
    holdHours,
    intervalMinutes,
  };
}

async function releasePendingEarnings({ source = "manual" } = {}) {
  const { enabled, holdHours } = getSchedulerConfig();

  if (!enabled) {
    return {
      skipped: true,
      reason: "disabled",
      updatedRows: 0,
      holdHours,
    };
  }

  const result = await pool.query(
    `UPDATE listener_earnings
     SET status = 'available'
     WHERE status = 'pending'
       AND (net_amount - COALESCE(paid_amount, 0)) > 0
       AND created_at <= NOW() - ($1::int * INTERVAL '1 hour')`,
    [holdHours],
  );

  const updatedRows = result.rowCount || 0;

  if (updatedRows > 0) {
    logger.info("Released pending listener earnings", {
      source,
      updatedRows,
      holdHours,
    });
  }

  return {
    skipped: false,
    updatedRows,
    holdHours,
  };
}

async function runReleaseTick(source) {
  if (runInProgress) {
    return;
  }

  runInProgress = true;
  try {
    await releasePendingEarnings({ source });
  } catch (error) {
    logger.error("Failed to release pending listener earnings", {
      source,
      error: error.message,
    });
  } finally {
    runInProgress = false;
  }
}

async function runPendingEarningsReleaseOnStartup() {
  await runReleaseTick("startup");
}

function startPendingEarningsReleaseScheduler() {
  const { enabled, holdHours, intervalMinutes } = getSchedulerConfig();

  if (!enabled) {
    logger.info("Listener earnings release scheduler disabled", {
      holdHours,
      intervalMinutes,
    });
    return;
  }

  if (releaseTimer) {
    return;
  }

  releaseTimer = setInterval(
    () => {
      runReleaseTick("interval");
    },
    intervalMinutes * 60 * 1000,
  );

  if (typeof releaseTimer.unref === "function") {
    releaseTimer.unref();
  }

  logger.info("Listener earnings release scheduler started", {
    holdHours,
    intervalMinutes,
  });
}

function stopPendingEarningsReleaseScheduler() {
  if (!releaseTimer) {
    return;
  }

  clearInterval(releaseTimer);
  releaseTimer = null;
  logger.info("Listener earnings release scheduler stopped");
}

module.exports = {
  getSchedulerConfig,
  releasePendingEarnings,
  runPendingEarningsReleaseOnStartup,
  startPendingEarningsReleaseScheduler,
  stopPendingEarningsReleaseScheduler,
};
