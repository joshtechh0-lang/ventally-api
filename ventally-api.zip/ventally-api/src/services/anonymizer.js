const { pool } = require("../database/connection");
const { redisClient } = require("./redis");
const logger = require("../utils/logger");
const crypto = require("crypto");

const REDIS_IDENTITY_PREFIX = "identity:";
const IDENTITY_TTL = 24 * 60 * 60; // 24 hours

/**
 * Generate a random anonymous name from database parts
 * @returns {Promise<string>} Anonymous name like "Swift Fox"
 */
async function generateAnonymousName() {
  try {
    const result = await pool.query(`
      WITH random_adjective AS (
        SELECT value FROM anonymous_name_parts 
        WHERE part_type = 'adjective' 
        ORDER BY RANDOM() 
        LIMIT 1
      ),
      random_noun AS (
        SELECT value FROM anonymous_name_parts 
        WHERE part_type = 'noun' 
        ORDER BY RANDOM() 
        LIMIT 1
      )
      SELECT 
        (SELECT value FROM random_adjective) || ' ' || (SELECT value FROM random_noun) AS name
    `);

    if (result.rows.length === 0) {
      logger.warn("No anonymous name parts found in database, using fallback");
      return `Anonymous User ${Math.floor(Math.random() * 10000)}`;
    }

    return result.rows[0].name;
  } catch (error) {
    logger.error(`Error generating anonymous name: ${error.message}`);
    return `Anonymous User ${Math.floor(Math.random() * 10000)}`;
  }
}

/**
 * Generate a random avatar seed for deterministic avatar generation on client
 * @returns {string} Random seed string
 */
function generateAvatarSeed() {
  return crypto.randomBytes(16).toString("hex");
}

/**
 * Create a session identity for a user
 * @param {string} userId - User UUID
 * @param {string} sessionId - Session UUID
 * @param {string} sessionType - 'call' or 'chat'
 * @returns {Promise<Object>} Identity object
 */
async function createSessionIdentity(userId, sessionId, sessionType) {
  try {
    const anonymousName = await generateAnonymousName();
    const avatarSeed = generateAvatarSeed();

    const result = await pool.query(
      `INSERT INTO session_identities 
        (user_id, session_id, session_type, anonymous_name, avatar_seed)
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (session_id, user_id) 
      DO UPDATE SET 
        anonymous_name = EXCLUDED.anonymous_name,
        avatar_seed = EXCLUDED.avatar_seed
      RETURNING *`,
      [userId, sessionId, sessionType, anonymousName, avatarSeed],
    );

    const identity = result.rows[0];

    // Cache in Redis
    const cacheKey = `${REDIS_IDENTITY_PREFIX}${sessionId}:${userId}`;
    await redisClient.setEx(
      cacheKey,
      IDENTITY_TTL,
      JSON.stringify({
        anonymousName: identity.anonymous_name,
        avatarSeed: identity.avatar_seed,
        userId: identity.user_id,
      }),
    );

    logger.info(
      `Created session identity for user ${userId} in session ${sessionId}: ${anonymousName}`,
    );

    return {
      anonymousName: identity.anonymous_name,
      avatarSeed: identity.avatar_seed,
      userId: identity.user_id,
    };
  } catch (error) {
    logger.error(`Error creating session identity: ${error.message}`);
    throw error;
  }
}

/**
 * Get session identity for a user
 * @param {string} sessionId - Session UUID
 * @param {string} userId - User UUID
 * @returns {Promise<Object|null>} Identity object or null
 */
async function getSessionIdentity(sessionId, userId) {
  try {
    // Try cache first
    const cacheKey = `${REDIS_IDENTITY_PREFIX}${sessionId}:${userId}`;
    const cached = await redisClient.get(cacheKey);

    if (cached) {
      return JSON.parse(cached);
    }

    // Query database
    const result = await pool.query(
      `SELECT anonymous_name, avatar_seed, user_id 
       FROM session_identities 
       WHERE session_id = $1 AND user_id = $2`,
      [sessionId, userId],
    );

    if (result.rows.length === 0) {
      return null;
    }

    const identity = {
      anonymousName: result.rows[0].anonymous_name,
      avatarSeed: result.rows[0].avatar_seed,
      userId: result.rows[0].user_id,
    };

    // Cache for future requests
    await redisClient.setEx(cacheKey, IDENTITY_TTL, JSON.stringify(identity));

    return identity;
  } catch (error) {
    logger.error(`Error getting session identity: ${error.message}`);
    return null;
  }
}

/**
 * Get both participants' anonymous identities for a session
 * @param {string} sessionId - Session UUID
 * @param {string} sessionType - 'call' or 'chat'
 * @returns {Promise<Array>} Array of identity objects
 */
async function getSessionParticipants(sessionId, sessionType) {
  try {
    const result = await pool.query(
      `SELECT user_id, anonymous_name, avatar_seed 
       FROM session_identities 
       WHERE session_id = $1 AND session_type = $2 
       ORDER BY created_at ASC`,
      [sessionId, sessionType],
    );

    return result.rows.map((row) => ({
      userId: row.user_id,
      anonymousName: row.anonymous_name,
      avatarSeed: row.avatar_seed,
    }));
  } catch (error) {
    logger.error(`Error getting session participants: ${error.message}`);
    return [];
  }
}

/**
 * Get the other participant's identity in a session
 * @param {string} sessionId - Session UUID
 * @param {string} myUserId - Current user's UUID
 * @param {string} sessionType - 'call' or 'chat'
 * @returns {Promise<Object|null>} Other user's identity
 */
async function getOtherParticipantIdentity(sessionId, myUserId, sessionType) {
  try {
    const result = await pool.query(
      `SELECT user_id, anonymous_name, avatar_seed 
       FROM session_identities 
       WHERE session_id = $1 AND session_type = $2 AND user_id != $3
       LIMIT 1`,
      [sessionId, sessionType, myUserId],
    );

    if (result.rows.length === 0) {
      return null;
    }

    return {
      userId: result.rows[0].user_id,
      anonymousName: result.rows[0].anonymous_name,
      avatarSeed: result.rows[0].avatar_seed,
    };
  } catch (error) {
    logger.error(`Error getting other participant identity: ${error.message}`);
    return null;
  }
}

/**
 * Clear session identities from cache
 * @param {string} sessionId - Session UUID
 */
async function clearSessionIdentityCache(sessionId) {
  try {
    const pattern = `${REDIS_IDENTITY_PREFIX}${sessionId}:*`;
    const keys = await redisClient.keys(pattern);

    if (keys.length > 0) {
      await redisClient.del(keys);
      logger.info(
        `Cleared ${keys.length} identity cache entries for session ${sessionId}`,
      );
    }
  } catch (error) {
    logger.error(`Error clearing session identity cache: ${error.message}`);
  }
}

module.exports = {
  generateAnonymousName,
  generateAvatarSeed,
  createSessionIdentity,
  getSessionIdentity,
  getSessionParticipants,
  getOtherParticipantIdentity,
  clearSessionIdentityCache,
};
