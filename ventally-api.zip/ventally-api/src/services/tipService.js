const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const presence = require("../services/presence");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const logger = require("../utils/logger");
const stripeLogger = require("../utils/stripeLogger");
const { mapStripeCardError } = require("../utils/stripeCardError");
const { calculateInclusiveTax } = require("./stripeTaxService");

const TIP_WINDOW_HOURS = 24;
const TIP_MIN_AMOUNT = 0.5;
const TIP_MAX_AMOUNT = 500;
const TIP_CURRENCY = "usd";
const CALL_AUTO_END_STATUSES = [
  "requesting",
  "ringing",
  "active",
  "initiated",
  "in-progress",
];
const CHAT_AUTO_END_STATUSES = ["active", "requesting", "ringing"];

class TipError extends Error {
  constructor(statusCode, message, code) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

function toMoney(value) {
  return Math.round((parseFloat(value) + Number.EPSILON) * 100) / 100;
}

function parseTipAmount(amountRaw) {
  const amount = parseFloat(amountRaw);

  if (Number.isNaN(amount)) {
    throw new TipError(
      400,
      "Tip amount must be a valid number",
      "invalid_amount",
    );
  }

  if (amount < TIP_MIN_AMOUNT || amount > TIP_MAX_AMOUNT) {
    throw new TipError(
      422,
      `Tip amount must be between $${TIP_MIN_AMOUNT.toFixed(2)} and $${TIP_MAX_AMOUNT.toFixed(2)}`,
      "amount_out_of_bounds",
    );
  }

  return toMoney(amount);
}

function normalizeMessage(message) {
  if (message === undefined || message === null) {
    return null;
  }

  if (typeof message !== "string") {
    throw new TipError(400, "Tip message must be a string", "invalid_message");
  }

  const trimmed = message.trim();
  if (trimmed.length === 0) {
    return null;
  }

  if (trimmed.length > 500) {
    throw new TipError(
      422,
      "Tip message cannot exceed 500 characters",
      "message_too_long",
    );
  }

  return trimmed;
}

async function resolvePaymentMethod(customerId, fallbackPaymentMethod) {
  if (!stripe) {
    return null;
  }

  if (fallbackPaymentMethod) {
    return fallbackPaymentMethod;
  }

  const customer = await stripe.customers.retrieve(customerId);
  if (customer?.invoice_settings?.default_payment_method) {
    return customer.invoice_settings.default_payment_method;
  }

  const paymentMethods = await stripe.paymentMethods.list({
    customer: customerId,
    type: "card",
    limit: 1,
  });

  return paymentMethods.data[0]?.id || null;
}

async function fetchEligibleCall(client, sessionId, venterId) {
  const sessionResult = await client.query(
    `SELECT id, venter_id, listener_id, status, ended_at
     FROM voice_calls
     WHERE id = $1`,
    [sessionId],
  );

  if (sessionResult.rows.length === 0) {
    throw new TipError(404, "Call not found", "call_not_found");
  }

  const session = sessionResult.rows[0];

  if (session.venter_id !== venterId) {
    throw new TipError(
      403,
      "Only the venter who started this call can send a tip",
      "not_call_venter",
    );
  }

  if (session.status !== "ended" || !session.ended_at) {
    if (CALL_AUTO_END_STATUSES.includes(session.status)) {
      const endResult = await client.query(
        `UPDATE voice_calls
         SET status = 'ended', ended_at = COALESCE(ended_at, NOW())
         WHERE id = $1
         RETURNING status, ended_at`,
        [sessionId],
      );

      session.status = endResult.rows[0].status;
      session.ended_at = endResult.rows[0].ended_at;
      session.auto_ended_for_tip = true;
    } else {
      throw new TipError(
        409,
        "Tips are only allowed after the call has ended",
        "call_not_ended",
      );
    }
  }

  const hoursSinceEnd =
    (Date.now() - new Date(session.ended_at).getTime()) / (1000 * 60 * 60);

  if (hoursSinceEnd > TIP_WINDOW_HOURS) {
    throw new TipError(
      422,
      `Tip window expired. Tips are allowed within ${TIP_WINDOW_HOURS} hours after call end`,
      "tip_window_expired",
    );
  }

  return session;
}

async function fetchEligibleChat(client, sessionId, venterId) {
  const sessionResult = await client.query(
    `SELECT id, venter_id, listener_id, status, ended_at
     FROM conversations
     WHERE id = $1`,
    [sessionId],
  );

  if (sessionResult.rows.length === 0) {
    throw new TipError(404, "Chat session not found", "chat_not_found");
  }

  const session = sessionResult.rows[0];

  if (session.venter_id !== venterId) {
    throw new TipError(
      403,
      "Only the venter who started this chat can send a tip",
      "not_chat_venter",
    );
  }

  if (session.status !== "ended" || !session.ended_at) {
    if (CHAT_AUTO_END_STATUSES.includes(session.status)) {
      const endResult = await client.query(
        `UPDATE conversations
         SET status = 'ended', ended_at = COALESCE(ended_at, NOW())
         WHERE id = $1
         RETURNING status, ended_at`,
        [sessionId],
      );

      session.status = endResult.rows[0].status;
      session.ended_at = endResult.rows[0].ended_at;
      session.auto_ended_for_tip = true;
    } else {
      throw new TipError(
        409,
        "Tips are only allowed after the chat has ended",
        "chat_not_ended",
      );
    }
  }

  const hoursSinceEnd =
    (Date.now() - new Date(session.ended_at).getTime()) / (1000 * 60 * 60);

  if (hoursSinceEnd > TIP_WINDOW_HOURS) {
    throw new TipError(
      422,
      `Tip window expired. Tips are allowed within ${TIP_WINDOW_HOURS} hours after chat end`,
      "tip_window_expired",
    );
  }

  return session;
}

async function fetchEligibleSession(client, sessionId, venterId) {
  try {
    const session = await fetchEligibleCall(client, sessionId, venterId);
    return {
      session,
      sessionType: "call",
    };
  } catch (error) {
    if (!(error instanceof TipError) || error.code !== "call_not_found") {
      throw error;
    }
  }

  try {
    const session = await fetchEligibleChat(client, sessionId, venterId);
    return {
      session,
      sessionType: "chat",
    };
  } catch (error) {
    if (error instanceof TipError && error.code === "chat_not_found") {
      throw new TipError(404, "Session not found", "session_not_found");
    }
    throw error;
  }
}

function buildTipMetadata(tip, amount, currency, sessionType, sessionId) {
  const metadata = {
    feature: "listener_tip",
    tip_id: String(tip.id),
    session_type: sessionType,
    session_id: String(sessionId),
    venter_id: String(tip.venter_id),
    listener_id: String(tip.listener_id),
    amount_currency: amount.toFixed(2),
    currency,
  };

  if (tip.call_id) {
    metadata.call_id = String(tip.call_id);
  }

  return metadata;
}

async function insertTipEarningsRecord(client, tipId, listenerId, amount) {
  const existingResult = await client.query(
    `SELECT id
     FROM listener_earnings
     WHERE session_type = 'tip' AND session_id = $1
     LIMIT 1`,
    [tipId],
  );

  if (existingResult.rows.length > 0) {
    return;
  }

  await client.query(
    `INSERT INTO listener_earnings
      (listener_id, session_type, session_id, gross_amount, platform_fee, net_amount, platform_fee_percentage, status)
     VALUES ($1, 'tip', $2, $3, 0, $3, 0, 'pending')`,
    [listenerId, tipId, amount],
  );
}

async function insertWalletTransactionIfMissing(client, params) {
  const {
    userId,
    transactionType,
    amountCurrency,
    stripePaymentIntentId,
    description,
    metadata,
    balanceAfterCurrency,
  } = params;

  if (stripePaymentIntentId) {
    const existing = await client.query(
      `SELECT id
       FROM wallet_transactions
       WHERE stripe_payment_intent_id = $1 AND transaction_type = $2
       LIMIT 1`,
      [stripePaymentIntentId, transactionType],
    );

    if (existing.rows.length > 0) {
      return;
    }
  }

  await client.query(
    `INSERT INTO wallet_transactions
      (user_id, transaction_type, amount_currency, balance_after_currency, stripe_payment_intent_id, description, metadata)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [
      userId,
      transactionType,
      amountCurrency,
      balanceAfterCurrency || null,
      stripePaymentIntentId || null,
      description,
      metadata ? JSON.stringify(metadata) : null,
    ],
  );
}

async function markTipCompletedById({ tipId, stripePaymentIntentId = null }) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const tipResult = await client.query(
      `SELECT *
       FROM listener_tips
       WHERE id = $1
       FOR UPDATE`,
      [tipId],
    );

    if (tipResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return null;
    }

    const tip = tipResult.rows[0];

    if (tip.status === "completed") {
      await client.query("COMMIT");
      return tip;
    }

    const metadata = {
      feature: "listener_tip",
      tip_id: tip.id,
      session_type: tip.session_type,
      session_id: tip.session_id,
      call_id: tip.call_id,
    };

    const subjectLabel = tip.session_type === "chat" ? "chat" : "call";
    const subjectId = String(tip.session_id || tip.call_id).substring(0, 8);

    await client.query(
      `UPDATE listener_tips
       SET status = 'completed',
           completed_at = NOW(),
           stripe_payment_intent_id = COALESCE($1, stripe_payment_intent_id),
           failure_reason = NULL
       WHERE id = $2`,
      [stripePaymentIntentId, tip.id],
    );

    await insertWalletTransactionIfMissing(client, {
      userId: tip.venter_id,
      transactionType: "tip_sent",
      amountCurrency: -parseFloat(tip.amount_currency),
      stripePaymentIntentId:
        stripePaymentIntentId || tip.stripe_payment_intent_id,
      description: `Tip sent for ${subjectLabel} ${subjectId}`,
      metadata,
    });

    await insertWalletTransactionIfMissing(client, {
      userId: tip.listener_id,
      transactionType: "tip_received",
      amountCurrency: parseFloat(tip.amount_currency),
      stripePaymentIntentId:
        stripePaymentIntentId || tip.stripe_payment_intent_id,
      description: `Tip received for ${subjectLabel} ${subjectId}`,
      metadata,
    });

    await insertTipEarningsRecord(
      client,
      tip.id,
      tip.listener_id,
      parseFloat(tip.amount_currency),
    );

    await client.query("COMMIT");

    return {
      ...tip,
      status: "completed",
      stripe_payment_intent_id:
        stripePaymentIntentId || tip.stripe_payment_intent_id,
    };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

async function markTipFailedByIntent(paymentIntent) {
  const tipId = paymentIntent.metadata?.tip_id;
  if (!tipId) {
    return null;
  }

  const failureReason =
    paymentIntent.last_payment_error?.message || "Payment failed";

  const result = await pool.query(
    `UPDATE listener_tips
     SET status = CASE WHEN status = 'completed' THEN status ELSE 'failed' END,
         failure_reason = CASE WHEN status = 'completed' THEN failure_reason ELSE $1 END,
         stripe_payment_intent_id = COALESCE(stripe_payment_intent_id, $2)
     WHERE id = $3
     RETURNING *`,
    [failureReason, paymentIntent.id, tipId],
  );

  return result.rows[0] || null;
}

async function createTip({
  venterId,
  sessionId,
  amountRaw,
  message,
  io,
}) {
  const amount = parseTipAmount(amountRaw);
  const normalizedMessage = normalizeMessage(message);
  let detectedSessionType = null;

  const client = await pool.connect();
  let inTransaction = false;
  let pendingStripeTipId = null;

  async function runPostAutoEndCleanup(sessionType, session) {
    if (!session?.auto_ended_for_tip) {
      return;
    }

    if (sessionType === "call") {
      try {
        await stopBalanceMonitoring(session.id);
      } catch (monitorError) {
        logger.warn("Failed stopping balance monitor after tip auto-end", {
          callId: session.id,
          error: monitorError.message,
        });
      }
    }

    await presence.clearListenerBusy(session.listener_id);
  }

  try {
    await client.query("BEGIN");
    inTransaction = true;

    const { session, sessionType } = await fetchEligibleSession(
      client,
      sessionId,
      venterId,
    );
    detectedSessionType = sessionType;

    const callId = sessionType === "call" ? session.id : null;

    const walletResult = await client.query(
      `SELECT balance_currency, currency_code, stripe_customer_id, default_payment_method
       FROM user_wallets
       WHERE user_id = $1
       FOR UPDATE`,
      [venterId],
    );

    if (walletResult.rows.length === 0) {
      throw new TipError(404, "Wallet not found", "wallet_not_found");
    }

    const wallet = walletResult.rows[0];
    const walletBalance = parseFloat(wallet.balance_currency || 0);

    const baseTipValues = [
      callId,
      sessionType,
      session.id,
      venterId,
      session.listener_id,
      amount,
      (wallet.currency_code || "USD").toUpperCase(),
      normalizedMessage,
    ];

    if (walletBalance >= amount) {
      const newBalance = toMoney(walletBalance - amount);

      await client.query(
        `UPDATE user_wallets
         SET balance_currency = $1,
             updated_at = NOW()
         WHERE user_id = $2`,
        [newBalance, venterId],
      );

      const tipResult = await client.query(
        `INSERT INTO listener_tips
          (call_id, session_type, session_id, venter_id, listener_id, amount_currency, currency, message, payment_source, status, completed_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'wallet', 'completed', NOW())
         RETURNING *`,
        baseTipValues,
      );

      const tip = tipResult.rows[0];
      const metadata = buildTipMetadata(
        tip,
        amount,
        tip.currency,
        sessionType,
        session.id,
      );
      const subjectLabel = sessionType === "chat" ? "chat" : "call";
      const subjectId = String(session.id).substring(0, 8);

      await insertWalletTransactionIfMissing(client, {
        userId: venterId,
        transactionType: "tip_sent",
        amountCurrency: -amount,
        description: `Tip sent for ${subjectLabel} ${subjectId}`,
        metadata,
        balanceAfterCurrency: newBalance,
      });

      await insertWalletTransactionIfMissing(client, {
        userId: session.listener_id,
        transactionType: "tip_received",
        amountCurrency: amount,
        description: `Tip received for ${subjectLabel} ${subjectId}`,
        metadata,
      });

      await insertTipEarningsRecord(client, tip.id, session.listener_id, amount);

      await client.query("COMMIT");
      inTransaction = false;

      await runPostAutoEndCleanup(sessionType, session);

      if (io) {
        io.to(String(session.listener_id)).emit("tip:received", {
          tipId: tip.id,
          sessionId: session.id,
          sessionType,
          callId,
          amount,
          message: normalizedMessage,
          source: "wallet",
          createdAt: tip.created_at,
        });

        io.to(String(venterId)).emit("tip:sent", {
          tipId: tip.id,
          sessionId: session.id,
          sessionType,
          callId,
          amount,
          status: "completed",
          source: "wallet",
          createdAt: tip.created_at,
        });
      }

      return {
        status: "completed",
        paymentSource: "wallet",
        tip,
      };
    }

    if (!stripe) {
      throw new TipError(
        503,
        "Stripe is not configured for tip card payments",
        "stripe_not_configured",
      );
    }

    if (!wallet.stripe_customer_id) {
      throw new TipError(
        402,
        "No payment method available. Please add a card first",
        "missing_payment_method",
      );
    }

    const tipInsertResult = await client.query(
      `INSERT INTO listener_tips
        (call_id, session_type, session_id, venter_id, listener_id, amount_currency, currency, message, payment_source, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'stripe', 'pending')
       RETURNING *`,
      baseTipValues,
    );

    const pendingTip = tipInsertResult.rows[0];
    pendingStripeTipId = pendingTip.id;

    await client.query("COMMIT");
    inTransaction = false;

    await runPostAutoEndCleanup(sessionType, session);

    const paymentMethodId = await resolvePaymentMethod(
      wallet.stripe_customer_id,
      wallet.default_payment_method,
    );

    if (!paymentMethodId) {
      await pool.query(
        `UPDATE listener_tips
         SET status = 'failed', failure_reason = $1
         WHERE id = $2`,
        ["No default payment method found", pendingTip.id],
      );

      throw new TipError(
        402,
        "No payment method available. Please add a card first",
        "missing_payment_method",
      );
    }

    const tipStepCtx = {
      venterId,
      sessionType,
      sessionId: session.id,
      tipId: pendingTip.id,
      amount,
    };

    const tipAmountCents = Math.round(amount * 100);

    // Stripe Tax (inclusive): compute the embedded tax up front so we can record
    // a tax transaction after the charge. Inclusive => the charged amount is
    // unchanged. Best-effort: a null calculation just means we charge untaxed.
    const taxCalculation = await calculateInclusiveTax({
      customerId: wallet.stripe_customer_id,
      amountCents: tipAmountCents,
      currency: TIP_CURRENCY,
      reference: `tip:${pendingTip.id}`,
    });

    let paymentIntent;
    try {
      stripeLogger.attempt("paymentIntents.create:listener_tip", tipStepCtx);
      paymentIntent = await stripe.paymentIntents.create({
        amount: tipAmountCents,
        currency: TIP_CURRENCY,
        customer: wallet.stripe_customer_id,
        payment_method: paymentMethodId,
        off_session: true,
        confirm: true,
        metadata: {
          user_id: String(venterId),
          ...buildTipMetadata(
            pendingTip,
            amount,
            TIP_CURRENCY.toUpperCase(),
            sessionType,
            session.id,
          ),
          ...(taxCalculation ? { tax_calculation: taxCalculation.id } : {}),
        },
        description: `Listener tip for ${sessionType} ${String(session.id).substring(0, 8)}`,
      });
      stripeLogger.success(
        "paymentIntents.create:listener_tip",
        paymentIntent,
        tipStepCtx,
      );
    } catch (stripeErr) {
      stripeLogger.failure(
        "paymentIntents.create:listener_tip",
        stripeErr,
        tipStepCtx,
      );
      throw stripeErr;
    }

    await pool.query(
      `UPDATE listener_tips
       SET stripe_payment_intent_id = $1
       WHERE id = $2`,
      [paymentIntent.id, pendingTip.id],
    );

    let finalStatus = "pending";
    if (paymentIntent.status === "succeeded") {
      await markTipCompletedById({
        tipId: pendingTip.id,
        stripePaymentIntentId: paymentIntent.id,
      });
      finalStatus = "completed";

      if (io) {
        io.to(String(session.listener_id)).emit("tip:received", {
          tipId: pendingTip.id,
          sessionId: session.id,
          sessionType,
          callId,
          amount,
          message: normalizedMessage,
          source: "stripe",
          createdAt: pendingTip.created_at,
        });

        io.to(String(venterId)).emit("tip:sent", {
          tipId: pendingTip.id,
          sessionId: session.id,
          sessionType,
          callId,
          amount,
          status: "completed",
          source: "stripe",
          createdAt: pendingTip.created_at,
        });
      }
    }

    return {
      status: finalStatus,
      paymentSource: "stripe",
      tip: {
        ...pendingTip,
        stripe_payment_intent_id: paymentIntent.id,
      },
      paymentIntent: {
        id: paymentIntent.id,
        status: paymentIntent.status,
      },
    };
  } catch (error) {
    if (inTransaction) {
      await client.query("ROLLBACK");
      inTransaction = false;
    }

    if (pendingStripeTipId) {
      try {
        await pool.query(
          `UPDATE listener_tips
           SET status = 'failed',
               failure_reason = COALESCE($1, 'Payment failed')
           WHERE id = $2 AND status = 'pending'`,
          [error.message, pendingStripeTipId],
        );
      } catch (statusError) {
        logger.error("Failed to mark pending tip as failed", {
          tipId: pendingStripeTipId,
          error: statusError.message,
        });
      }
    }

    if (error?.code === "23505") {
      throw new TipError(
        409,
        "You already tipped this session",
        "tip_already_exists",
      );
    }

    if (error.type === "StripeCardError") {
      const mapped = mapStripeCardError(error);
      logger.warn("Stripe declined tip payment", {
        venterId,
        sessionId,
        sessionType: detectedSessionType,
        code: mapped.code,
        declineCode: mapped.declineCode,
        error: error.message,
      });
      throw new TipError(mapped.statusCode, mapped.userMessage, mapped.code);
    }

    throw error;
  } finally {
    client.release();
  }
}

async function completeStripeTipFromPaymentIntent(paymentIntent) {
  const tipId = paymentIntent.metadata?.tip_id;
  if (!tipId) {
    return null;
  }

  return markTipCompletedById({
    tipId,
    stripePaymentIntentId: paymentIntent.id,
  });
}

async function getTipsForUser({ userId, direction, limit = 20, offset = 0 }) {
  const isSent = direction === "sent";

  const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
  const parsedOffset = Math.max(parseInt(offset, 10) || 0, 0);

  const userColumn = isSent ? "venter_id" : "listener_id";

  const queryResult = await pool.query(
    `SELECT lt.id,
            lt.call_id,
          lt.session_type,
          lt.session_id,
            lt.venter_id,
            lt.listener_id,
            lt.amount_currency,
            lt.currency,
            lt.message,
            lt.payment_source,
            lt.status,
            lt.created_at,
            lt.completed_at,
            lt.failure_reason
     FROM listener_tips lt
     WHERE lt.${userColumn} = $1
     ORDER BY lt.created_at DESC
     LIMIT $2 OFFSET $3`,
    [userId, parsedLimit, parsedOffset],
  );

  const countResult = await pool.query(
    `SELECT COUNT(*) AS total
     FROM listener_tips
     WHERE ${userColumn} = $1`,
    [userId],
  );

  return {
    tips: queryResult.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total, 10),
      limit: parsedLimit,
      offset: parsedOffset,
      hasMore:
        parsedOffset + queryResult.rows.length <
        parseInt(countResult.rows[0].total, 10),
    },
  };
}

async function getTipById({ tipId, userId }) {
  const result = await pool.query(
    `SELECT id,
            call_id,
          session_type,
          session_id,
            venter_id,
            listener_id,
            amount_currency,
            currency,
            message,
            payment_source,
            status,
            created_at,
            completed_at,
            failure_reason
     FROM listener_tips
     WHERE id = $1`,
    [tipId],
  );

  if (result.rows.length === 0) {
    throw new TipError(404, "Tip not found", "tip_not_found");
  }

  const tip = result.rows[0];

  if (tip.venter_id !== userId && tip.listener_id !== userId) {
    throw new TipError(403, "Permission denied", "not_tip_participant");
  }

  return tip;
}

module.exports = {
  TIP_WINDOW_HOURS,
  TIP_MIN_AMOUNT,
  TIP_MAX_AMOUNT,
  TIP_CURRENCY,
  TipError,
  createTip,
  completeStripeTipFromPaymentIntent,
  markTipFailedByIntent,
  getTipsForUser,
  getTipById,
  resolvePaymentMethod,
};
