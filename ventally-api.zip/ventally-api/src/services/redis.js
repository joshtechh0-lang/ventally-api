const redis = require("redis");
const logger = require("../utils/logger");

// Determine if we should use TLS (for Upstash or other cloud Redis)
const useRedis =
  process.env.REDIS_HOST && process.env.REDIS_HOST !== "localhost";
const useTLS =
  useRedis &&
  (process.env.NODE_ENV === "production" ||
    process.env.REDIS_HOST.includes("upstash.io"));

const redisConfig = {
  socket: {
    host: process.env.REDIS_HOST || "localhost",
    port: parseInt(process.env.REDIS_PORT) || 6379,
    tls: useTLS,
    ...(useTLS && {
      rejectUnauthorized: false, // Required for Upstash
    }),
  },
  password: process.env.REDIS_PASSWORD || undefined,
  username: process.env.REDIS_USERNAME || "default",
};

logger.debug("Redis configuration", {
  host: redisConfig.socket.host,
  port: redisConfig.socket.port,
  tls: useTLS,
  hasPassword: !!redisConfig.password,
  username: redisConfig.username,
});

const redisClient = redis.createClient(redisConfig);
let socketIoPubClient = null;
let socketIoSubClient = null;

redisClient.on("error", (err) => {
  logger.error("Redis Client Error", {
    error: err.message,
    stack: err.stack,
    host: process.env.REDIS_HOST,
    port: process.env.REDIS_PORT,
  });
});

redisClient.on("connect", () => {
  logger.redis("Redis Client Connected", {
    host: process.env.REDIS_HOST || "localhost",
    port: process.env.REDIS_PORT || 6379,
    tls: useTLS,
  });
});

redisClient.on("reconnecting", () => {
  logger.redis("Redis Client Reconnecting...");
});

redisClient.on("ready", () => {
  logger.redis("Redis Client Ready");
});

redisClient.on("end", () => {
  logger.redis("Redis Client Connection Ended");
});

async function connectRedis() {
  try {
    if (redisClient.isOpen) {
      logger.redis("Redis client already connected");
      return redisClient;
    }

    await redisClient.connect();
    logger.redis("Redis connection established successfully");
    return redisClient;
  } catch (error) {
    logger.error("Redis connection error", {
      error: error.message,
      stack: error.stack,
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
      tls: useTLS,
    });
    throw error;
  }
}

async function configureSocketIoRedisAdapter(io) {
  if (!io) {
    return false;
  }

  if (socketIoPubClient?.isOpen && socketIoSubClient?.isOpen) {
    return true;
  }

  try {
    const { createAdapter } = require("@socket.io/redis-adapter");

    socketIoPubClient = redis.createClient(redisConfig);
    socketIoSubClient = socketIoPubClient.duplicate();

    await Promise.all([
      socketIoPubClient.connect(),
      socketIoSubClient.connect(),
    ]);
    io.adapter(createAdapter(socketIoPubClient, socketIoSubClient));

    logger.info("Socket.IO Redis adapter configured");
    return true;
  } catch (error) {
    logger.warn("Socket.IO Redis adapter setup failed", {
      error: error.message,
    });

    return false;
  }
}

async function closeSocketIoRedisAdapter() {
  try {
    if (socketIoPubClient?.isOpen) {
      await socketIoPubClient.quit();
    }
  } catch (error) {
    logger.warn("Error closing Socket.IO Redis pub client", {
      error: error.message,
    });
  }

  try {
    if (socketIoSubClient?.isOpen) {
      await socketIoSubClient.quit();
    }
  } catch (error) {
    logger.warn("Error closing Socket.IO Redis sub client", {
      error: error.message,
    });
  }

  socketIoPubClient = null;
  socketIoSubClient = null;
}

module.exports = {
  redisClient,
  connectRedis,
  configureSocketIoRedisAdapter,
  closeSocketIoRedisAdapter,
};
