const { pool } = require("../database/connection");

const MAX_LIMIT = 200;

async function log({ messageId, conversationId, senderId, content, level, tags, reason, method }) {
  await pool.query(
    `INSERT INTO message_moderation
       (message_id, conversation_id, sender_id, content, level, tags, reason, method)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [messageId, conversationId, senderId, content, level, tags, reason ?? null, method],
  );
}

async function query({ minLevel = 1, page = 1, limit = 50 } = {}) {
  const safeLimit = Math.min(Number(limit) || 50, MAX_LIMIT);
  const safePage  = Math.max(Number(page)  || 1,  1);
  const offset    = (safePage - 1) * safeLimit;

  const [rowsResult, countResult] = await Promise.all([
    pool.query(
      `SELECT id, message_id, conversation_id, sender_id,
              content, level, tags, reason, method, created_at
       FROM message_moderation
       WHERE level >= $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`,
      [minLevel, safeLimit, offset],
    ),
    pool.query(
      `SELECT COUNT(*) AS total FROM message_moderation WHERE level >= $1`,
      [minLevel],
    ),
  ]);

  const total = parseInt(countResult.rows[0].total, 10);

  return {
    entries: rowsResult.rows,
    pagination: {
      page: safePage,
      limit: safeLimit,
      total,
      pages: Math.ceil(total / safeLimit),
    },
  };
}

async function stats() {
  const result = await pool.query(`
    SELECT
      COUNT(*)                                    AS total,
      COUNT(*) FILTER (WHERE level >= 2)          AS flagged,
      COUNT(*) FILTER (WHERE level = 4)           AS critical,
      COUNT(*) FILTER (WHERE method = 'ai')       AS ai_classified
    FROM message_moderation
  `);

  const row = result.rows[0];
  return {
    total:        parseInt(row.total, 10),
    flagged:      parseInt(row.flagged, 10),
    critical:     parseInt(row.critical, 10),
    aiClassified: parseInt(row.ai_classified, 10),
  };
}

module.exports = { log, query, stats };
