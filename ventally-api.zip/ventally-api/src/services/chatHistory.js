const { pool } = require("../database/connection");

function normalizeLimit(limit, fallback = 50, max = 100) {
  const parsedLimit = parseInt(limit, 10);

  if (Number.isNaN(parsedLimit) || parsedLimit <= 0) {
    return fallback;
  }

  return Math.min(parsedLimit, max);
}

async function getConversationParticipants(conversationId) {
  const convResult = await pool.query(
    "SELECT venter_id, listener_id, status FROM conversations WHERE id = $1",
    [conversationId],
  );

  if (convResult.rows.length === 0) {
    return null;
  }

  return convResult.rows[0];
}

function isConversationParticipant(conversation, userId) {
  if (!conversation) {
    return false;
  }

  return (
    conversation.venter_id === userId || conversation.listener_id === userId
  );
}

async function getConversationMessages({
  conversationId,
  userId,
  limit,
  before,
}) {
  const normalizedLimit = normalizeLimit(limit);
  const uuidPattern =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  let query = `
    SELECT m.*, si.anonymous_name as sender_name, si.avatar_seed as sender_avatar
    FROM messages m
    LEFT JOIN session_identities si ON si.session_id = m.conversation_id
      AND si.user_id = m.sender_id AND si.session_type = 'chat'
    WHERE m.conversation_id = $1
  `;

  const params = [conversationId];

  if (before) {
    if (uuidPattern.test(before)) {
      query += ` AND m.created_at < (
        SELECT created_at
        FROM messages
        WHERE id = $${params.length + 1}
          AND conversation_id = $1
      )`;
      params.push(before);
    } else {
      query += ` AND m.created_at < $${params.length + 1}`;
      params.push(before);
    }
  }

  query += ` ORDER BY m.created_at DESC LIMIT $${params.length + 1}`;
  params.push(normalizedLimit);

  const result = await pool.query(query, params);

  const messages = result.rows.reverse().map((row) => ({
    id: row.id,
    content: row.content,
    sender: {
      anonymousName: row.sender_name,
      avatarSeed: row.sender_avatar,
      isMe: row.sender_id === userId,
    },
    deliveredAt: row.delivered_at,
    readAt: row.read_at,
    createdAt: row.created_at,
  }));

  const oldestMessage = messages.length > 0 ? messages[0] : null;

  return {
    messages,
    count: messages.length,
    limit: normalizedLimit,
    before: oldestMessage ? oldestMessage.createdAt : null,
    hasMore: messages.length === normalizedLimit,
  };
}

module.exports = {
  normalizeLimit,
  getConversationParticipants,
  isConversationParticipant,
  getConversationMessages,
};
