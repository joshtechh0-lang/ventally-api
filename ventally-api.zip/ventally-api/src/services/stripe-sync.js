/**
 * Stripe Subscription Plans Sync Service
 *
 * This service syncs Stripe price IDs with database subscription plans.
 * It runs on application startup to ensure all plans have their Stripe price IDs populated.
 */

const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");

const STRIPE_CATALOG_VERSION = "2026-03-mobile-v3";
const ANNUAL_DISCOUNT_RATE = 0.2;
const ANNUAL_PRICE_OVERRIDES = {
  "Light Support": 379,
  "Balanced Support": 699,
  "Consistent Care": 1088,
  "High Support": 2099,
};

function toCurrencyAmount(value) {
  return Number(Number(value).toFixed(2));
}

function resolveAnnualPriceByPlan(plan) {
  const monthlyPrice = Number(plan.price_monthly || 0);
  if (monthlyPrice <= 0) {
    return 0;
  }

  if (Object.prototype.hasOwnProperty.call(ANNUAL_PRICE_OVERRIDES, plan.name)) {
    return toCurrencyAmount(ANNUAL_PRICE_OVERRIDES[plan.name]);
  }

  return toCurrencyAmount(monthlyPrice * 12 * (1 - ANNUAL_DISCOUNT_RATE));
}

function buildPlanProductDescription(plan) {
  const includedMinutes = Number(plan.included_minutes || 0);
  const includedMessages = Number(plan.included_messages_monthly || 0);

  return `${includedMinutes} monthly support minutes and ${includedMessages} messages`;
}

function buildPlanProductMetadata(plan) {
  return {
    plan_id: plan.id,
    catalog_version: STRIPE_CATALOG_VERSION,
    included_minutes: String(Number(plan.included_minutes || 0)),
    included_messages_monthly: String(Number(plan.included_messages_monthly || 0)),
    overage_rate: String(Number(plan.overage_rate || 0)),
  };
}

function productNeedsPlanSync(product, plan) {
  if (!product || typeof product !== "object") {
    return false;
  }

  const expectedDescription = buildPlanProductDescription(plan);
  if ((product.description || "") !== expectedDescription) {
    return true;
  }

  const expectedMetadata = buildPlanProductMetadata(plan);
  for (const [key, value] of Object.entries(expectedMetadata)) {
    if ((product.metadata?.[key] || "") !== value) {
      return true;
    }
  }

  return false;
}

async function syncStripeProductWithPlan(product, plan) {
  const expectedDescription = buildPlanProductDescription(plan);
  const expectedMetadata = buildPlanProductMetadata(plan);

  if (!productNeedsPlanSync(product, plan)) {
    return { updated: false };
  }

  await stripe.products.update(product.id, {
    description: expectedDescription,
    metadata: {
      ...(product.metadata || {}),
      ...expectedMetadata,
    },
  });

  return { updated: true };
}

/**
 * Sync subscription plans with Stripe
 * Maps existing Stripe prices to database plans by matching:
 * 1. Product name contains plan name (case-insensitive)
 * 2. Price amount matches plan price_monthly
 * 3. Price is recurring (monthly)
 */
async function syncSubscriptionPlansWithStripe() {
  if (!process.env.STRIPE_SECRET_KEY) {
    logger.warn("Stripe secret key not configured, skipping plan sync");
    return;
  }

  try {
    logger.info("🔄 Starting Stripe subscription plans sync...");

    // Get all active plans from database
    const plansResult = await pool.query(
      `SELECT id, name, price_monthly, included_minutes, included_messages_monthly, overage_rate, stripe_price_id, stripe_price_id_annual
       FROM subscription_plans 
       WHERE is_active = true 
       ORDER BY price_monthly`,
    );

    const dbPlans = plansResult.rows;
    logger.info(`Found ${dbPlans.length} subscription plans in database`);

    const prices = await stripe.prices.list({
      active: true,
      type: "recurring",
      limit: 100,
      expand: ["data.product"],
    });

    logger.info(
      `Found ${prices.data.length} active recurring prices in Stripe`,
    );

    let syncedCount = 0;
    let createdCount = 0;
    let productUpdatedCount = 0;
    let productAlreadyMatchingCount = 0;

    for (const plan of dbPlans) {
      let resolvedPrice = null;
      const planPriceCents = Math.round(parseFloat(plan.price_monthly) * 100);

      // Prefer metadata-based matching first
      const metadataMatch = prices.data.find((price) => {
        if (price.recurring?.interval !== "month") return false;
        if (price.unit_amount !== planPriceCents) return false;
        const metadataPlanId =
          price.metadata?.plan_id || price.product?.metadata?.plan_id;
        return metadataPlanId === plan.id;
      });

      if (metadataMatch) {
        resolvedPrice = metadataMatch;
      }

      // Fallback to exact name + price match
      if (!resolvedPrice) {
        resolvedPrice = prices.data.find((price) => {
          if (price.recurring?.interval !== "month") return false;
          if (price.unit_amount !== planPriceCents) return false;

          const productName = price.product?.name?.trim().toLowerCase() || "";
          const planName = plan.name.trim().toLowerCase();
          return productName === planName;
        });
      }

      if (!resolvedPrice) {
        const createdPriceId = await ensureStripePriceForPlan(plan.id, {
          billingCycle: "monthly",
        });
        resolvedPrice = { id: createdPriceId };
        createdCount++;
      }

      if (!resolvedPrice.product) {
        resolvedPrice = await stripe.prices.retrieve(resolvedPrice.id, {
          expand: ["product"],
        });
      }

      const resolvedProduct =
        typeof resolvedPrice.product === "string"
          ? await stripe.products.retrieve(resolvedPrice.product)
          : resolvedPrice.product;

      if (resolvedProduct?.id) {
        try {
          const productSyncResult = await syncStripeProductWithPlan(
            resolvedProduct,
            plan,
          );
          if (productSyncResult.updated) {
            productUpdatedCount++;
            logger.info(
              `✓ Updated Stripe product ${resolvedProduct.id} description/metadata for plan "${plan.name}"`,
            );
          } else {
            productAlreadyMatchingCount++;
          }
        } catch (productSyncError) {
          logger.warn(
            `Failed to reconcile Stripe product for plan "${plan.name}": ${productSyncError.message}`,
          );
        }
      }

      await pool.query(
        "UPDATE subscription_plans SET stripe_price_id = $1, updated_at = NOW() WHERE id = $2",
        [resolvedPrice.id, plan.id],
      );

      syncedCount++;
      logger.info(
        `✓ Synced "${plan.name}" ($${plan.price_monthly}/mo) with Stripe price ${resolvedPrice.id}`,
      );

      if (Number(plan.price_monthly) > 0) {
        const annualPriceId = await ensureStripePriceForPlan(plan.id, {
          billingCycle: "annual",
          annualPrice: resolveAnnualPriceByPlan(plan),
        });
        logger.info(
          `✓ Synced "${plan.name}" annual Stripe price ${annualPriceId}`,
        );
      }
    }

    const cleanupResult = await archiveLegacyStripePlanPrices(dbPlans);

    logger.info(
      `✅ Stripe sync completed: ${syncedCount} active plans synced, ${createdCount} prices created, ${productUpdatedCount} products updated, ${productAlreadyMatchingCount} products already matching, ${cleanupResult.archivedPrices} legacy prices archived`,
    );

    return {
      total: dbPlans.length,
      synced: syncedCount,
      created: createdCount,
      productUpdated: productUpdatedCount,
      productAlreadyMatching: productAlreadyMatchingCount,
      archivedPrices: cleanupResult.archivedPrices,
    };
  } catch (error) {
    logger.error("Error syncing subscription plans with Stripe:", error);
    // Don't throw - we don't want to prevent app startup if sync fails
    return null;
  }
}

/**
 * Gracefully archive inactive/legacy Stripe prices for plan products
 */
async function archiveLegacyStripePlanPrices(activePlans) {
  const activePlanNames = new Set(
    activePlans.map((plan) => plan.name.trim().toLowerCase()),
  );

  const inactivePlansResult = await pool.query(
    `SELECT name, stripe_price_id, stripe_price_id_annual
     FROM subscription_plans
     WHERE is_active = false`,
  );

  const inactivePlanNames = new Set(
    inactivePlansResult.rows
      .map((row) => row.name)
      .filter(Boolean)
      .map((name) => name.trim().toLowerCase()),
  );

  const inactivePriceIds = new Set(
    inactivePlansResult.rows
      .flatMap((row) => [row.stripe_price_id, row.stripe_price_id_annual])
      .filter(Boolean),
  );

  const prices = await stripe.prices.list({
    active: true,
    type: "recurring",
    limit: 100,
    expand: ["data.product"],
  });

  let archivedPrices = 0;
  const touchedProducts = new Set();

  for (const price of prices.data) {
    const productName = price.product?.name?.trim().toLowerCase() || "";
    const shouldArchive =
      inactivePriceIds.has(price.id) ||
      (inactivePlanNames.has(productName) && !activePlanNames.has(productName));

    if (!shouldArchive) {
      continue;
    }

    try {
      await stripe.prices.update(price.id, { active: false });
      archivedPrices++;
      if (price.product?.id) {
        touchedProducts.add(price.product.id);
      }
      logger.info(`Archived legacy Stripe price ${price.id}`);
    } catch (error) {
      logger.warn(
        `Failed to archive Stripe price ${price.id}: ${error.message}`,
      );
    }
  }

  // Archive product only if all recurring prices are inactive
  for (const productId of touchedProducts) {
    try {
      const productPrices = await stripe.prices.list({
        product: productId,
        active: true,
        type: "recurring",
        limit: 10,
      });

      if (productPrices.data.length === 0) {
        await stripe.products.update(productId, { active: false });
        logger.info(`Archived legacy Stripe product ${productId}`);
      }
    } catch (error) {
      logger.warn(
        `Failed to evaluate/archive Stripe product ${productId}: ${error.message}`,
      );
    }
  }

  return { archivedPrices };
}

/**
 * Create Stripe price for a plan if it doesn't exist
 * This is called when a user subscribes to a plan that doesn't have a Stripe price yet
 */
async function ensureStripePriceForPlan(planId, options = {}) {
  try {
    const billingCycle =
      options.billingCycle && options.billingCycle === "annual"
        ? "annual"
        : "monthly";
    const interval = billingCycle === "annual" ? "year" : "month";

    const planResult = await pool.query(
      "SELECT * FROM subscription_plans WHERE id = $1",
      [planId],
    );

    if (planResult.rows.length === 0) {
      throw new Error("Plan not found");
    }

    const plan = planResult.rows[0];

    const existingPriceId =
      billingCycle === "annual"
        ? plan.stripe_price_id_annual
        : plan.stripe_price_id;

    // Check if already has Stripe price for the selected cycle
    if (existingPriceId) {
      return existingPriceId;
    }

    logger.info(`Creating Stripe ${billingCycle} price for plan: ${plan.name}`);

    let productId = null;
    if (plan.stripe_price_id) {
      try {
        const existingMonthlyPrice = await stripe.prices.retrieve(
          plan.stripe_price_id,
          { expand: ["product"] },
        );
        productId = existingMonthlyPrice.product?.id || null;
      } catch (error) {
        logger.warn(
          `Failed to fetch product from existing monthly price ${plan.stripe_price_id}: ${error.message}`,
        );
      }
    }

    if (!productId) {
      const product = await stripe.products.create({
        name: plan.name,
        description: buildPlanProductDescription(plan),
        metadata: buildPlanProductMetadata(plan),
      });
      productId = product.id;
    }

    const annualPrice =
      options.annualPrice != null
        ? Number(options.annualPrice)
        : resolveAnnualPriceByPlan(plan);
    const unitAmount =
      billingCycle === "annual"
        ? Math.round(annualPrice * 100)
        : Math.round(parseFloat(plan.price_monthly) * 100);

    // Create Stripe price
    const price = await stripe.prices.create({
      product: productId,
      unit_amount: unitAmount,
      currency: "usd",
      // Stripe Tax: subscription prices are tax-inclusive. (Existing prices with
      // tax_behavior "unspecified" inherit the account-default behavior, which
      // must also be set to inclusive — see deploy notes.)
      tax_behavior: "inclusive",
      recurring: {
        interval,
      },
      metadata: {
        plan_id: plan.id,
        catalog_version: STRIPE_CATALOG_VERSION,
        billing_cycle: billingCycle,
      },
    });

    // Update database
    if (billingCycle === "annual") {
      await pool.query(
        "UPDATE subscription_plans SET stripe_price_id_annual = $1, updated_at = NOW() WHERE id = $2",
        [price.id, planId],
      );
    } else {
      await pool.query(
        "UPDATE subscription_plans SET stripe_price_id = $1, updated_at = NOW() WHERE id = $2",
        [price.id, planId],
      );
    }

    logger.info(
      `✓ Created Stripe ${billingCycle} price ${price.id} for plan "${plan.name}"`,
    );

    return price.id;
  } catch (error) {
    logger.error(`Error ensuring Stripe price for plan ${planId}:`, error);
    throw error;
  }
}

module.exports = {
  syncSubscriptionPlansWithStripe,
  ensureStripePriceForPlan,
};
