const { SESClient, SendEmailCommand } = require("@aws-sdk/client-ses");
const logger = require("../utils/logger");
const {
  getVerificationEmailHtml,
  getPasswordResetEmailHtml,
  getEmailChangeOtpHtml,
  getEmailUpdatedEmailHtml,
  getCrisisCallFollowUpEmailHtml,
  getPhoneUpdatedEmailHtml,
  getCreditPurchaseEmailHtml,
  getSubscriptionActivationEmailHtml,
  getTwoFactorAuthEmailHtml,
  getAppealReceivedEmailHtml,
  getListenerApprovalEmailHtml,
  getListenerDeniedEmailHtml,
  getListenerSignUpConfirmationEmailHtml,
  getPaymentFailedEmailHtml,
  getPlanCancelledEmailHtml,
  getRefundConfirmationEmailHtml,
  getSupportTicketReceivedEmailHtml,
  getAbandonedSignupEmailHtml,
} = require("./email_assets/template");

// Configure AWS SDK credentials
let sesClientConfig = {
  region: process.env.AWS_REGION || "us-east-1",
};

if (process.env.NODE_ENV === "development") {
  sesClientConfig.endpoint = process.env.AWS_ENDPOINT_URL;
  sesClientConfig.credentials = {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "test",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "test",
  };
} else {
  // SDK v3 auto-reads AWS_ENDPOINT_URL from env — remove it so it never
  // accidentally routes to LocalStack in staging/production.
  delete process.env.AWS_ENDPOINT_URL;
}

if (process.env.NODE_ENV !== "development" && process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
  sesClientConfig.credentials = {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  };
  logger.info("Using explicit AWS credentials from environment variables");
}

const sesClient = new SESClient(sesClientConfig);

logger.info(
  `Email service initialized with ${
    process.env.NODE_ENV === "development" ? "LocalStack SES" : "AWS SES"
  }`,
);
if (process.env.NODE_ENV === "development") {
  logger.debug(`LocalStack endpoint: ${process.env.AWS_ENDPOINT_URL}`);
} else {
  logger.info(`AWS Region: ${sesClientConfig.region}`);
  logger.info(
    `Using ${sesClientConfig.credentials ? "explicit" : "IAM role"} credentials`,
  );
}

/**
 * Base send function — all other functions delegate here.
 */
async function sendEmail({ to, subject, htmlBody, textBody }) {
  try {
    const fromEmail = process.env.SES_FROM_EMAIL || "noreply@ventally.co";
    const fromName = process.env.SES_FROM_NAME || "Ventally Support";

    logger.info(`📧 Preparing to send email to ${to}`);
    logger.debug(`Email subject: "${subject}"`);

    const params = {
      Source: `${fromName} <${fromEmail}>`,
      Destination: { ToAddresses: [to] },
      Message: {
        Subject: { Data: subject, Charset: "UTF-8" },
        Body: {
          Html: { Data: htmlBody, Charset: "UTF-8" },
          Text: {
            Data: textBody || htmlBody.replace(/<[^>]*>/g, ""),
            Charset: "UTF-8",
          },
        },
      },
    };

    if (process.env.NODE_ENV === "development") {
      logger.debug(`From: ${fromName} <${fromEmail}>`);
      logger.debug(`To: ${to}`);
    }

    const command = new SendEmailCommand(params);
    const result = await sesClient.send(command);

    logger.info(`✅ Email sent successfully to ${to}`);
    logger.info(`MessageId: ${result.MessageId}`);

    if (
      process.env.NODE_ENV === "development" &&
      process.env.SEND_EMAIL_RESPONSE === "true"
    ) {
      return {
        success: true,
        messageId: result.MessageId,
        emailPreview: {
          to,
          from: `${fromName} <${fromEmail}>`,
          subject,
          htmlBody,
          textBody: textBody || htmlBody.replace(/<[^>]*>/g, ""),
        },
      };
    }

    return { success: true, messageId: result.MessageId };
  } catch (error) {
    logger.error(`❌ Error sending email to ${to}: ${error.message}`);
    throw new Error(`Failed to send email: ${error.message}`);
  }
}

// ---------------------------------------------------------------------------
// Existing send functions (updated to new static templates)
// Signatures preserved so existing callers don't break.
// ---------------------------------------------------------------------------

async function sendVerificationEmail(to, otp, firstName, expiryMinutes) {
  const subject = "Verify your Ventally account";
  const htmlBody = getVerificationEmailHtml({ firstName, otp, expiryMinutes });
  const textBody = `Hi ${firstName || "there"},\n\nYour Ventally verification code is: ${otp}\nThis code expires in ${expiryMinutes} minutes.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendPasswordResetEmail(to, otp, firstName, expiryMinutes) {
  const subject = "Reset your Ventally password";
  const htmlBody = getPasswordResetEmailHtml({ firstName, otp, expiryMinutes });
  const textBody = `Hi ${firstName || "there"},\n\nYour Ventally password reset code is: ${otp}\nThis code expires in ${expiryMinutes} minutes.\n\nIf you didn't request this, you can safely ignore this email.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendEmailChangeOtpEmail(to, otp, expiryMinutes, firstName) {
  const subject = "Confirm your new Ventally email";
  const htmlBody = getEmailChangeOtpHtml({ firstName, otp, expiryMinutes });
  const textBody = `Hi ${firstName || "there"},\n\nYour Ventally email change code is: ${otp}\nThis code expires in ${expiryMinutes} minutes.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendEmailUpdatedEmail(to) {
  const subject = "Your Ventally email address has been updated";
  const htmlBody = getEmailUpdatedEmailHtml();
  const textBody = `Your Ventally email address has been successfully updated.\n\nIf you did not make this change, contact support immediately.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendCrisisCallFollowUpEmail(to) {
  const subject = "We're still here for you";
  const htmlBody = getCrisisCallFollowUpEmailHtml();
  const textBody = `We noticed your session ended earlier. If things felt overwhelming, you're not alone.\n\nYou can reach the 988 Suicide & Crisis Lifeline by calling or texting 988.\n\nVentally is still here for you whenever you're ready.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendPhoneUpdatedEmail(to) {
  const subject = "Your Ventally phone number has been updated";
  const htmlBody = getPhoneUpdatedEmailHtml();
  const textBody = `Your Ventally phone number has been successfully updated.\n\nIf you did not make this change, contact support immediately.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendCreditPurchaseEmail(to) {
  const subject = "Payment Successful - Credits Added to Your Account";
  const htmlBody = getCreditPurchaseEmailHtml();
  const textBody = `Payment Successful\n\nYour minutes have been added to your Ventally account. Open the app to start a call.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendSubscriptionActivationEmail(to) {
  const subject = "Subscription Activated - Welcome to Ventally!";
  const htmlBody = getSubscriptionActivationEmailHtml();
  const textBody = `Your Ventally subscription is now active.\n\nYour minutes are ready whenever you need them. Open the app to get started.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

// ---------------------------------------------------------------------------
// New send functions
// ---------------------------------------------------------------------------

async function sendTwoFactorAuthEmail(to, firstName, code) {
  const subject = "Your Ventally verification code";
  const htmlBody = getTwoFactorAuthEmailHtml({ firstName, code });
  const textBody = `Hi ${firstName || "there"},\n\nYour verification code is: ${code}\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendAppealReceivedEmail(to, firstName) {
  const subject = "We've received your appeal";
  const htmlBody = getAppealReceivedEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nWe've received your appeal and will review it shortly.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendListenerApprovalEmail(to, firstName) {
  const subject = "Your Ventally listener application has been approved";
  const htmlBody = getListenerApprovalEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nCongratulations — your listener application has been approved. You can now log in and start supporting others.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendListenerDeniedEmail(to, firstName) {
  const subject = "Update on your Ventally listener application";
  const htmlBody = getListenerDeniedEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nThank you for applying to be a Ventally listener. Unfortunately we're unable to approve your application at this time.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendListenerSignUpConfirmationEmail(to, firstName) {
  const subject = "Welcome to Ventally — application received";
  const htmlBody = getListenerSignUpConfirmationEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nThank you for signing up as a Ventally listener. We'll review your application and be in touch soon.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendPaymentFailedEmail(to, firstName) {
  const subject = "Action required — payment failed";
  const htmlBody = getPaymentFailedEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nWe were unable to process your payment. Please update your payment method in the app.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendPlanCancelledEmail(to, firstName) {
  const subject = "Your Ventally plan has been cancelled";
  const htmlBody = getPlanCancelledEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nYour Ventally subscription has been cancelled. You can resubscribe any time from the app.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendRefundConfirmationEmail(to, firstName) {
  const subject = "Your refund has been processed";
  const htmlBody = getRefundConfirmationEmailHtml({ firstName });
  const textBody = `Hi ${firstName || "there"},\n\nYour refund has been processed. Please allow a few business days for it to appear on your statement.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

async function sendAbandonedSignupEmail(to) {
  const signupUrl = process.env.APP_SIGNUP_URL || "https://ventally.co/signup";
  const htmlBody = getAbandonedSignupEmailHtml({ signupUrl });
  return sendEmail({
    to,
    subject: "You left something behind — finish creating your Ventally account",
    htmlBody,
  });
}

async function sendSupportTicketReceivedEmail(to) {
  const subject = "We've received your support request";
  const htmlBody = getSupportTicketReceivedEmailHtml();
  const textBody = `Thank you for reaching out to Ventally support. We've received your request and will respond as soon as possible.\n\n© ${new Date().getFullYear()} Ventally. All rights reserved.`;
  return sendEmail({ to, subject, htmlBody, textBody });
}

module.exports = {
  sendEmail,
  sendVerificationEmail,
  sendPasswordResetEmail,
  sendEmailChangeOtpEmail,
  sendEmailUpdatedEmail,
  sendCrisisCallFollowUpEmail,
  sendPhoneUpdatedEmail,
  sendCreditPurchaseEmail,
  sendSubscriptionActivationEmail,
  sendTwoFactorAuthEmail,
  sendAppealReceivedEmail,
  sendListenerApprovalEmail,
  sendListenerDeniedEmail,
  sendListenerSignUpConfirmationEmail,
  sendPaymentFailedEmail,
  sendPlanCancelledEmail,
  sendRefundConfirmationEmail,
  sendSupportTicketReceivedEmail,
  sendAbandonedSignupEmail,
};
