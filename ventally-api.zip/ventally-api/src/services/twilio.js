const twilio = require("twilio");
const logger = require("../utils/logger");

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER;

if (!accountSid || !authToken || !twilioPhoneNumber) {
  logger.warn(
    "Twilio SMS credentials not fully configured. SMS features may be unavailable.",
  );
}

const twilioClient =
  accountSid && authToken ? twilio(accountSid, authToken) : null;

function isValidPhoneNumber(phoneNumber) {
  const e164Regex = /^\+[1-9]\d{1,14}$/;
  return e164Regex.test(phoneNumber);
}

module.exports = {
  twilioClient,
  isValidPhoneNumber,
};
