const { v4: uuidv4 } = require("uuid");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const stripeLogger = require("../utils/stripeLogger");
const {
  normalizeBaseUrl,
  getCanonicalPublicBaseUrl,
  buildPublicUrl,
} = require("../utils/publicUrl");

const stripe = require("../config/stripe");
const { getSchedulerConfig } = require("./earningsReleaseScheduler");

// Public business website prefilled onto each listener's Connect account so the
// hosted onboarding never prompts for it. Listeners are individuals; this is the
// platform's site (not theirs), and prefilling it is what removes the "Business
// website" step from the payout flow. Overridable via env.
const LISTENER_CONNECT_BUSINESS_URL =
  process.env.STRIPE_CONNECT_BUSINESS_URL || "https://ventally.co";

class ListenerPayoutError extends Error {
  constructor(
    message,
    statusCode = 400,
    code = "PAYOUT_ERROR",
    details = null,
  ) {
    super(message);
    this.name = "ListenerPayoutError";
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

// HTTP statuses Stripe returns that carry an actionable, client-safe
// explanation (bad params, a gated/incomplete platform profile, rate limits).
// Stripe auth (401/403) and 5xx are our-side/upstream problems we should not
// relay verbatim — those collapse to a generic 500.
const FORWARDABLE_STRIPE_STATUSES = new Set([400, 402, 404, 409, 422, 429]);

/**
 * Normalize a caught error into a ListenerPayoutError. Stripe errors with an
 * actionable status (e.g. the 400 loss-responsibility / capability gates) keep
 * their real status code and message so the client sees the true cause instead
 * of a masked 500; everything else falls back to 500.
 */
function toListenerPayoutError(error, fallbackMessage, fallbackCode) {
  if (error instanceof ListenerPayoutError) {
    return error;
  }

  const isStripeError =
    (typeof error?.type === "string" && error.type.startsWith("Stripe")) ||
    typeof error?.statusCode === "number";

  const details = isStripeError
    ? { stripeType: error.type, stripeCode: error.code }
    : null;

  if (isStripeError && FORWARDABLE_STRIPE_STATUSES.has(error.statusCode)) {
    return new ListenerPayoutError(
      error.message || fallbackMessage,
      error.statusCode,
      fallbackCode,
      details,
    );
  }

  return new ListenerPayoutError(fallbackMessage, 500, fallbackCode, details);
}

function parseCurrency(value) {
  return parseFloat(value || 0);
}

function centsToAmount(cents) {
  return (cents / 100).toFixed(2);
}

function amountToCents(value) {
  const normalized = Number.parseFloat(value);
  if (!Number.isFinite(normalized)) {
    return null;
  }

  return Math.round(normalized * 100);
}

function parseRequestedAmountToCents(requestedAmount) {
  if (requestedAmount === undefined || requestedAmount === null) {
    return null;
  }

  const asText = String(requestedAmount).trim();
  if (!asText) {
    return null;
  }

  if (!/^\d+(\.\d{1,2})?$/.test(asText)) {
    throw new ListenerPayoutError(
      "Withdrawal amount must be a positive number with up to 2 decimals",
      422,
      "INVALID_WITHDRAWAL_AMOUNT",
    );
  }

  const cents = amountToCents(asText);
  if (!cents || cents <= 0) {
    throw new ListenerPayoutError(
      "Withdrawal amount must be greater than 0",
      422,
      "INVALID_WITHDRAWAL_AMOUNT",
    );
  }

  return cents;
}

function toStripeCents(amount) {
  return Math.round(parseFloat(amount) * 100);
}

function getPlatformKey(platform) {
  const normalized = String(platform || "")
    .trim()
    .toLowerCase();
  if (["ios", "android", "web"].includes(normalized)) {
    return normalized;
  }

  return "web";
}

function resolveUrlOrPath(rawValue, baseUrl = null) {
  if (!rawValue) {
    return null;
  }

  const trimmed = String(rawValue).trim();
  if (!trimmed) {
    return null;
  }

  const absoluteUrl = normalizeBaseUrl(trimmed);
  if (absoluteUrl) {
    return absoluteUrl;
  }

  if (trimmed.startsWith("/")) {
    return buildPublicUrl(baseUrl, trimmed);
  }

  return null;
}

function resolveConnectRedirectUrls(platform, returnUrl, refreshUrl) {
  const platformKey = getPlatformKey(platform);
  const platformSuffix = platformKey.toUpperCase();

  const clientBaseUrl = normalizeBaseUrl(process.env.CLIENT_URL);
  const canonicalPublicBaseUrl = getCanonicalPublicBaseUrl();
  const baseUrl =
    clientBaseUrl ||
    canonicalPublicBaseUrl ||
    normalizeBaseUrl("http://localhost:3000");

  const configuredReturn =
    process.env[`STRIPE_CONNECT_RETURN_URL_${platformSuffix}`] ||
    process.env.STRIPE_CONNECT_RETURN_URL;

  const configuredRefresh =
    process.env[`STRIPE_CONNECT_REFRESH_URL_${platformSuffix}`] ||
    process.env.STRIPE_CONNECT_REFRESH_URL;

  const configuredReturnByPlatform =
    process.env[`STRIPE_CONNECT_RETURN_URL_${platformSuffix}`];
  const configuredRefreshByPlatform =
    process.env[`STRIPE_CONNECT_REFRESH_URL_${platformSuffix}`];

  const fallbackReturnUrl = buildPublicUrl(
    baseUrl,
    "/api/billing/cancel?flow=bank_link&result=return",
  );
  const fallbackRefreshUrl = buildPublicUrl(
    baseUrl,
    "/api/billing/cancel?flow=bank_link&result=refresh",
  );

  if (returnUrl && !resolveUrlOrPath(returnUrl, baseUrl)) {
    logger.warn("Ignoring non-http returnUrl override for Stripe onboarding", {
      platform: platformKey,
      returnUrl,
    });
  }

  if (refreshUrl && !resolveUrlOrPath(refreshUrl, baseUrl)) {
    logger.warn("Ignoring non-http refreshUrl override for Stripe onboarding", {
      platform: platformKey,
      refreshUrl,
    });
  }

  let resolvedReturnUrl;
  let resolvedRefreshUrl;

  if (platformKey === "ios" || platformKey === "android") {
    // For mobile, prefer platform-specific envs and client fallback over global API defaults.
    resolvedReturnUrl =
      resolveUrlOrPath(returnUrl, baseUrl) ||
      resolveUrlOrPath(configuredReturnByPlatform, baseUrl) ||
      fallbackReturnUrl ||
      resolveUrlOrPath(configuredReturn, baseUrl);

    resolvedRefreshUrl =
      resolveUrlOrPath(refreshUrl, baseUrl) ||
      resolveUrlOrPath(configuredRefreshByPlatform, baseUrl) ||
      fallbackRefreshUrl ||
      resolveUrlOrPath(configuredRefresh, baseUrl);
  } else {
    resolvedReturnUrl =
      resolveUrlOrPath(returnUrl, baseUrl) ||
      resolveUrlOrPath(configuredReturn, baseUrl) ||
      fallbackReturnUrl;

    resolvedRefreshUrl =
      resolveUrlOrPath(refreshUrl, baseUrl) ||
      resolveUrlOrPath(configuredRefresh, baseUrl) ||
      fallbackRefreshUrl;
  }

  if (!resolvedReturnUrl || !resolvedRefreshUrl) {
    throw new ListenerPayoutError(
      "Bank-link callback URLs are not configured as valid HTTP URLs",
      500,
      "BANK_LINK_URL_INVALID",
      {
        platform: platformKey,
      },
    );
  }

  return {
    returnUrl: resolvedReturnUrl,
    refreshUrl: resolvedRefreshUrl,
    platform: platformKey,
  };
}

function mapStripeAccountStatus(account) {
  if (!account) {
    return "not_connected";
  }

  if (account.payouts_enabled) {
    return "active";
  }

  const currentlyDue = account.requirements?.currently_due || [];
  const pendingVerification = account.requirements?.pending_verification || [];
  const disabledReason = account.requirements?.disabled_reason;

  if (disabledReason) {
    return "disabled";
  }

  if (currentlyDue.length > 0) {
    return "incomplete";
  }

  if (pendingVerification.length > 0 || account.details_submitted) {
    return "pending_review";
  }

  return "incomplete";
}

function getRequirementsDue(account) {
  const currentlyDue = account?.requirements?.currently_due || [];
  const pastDue = account?.requirements?.past_due || [];
  return [...new Set([...currentlyDue, ...pastDue])];
}

function mapStripeFailureReason(error) {
  if (error?.message) {
    return error.message.slice(0, 500);
  }

  return "Stripe transfer failed";
}

function isStripeResourceMissingError(error, expectedParam = null) {
  const code = String(error?.code || "").toLowerCase();
  const param = String(error?.param || "").toLowerCase();
  const message = String(error?.message || "").toLowerCase();

  if (code !== "resource_missing") {
    return false;
  }

  if (!expectedParam) {
    return true;
  }

  const normalizedExpected = String(expectedParam).toLowerCase();
  return param === normalizedExpected || message.includes("no such");
}

// Stripe rejects an explicit transfers-only capability request until the
// platform is approved to request `transfers` without `card_payments`
// ("Your platform needs approval for accounts to have requested the
// `transfers` capability without the `card_payments` capability..."). Detect
// that specific gate so callers can fall back to implicit (controller-granted)
// capabilities and keep onboarding working until the approval lands — at which
// point the explicit request simply starts succeeding.
function isTransfersApprovalGateError(error) {
  if (error?.type !== "StripeInvalidRequestError") {
    return false;
  }
  const message = String(error?.message || "").toLowerCase();
  return message.includes("transfers") && message.includes("card_payments");
}

// Stripe locks certain connected-account params (notably `business_type`) once
// the account starts onboarding — the platform then lacks permission to update
// them and gets `oauth_not_supported` ("does not have the required permissions
// for the parameter '<param>'..."). Detect that for a specific param so a
// best-effort remediation can drop just that field and still apply the rest.
function isAccountParamPermissionError(error, param) {
  if (error?.type !== "StripeInvalidRequestError") {
    return false;
  }
  const message = String(error?.message || "").toLowerCase();
  return (
    message.includes("permission") &&
    message.includes(`'${String(param).toLowerCase()}'`)
  );
}

async function getListenerVerificationState(client, listenerId) {
  const verificationResult = await client.query(
    `SELECT
        (
          SELECT status
          FROM listener_verification_documents
          WHERE listener_id = $1
          ORDER BY reviewed_at DESC NULLS LAST, created_at DESC
          LIMIT 1
        ) AS latest_status,
        EXISTS (
          SELECT 1
          FROM listener_verification_documents
          WHERE listener_id = $1
            AND LOWER(TRIM(status)) IN ('verified', 'approved')
        ) AS has_verified_record,
        (
          SELECT is_verified
          FROM users
          WHERE id = $1
          LIMIT 1
        ) AS is_user_verified`,
    [listenerId],
  );

  const latestVerificationStatus = verificationResult.rows[0]?.latest_status;
  const hasVerifiedRecord = Boolean(
    verificationResult.rows[0]?.has_verified_record,
  );
  const isUserVerified = Boolean(verificationResult.rows[0]?.is_user_verified);
  const normalized = String(latestVerificationStatus || "")
    .trim()
    .toLowerCase();
  const isVerifiedListener =
    isUserVerified ||
    hasVerifiedRecord ||
    normalized === "verified" ||
    normalized === "approved";

  return {
    latestVerificationStatus,
    hasVerifiedRecord,
    isUserVerified,
    isVerifiedListener,
  };
}

async function createConnectAccountForListener(client, listenerId) {
  const userResult = await client.query(
    "SELECT email FROM users WHERE id = $1 LIMIT 1",
    [listenerId],
  );

  if (userResult.rows.length === 0) {
    throw new ListenerPayoutError("User not found", 404, "USER_NOT_FOUND");
  }

  // Base account params shared by the primary (transfers-only) attempt and the
  // fallback. `capabilities` is added only to the primary attempt below.
  const accountParams = {
    // No country hardcoded — Stripe Express lets the listener select their
    // own country during onboarding, supporting all 42 countries enabled in
    // the Stripe Connect dashboard (UK, AU, CA, EU, etc.).
    email: userResult.rows[0].email,
    // Listeners are individuals (peer supporters / sole proprietors), never
    // companies. Pre-setting business_type makes the hosted Express flow skip
    // the "register a business" step and collect individual KYC instead.
    // NOTE: do NOT add a top-level `type` here — it only accepts
    // standard/express/custom and is mutually exclusive with `controller`.
    business_type: "individual",
    // Prefill the business website so onboarding doesn't ask for it. transfers
    // requires `business_profile.url`; providing it up front skips that screen.
    business_profile: { url: LISTENER_CONNECT_BUSINESS_URL },
    controller: {
      // Express dashboard requires the platform (application) to control
      // losses; Stripe rejects losses.payments=stripe with this combo
      // ("With a dashboard type of `express`, the Connect application must
      // control losses."). Requires the loss-responsibility section of the
      // LIVE Connect platform profile to be completed, otherwise account
      // link creation 400s with "review the responsibilities of managing
      // losses for connected accounts".
      losses: { payments: "application" }, // platform controls losses (required for express)
      fees: { payer: "application" }, // platform collects fees
      stripe_dashboard: { type: "express" }, // Express dashboard experience
    },
    metadata: {
      listener_id: listenerId,
    },
  };

  let account;
  try {
    stripeLogger.attempt("accounts.create:connect_express", { listenerId });
    account = await stripe.accounts.create({
      ...accountParams,
      // Listeners only RECEIVE payouts — explicitly request `transfers` and
      // nothing else. Crucially this avoids `card_payments`, whose verification
      // requirements are what drag the merchant screens (industry/MCC, statement
      // descriptor) into onboarding. (The recipient ToS agreement, which also
      // drops card_payments, is NOT usable here: Stripe rejects it for a US
      // platform onboarding US accounts — it's cross-border-payouts only.)
      // If Stripe hasn't yet approved transfers-without-card_payments for this
      // platform, this request 400s and we fall back below.
      capabilities: { transfers: { requested: true } },
    });
    stripeLogger.success("accounts.create:connect_express", account, {
      listenerId,
    });
  } catch (stripeErr) {
    if (!isTransfersApprovalGateError(stripeErr)) {
      stripeLogger.failure("accounts.create:connect_express", stripeErr, {
        listenerId,
      });
      throw stripeErr;
    }

    // Platform not yet approved for transfers-without-card_payments. Create the
    // account WITHOUT the explicit capability request so onboarding keeps
    // working (capabilities are then granted implicitly via the Express
    // controller). The merchant screens remain until Stripe grants approval, at
    // which point the primary attempt above succeeds and they disappear — no
    // redeploy needed. See isTransfersApprovalGateError / the support gate.
    logger.warn(
      "Stripe has not approved transfers-without-card_payments; creating Connect account without explicit capabilities (fallback)",
      { listenerId, error: stripeErr.message },
    );
    try {
      stripeLogger.attempt("accounts.create:connect_express_fallback", {
        listenerId,
      });
      account = await stripe.accounts.create(accountParams);
      stripeLogger.success("accounts.create:connect_express_fallback", account, {
        listenerId,
      });
    } catch (fallbackErr) {
      stripeLogger.failure(
        "accounts.create:connect_express_fallback",
        fallbackErr,
        { listenerId },
      );
      throw fallbackErr;
    }
  }

  await client.query(
    `UPDATE listener_profiles
     SET stripe_connect_account_id = $2,
         stripe_account_status = 'incomplete',
         payout_enabled = false
     WHERE listener_id = $1`,
    [listenerId, account.id],
  );

  return account.id;
}

/**
 * Loads the listener profile (FOR UPDATE) and returns a usable Stripe Connect
 * account id, creating one if missing and remediating older accounts in place.
 *
 * Shared by the hosted-link (accountLinks) and embedded (accountSessions) bank
 * onboarding flows so both get identical create/recreate/remediation behavior.
 * Must be called inside an open transaction on `client`.
 */
async function ensureConnectAccountForListener(client, listenerId) {
  const profileResult = await client.query(
    `SELECT listener_id, stripe_connect_account_id
     FROM listener_profiles
     WHERE listener_id = $1
     LIMIT 1
     FOR UPDATE`,
    [listenerId],
  );

  if (profileResult.rows.length === 0) {
    throw new ListenerPayoutError(
      "Listener profile not found",
      404,
      "LISTENER_PROFILE_NOT_FOUND",
    );
  }

  let stripeConnectAccountId = profileResult.rows[0].stripe_connect_account_id;

  if (!stripeConnectAccountId) {
    return createConnectAccountForListener(client, listenerId);
  }

  try {
    const existingAccount = await stripe.accounts.retrieve(
      stripeConnectAccountId,
    );

    // Remediate accounts created before the individual/payout-only config was
    // applied: if the listener hasn't submitted onboarding yet, bring the account
    // up to the same shape as a freshly created one — individual business_type,
    // the `transfers` capability requested, and a prefilled business website —
    // so the flow stops prompting for a business / website. Best-effort: never
    // block onboarding if Stripe rejects the update.
    if (!existingAccount.details_submitted) {
      const remediation = {};

      if (existingAccount.business_type !== "individual") {
        remediation.business_type = "individual";
      }
      if (!existingAccount.capabilities?.transfers) {
        remediation.capabilities = { transfers: { requested: true } };
      }
      if (!existingAccount.business_profile?.url) {
        remediation.business_profile = { url: LISTENER_CONNECT_BUSINESS_URL };
      }

      // Individual params can each be rejected and fail the whole update:
      // `capabilities` until the platform is approved for transfers-without-
      // card_payments, and `business_type` once Stripe locks it after onboarding
      // starts. On such a rejection, drop just the offending field and retry so
      // the safe parts (e.g. the business-website prefill) still apply.
      let pending = remediation;
      while (Object.keys(pending).length > 0) {
        try {
          await stripe.accounts.update(stripeConnectAccountId, pending);
          break;
        } catch (updateError) {
          let dropKey = null;
          if (isTransfersApprovalGateError(updateError) && pending.capabilities) {
            dropKey = "capabilities";
          } else if (
            isAccountParamPermissionError(updateError, "business_type") &&
            pending.business_type
          ) {
            dropKey = "business_type";
          }

          if (!dropKey) {
            logger.warn(
              "Could not remediate existing Connect account to individual/payout-only shape",
              {
                listenerId,
                accountId: stripeConnectAccountId,
                attempted: Object.keys(pending),
                error: updateError.message,
              },
            );
            break;
          }

          const { [dropKey]: _dropped, ...rest } = pending;
          pending = rest;
        }
      }
    }

    return stripeConnectAccountId;
  } catch (retrieveError) {
    if (!isStripeResourceMissingError(retrieveError, "account")) {
      throw retrieveError;
    }

    logger.warn(
      "Stored Stripe connected account missing; creating replacement account",
      {
        listenerId,
        previousAccountId: stripeConnectAccountId,
      },
    );

    return createConnectAccountForListener(client, listenerId);
  }
}

async function assertListenerEligibleForWithdrawal(client, listenerId) {
  const profileResult = await client.query(
    `SELECT listener_id, stripe_connect_account_id, stripe_account_status, payout_enabled
     FROM listener_profiles
     WHERE listener_id = $1
     LIMIT 1
     FOR UPDATE`,
    [listenerId],
  );

  if (profileResult.rows.length === 0) {
    throw new ListenerPayoutError(
      "Listener profile not found",
      404,
      "LISTENER_PROFILE_NOT_FOUND",
    );
  }

  const profile = profileResult.rows[0];
  let payoutEnabled = Boolean(profile.payout_enabled);
  let stripeAccountStatus = profile.stripe_account_status || null;
  let requirementsDue = [];

  if (!profile.stripe_connect_account_id) {
    throw new ListenerPayoutError(
      "Connect your Stripe payout account before withdrawing",
      422,
      "STRIPE_ACCOUNT_NOT_CONNECTED",
    );
  }

  try {
    stripeLogger.attempt("accounts.retrieve:withdrawal_eligibility", {
      listenerId,
      accountId: profile.stripe_connect_account_id,
    });
    const account = await stripe.accounts.retrieve(
      profile.stripe_connect_account_id,
    );
    payoutEnabled = Boolean(account.payouts_enabled);
    stripeAccountStatus = mapStripeAccountStatus(account);
    requirementsDue = getRequirementsDue(account);
    stripeLogger.success("accounts.retrieve:withdrawal_eligibility", account, {
      listenerId,
      accountId: profile.stripe_connect_account_id,
      payoutEnabled,
      stripeAccountStatus,
    });

    await client.query(
      `UPDATE listener_profiles
       SET stripe_account_status = $2,
           payout_enabled = $3
       WHERE listener_id = $1`,
      [listenerId, stripeAccountStatus, payoutEnabled],
    );
  } catch (error) {
    stripeLogger.failure("accounts.retrieve:withdrawal_eligibility", error, {
      listenerId,
      accountId: profile.stripe_connect_account_id,
    });

    throw new ListenerPayoutError(
      "Unable to verify payout account status. Please try again.",
      503,
      "PAYOUT_SERVICE_UNAVAILABLE",
    );
  }

  if (!payoutEnabled) {
    throw new ListenerPayoutError(
      "Payouts are not enabled for this listener account",
      422,
      "PAYOUT_NOT_ENABLED",
      {
        stripeAccountStatus,
        requirementsDue,
      },
    );
  }

  const verification = await getListenerVerificationState(client, listenerId);

  if (!verification.isVerifiedListener) {
    throw new ListenerPayoutError(
      "Only verified listeners can withdraw earnings",
      403,
      "LISTENER_NOT_VERIFIED",
      {
        latestVerificationStatus:
          verification.latestVerificationStatus || "not_submitted",
        hasVerifiedRecord: verification.hasVerifiedRecord,
        isUserVerified: verification.isUserVerified,
      },
    );
  }

  return {
    stripeConnectAccountId: profile.stripe_connect_account_id,
    payoutEnabled,
    stripeAccountStatus,
    requirementsDue,
  };
}

async function getWithdrawableBalance(listenerId) {
  const result = await pool.query(
    `SELECT COALESCE(SUM(net_amount - COALESCE(paid_amount, 0)), 0) AS available_balance
     FROM listener_earnings
     WHERE listener_id = $1
       AND status = 'available'
       AND (net_amount - COALESCE(paid_amount, 0)) > 0`,
    [listenerId],
  );

  return parseCurrency(result.rows[0]?.available_balance);
}

async function createBankAccountOnboardingLink(
  listenerId,
  { platform, returnUrl, refreshUrl } = {},
) {
  if (!stripe) {
    throw new ListenerPayoutError(
      "Payout service is not configured",
      503,
      "PAYOUT_SERVICE_UNAVAILABLE",
    );
  }

  const client = await pool.connect();
  let hasCommitted = false;

  try {
    await client.query("BEGIN");

    let stripeConnectAccountId = await ensureConnectAccountForListener(
      client,
      listenerId,
    );

    const resolvedUrls = resolveConnectRedirectUrls(
      platform,
      returnUrl,
      refreshUrl,
    );

    let accountLink;
    try {
      stripeLogger.attempt("accountLinks.create:onboarding", {
        listenerId,
        accountId: stripeConnectAccountId,
      });
      accountLink = await stripe.accountLinks.create({
        account: stripeConnectAccountId,
        type: "account_onboarding",
        refresh_url: resolvedUrls.refreshUrl,
        return_url: resolvedUrls.returnUrl,
      });
    } catch (linkError) {
      if (!isStripeResourceMissingError(linkError, "account")) {
        throw linkError;
      }

      logger.warn(
        "Stripe account link creation failed due to missing account; recreating account and retrying once",
        {
          listenerId,
          previousAccountId: stripeConnectAccountId,
        },
      );

      stripeConnectAccountId = await createConnectAccountForListener(
        client,
        listenerId,
      );

      stripeLogger.attempt("accountLinks.create:onboarding_retry", {
        listenerId,
        accountId: stripeConnectAccountId,
      });
      accountLink = await stripe.accountLinks.create({
        account: stripeConnectAccountId,
        type: "account_onboarding",
        refresh_url: resolvedUrls.refreshUrl,
        return_url: resolvedUrls.returnUrl,
      });
    }

    stripeLogger.success("accountLinks.create:onboarding", accountLink, {
      listenerId,
      accountId: stripeConnectAccountId,
    });

    await client.query("COMMIT");
    hasCommitted = true;

    return {
      accountId: stripeConnectAccountId,
      onboardingUrl: accountLink.url,
      expiresAt: new Date(accountLink.expires_at * 1000).toISOString(),
      platform: resolvedUrls.platform,
      returnUrl: resolvedUrls.returnUrl,
      refreshUrl: resolvedUrls.refreshUrl,
    };
  } catch (error) {
    if (!hasCommitted) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        logger.error("Failed to rollback bank-link transaction", {
          error: rollbackError.message,
        });
      }
    }

    if (error instanceof ListenerPayoutError) {
      throw error;
    }

    stripeLogger.failure("accountLinks.create:onboarding", error, {
      listenerId,
      stack: error.stack,
    });

    throw toListenerPayoutError(
      error,
      "Failed to create bank-account onboarding link",
      "BANK_LINK_CREATE_FAILED",
    );
  } finally {
    client.release();
  }
}

async function createBankAccountSession(listenerId) {
  if (!stripe) {
    throw new ListenerPayoutError(
      "Payout service is not configured",
      503,
      "PAYOUT_SERVICE_UNAVAILABLE",
    );
  }

  const client = await pool.connect();
  let hasCommitted = false;

  try {
    await client.query("BEGIN");

    const stripeConnectAccountId = await ensureConnectAccountForListener(
      client,
      listenerId,
    );

    let session;
    try {
      stripeLogger.attempt("accountSessions.create:onboarding", {
        listenerId,
        accountId: stripeConnectAccountId,
      });
      session = await stripe.accountSessions.create({
        account: stripeConnectAccountId,
        components: {
          account_onboarding: {
            enabled: true,
            // Keep bank-account (external account) collection inside the
            // embedded onboarding flow so listeners still link their payout
            // account. The mobile client drops the extra "Business type" screen
            // by excluding the business_type requirement client-side via
            // setCollectionOptions({ requirements: { exclude: ['business_type'] } }).
            features: { external_account_collection: true },
          },
        },
      });
      stripeLogger.success("accountSessions.create:onboarding", session, {
        listenerId,
        accountId: stripeConnectAccountId,
      });
    } catch (sessionError) {
      stripeLogger.failure("accountSessions.create:onboarding", sessionError, {
        listenerId,
        accountId: stripeConnectAccountId,
      });
      throw sessionError;
    }

    await client.query("COMMIT");
    hasCommitted = true;

    return {
      accountId: stripeConnectAccountId,
      clientSecret: session.client_secret,
    };
  } catch (error) {
    if (!hasCommitted) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        logger.error("Failed to rollback bank-account session transaction", {
          error: rollbackError.message,
        });
      }
    }

    throw toListenerPayoutError(
      error,
      "Failed to create bank-account onboarding session",
      "BANK_LINK_SESSION_FAILED",
    );
  } finally {
    client.release();
  }
}

async function getBankAccountStatus(listenerId) {
  if (!stripe) {
    throw new ListenerPayoutError(
      "Payout service is not configured",
      503,
      "PAYOUT_SERVICE_UNAVAILABLE",
    );
  }

  const client = await pool.connect();

  try {
    const profileResult = await client.query(
      `SELECT listener_id, stripe_connect_account_id, stripe_account_status, payout_enabled
       FROM listener_profiles
       WHERE listener_id = $1
       LIMIT 1`,
      [listenerId],
    );

    if (profileResult.rows.length === 0) {
      throw new ListenerPayoutError(
        "Listener profile not found",
        404,
        "LISTENER_PROFILE_NOT_FOUND",
      );
    }

    const profile = profileResult.rows[0];
    const verification = await getListenerVerificationState(client, listenerId);
    const verificationPayload = {
      isVerifiedListener: verification.isVerifiedListener,
      latestVerificationStatus:
        verification.latestVerificationStatus || "not_submitted",
      canWithdraw: false,
    };

    if (!profile.stripe_connect_account_id) {
      return {
        stripeAccountStatus: "not_connected",
        payoutEnabled: false,
        requirementsDue: [],
        accountId: null,
        verification: verificationPayload,
      };
    }

    let account;
    try {
      account = await stripe.accounts.retrieve(
        profile.stripe_connect_account_id,
      );
    } catch (retrieveError) {
      if (!isStripeResourceMissingError(retrieveError, "account")) {
        throw retrieveError;
      }

      logger.warn(
        "Stored Stripe connected account missing during status fetch",
        {
          listenerId,
          missingAccountId: profile.stripe_connect_account_id,
        },
      );

      await client.query(
        `UPDATE listener_profiles
         SET stripe_connect_account_id = NULL,
             stripe_account_status = 'not_connected',
             payout_enabled = false
         WHERE listener_id = $1`,
        [listenerId],
      );

      return {
        stripeAccountStatus: "not_connected",
        payoutEnabled: false,
        requirementsDue: [],
        accountId: null,
        verification: verificationPayload,
      };
    }

    const payoutEnabled = Boolean(account.payouts_enabled);
    const stripeAccountStatus = mapStripeAccountStatus(account);
    const requirementsDue = getRequirementsDue(account);

    await client.query(
      `UPDATE listener_profiles
       SET stripe_account_status = $2,
           payout_enabled = $3
       WHERE listener_id = $1`,
      [listenerId, stripeAccountStatus, payoutEnabled],
    );

    verificationPayload.canWithdraw =
      payoutEnabled && verification.isVerifiedListener;

    return {
      stripeAccountStatus,
      payoutEnabled,
      requirementsDue,
      accountId: profile.stripe_connect_account_id,
      verification: verificationPayload,
    };
  } catch (error) {
    if (error instanceof ListenerPayoutError) {
      throw error;
    }

    logger.error("Failed to fetch bank-account status", {
      listenerId,
      error: error.message,
      stack: error.stack,
    });

    throw new ListenerPayoutError(
      "Failed to fetch bank-account status",
      500,
      "BANK_LINK_STATUS_FAILED",
    );
  } finally {
    client.release();
  }
}

async function syncStripeAccountStatus(account) {
  if (!account?.id) {
    return { updated: false, reason: "missing_account" };
  }

  const payoutEnabled = Boolean(account.payouts_enabled);
  const stripeAccountStatus = mapStripeAccountStatus(account);

  const result = await pool.query(
    `UPDATE listener_profiles
     SET stripe_account_status = $2,
         payout_enabled = $3
     WHERE stripe_connect_account_id = $1
     RETURNING listener_id`,
    [account.id, stripeAccountStatus, payoutEnabled],
  );

  if (result.rows.length === 0) {
    return { updated: false, reason: "no_listener_for_account" };
  }

  return {
    updated: true,
    listenerId: result.rows[0].listener_id,
    stripeAccountStatus,
    payoutEnabled,
  };
}

async function requestWithdrawal(listenerId, requestedAmount = null) {
  if (!stripe) {
    throw new ListenerPayoutError(
      "Payout service is not configured",
      503,
      "PAYOUT_SERVICE_UNAVAILABLE",
    );
  }

  const client = await pool.connect();
  let hasCommitted = false;

  try {
    await client.query("BEGIN");

    const requestedCents = parseRequestedAmountToCents(requestedAmount);

    const { stripeConnectAccountId } =
      await assertListenerEligibleForWithdrawal(client, listenerId);

    // Release this listener's matured pending earnings before reading the
    // available balance, so a withdrawal works the moment funds are earned
    // instead of waiting for the next earnings-release scheduler tick. Uses the
    // same predicate as releasePendingEarnings(), scoped to this listener and run
    // on the transaction client so it stays atomic with the FOR UPDATE select.
    const { enabled: releaseEnabled, holdHours } = getSchedulerConfig();
    if (releaseEnabled) {
      await client.query(
        `UPDATE listener_earnings
            SET status = 'available'
          WHERE listener_id = $1
            AND status = 'pending'
            AND (net_amount - COALESCE(paid_amount, 0)) > 0
            AND created_at <= NOW() - ($2::int * INTERVAL '1 hour')`,
        [listenerId, holdHours],
      );
    }

    const earningsResult = await client.query(
      `SELECT id, net_amount, COALESCE(paid_amount, 0) AS paid_amount
       FROM listener_earnings
       WHERE listener_id = $1
         AND status = 'available'
         AND (net_amount - COALESCE(paid_amount, 0)) > 0
       ORDER BY created_at ASC
       FOR UPDATE`,
      [listenerId],
    );

    if (earningsResult.rows.length === 0) {
      throw new ListenerPayoutError(
        "No available earnings to withdraw",
        422,
        "NO_AVAILABLE_EARNINGS",
      );
    }

    const earningBalances = earningsResult.rows.map((row) => {
      const netCents = toStripeCents(row.net_amount);
      const paidCents = toStripeCents(row.paid_amount);
      return {
        id: row.id,
        remainingCents: Math.max(0, netCents - paidCents),
      };
    });

    const availableCents = earningBalances.reduce(
      (sum, row) => sum + row.remainingCents,
      0,
    );

    const targetCents = requestedCents || availableCents;
    if (targetCents > availableCents) {
      throw new ListenerPayoutError(
        "Requested amount exceeds available earnings",
        422,
        "WITHDRAWAL_AMOUNT_EXCEEDS_AVAILABLE",
        {
          requestedAmount: parseCurrency(centsToAmount(targetCents)),
          availableAmount: parseCurrency(centsToAmount(availableCents)),
        },
      );
    }

    const allocations = [];
    let remainingCents = targetCents;
    for (const row of earningBalances) {
      if (remainingCents <= 0) {
        break;
      }

      const allocatedCents = Math.min(remainingCents, row.remainingCents);
      if (allocatedCents > 0) {
        allocations.push({
          earningId: row.id,
          allocatedCents,
        });
        remainingCents -= allocatedCents;
      }
    }

    if (remainingCents > 0 || allocations.length === 0) {
      throw new ListenerPayoutError(
        "Unable to allocate requested withdrawal amount",
        422,
        "WITHDRAWAL_ALLOCATION_FAILED",
      );
    }

    const totalAmount = centsToAmount(targetCents);

    const idempotencyKey = uuidv4();

    const payoutResult = await client.query(
      `INSERT INTO listener_payouts
        (listener_id, amount, status, idempotency_key, requested_at, request_source, metadata)
       VALUES ($1, $2, 'processing', $3, NOW(), 'listener_manual', $4)
       RETURNING id, amount, status, created_at`,
      [
        listenerId,
        totalAmount,
        idempotencyKey,
        JSON.stringify({
          requestedAmount: centsToAmount(targetCents),
          allocationCount: allocations.length,
        }),
      ],
    );

    const payout = payoutResult.rows[0];

    for (const allocation of allocations) {
      await client.query(
        `INSERT INTO listener_payout_allocations (payout_id, earning_id, allocated_amount)
         VALUES ($1, $2, $3)`,
        [
          payout.id,
          allocation.earningId,
          centsToAmount(allocation.allocatedCents),
        ],
      );
    }

    for (const allocation of allocations) {
      await client.query(
        `UPDATE listener_earnings
         SET paid_amount = paid_amount + $2,
             status = CASE
               WHEN paid_amount + $2 >= net_amount THEN 'paid'
               ELSE 'available'
             END,
             payout_id = $3
         WHERE id = $1`,
        [
          allocation.earningId,
          centsToAmount(allocation.allocatedCents),
          payout.id,
        ],
      );
    }

    let transfer;
    const transferStepCtx = {
      listenerId,
      payoutId: payout.id,
      amountCents: targetCents,
      destination: stripeConnectAccountId,
    };

    try {
      stripeLogger.attempt("transfers.create:listener_payout", transferStepCtx);
      transfer = await stripe.transfers.create(
        {
          amount: targetCents,
          currency: "usd",
          destination: stripeConnectAccountId,
          metadata: {
            listener_id: listenerId,
            listener_payout_id: payout.id,
            allocation_count: String(allocations.length),
          },
        },
        {
          idempotencyKey,
        },
      );
      stripeLogger.success(
        "transfers.create:listener_payout",
        transfer,
        transferStepCtx,
      );
    } catch (stripeError) {
      const failureReason = mapStripeFailureReason(stripeError);
      stripeLogger.failure("transfers.create:listener_payout", stripeError, {
        ...transferStepCtx,
        failureReason,
      });

      await client.query(
        `DELETE FROM listener_payout_allocations
         WHERE payout_id = $1`,
        [payout.id],
      );

      for (const allocation of allocations) {
        await client.query(
          `UPDATE listener_earnings
           SET paid_amount = GREATEST(0, paid_amount - $2),
               status = 'available',
               payout_id = NULL
           WHERE id = $1`,
          [allocation.earningId, centsToAmount(allocation.allocatedCents)],
        );
      }

      await client.query(
        `UPDATE listener_payouts
         SET status = 'failed',
             failure_reason = $2,
             processed_at = NOW()
         WHERE id = $1`,
        [payout.id, failureReason],
      );

      await client.query("COMMIT");
      hasCommitted = true;

      throw new ListenerPayoutError(
        "Payout transfer failed",
        502,
        "PAYOUT_TRANSFER_FAILED",
        {
          payoutId: payout.id,
          failureReason,
        },
      );
    }

    await client.query(
      `UPDATE listener_payouts
       SET status = 'completed',
           stripe_transfer_id = $2,
           processed_at = NOW(),
           failure_reason = NULL
       WHERE id = $1`,
      [payout.id, transfer.id],
    );

    await client.query("COMMIT");
    hasCommitted = true;

    return {
      payoutId: payout.id,
      amount: parseCurrency(payout.amount),
      requestedAmount: parseCurrency(centsToAmount(targetCents)),
      processedAmount: parseCurrency(payout.amount),
      status: "completed",
      stripeTransferId: transfer.id,
      createdAt: payout.created_at,
      processedAt: new Date().toISOString(),
      earningsCount: allocations.length,
      allocationCount: allocations.length,
    };
  } catch (error) {
    if (!hasCommitted) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        logger.error("Failed to rollback listener payout transaction", {
          error: rollbackError.message,
        });
      }
    }

    if (error instanceof ListenerPayoutError) {
      throw error;
    }

    logger.error("Unexpected error while requesting listener withdrawal", {
      listenerId,
      error: error.message,
      stack: error.stack,
    });

    throw new ListenerPayoutError(
      "Failed to process withdrawal request",
      500,
      "WITHDRAWAL_REQUEST_FAILED",
    );
  } finally {
    client.release();
  }
}

module.exports = {
  ListenerPayoutError,
  assertListenerEligibleForWithdrawal,
  createBankAccountOnboardingLink,
  createBankAccountSession,
  getBankAccountStatus,
  getWithdrawableBalance,
  requestWithdrawal,
  syncStripeAccountStatus,
};
