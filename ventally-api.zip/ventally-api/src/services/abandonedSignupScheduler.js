/**
 * Abandoned Signup Scheduler
 *
 * Runs every 2 hours. Finds rows in `abandoned_signups` where:
 *   - created_at > 30 minutes ago  (give them time to finish)
 *   - email_sent_at IS NULL         (haven't emailed them yet)
 *   - no verified user exists with that email
 *
 * Sends a re-engagement email via AWS SES, then marks email_sent_at.
 *
 * Config env vars:
 *   ABANDONED_SIGNUP_SCHEDULER_ENABLED  — default true
 *   ABANDONED_SIGNUP_DELAY_MINUTES      — default 30  (min time after capture before email)
 *   ABANDONED_SIGNUP_INTERVAL_HOURS     — default 2   (how often the job runs)
 */

const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const { sendAbandonedSignupEmail } = require("./email");

const DEFAULT_ENABLED         = true;
const DEFAULT_DELAY_MINUTES   = 30;
const DEFAULT_INTERVAL_HOURS  = 2;
const BATCH_SIZE              = 50; // emails per run

let schedulerTimer = null;
let runInProgress  = false;

function parseBoolean(value, fallback) {
  if (value === undefined || value === null || value === "") return fallback;
  return ["1", "true", "yes", "on"].includes(String(value).trim().toLowerCase());
}

function parsePositiveInt(value, fallback) {
  const n = parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

function getConfig() {
  return {
    enabled: parseBoolean(
      process.env.ABANDONED_SIGNUP_SCHEDULER_ENABLED,
      DEFAULT_ENABLED,
    ),
    delayMinutes: parsePositiveInt(
      process.env.ABANDONED_SIGNUP_DELAY_MINUTES,
      DEFAULT_DELAY_MINUTES,
    ),
    intervalMs: parsePositiveInt(
      process.env.ABANDONED_SIGNUP_INTERVAL_HOURS,
      DEFAULT_INTERVAL_HOURS,
    ) * 60 * 60 * 1000,
  };
}

async function runAbandonedSignupJob() {
  if (runInProgress) {
    logger.warn("AbandonedSignupScheduler: previous run still in progress — skipping");
    return;
  }

  const { delayMinutes } = getConfig();
  runInProgress = true;
  logger.info(`AbandonedSignupScheduler: starting run (delay=${delayMinutes}min)`);

  const client = await pool.connect();
  let sent = 0;
  let skipped = 0;

  try {
    // Fetch candidates: captured >delayMinutes ago, email not sent yet
    const candidates = await client.query(
      `SELECT a.id, a.email, a.user_type
         FROM abandoned_signups a
        WHERE a.email_sent_at IS NULL
          AND a.created_at < NOW() - ($1 || ' minutes')::INTERVAL
        ORDER BY a.created_at ASC
        LIMIT $2`,
      [String(delayMinutes), BATCH_SIZE],
    );

    if (candidates.rows.length === 0) {
      logger.info("AbandonedSignupScheduler: no candidates — nothing to do");
      return;
    }

    logger.info(`AbandonedSignupScheduler: ${candidates.rows.length} candidate(s) found`);

    for (const row of candidates.rows) {
      const { id, email } = row;

      // Skip if this email now has a verified account (they finished!)
      const verified = await client.query(
        "SELECT 1 FROM users WHERE LOWER(email) = LOWER($1) AND is_verified = true LIMIT 1",
        [email],
      );

      if (verified.rows.length > 0) {
        // Clean up the record — no point keeping it
        await client.query("DELETE FROM abandoned_signups WHERE id = $1", [id]);
        skipped++;
        continue;
      }

      try {
        await sendAbandonedSignupEmail(email);
        await client.query(
          "UPDATE abandoned_signups SET email_sent_at = NOW() WHERE id = $1",
          [id],
        );
        sent++;
        logger.info(`AbandonedSignupScheduler: re-engagement email sent to ${email}`);
      } catch (emailErr) {
        logger.error(`AbandonedSignupScheduler: failed to send to ${email}: ${emailErr.message}`);
        // Leave email_sent_at NULL so it retries next run
      }
    }
  } catch (err) {
    logger.error("AbandonedSignupScheduler: run error:", err);
  } finally {
    client.release();
    runInProgress = false;
    logger.info(`AbandonedSignupScheduler: done — sent=${sent}, skipped=${skipped}`);
  }
}

function start() {
  const { enabled, intervalMs } = getConfig();

  if (!enabled) {
    logger.info("AbandonedSignupScheduler: disabled via env — not starting");
    return;
  }

  if (schedulerTimer) {
    logger.warn("AbandonedSignupScheduler: already running");
    return;
  }

  logger.info(`AbandonedSignupScheduler: starting (interval=${intervalMs / 3600000}h)`);

  // Run once shortly after boot, then on the interval
  setTimeout(() => runAbandonedSignupJob(), 5 * 60 * 1000); // 5 min after boot
  schedulerTimer = setInterval(runAbandonedSignupJob, intervalMs);
}

function stop() {
  if (schedulerTimer) {
    clearInterval(schedulerTimer);
    schedulerTimer = null;
    logger.info("AbandonedSignupScheduler: stopped");
  }
}

module.exports = { start, stop, runAbandonedSignupJob };
