const auditLog = require("./moderationAuditLog");
const logger   = require("../utils/logger");

// ---------------------------------------------------------------------------
// Level constants
// ---------------------------------------------------------------------------
const LEVELS = { CLEAN: 1, CAUTION: 2, WARNING: 3, CRITICAL: 4 };

// ---------------------------------------------------------------------------
// Rule-based classifier
// Patterns are ordered most-severe first so we return on first match.
// ---------------------------------------------------------------------------
const RULES = [
  {
    level: LEVELS.CRITICAL,
    tags: ["hate-speech"],
    pattern: /\b(nigger|nigga|faggot|tranny|kike|spic|chink|cunt|whore|slut|bitch)\b/i,
  },
  {
    level: LEVELS.CRITICAL,
    tags: ["violence"],
    pattern: /\b(kill\s+your?self|kys|i('ll| will) (kill|murder|hurt) you|shoot\s+you|rape\s+you)\b/i,
  },
  {
    level: LEVELS.CRITICAL,
    tags: ["explicit"],
    pattern: /\b(fuck\s+me|suck\s+my\s+(dick|cock)|send\s+(nudes?|pics?)|naked|masturbat)\b/i,
  },
  {
    level: LEVELS.WARNING,
    tags: ["harassment"],
    pattern: /\b(you('re| are)(\s+\w+){0,3}\s+(stupid|dumb|idiot|moron|loser|worthless|pathetic|trash|garbage)|such\s+an?\s+(idiot|moron|loser))\b/i,
  },
  {
    level: LEVELS.WARNING,
    tags: ["profanity"],
    pattern: /\b(fuck(ing)?|shit|ass(hole)?|bastard|piss\s+off)\b/i,
  },
  {
    level: LEVELS.CAUTION,
    tags: ["profanity"],
    pattern: /\b(damn|crap|hell|bloody|bollocks|screw\s+you)\b/i,
  },
];

function ruleBasedClassify(content) {
  for (const rule of RULES) {
    if (rule.pattern.test(content)) {
      return {
        level:  rule.level,
        tags:   rule.tags,
        reason: `Matched rule-based pattern (level ${rule.level})`,
        method: "rule-based",
      };
    }
  }
  return { level: LEVELS.CLEAN, tags: [], reason: null, method: "rule-based" };
}

// ---------------------------------------------------------------------------
// AI classifier (Claude Haiku)
// Called only when ANTHROPIC_API_KEY is set.
// ---------------------------------------------------------------------------
const AI_PROMPT = `You are a content moderation assistant for a mental-health peer-support chat app called Ventally.
Classify the following user message and respond with ONLY valid JSON — no markdown, no explanation.

Levels:
  1 = Clean       (normal conversation)
  2 = Caution     (mild profanity, heated but non-targeted)
  3 = Warning     (offensive language, targeted insults)
  4 = Critical    (hate speech, slurs, threats, explicit sexual content)

Valid tags: profanity, spam, off-topic, harassment, hate-speech, violence, explicit, misinformation

Required JSON shape:
{
  "level": <integer 1-4>,
  "tags": [<string>, ...],
  "reason": <string or null>
}`;

async function aiClassify(content) {
  if (!process.env.ANTHROPIC_API_KEY) return null;

  let Anthropic;
  try {
    ({ default: Anthropic } = await import("@anthropic-ai/sdk"));
  } catch {
    return null;
  }

  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  const response = await Promise.race([
    client.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 256,
      messages: [
        { role: "user", content: `${AI_PROMPT}\n\nMessage: ${content}` },
      ],
    }),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error("AI moderation timeout")), 5000),
    ),
  ]);

  const raw = response.content?.[0]?.text?.trim();
  if (!raw) return null;

  const parsed = JSON.parse(raw);
  const level = Number(parsed.level);

  if (!Number.isInteger(level) || level < 1 || level > 4) return null;

  return {
    level,
    tags:   Array.isArray(parsed.tags) ? parsed.tags : [],
    reason: parsed.reason ?? null,
    method: "ai",
  };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
async function analyze(content, { messageId, conversationId, senderId }) {
  const ruleResult = ruleBasedClassify(content);

  let finalResult = ruleResult;

  // Only call AI when rule-based returns Clean or Caution — Critical/Warning
  // from rules are already high-confidence.
  if (ruleResult.level <= LEVELS.CAUTION && process.env.ANTHROPIC_API_KEY) {
    try {
      const aiResult = await aiClassify(content);
      if (aiResult) finalResult = aiResult;
    } catch (err) {
      logger.warn(`AI moderation fallback to rule-based: ${err.message}`);
    }
  }

  try {
    await auditLog.log({
      messageId,
      conversationId,
      senderId,
      content,
      level:  finalResult.level,
      tags:   finalResult.tags,
      reason: finalResult.reason,
      method: finalResult.method,
    });
  } catch (err) {
    logger.error(`Failed to persist moderation result: ${err.message}`);
  }

  return finalResult;
}

module.exports = { analyze };
