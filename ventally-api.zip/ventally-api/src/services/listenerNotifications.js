const { pool } = require("../database/connection");
const { sendNotificationToMultipleDevices } = require("./fcm");
const logger = require("../utils/logger");

const DEFAULT_NOTIFICATION_SETTINGS = {
  all_notifications: true,
  message_notifications: true,
  call_notifications: true,
  sound_vibration: true,
};

function getMergedSettings(settings) {
  return {
    ...DEFAULT_NOTIFICATION_SETTINGS,
    ...(settings || {}),
  };
}

function isNotificationAllowed(settings, channel) {
  const merged = getMergedSettings(settings);

  if (!merged.all_notifications || !merged.sound_vibration) {
    return false;
  }

  if (channel === "call") {
    return !!merged.call_notifications;
  }

  return !!merged.message_notifications;
}

async function getUserNotificationSettings(userId) {
  const result = await pool.query(
    `SELECT all_notifications, message_notifications, call_notifications, sound_vibration
     FROM user_notification_preferences
     WHERE user_id = $1
     LIMIT 1`,
    [userId],
  );

  return getMergedSettings(result.rows[0]);
}

async function logNotification(userId, title, body, data, status) {
  try {
    await pool.query(
      `INSERT INTO notifications (user_id, title, body, data, type, status)
       VALUES ($1, $2, $3, $4, 'push', $5)`,
      [userId, title, body, data || {}, status],
    );
  } catch (error) {
    logger.warn("Failed to persist notification log", {
      userId,
      status,
      error: error.message,
    });
  }
}

async function sendUserPushNotification({
  userId,
  title,
  body,
  data = {},
  channel = "message",
}) {
  try {
    const settings = await getUserNotificationSettings(userId);

    if (!isNotificationAllowed(settings, channel)) {
      await logNotification(userId, title, body, data, "skipped");
      return {
        userId,
        skipped: true,
        successCount: 0,
        failureCount: 0,
      };
    }

    const tokensResult = await pool.query(
      `SELECT token
       FROM device_tokens
       WHERE user_id = $1
         AND is_active = true`,
      [userId],
    );

    const tokens = tokensResult.rows.map((row) => row.token).filter(Boolean);

    if (tokens.length === 0) {
      await logNotification(userId, title, body, data, "skipped");
      return {
        userId,
        skipped: true,
        successCount: 0,
        failureCount: 0,
      };
    }

    const response = await sendNotificationToMultipleDevices(
      tokens,
      { title, body },
      data,
    );

    const status = response.successCount > 0 ? "sent" : "failed";
    await logNotification(userId, title, body, data, status);

    return {
      userId,
      skipped: false,
      successCount: response.successCount,
      failureCount: response.failureCount,
    };
  } catch (error) {
    await logNotification(userId, title, body, data, "failed");
    logger.error("User push notification failed", {
      userId,
      channel,
      error: error.message,
    });

    return {
      userId,
      skipped: false,
      successCount: 0,
      failureCount: 1,
      error: error.message,
    };
  }
}

async function sendUserPushNotifications(userIds, payload) {
  const uniqueUserIds = [...new Set((userIds || []).filter(Boolean))];

  if (uniqueUserIds.length === 0) {
    return {
      total: 0,
      sent: 0,
      failed: 0,
      skipped: 0,
    };
  }

  const results = await Promise.all(
    uniqueUserIds.map((userId) =>
      sendUserPushNotification({
        userId,
        ...payload,
      }),
    ),
  );

  return {
    total: uniqueUserIds.length,
    sent: results.filter((item) => item.successCount > 0).length,
    failed: results.filter((item) => item.failureCount > 0).length,
    skipped: results.filter((item) => item.skipped).length,
    results,
  };
}

// Backward-compatible aliases used across the codebase.
async function sendListenerPushNotification({ listenerId, ...payload }) {
  return sendUserPushNotification({
    userId: listenerId,
    ...payload,
  });
}

async function sendListenerPushNotifications(listenerIds, payload) {
  return sendUserPushNotifications(listenerIds, payload);
}

module.exports = {
  sendUserPushNotification,
  sendUserPushNotifications,
  sendListenerPushNotification,
  sendListenerPushNotifications,
};
