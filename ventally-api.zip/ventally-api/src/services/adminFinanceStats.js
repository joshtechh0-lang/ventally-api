const { pool } = require("../database/connection");

const stripe = require("../config/stripe");

const REVENUE_TRANSACTION_TYPES = [
  "subscription_payment",
  "subscription_renewal",
  "credit_purchase",
];

function toNumber(value) {
  const numericValue = parseFloat(value);
  return Number.isFinite(numericValue) ? numericValue : 0;
}

function roundCurrency(value) {
  return parseFloat(toNumber(value).toFixed(2));
}

function calculatePercentChange(currentValue, previousValue) {
  if (previousValue === 0) {
    return currentValue === 0 ? 0 : 100;
  }

  return roundCurrency(((currentValue - previousValue) / previousValue) * 100);
}

async function getRevenueWindowSummary() {
  const summaryQuery = `
    WITH checkout_revenue AS (
      SELECT
        COALESCE(cs.stripe_payment_intent_id, cs.stripe_session_id) AS dedupe_key,
        COALESCE(cs.completed_at, cs.created_at) AS event_time,
        (cs.amount_total::numeric / 100.0) AS amount,
        1 AS source_priority
      FROM checkout_sessions cs
      WHERE cs.status = 'completed'
        AND cs.amount_total IS NOT NULL
        AND cs.amount_total > 0
        AND COALESCE(cs.completed_at, cs.created_at) >= NOW() - INTERVAL '14 days'
    ),
    wallet_revenue AS (
      SELECT
        COALESCE(
          wt.stripe_payment_intent_id,
          wt.metadata->>'invoice_id',
          wt.metadata->>'session_id',
          wt.id::text
        ) AS dedupe_key,
        wt.created_at AS event_time,
        wt.amount_currency::numeric AS amount,
        2 AS source_priority
      FROM wallet_transactions wt
      WHERE wt.transaction_type = ANY($1::text[])
        AND wt.amount_currency IS NOT NULL
        AND wt.amount_currency > 0
        AND wt.created_at >= NOW() - INTERVAL '14 days'
    ),
    combined AS (
      SELECT * FROM checkout_revenue
      UNION ALL
      SELECT * FROM wallet_revenue
    ),
    ranked AS (
      SELECT
        dedupe_key,
        event_time,
        amount,
        ROW_NUMBER() OVER (
          PARTITION BY dedupe_key
          ORDER BY source_priority ASC, event_time DESC
        ) AS rank_position
      FROM combined
    ),
    deduped AS (
      SELECT event_time, amount
      FROM ranked
      WHERE rank_position = 1
    )
    SELECT
      COALESCE(
        SUM(CASE WHEN event_time >= NOW() - INTERVAL '7 days' THEN amount ELSE 0 END),
        0
      ) AS current_revenue,
      COALESCE(
        SUM(
          CASE
            WHEN event_time >= NOW() - INTERVAL '14 days'
              AND event_time < NOW() - INTERVAL '7 days'
            THEN amount
            ELSE 0
          END
        ),
        0
      ) AS previous_revenue
    FROM deduped
  `;

  const summaryResult = await pool.query(summaryQuery, [
    REVENUE_TRANSACTION_TYPES,
  ]);
  const row = summaryResult.rows[0] || {};

  const currentRevenue = roundCurrency(row.current_revenue);
  const previousRevenue = roundCurrency(row.previous_revenue);

  return {
    currentRevenue,
    previousRevenue,
    increasePercent: calculatePercentChange(currentRevenue, previousRevenue),
  };
}

async function getWeeklySalesTrend() {
  const trendQuery = `
    WITH week_windows AS (
      SELECT generate_series(
        date_trunc('week', NOW()) - INTERVAL '7 weeks',
        date_trunc('week', NOW()),
        INTERVAL '1 week'
      ) AS week_start
    ),
    checkout_revenue AS (
      SELECT
        COALESCE(cs.stripe_payment_intent_id, cs.stripe_session_id) AS dedupe_key,
        COALESCE(cs.completed_at, cs.created_at) AS event_time,
        (cs.amount_total::numeric / 100.0) AS amount,
        1 AS source_priority
      FROM checkout_sessions cs
      WHERE cs.status = 'completed'
        AND cs.amount_total IS NOT NULL
        AND cs.amount_total > 0
        AND COALESCE(cs.completed_at, cs.created_at) >= date_trunc('week', NOW()) - INTERVAL '7 weeks'
    ),
    wallet_revenue AS (
      SELECT
        COALESCE(
          wt.stripe_payment_intent_id,
          wt.metadata->>'invoice_id',
          wt.metadata->>'session_id',
          wt.id::text
        ) AS dedupe_key,
        wt.created_at AS event_time,
        wt.amount_currency::numeric AS amount,
        2 AS source_priority
      FROM wallet_transactions wt
      WHERE wt.transaction_type = ANY($1::text[])
        AND wt.amount_currency IS NOT NULL
        AND wt.amount_currency > 0
        AND wt.created_at >= date_trunc('week', NOW()) - INTERVAL '7 weeks'
    ),
    combined AS (
      SELECT * FROM checkout_revenue
      UNION ALL
      SELECT * FROM wallet_revenue
    ),
    ranked AS (
      SELECT
        dedupe_key,
        event_time,
        amount,
        ROW_NUMBER() OVER (
          PARTITION BY dedupe_key
          ORDER BY source_priority ASC, event_time DESC
        ) AS rank_position
      FROM combined
    ),
    deduped AS (
      SELECT
        date_trunc('week', event_time) AS week_start,
        amount
      FROM ranked
      WHERE rank_position = 1
    ),
    weekly_totals AS (
      SELECT week_start, SUM(amount)::numeric AS revenue
      FROM deduped
      GROUP BY week_start
    )
    SELECT
      ww.week_start,
      (ww.week_start + INTERVAL '6 days') AS week_end,
      COALESCE(wt.revenue, 0) AS revenue
    FROM week_windows ww
    LEFT JOIN weekly_totals wt ON wt.week_start = ww.week_start
    ORDER BY ww.week_start ASC
  `;

  const trendResult = await pool.query(trendQuery, [REVENUE_TRANSACTION_TYPES]);

  return trendResult.rows.map((row) => ({
    weekStart: row.week_start,
    weekEnd: row.week_end,
    revenue: roundCurrency(row.revenue),
  }));
}

async function getExpectedRevenueForNext7Days() {
  const subscriptionsQuery = `
    SELECT
      us.id,
      us.user_id,
      us.stripe_subscription_id,
      us.billing_cycle_end,
      us.status,
      COALESCE(sp.price_monthly, 0) AS plan_price_monthly,
      uw.stripe_customer_id
    FROM user_subscriptions us
    LEFT JOIN subscription_plans sp ON sp.id = us.plan_id
    LEFT JOIN user_wallets uw ON uw.user_id = us.user_id
    WHERE us.status IN ('active', 'trialing', 'past_due')
      AND us.stripe_subscription_id IS NOT NULL
      AND us.billing_cycle_end >= CURRENT_DATE
      AND us.billing_cycle_end < CURRENT_DATE + INTERVAL '8 days'
    ORDER BY us.billing_cycle_end ASC
  `;

  const subscriptionsResult = await pool.query(subscriptionsQuery);
  const subscriptionRows = subscriptionsResult.rows;

  if (subscriptionRows.length === 0) {
    const now = new Date();
    const toDate = new Date(now);
    toDate.setDate(toDate.getDate() + 7);

    return {
      totalRevenue: 0,
      subscriptionCount: 0,
      stripeInvoiceCount: 0,
      fallbackEstimateCount: 0,
      fromDate: now.toISOString(),
      toDate: toDate.toISOString(),
    };
  }

  let totalRevenue = 0;
  let stripeInvoiceCount = 0;
  let fallbackEstimateCount = 0;

  const upcomingAmounts = await Promise.all(
    subscriptionRows.map(async (subscriptionRow) => {
      const fallbackAmount = roundCurrency(subscriptionRow.plan_price_monthly);

      if (!stripe) {
        fallbackEstimateCount += 1;
        return fallbackAmount;
      }

      try {
        const upcomingInvoiceParams = {
          subscription: subscriptionRow.stripe_subscription_id,
        };

        if (subscriptionRow.stripe_customer_id) {
          upcomingInvoiceParams.customer = subscriptionRow.stripe_customer_id;
        }

        const invoice = await stripe.invoices.retrieveUpcoming(
          upcomingInvoiceParams,
        );

        const invoiceAmount =
          typeof invoice.amount_due === "number"
            ? invoice.amount_due / 100
            : typeof invoice.total === "number"
              ? invoice.total / 100
              : fallbackAmount;

        stripeInvoiceCount += 1;
        return roundCurrency(invoiceAmount);
      } catch (error) {
        fallbackEstimateCount += 1;
        return fallbackAmount;
      }
    }),
  );

  for (const amount of upcomingAmounts) {
    totalRevenue += toNumber(amount);
  }

  const now = new Date();
  const toDate = new Date(now);
  toDate.setDate(toDate.getDate() + 7);

  return {
    totalRevenue: roundCurrency(totalRevenue),
    subscriptionCount: subscriptionRows.length,
    stripeInvoiceCount,
    fallbackEstimateCount,
    fromDate: now.toISOString(),
    toDate: toDate.toISOString(),
  };
}

async function getAdminFinanceStats() {
  const [windowSummary, weeklyTrend, expectedRevenue] = await Promise.all([
    getRevenueWindowSummary(),
    getWeeklySalesTrend(),
    getExpectedRevenueForNext7Days(),
  ]);

  return {
    generatedAt: new Date().toISOString(),
    currency: "USD",
    weeklyRevenueIncrease: {
      windowDays: 7,
      currentRevenue: windowSummary.currentRevenue,
      previousRevenue: windowSummary.previousRevenue,
      increasePercent: windowSummary.increasePercent,
    },
    nextExpectedRevenue: {
      windowDays: 7,
      totalRevenue: expectedRevenue.totalRevenue,
      subscriptionCount: expectedRevenue.subscriptionCount,
      stripeInvoiceCount: expectedRevenue.stripeInvoiceCount,
      fallbackEstimateCount: expectedRevenue.fallbackEstimateCount,
      fromDate: expectedRevenue.fromDate,
      toDate: expectedRevenue.toDate,
    },
    weeklySalesData: {
      windowWeeks: 8,
      series: weeklyTrend,
    },
  };
}

module.exports = {
  getAdminFinanceStats,
};
