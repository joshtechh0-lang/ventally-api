const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const { v4: uuidv4 } = require("uuid");

function resolveSessionContext({ voiceCallId, sessionType, sessionId }) {
  const resolvedSessionType = sessionType || (voiceCallId ? "call" : null);
  const resolvedSessionId = sessionId || voiceCallId || null;

  return {
    resolvedSessionType,
    resolvedSessionId,
  };
}

function buildFilters({ from, to, sessionType, actionTaken, riskCategory }) {
  const clauses = [];
  const params = [];

  if (from) {
    params.push(from);
    clauses.push(`ce.created_at >= $${params.length}`);
  }

  if (to) {
    params.push(to);
    clauses.push(`ce.created_at <= $${params.length}`);
  }

  if (sessionType) {
    params.push(sessionType);
    clauses.push(`ce.session_type = $${params.length}`);
  }

  if (actionTaken) {
    params.push(actionTaken);
    clauses.push(`ce.action_taken = $${params.length}`);
  }

  if (riskCategory) {
    params.push(riskCategory);
    clauses.push(`ce.risk_category = $${params.length}`);
  }

  return {
    whereClause: clauses.length > 0 ? `WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

/**
 * Log a crisis event
 * @param {Object} params - Crisis event parameters
 * @param {string} params.voiceCallId - Voice call ID
 * @param {string} params.userId - User who is in crisis (venter)
 * @param {string} params.triggerType - Type of trigger (manual, ai_detected, etc.)
 * @param {string} params.riskCategory - Category of risk (self_harm, suicide, etc.)
 * @param {Array<string>} params.detectedPhrases - Keywords/phrases detected (for AI)
 * @param {string} params.actionTaken - Action taken (escalated, transferred, etc.)
 * @param {boolean} params.manualTrigger - Whether manually triggered
 * @param {string} params.triggeredBy - User ID who triggered (listener)
 * @returns {Promise<Object>} Created crisis event
 */
async function logCrisisEvent({
  voiceCallId,
  callLogId = null,
  sessionType,
  sessionId,
  userId,
  triggerType,
  riskCategory,
  detectedPhrases = [],
  actionTaken,
  manualTrigger = false,
  triggeredBy = null,
}) {
  const client = await pool.connect();

  try {
    const eventId = uuidv4();
    const { resolvedSessionType, resolvedSessionId } = resolveSessionContext({
      voiceCallId,
      sessionType,
      sessionId,
    });

    const result = await client.query(
      `INSERT INTO crisis_events (
        id, call_log_id, voice_call_id, session_type, session_id,
        user_id, trigger_type, risk_category,
        detected_phrases, action_taken, manual_trigger, triggered_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *`,
      [
        eventId,
        callLogId,
        voiceCallId,
        resolvedSessionType,
        resolvedSessionId,
        userId,
        triggerType,
        riskCategory,
        detectedPhrases,
        actionTaken,
        manualTrigger,
        triggeredBy,
      ],
    );

    logger.info(`Crisis event ${eventId} logged`, {
      voiceCallId,
      sessionType: resolvedSessionType,
      sessionId: resolvedSessionId,
      riskCategory,
      actionTaken,
      manualTrigger,
    });

    return result.rows[0];
  } finally {
    client.release();
  }
}

/**
 * Update voice call with crisis escalation flag
 * @param {string} voiceCallId - Voice call ID
 * @returns {Promise<Object>} Updated voice call
 */
async function markCallAsCrisisEscalated(voiceCallId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `UPDATE voice_calls 
       SET crisis_escalated = true
       WHERE id = $1 
       RETURNING *`,
      [voiceCallId],
    );

    if (result.rows.length === 0) {
      throw new Error("Voice call not found");
    }

    logger.info(`Call ${voiceCallId} marked as crisis escalated`);

    return result.rows[0];
  } finally {
    client.release();
  }
}

/**
 * Check if call has already been escalated
 * @param {string} voiceCallId - Voice call ID
 * @returns {Promise<boolean>} Whether call is already escalated
 */
async function isCallEscalated(voiceCallId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      "SELECT crisis_escalated FROM voice_calls WHERE id = $1",
      [voiceCallId],
    );

    if (result.rows.length === 0) {
      return false;
    }

    return result.rows[0].crisis_escalated === true;
  } finally {
    client.release();
  }
}

/**
 * Check if 988 handoff has already been performed for this call
 * @param {string} voiceCallId - Voice call ID
 * @returns {Promise<boolean>} Whether 988 handoff has occurred
 */
async function hasHandoff988Occurred(voiceCallId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT COUNT(*) as count 
       FROM crisis_events 
       WHERE voice_call_id = $1 
       AND action_taken = '988_handoff'`,
      [voiceCallId],
    );

    return parseInt(result.rows[0].count) > 0;
  } finally {
    client.release();
  }
}

/**
 * Check if a help escalation event already exists for a session.
 * Legacy call escalation action `escalated` is treated as equivalent.
 * @param {string} sessionType - Session type (`call` or `chat`)
 * @param {string} sessionId - Session identifier
 * @returns {Promise<boolean>}
 */
async function hasHelpEscalationOccurred(sessionType, sessionId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT COUNT(*) AS count
       FROM crisis_events ce
       WHERE (
         (ce.session_type = $1 AND ce.session_id = $2)
         OR ($1 = 'call' AND ce.voice_call_id = $2)
       )
       AND ce.action_taken IN ('help_escalated', 'escalated')`,
      [sessionType, sessionId],
    );

    return parseInt(result.rows[0].count, 10) > 0;
  } finally {
    client.release();
  }
}

/**
 * Get session participants for listener authorization checks.
 * @param {string} sessionType - Session type (`call` or `chat`)
 * @param {string} sessionId - Session identifier
 * @returns {Promise<Object|null>}
 */
async function getSessionParticipants(sessionType, sessionId) {
  const client = await pool.connect();

  try {
    if (sessionType === "call") {
      const result = await client.query(
        `SELECT id, venter_id, listener_id
         FROM voice_calls
         WHERE id = $1`,
        [sessionId],
      );

      return result.rows[0] || null;
    }

    if (sessionType === "chat") {
      const result = await client.query(
        `SELECT id, venter_id, listener_id
         FROM conversations
         WHERE id = $1`,
        [sessionId],
      );

      return result.rows[0] || null;
    }

    return null;
  } finally {
    client.release();
  }
}

/**
 * Get crisis events for a call
 * @param {string} voiceCallId - Voice call ID
 * @returns {Promise<Array>} Crisis events
 */
async function getCrisisEvents(voiceCallId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT ce.*, 
              u.email as user_email,
              t.email as triggered_by_email
       FROM crisis_events ce
       LEFT JOIN users u ON u.id = ce.user_id
       LEFT JOIN users t ON t.id = ce.triggered_by
        WHERE ce.voice_call_id = $1
           OR (ce.session_type = 'call' AND ce.session_id = $1)
       ORDER BY ce.created_at ASC`,
      [voiceCallId],
    );

    return result.rows;
  } finally {
    client.release();
  }
}

/**
 * Aggregate crisis event statistics for admin reporting.
 * @param {Object} filters
 * @returns {Promise<Object>}
 */
async function getCrisisAdminStats(filters = {}) {
  const client = await pool.connect();

  try {
    const { whereClause, params } = buildFilters(filters);

    const [
      totalsResult,
      sessionTypeResult,
      riskResult,
      actionResult,
      dailyResult,
    ] = await Promise.all([
      client.query(
        `SELECT
             COUNT(*)::int AS total_events,
             COUNT(DISTINCT ce.session_id)::int AS total_sessions,
             COUNT(DISTINCT ce.user_id)::int AS impacted_users,
             COUNT(DISTINCT ce.triggered_by)::int AS triggering_listeners
           FROM crisis_events ce
           ${whereClause}`,
        params,
      ),
      client.query(
        `SELECT ce.session_type, COUNT(*)::int AS count
           FROM crisis_events ce
           ${whereClause}
           GROUP BY ce.session_type
           ORDER BY count DESC`,
        params,
      ),
      client.query(
        `SELECT ce.risk_category, COUNT(*)::int AS count
           FROM crisis_events ce
           ${whereClause}
           GROUP BY ce.risk_category
           ORDER BY count DESC`,
        params,
      ),
      client.query(
        `SELECT ce.action_taken, COUNT(*)::int AS count
           FROM crisis_events ce
           ${whereClause}
           GROUP BY ce.action_taken
           ORDER BY count DESC`,
        params,
      ),
      client.query(
        `SELECT DATE_TRUNC('day', ce.created_at)::date AS date, COUNT(*)::int AS count
           FROM crisis_events ce
           ${whereClause}
           GROUP BY DATE_TRUNC('day', ce.created_at)
           ORDER BY DATE_TRUNC('day', ce.created_at) ASC`,
        params,
      ),
    ]);

    return {
      totals: totalsResult.rows[0] || {
        total_events: 0,
        total_sessions: 0,
        impacted_users: 0,
        triggering_listeners: 0,
      },
      bySessionType: sessionTypeResult.rows,
      byRiskCategory: riskResult.rows,
      byActionTaken: actionResult.rows,
      daily: dailyResult.rows,
    };
  } finally {
    client.release();
  }
}

module.exports = {
  logCrisisEvent,
  markCallAsCrisisEscalated,
  isCallEscalated,
  hasHandoff988Occurred,
  hasHelpEscalationOccurred,
  getSessionParticipants,
  getCrisisEvents,
  getCrisisAdminStats,
};
