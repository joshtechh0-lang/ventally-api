const { EventEmitter } = require("events");

const realtimeEvents = new EventEmitter();

function emitListenerStatusUpdate(payload) {
  realtimeEvents.emit("listener:status", payload);
}

module.exports = {
  realtimeEvents,
  emitListenerStatusUpdate,
};
