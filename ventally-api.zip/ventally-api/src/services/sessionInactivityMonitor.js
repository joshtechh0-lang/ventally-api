const { pool } = require("../database/connection");
const { redisClient } = require("./redis");
const { getSetting } = require("./settings");
const logger = require("../utils/logger");

const DEFAULT_IDLE_TIMEOUT_MINUTES = 30;
const CHECK_INTERVAL_MS = 60 * 1000;
const ACTIVITY_KEY_TTL_SECONDS = 31 * 60;
const CHAT_ACTIVITY_PREFIX = "session:activity:chat:";
const CALL_ACTIVITY_PREFIX = "session:activity:call:";

let intervalId = null;
let monitorInProgress = false;

function getChatActivityKey(conversationId) {
  return `${CHAT_ACTIVITY_PREFIX}${conversationId}`;
}

function getCallActivityKey(callId) {
  return `${CALL_ACTIVITY_PREFIX}${callId}`;
}

async function touchChatSessionActivity(conversationId) {
  if (!conversationId) {
    return;
  }

  try {
    await redisClient.setEx(
      getChatActivityKey(conversationId),
      ACTIVITY_KEY_TTL_SECONDS,
      String(Date.now()),
    );
  } catch (error) {
    logger.warn("Failed to update chat session activity", {
      conversationId,
      error: error.message,
    });
  }
}

async function touchCallSessionActivity(callId) {
  if (!callId) {
    return;
  }

  try {
    await redisClient.setEx(
      getCallActivityKey(callId),
      ACTIVITY_KEY_TTL_SECONDS,
      String(Date.now()),
    );
  } catch (error) {
    logger.warn("Failed to update call session activity", {
      callId,
      error: error.message,
    });
  }
}

function createMockRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.body = payload;
      return this;
    },
  };
}

function createControllerReq(io, id, userId) {
  return {
    params: { id },
    user: { id: userId },
    app: {
      get(key) {
        if (key === "io") {
          return io;
        }
        return null;
      },
    },
  };
}

async function getMostRecentActivity(activityKey, fallbackDate) {
  let latest = fallbackDate ? new Date(fallbackDate).getTime() : 0;

  try {
    const redisValue = await redisClient.get(activityKey);
    const redisTs = Number(redisValue);
    if (Number.isFinite(redisTs) && redisTs > latest) {
      latest = redisTs;
    }
  } catch (error) {
    logger.warn("Failed to read session activity from Redis", {
      activityKey,
      error: error.message,
    });
  }

  return latest;
}

async function endInactiveConversation(io, conversation) {
  try {
    const { endConversation } = require("../controllers/chatController");
    const actorId = conversation.venter_id || conversation.listener_id;
    const req = createControllerReq(io, conversation.id, actorId);
    const res = createMockRes();

    await endConversation(req, res);

    if (res.statusCode >= 400) {
      logger.warn("Failed to auto-end inactive conversation", {
        conversationId: conversation.id,
        statusCode: res.statusCode,
        response: res.body,
      });
      return;
    }

    logger.info("Auto-ended inactive conversation", {
      conversationId: conversation.id,
      idleTimeoutMinutes: DEFAULT_IDLE_TIMEOUT_MINUTES,
    });
  } catch (error) {
    logger.error("Error auto-ending inactive conversation", {
      conversationId: conversation.id,
      error: error.message,
    });
  }
}

async function endInactiveCall(io, call) {
  try {
    const { endCall } = require("../controllers/callController");
    const actorId = call.venter_id || call.listener_id;
    const req = createControllerReq(io, call.id, actorId);
    const res = createMockRes();

    await endCall(req, res);

    if (res.statusCode >= 400) {
      logger.warn("Failed to auto-end inactive call", {
        callId: call.id,
        statusCode: res.statusCode,
        response: res.body,
      });
      return;
    }

    logger.info("Auto-ended inactive call", {
      callId: call.id,
      idleTimeoutMinutes: DEFAULT_IDLE_TIMEOUT_MINUTES,
    });
  } catch (error) {
    logger.error("Error auto-ending inactive call", {
      callId: call.id,
      error: error.message,
    });
  }
}

async function runInactivityCheck(io) {
  if (monitorInProgress) {
    return;
  }

  monitorInProgress = true;

  try {
    const idleTimeoutMinutes = await getSetting(
      "session_idle_timeout_minutes",
      DEFAULT_IDLE_TIMEOUT_MINUTES,
    );

    const thresholdMs = Date.now() - Number(idleTimeoutMinutes) * 60 * 1000;

    const inactiveChatsResult = await pool.query(
      `SELECT c.id,
              c.venter_id,
              c.listener_id,
              COALESCE(MAX(m.created_at), c.started_at, c.created_at) AS last_activity_at
       FROM conversations c
       LEFT JOIN messages m ON m.conversation_id = c.id
       WHERE c.status = 'active'
       GROUP BY c.id, c.venter_id, c.listener_id, c.started_at, c.created_at
       ORDER BY last_activity_at ASC
       LIMIT 200`,
    );

    for (const conversation of inactiveChatsResult.rows) {
      const lastActivityMs = await getMostRecentActivity(
        getChatActivityKey(conversation.id),
        conversation.last_activity_at,
      );

      if (lastActivityMs > thresholdMs) {
        continue;
      }

      await endInactiveConversation(io, conversation);
      await redisClient.del(getChatActivityKey(conversation.id));
    }

    const inactiveCallsResult = await pool.query(
      `SELECT id, venter_id, listener_id, status,
              COALESCE(started_at, created_at) AS last_activity_at
       FROM voice_calls
       WHERE status IN ('ringing', 'active')
       ORDER BY COALESCE(started_at, created_at) ASC
       LIMIT 200`,
    );

    for (const call of inactiveCallsResult.rows) {
      const lastActivityMs = await getMostRecentActivity(
        getCallActivityKey(call.id),
        call.last_activity_at,
      );

      if (lastActivityMs > thresholdMs) {
        continue;
      }

      await endInactiveCall(io, call);
      await redisClient.del(getCallActivityKey(call.id));
    }
  } catch (error) {
    logger.error("Error running inactivity monitor", {
      error: error.message,
    });
  } finally {
    monitorInProgress = false;
  }
}

function startSessionInactivityMonitoring(io) {
  if (intervalId) {
    return;
  }

  intervalId = setInterval(() => {
    runInactivityCheck(io).catch((error) => {
      logger.error("Session inactivity monitor tick failed", {
        error: error.message,
      });
    });
  }, CHECK_INTERVAL_MS);

  logger.info("Session inactivity monitor started", {
    checkIntervalMs: CHECK_INTERVAL_MS,
    defaultIdleTimeoutMinutes: DEFAULT_IDLE_TIMEOUT_MINUTES,
  });
}

function stopSessionInactivityMonitoring() {
  if (!intervalId) {
    return;
  }

  clearInterval(intervalId);
  intervalId = null;

  logger.info("Session inactivity monitor stopped");
}

module.exports = {
  startSessionInactivityMonitoring,
  stopSessionInactivityMonitoring,
  touchChatSessionActivity,
  touchCallSessionActivity,
};
