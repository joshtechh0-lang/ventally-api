/**
 * Stripe Tax helpers for off-session charges (PAYG, tips).
 *
 * `automatic_tax: { enabled: true }` only works on Checkout Sessions, Invoices
 * and Subscriptions — it is NOT a parameter on PaymentIntent. The PAYG and tip
 * flows charge a saved card off-session via PaymentIntent, so for those we use
 * the Tax Calculations API instead:
 *   1. calculateInclusiveTax() up front  → compute the embedded tax portion,
 *   2. tag the PaymentIntent with the calculation id,
 *   3. recordTaxTransaction() once the charge succeeds (webhook) → books the tax
 *      transaction in Stripe Tax for reporting/filing.
 *
 * Tax is INCLUSIVE, so calculation.amount_total === amountCents: the amount we
 * charge the customer never changes; only the embedded tax portion is recorded.
 *
 * Every call here is best-effort. Tax must NEVER block or alter a charge: a
 * null/failed result means "charge as before, just don't record tax" (typically
 * because the customer has no address on file or no registration covers them).
 */
const stripe = require("../config/stripe");
const stripeLogger = require("../utils/stripeLogger");

// Optional account-wide product tax code. When unset, Stripe applies the
// account's default product tax code configured in the dashboard.
const DEFAULT_TAX_CODE = process.env.STRIPE_DEFAULT_TAX_CODE || null;

/**
 * Compute inclusive tax for a single off-session charge.
 *
 * @param {object}  params
 * @param {string}  params.customerId  Stripe customer (must have an address for
 *                                     tax to resolve; otherwise we return null).
 * @param {number}  params.amountCents Charge amount in the smallest unit.
 * @param {string}  params.currency    ISO currency, e.g. "usd".
 * @param {string}  params.reference   Stable line-item reference (e.g. the
 *                                     session/tip id) for the calculation.
 * @param {string} [params.taxCode]    Override product tax code.
 * @returns {Promise<object|null>} The Stripe Tax Calculation, or null if tax
 *          could not be calculated (Stripe disabled, no address, no
 *          registration, invalid amount, …).
 */
async function calculateInclusiveTax({
  customerId,
  amountCents,
  currency,
  reference,
  taxCode = DEFAULT_TAX_CODE,
}) {
  if (!stripe || !customerId || !amountCents || amountCents <= 0) {
    return null;
  }

  const ctx = { customerId, amountCents, currency, reference };
  try {
    stripeLogger.attempt("tax.calculations.create", ctx);
    const calculation = await stripe.tax.calculations.create({
      currency,
      customer: customerId,
      line_items: [
        {
          amount: amountCents,
          reference,
          tax_behavior: "inclusive",
          ...(taxCode ? { tax_code: taxCode } : {}),
        },
      ],
    });
    stripeLogger.success("tax.calculations.create", calculation, ctx);
    return calculation;
  } catch (err) {
    // Most common: customer has no address, or no registration in their region.
    // Never block the charge on tax — log and fall back to an untaxed charge.
    stripeLogger.failure("tax.calculations.create", err, ctx);
    return null;
  }
}

/**
 * Book a Tax Transaction from a previously-created calculation. Called after the
 * PaymentIntent succeeds (webhook). Idempotent on `reference` — pass the
 * PaymentIntent id so webhook retries don't double-record.
 *
 * @param {object} params
 * @param {string} params.calculationId  Id returned by calculateInclusiveTax.
 * @param {string} params.reference      Unique reference (the PaymentIntent id).
 * @returns {Promise<object|null>} The Tax Transaction, or null on failure
 *          (logged, never thrown).
 */
async function recordTaxTransaction({ calculationId, reference }) {
  if (!stripe || !calculationId || !reference) {
    return null;
  }

  const ctx = { calculationId, reference };
  try {
    stripeLogger.attempt("tax.transactions.createFromCalculation", ctx);
    const transaction = await stripe.tax.transactions.createFromCalculation(
      {
        calculation: calculationId,
        reference,
      },
      // Short-term idempotency for webhook retries; the unique `reference` on the
      // transaction is the durable guard once the key expires.
      { idempotencyKey: `taxtxn:${reference}` },
    );
    stripeLogger.success(
      "tax.transactions.createFromCalculation",
      transaction,
      ctx,
    );
    return transaction;
  } catch (err) {
    stripeLogger.failure("tax.transactions.createFromCalculation", err, ctx);
    return null;
  }
}

module.exports = { calculateInclusiveTax, recordTaxTransaction };
