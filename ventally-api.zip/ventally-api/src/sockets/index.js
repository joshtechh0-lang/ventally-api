const logger = require("../utils/logger");

/**
 * Initialize all Socket.io handlers
 * @param {Server} io - Socket.io server instance
 */
module.exports = (io) => {
  logger.info("Initializing Socket.io handlers");

  // Import and initialize handlers
  require("./chatHandler")(io);
  require("./callHandler")(io);
  require("./discoveryHandler")(io);

  logger.info("Socket.io handlers initialized");
};
