const { pool } = require("../database/connection");
const anonymizer = require("../services/anonymizer");
const presence = require("../services/presence");
const klaviyo = require("../services/klaviyo");
const logger = require("../utils/logger");
const {
  startBalanceMonitoring,
  stopBalanceMonitoring,
} = require("../services/balanceMonitor");
const {
  touchCallSessionActivity,
} = require("../services/sessionInactivityMonitor");

module.exports = (io) => {
  io.on("connection", (socket) => {
    /**
     * Join call room (when participant joins Twilio call)
     */
    socket.on("call:joined", async (data) => {
      try {
        const { callId, conferenceSid, sessionSid } = data;
        const joinedSessionSid = sessionSid || conferenceSid;

        if (!callId) {
          return socket.emit("error", {
            event: "call:joined",
            message: "Call ID required",
          });
        }

        // Verify participant authorization
        const callResult = await pool.query(
          `SELECT venter_id, listener_id, status, started_at, rate_per_minute,
                  twilio_conference_sid, voice_session_sid
           FROM voice_calls 
           WHERE id = $1`,
          [callId],
        );

        if (callResult.rows.length === 0) {
          return socket.emit("error", {
            event: "call:joined",
            message: "Call not found",
          });
        }

        const call = callResult.rows[0];

        await touchCallSessionActivity(callId);

        if (![call.venter_id, call.listener_id].includes(socket.userId)) {
          return socket.emit("error", {
            event: "call:joined",
            message: "Not authorized",
          });
        }

        // Join Socket.io room
        const roomName = `call:${callId}`;
        socket.join(roomName);

        // If session SID provided by mobile, update it immediately for tracing.
        if (joinedSessionSid && !call.voice_session_sid) {
          if (/^[A-Za-z0-9_-]{8,128}$/.test(joinedSessionSid)) {
            await pool.query(
              `UPDATE voice_calls 
               SET voice_session_sid = $1,
                   twilio_conference_sid = COALESCE(twilio_conference_sid, $1)
               WHERE id = $2 AND voice_session_sid IS NULL`,
              [joinedSessionSid, callId],
            );
            logger.debug(
              `Session SID ${joinedSessionSid} set for call ${callId} via socket`,
            );
          } else {
            logger.warn(
              `Invalid session SID format received: ${joinedSessionSid}`,
            );
          }
        }

        // ATOMIC: Transition from ringing to active (race condition safe)
        // Only the FIRST participant to emit this will succeed
        if (call.status === "ringing" && !call.started_at) {
          const updateResult = await pool.query(
            `UPDATE voice_calls 
             SET status = 'active', 
                 started_at = NOW() 
             WHERE id = $1 
               AND status = 'ringing' 
               AND started_at IS NULL 
             RETURNING started_at, venter_id, rate_per_minute`,
            [callId],
          );

          // Check if we won the race (returned rows means we were first)
          if (updateResult.rows.length > 0) {
            const updatedCall = updateResult.rows[0];

            logger.info(
              "[minutes-debug] call:joined set call active (started_at set)",
              {
                callId,
                venterId: updatedCall.venter_id,
                startedAt: updatedCall.started_at,
                setBy: socket.userId,
              },
            );

            // Notify room that call is now active
            io.to(roomName).emit("call:active", {
              callId: callId,
              startedAt: updatedCall.started_at.toISOString(),
            });

            // Start balance monitoring ONCE (only winner of race does this)
            try {
              await startBalanceMonitoring(
                callId,
                updatedCall.venter_id,
                parseFloat(updatedCall.rate_per_minute),
                updatedCall.started_at,
                io,
              );
              logger.info(
                `Balance monitoring started for call ${callId} by user ${socket.userId}`,
              );
            } catch (monitorError) {
              logger.error(
                `Failed to start balance monitoring for call ${callId}:`,
                monitorError,
              );
            }
          } else {
            // Lost race - another participant already activated the call
            logger.debug(
              `User ${socket.userId} joined call ${callId} (already active)`,
            );
          }
        } else {
          logger.info(
            "[minutes-debug] call:joined did NOT activate call",
            {
              callId,
              statusAtJoin: call.status,
              startedAt: call.started_at,
              joinedBy: socket.userId,
            },
          );
        }

        socket.emit("call:joined:ack", {
          callId: callId,
          status: call.status === "ringing" ? "active" : call.status,
        });

        logger.debug(`User ${socket.userId} joined call room ${callId}`);
      } catch (error) {
        logger.error(`Error in call:joined: ${error.message}`, error);
        socket.emit("error", {
          event: "call:joined",
          message: "Failed to join call",
        });
      }
    });

    /**
     * Leave call room
     */
    socket.on("call:leave", async (data) => {
      try {
        const { callId } = data;

        if (callId) {
          const roomName = `call:${callId}`;
          socket.leave(roomName);
          await touchCallSessionActivity(callId);

          // Stop balance monitoring when participant leaves
          try {
            await stopBalanceMonitoring(callId);
            logger.debug(`Balance monitoring stopped for call ${callId}`);
          } catch (monitorError) {
            logger.error(
              `Error stopping balance monitoring for call ${callId}:`,
              monitorError,
            );
          }

          // Release busy only after terminal call states to avoid premature availability.
          const callResult = await pool.query(
            `SELECT listener_id, venter_id, status
             FROM voice_calls
             WHERE id = $1`,
            [callId],
          );

          if (callResult.rows.length > 0) {
            const call = callResult.rows[0];
            const isParticipant = [call.listener_id, call.venter_id].includes(
              socket.userId,
            );
            if (
              isParticipant &&
              ["ended", "cancelled", "declined"].includes(call.status)
            ) {
              await presence.clearListenerBusy(call.listener_id);
            }
          }

          logger.debug(`User ${socket.userId} left call room ${callId}`);
        }
      } catch (error) {
        logger.error(`Error in call:leave: ${error.message}`);
      }
    });

    /**
     * Crisis end — either participant can trigger immediate session termination.
     * Skips billing settlement and tip UI on both clients.
     */
    socket.on("session:crisis_end", async (data) => {
      try {
        const { callId } = data;

        if (!callId) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: "Call ID required",
          });
        }

        const callResult = await pool.query(
          "SELECT venter_id, listener_id, status FROM voice_calls WHERE id = $1",
          [callId],
        );

        if (callResult.rows.length === 0) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: "Call not found",
          });
        }

        const call = callResult.rows[0];

        if (![call.venter_id, call.listener_id].includes(socket.userId)) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: "Not authorized",
          });
        }

        if (!["ringing", "active"].includes(call.status)) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: `Cannot end: call is ${call.status}`,
          });
        }

        await touchCallSessionActivity(callId);

        try {
          await stopBalanceMonitoring(callId);
        } catch (monitorError) {
          logger.error(
            `Failed to stop balance monitoring for call ${callId} during crisis end:`,
            monitorError,
          );
        }

        await pool.query(
          `UPDATE voice_calls SET status = 'ended', ended_at = NOW()
           WHERE id = $1 AND status NOT IN ('ended', 'cancelled', 'declined')`,
          [callId],
        );

        const payload = { callId, reason: "crisis", skipTip: true };
        io.to(String(call.venter_id)).emit("session:ended", payload);
        io.to(String(call.listener_id)).emit("session:ended", payload);

        pool.query("SELECT email, first_name FROM users WHERE id = $1", [call.venter_id])
          .then(({ rows }) => {
            if (rows.length > 0) {
              klaviyo.trackCrisisCallFollowUp({ email: rows[0].email });
            }
          })
          .catch(() => {});

        logger.info(
          `Call ${callId} ended via crisis by user ${socket.userId}`,
        );
      } catch (error) {
        logger.error(`Error in session:crisis_end: ${error.message}`, error);
        socket.emit("error", {
          event: "session:crisis_end",
          message: "Failed to end session",
        });
      }
    });

    /**
     * Cancel call (before accepted)
     */
    socket.on("call:cancel", async (data) => {
      try {
        const { callId } = data;

        if (!callId) {
          return socket.emit("error", {
            event: "call:cancel",
            message: "Call ID required",
          });
        }

        const callResult = await pool.query(
          "SELECT venter_id, listener_id, status FROM voice_calls WHERE id = $1",
          [callId],
        );

        if (callResult.rows.length === 0) {
          return socket.emit("error", {
            event: "call:cancel",
            message: "Call not found",
          });
        }

        const call = callResult.rows[0];
        await touchCallSessionActivity(callId);

        // Only venter can cancel
        if (call.venter_id !== socket.userId) {
          return socket.emit("error", {
            event: "call:cancel",
            message: "Only the caller can cancel",
          });
        }

        // Can only cancel if still requesting
        if (call.status !== "requesting") {
          return socket.emit("error", {
            event: "call:cancel",
            message: `Cannot cancel: call is ${call.status}`,
          });
        }

        // Update status
        await pool.query(
          "UPDATE voice_calls SET status = 'cancelled', ended_at = NOW() WHERE id = $1",
          [callId],
        );

        // Notify listener (user personal room)
        io.to(String(call.listener_id)).emit("call:cancelled", {
          callId: callId,
          message: "The caller cancelled the request",
        });

        socket.emit("call:cancel:ack", {
          callId: callId,
        });

        logger.info(`Call ${callId} cancelled by venter`);
      } catch (error) {
        logger.error(`Error in call:cancel: ${error.message}`);
        socket.emit("error", {
          event: "call:cancel",
          message: "Failed to cancel call",
        });
      }
    });
  });
};
