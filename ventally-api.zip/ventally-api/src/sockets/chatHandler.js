const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const anonymizer = require("../services/anonymizer");
const walletController = require("../controllers/walletController");
const presence = require("../services/presence");
const {
  sendUserPushNotifications,
} = require("../services/listenerNotifications");
const {
  getConversationParticipants,
  isConversationParticipant,
  getConversationMessages,
} = require("../services/chatHistory");
const klaviyo = require("../services/klaviyo");
const logger = require("../utils/logger");
const {
  touchChatSessionActivity,
} = require("../services/sessionInactivityMonitor");
const moderationService = require("../services/moderationService");

function emitChatError(socket, message, reason) {
  logger.warn("Chat message rejected", {
    userId: socket?.userId,
    reason,
    message,
  });

  socket.emit("error", {
    event: "chat:message",
    message,
    reason,
  });
}

function emitInsufficientBalanceSessionEvent(
  io,
  conversation,
  actorId,
  reason,
) {
  if (!io || !conversation?.id) {
    return;
  }

  const payload = {
    conversationId: conversation.id,
    reason: reason || "insufficient_balance",
    actorId,
    status: "blocked",
    message: "Insufficient balance to continue chat session",
    timestamp: new Date().toISOString(),
  };

  io.to(`chat:${conversation.id}`).emit("chat:insufficient-balance", payload);
  io.to(String(conversation.venter_id)).emit(
    "chat:insufficient-balance",
    payload,
  );
  io.to(String(conversation.listener_id)).emit(
    "chat:insufficient-balance",
    payload,
  );
}

function createMockRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.body = payload;
      return this;
    },
  };
}

async function reflectInsufficientBalanceInSession(
  io,
  conversationId,
  actorId,
) {
  if (!conversationId || !actorId) {
    return;
  }

  try {
    const { endConversation } = require("../controllers/chatController");
    const req = {
      params: { id: conversationId },
      user: { id: actorId },
      app: {
        get(key) {
          if (key === "io") {
            return io;
          }
          return null;
        },
      },
    };
    const res = createMockRes();

    await endConversation(req, res);

    if (res.statusCode >= 400) {
      logger.warn("Failed to auto-end chat after insufficient balance", {
        conversationId,
        actorId,
        statusCode: res.statusCode,
        response: res.body,
      });
      return;
    }

    logger.info("Auto-ended chat after insufficient balance", {
      conversationId,
      actorId,
    });
  } catch (error) {
    logger.error("Error auto-ending chat after insufficient balance", {
      conversationId,
      actorId,
      error: error.message,
    });
  }
}

module.exports = (io) => {
  // Chat namespace - handles all chat Socket events
  io.on("connection", (socket) => {
    /**
     * Send a message in a conversation
     */
    socket.on("chat:message", async (data) => {
      const client = await pool.connect();

      try {
        const { conversationId, content } = data;

        if (!conversationId || !content || content.trim() === "") {
          return emitChatError(
            socket,
            "Conversation ID and content are required",
            "validation_failed",
          );
        }

        // Get conversation and verify participant
        await client.query("BEGIN");

        const convResult = await client.query(
          "SELECT venter_id, listener_id, status FROM conversations WHERE id = $1",
          [conversationId],
        );

        if (convResult.rows.length === 0) {
          await client.query("ROLLBACK");
          return emitChatError(socket, "Conversation not found", "not_found");
        }

        const conv = convResult.rows[0];
        conv.id = conversationId;

        if (![conv.venter_id, conv.listener_id].includes(socket.userId)) {
          await client.query("ROLLBACK");
          return emitChatError(
            socket,
            "You are not a participant in this conversation",
            "forbidden",
          );
        }

        if (conv.status !== "active") {
          await client.query("ROLLBACK");
          return emitChatError(
            socket,
            `Cannot send message: conversation is ${conv.status}`,
            "conversation_inactive",
          );
        }

        const isVenterMessage = socket.userId === conv.venter_id;

        if (isVenterMessage) {
          const eligibility = await walletController.canMakeCall(
            conv.venter_id,
          );

          if (!eligibility.allowed) {
            await client.query("ROLLBACK");
            const failureReason = eligibility.reason || "insufficient_balance";

            emitChatError(
              socket,
              "Insufficient balance to send message",
              failureReason,
            );

            emitInsufficientBalanceSessionEvent(
              io,
              conv,
              socket.userId,
              failureReason,
            );

            await reflectInsufficientBalanceInSession(
              io,
              conversationId,
              socket.userId,
            );

            return;
          }

          const subscriptionResult = await client.query(
            `SELECT id, included_messages, used_messages
             FROM user_subscriptions
             WHERE user_id = $1
               AND status IN ('active', 'trialing')
             ORDER BY created_at DESC
             LIMIT 1
             FOR UPDATE`,
            [conv.venter_id],
          );

          if (subscriptionResult.rows.length > 0) {
            const subscription = subscriptionResult.rows[0];

            await client.query(
              `UPDATE user_subscriptions
               SET used_messages = used_messages + 1,
                   updated_at = NOW()
               WHERE id = $1`,
              [subscription.id],
            );
          }
        }

        // Save message to database
        const messageResult = await client.query(
          `INSERT INTO messages (conversation_id, sender_id, content, delivered_at)
           VALUES ($1, $2, $3, NOW())
           RETURNING *`,
          [conversationId, socket.userId, content.trim()],
        );

        await client.query("COMMIT");

        const message = messageResult.rows[0];
        await touchChatSessionActivity(conversationId);

        // Non-blocking moderation — runs after COMMIT so message_id FK is valid
        moderationService
          .analyze(content.trim(), {
            messageId:      message.id,
            conversationId,
            senderId:       socket.userId,
          })
          .catch((err) => logger.error(`Moderation analysis failed: ${err.message}`));

        // Get sender's anonymous identity
        const senderIdentity = await anonymizer.getSessionIdentity(
          conversationId,
          socket.userId,
        );

        // Get recipient
        const recipientId =
          socket.userId === conv.venter_id ? conv.listener_id : conv.venter_id;
        const messageData = {
          messageId: message.id,
          conversationId: conversationId,
          content: message.content,
          senderId: socket.userId,
          receiverId: recipientId,
          sender: {
            anonymousName: senderIdentity.anonymousName,
            avatarSeed: `${senderIdentity.avatarSeed}:${conv.listener_id}`,
          },
          deliveredAt: message.delivered_at,
          createdAt: message.created_at,
        };

        // Deliver to recipient user room so all active sockets receive the message.
        io.to(String(recipientId)).emit("chat:message", messageData);

        const notificationPayload = {
          messageId: message.id,
          conversationId,
          type: "chat_message",
          notificationChannel: "message",
          sender: {
            id: socket.userId,
            anonymousName: senderIdentity.anonymousName,
            avatarSeed: `${senderIdentity.avatarSeed}:${conv.listener_id}`,
          },
          createdAt: message.created_at,
        };

        // Emit in-app notification for the actual receiver only.
        io.to(String(recipientId)).emit(
          "notifications:new-message",
          notificationPayload,
        );

        const pushResult = await sendUserPushNotifications([recipientId], {
          channel: "message",
          title: "Ventally",
          body: `${senderIdentity.anonymousName || "A user"} sent a new message`,
          data: {
            type: "chat_message",
            notification_channel: "message",
            messageId: String(message.id),
            conversationId: String(conversationId),
          },
        });

        logger.debug("Chat message notification dispatched", {
          conversationId: String(conversationId),
          messageId: String(message.id),
          recipientId: String(recipientId),
          push: pushResult,
        });

        // Acknowledge to sender
        socket.emit("chat:message:ack", {
          messageId: message.id,
          conversationId: conversationId,
          createdAt: message.created_at,
        });

        logger.debug(
          `Chat message sent in ${conversationId}: ${socket.userId} -> ${recipientId}`,
        );
      } catch (error) {
        try {
          await client.query("ROLLBACK");
        } catch (rollbackError) {
          logger.error(
            `Rollback failed in chat:message: ${rollbackError.message}`,
          );
        }

        logger.error(`Error in chat:message: ${error.message}`);
        emitChatError(socket, "Failed to send message", "internal_error");
      } finally {
        client.release();
      }
    });

    /**
     * Typing indicator
     */
    socket.on("chat:typing", async (data) => {
      try {
        const { conversationId, isTyping } = data;

        if (!conversationId) {
          return;
        }

        // Get conversation
        const convResult = await pool.query(
          "SELECT venter_id, listener_id FROM conversations WHERE id = $1",
          [conversationId],
        );

        if (convResult.rows.length === 0) {
          return;
        }

        const conv = convResult.rows[0];

        if (![conv.venter_id, conv.listener_id].includes(socket.userId)) {
          return;
        }

        // Get sender identity
        const senderIdentity = await anonymizer.getSessionIdentity(
          conversationId,
          socket.userId,
        );

        // Get recipient
        const recipientId =
          socket.userId === conv.venter_id ? conv.listener_id : conv.venter_id;
        io.to(String(recipientId)).emit("chat:typing", {
          conversationId: conversationId,
          user: {
            anonymousName: senderIdentity.anonymousName,
          },
          isTyping: isTyping,
        });

        await touchChatSessionActivity(conversationId);
      } catch (error) {
        logger.error(`Error in chat:typing: ${error.message}`);
      }
    });

    /**
     * Mark messages as read
     */
    socket.on("chat:read", async (data) => {
      try {
        const { conversationId, messageIds } = data;

        if (!conversationId || !messageIds || !Array.isArray(messageIds)) {
          return socket.emit("error", {
            event: "chat:read",
            message: "Conversation ID and message IDs array required",
          });
        }

        // Verify participant
        const convResult = await pool.query(
          "SELECT venter_id, listener_id FROM conversations WHERE id = $1",
          [conversationId],
        );

        if (convResult.rows.length === 0) {
          return;
        }

        const conv = convResult.rows[0];

        if (![conv.venter_id, conv.listener_id].includes(socket.userId)) {
          return;
        }

        // Update read status for messages sent TO this user (not BY this user)
        await pool.query(
          `UPDATE messages 
           SET read_at = NOW() 
           WHERE conversation_id = $1 
             AND id = ANY($2::uuid[])
             AND sender_id != $3
             AND read_at IS NULL`,
          [conversationId, messageIds, socket.userId],
        );

        await touchChatSessionActivity(conversationId);

        // Get other participant
        const recipientId =
          socket.userId === conv.venter_id ? conv.listener_id : conv.venter_id;
        // Notify sender that their messages were read on all active sockets.
        io.to(String(recipientId)).emit("chat:read:ack", {
          conversationId: conversationId,
          messageIds: messageIds,
          readAt: new Date().toISOString(),
        });

        socket.emit("chat:read:success", {
          conversationId: conversationId,
          messageIds: messageIds,
        });
      } catch (error) {
        logger.error(`Error in chat:read: ${error.message}`);
      }
    });

    /**
     * Join conversation room (for real-time updates)
     */
    socket.on("chat:join", async (data) => {
      try {
        const { conversationId, limit = 50, before } = data || {};

        if (!conversationId) {
          return socket.emit("error", {
            event: "chat:join",
            message: "Conversation ID required",
          });
        }

        // Verify participant
        const conversation = await getConversationParticipants(conversationId);

        if (!conversation) {
          return socket.emit("error", {
            event: "chat:join",
            message: "Conversation not found",
          });
        }

        if (!isConversationParticipant(conversation, socket.userId)) {
          return socket.emit("error", {
            event: "chat:join",
            message: "Not authorized",
          });
        }

        const history = await getConversationMessages({
          conversationId,
          userId: socket.userId,
          limit,
          before,
        });

        await touchChatSessionActivity(conversationId);

        // Join Socket.io room
        const roomName = `chat:${conversationId}`;
        socket.join(roomName);

        socket.emit("chat:joined", {
          conversationId: conversationId,
          status: conversation.status,
          initialHistory: {
            count: history.count,
            hasMore: history.hasMore,
            before: history.before,
            messages: history.messages,
          },
        });

        logger.debug(
          `User ${socket.userId} joined chat room ${conversationId}`,
        );
      } catch (error) {
        logger.error(`Error in chat:join: ${error.message}`);
        socket.emit("error", {
          event: "chat:join",
          message: "Failed to join conversation",
        });
      }
    });

    /**
     * Leave conversation room
     */
    socket.on("chat:leave", async (data) => {
      try {
        const { conversationId } = data;

        if (conversationId) {
          const roomName = `chat:${conversationId}`;
          socket.leave(roomName);

          const conversation =
            await getConversationParticipants(conversationId);
          if (
            conversation &&
            isConversationParticipant(conversation, socket.userId) &&
            ["ended", "cancelled", "declined"].includes(conversation.status)
          ) {
            await presence.clearListenerBusy(conversation.listener_id);
          }

          logger.debug(
            `User ${socket.userId} left chat room ${conversationId}`,
          );
        }
      } catch (error) {
        logger.error(`Error in chat:leave: ${error.message}`);
      }
    });

    /**
     * Crisis end — either participant can trigger immediate chat termination.
     * Skips tip UI on both clients.
     */
    socket.on("session:crisis_end", async (data) => {
      try {
        const { conversationId } = data;

        if (!conversationId) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: "Conversation ID required",
          });
        }

        const convResult = await pool.query(
          "SELECT venter_id, listener_id, status FROM conversations WHERE id = $1",
          [conversationId],
        );

        if (convResult.rows.length === 0) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: "Conversation not found",
          });
        }

        const conv = convResult.rows[0];

        if (![conv.venter_id, conv.listener_id].includes(socket.userId)) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: "Not authorized",
          });
        }

        if (!["active", "accepted"].includes(conv.status)) {
          return socket.emit("error", {
            event: "session:crisis_end",
            message: `Cannot end: conversation is ${conv.status}`,
          });
        }

        await touchChatSessionActivity(conversationId);

        await pool.query(
          `UPDATE conversations SET status = 'ended', ended_at = NOW()
           WHERE id = $1 AND status NOT IN ('ended', 'cancelled', 'declined')`,
          [conversationId],
        );

        const roomName = `chat:${conversationId}`;
        io.to(roomName).emit("session:ended", {
          conversationId,
          reason: "crisis",
          skipTip: true,
        });

        pool.query("SELECT email, first_name FROM users WHERE id = $1", [conv.venter_id])
          .then(({ rows }) => {
            if (rows.length > 0) {
              klaviyo.trackCrisisCallFollowUp({ email: rows[0].email });
            }
          })
          .catch(() => {});

        logger.info(
          `Conversation ${conversationId} ended via crisis by user ${socket.userId}`,
        );
      } catch (error) {
        logger.error(`Error in session:crisis_end (chat): ${error.message}`, error);
        socket.emit("error", {
          event: "session:crisis_end",
          message: "Failed to end session",
        });
      }
    });
  });
};
