"use strict";
const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const presence = require("../services/presence");
const { sendDataOnlyNotificationToMultipleDevices } = require("../services/fcm");
const { sendListenerSessionRequestEmail } = require("../services/email");
const logger = require("../utils/logger");

const twilio = (() => {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  if (sid && token) return require("twilio")(sid, token);
  return null;
})();
const twilioPhone = process.env.TWILIO_PHONE_NUMBER;
const BROADCAST_TTL_SECONDS = 60;

function emitToUser(io, userId, event, data) {
  if (!io || !userId) return;
  io.to(String(userId)).emit(event, data);
}

const getAllListeners = async (venterId) => {
  if (process.env.TEST_LISTENER_ID) {
    const r = await pool.query("SELECT lp.listener_id, u.email, u.first_name, u.phone FROM listener_profiles lp JOIN users u ON u.id = lp.listener_id WHERE lp.listener_id = $1", [process.env.TEST_LISTENER_ID]);
    return r.rows;
  }
  const result = await pool.query(
    `SELECT lp.listener_id, u.email, u.first_name, u.phone
     FROM listener_profiles lp
     JOIN users u ON u.id = lp.listener_id
     WHERE lp.is_online = true AND lp.is_busy = false
       AND u.is_active = true AND u.is_verified = true
       AND lp.listener_id != $1
     ORDER BY lp.average_rating DESC, lp.total_sessions DESC`,
    [venterId]
  );
  logger.info(`Notifying all ${result.rows.length} available listeners`);
  return result.rows;
};

const notifyAllListeners = async (sessionType, venterId, requestType, anonymousName, broadcastId) => {
  const loginUrl = "https://ventally-web-five.vercel.app/redirect?to=/listener/requests";
  try {
    const listeners = await getAllListeners(venterId);
    if (listeners.length === 0) return;

    // Push notifications go to ALL eligible listeners (online or not) — push is how we reach offline/backgrounded listeners.
        const allListenersResult = await pool.query(
      `SELECT lp.listener_id, u.email
         FROM listener_profiles lp
         JOIN users u ON u.id = lp.listener_id
         WHERE lp.is_busy = false AND u.is_active = true AND u.is_verified = true
           AND lp.listener_id != $1
           AND NOT EXISTS (
             SELECT 1 FROM blocked_users
             WHERE (blocker_id = $1 AND blocked_id = lp.listener_id)
                OR (blocker_id = lp.listener_id AND blocked_id = $1)
           )`,
      [venterId]
    );
    const allListenerIds = allListenersResult.rows.map(r => r.listener_id);

    const tokenResult = await pool.query(
      "SELECT dt.token, dt.user_id FROM device_tokens dt WHERE dt.is_active = true AND dt.user_id = ANY($1::uuid[])",
      [allListenerIds]
    );
    const tokens = tokenResult.rows
      .map(r => r.token);
    const listenersWithPush = new Set(tokenResult.rows.map(r => r.user_id));

    // For SMS/email fallback: use online-only listeners who have no push token
    const onlineListenerIds = new Set(listeners.map(l => l.listener_id));
    if (tokens.length > 0) {
      try {
        await sendDataOnlyNotificationToMultipleDevices(
          tokens,
          {
            type: "session_request",
            requestType,
            venterId,
            anonymousName,
            title: "Someone needs support",
            body: `A venter needs a ${sessionType} session. Tap to connect.`,
          },
          {
            title: "Someone needs support",
            body: `A venter needs a ${sessionType} session. Tap to connect.`,
          },
        );
        logger.info(`Push sent to ${tokens.length} listeners`);
      } catch (e) { logger.error("Push error:", e.message); }
    }

    for (const listener of listeners) {
      const hasPush = listenersWithPush.has(listener.listener_id);
      if (hasPush) continue;

      if (listener.phone && twilio && twilioPhone) {
        const smsMsg = `Ventally: A venter needs ${sessionType} support. Connect: ${loginUrl}`;
        twilio.messages.create({ body: smsMsg, from: twilioPhone, to: listener.phone })
          .then(() => logger.info(`SMS sent to ${listener.phone}`))
          .catch(() => {
            if (listener.email) {
              sendListenerSessionRequestEmail(listener.email, listener.first_name, sessionType, loginUrl)
                .catch(e => logger.error("Email fallback failed:", e.message));
            }
          });
      } else if (listener.email) {
        sendListenerSessionRequestEmail(listener.email, listener.first_name, sessionType, loginUrl)
          .catch(e => logger.error("Email failed:", e.message));
      }
    }
  } catch (e) { logger.error("notifyAllListeners error:", e?.message || String(e), { stack: e?.stack }); }
};

module.exports = function (io) {
  io.on("connection", (socket) => {
    socket.on("requests:broadcast", async (data = {}) => {
      logger.info(`requests:broadcast received from user: ${socket.userId}, data: ${JSON.stringify(data)}`);
      try {
        const requestType = data.type === "call" ? "call" : "chat";
        const userRole = socket.activeRole || socket.role;
        if (userRole !== "venter") {
          return socket.emit("error", { message: "Only venters can broadcast requests" });
        }

        const sessionType = requestType === "call" ? "voice" : "chat";

        const broadcastResult = await pool.query(
          `INSERT INTO socket_broadcast_requests (request_type, venter_id, status, expires_at)
           VALUES ($1, $2, 'open', NOW() + ($3 || ' seconds')::interval)
           RETURNING id`,
          [requestType, socket.userId, BROADCAST_TTL_SECONDS]
        );
        const broadcastId = broadcastResult.rows[0].id;

        const listeners = await presence.getAvailableListeners(socket.userId);

        if (listeners.length === 0) {
          await notifyAllListeners(sessionType, socket.userId, requestType, "Anonymous", broadcastId);
          return socket.emit("requests:broadcast:no-listeners", {
            message: "No listeners available right now",
          });
        }

        const venterResult = await pool.query(
          "SELECT anonymous_name, avatar_seed FROM user_sessions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1",
          [socket.userId]
        ).catch(() => ({ rows: [] }));
        const anonymousName = venterResult.rows[0]?.anonymous_name || "Anonymous";
        const avatarSeed = venterResult.rows[0]?.avatar_seed || socket.userId;

        for (const listener of listeners) {
          let requestId;
          if (requestType === "call") {
            const callResult = await pool.query(
              `INSERT INTO voice_calls (venter_id, listener_id, status, rate_per_minute, request_group_id, payment_mode)
               VALUES ($1, $2, 'requesting', $3, $4, 'prepaid')
               RETURNING id`,
              [socket.userId, listener.listenerId, listener.ratePerMinute, broadcastId]
            );
            requestId = callResult.rows[0].id;
          } else {
            const chatResult = await pool.query(
              `INSERT INTO conversations (venter_id, listener_id, status, rate_per_minute, request_group_id, payment_mode)
               VALUES ($1, $2, 'pending', $3, $4, 'prepaid')
               RETURNING id`,
              [socket.userId, listener.listenerId, listener.ratePerMinute, broadcastId]
            );
            requestId = chatResult.rows[0].id;
          }

          const payload = {
            requestId, id: requestId, callId: requestId, requestType,
            listenerId: listener.listenerId, venterId: socket.userId,
            ratePerMinute: listener.ratePerMinute,
            requester: { id: socket.userId, anonymousName, avatarSeed },
          };
          emitToUser(io, listener.listenerId, `${requestType}:request`, payload);
          logger.info(`Sent ${requestType}:request to listener ${listener.listenerId}`);
        }

        socket.emit("requests:broadcast:ack", {
          success: true,
          listenerCount: listeners.length,
        });

        await notifyAllListeners(sessionType, socket.userId, requestType, anonymousName, broadcastId);

      } catch (error) {
        logger.error(`Error in requests:broadcast: ${error.message}`);
        socket.emit("error", { message: "Failed to broadcast request" });
      }
    });
  });
};
