const express = require("express");
const router = express.Router();
const {
  authenticateToken,
  requireRole,
  requireAdminFeaturePermission,
} = require("../middleware/auth");
const { uploadVerificationDocumentFile } = require("../middleware/fileUpload");
const listenerVerificationController = require("../controllers/listenerVerificationController");

// Allow both "listener" and "venter" roles — during the initial listener
// signup flow the user may not have been switched to the listener role yet
// when they upload their ID document.
router.post(
  "/",
  authenticateToken,
  requireRole("listener", "venter"),
  uploadVerificationDocumentFile,
  listenerVerificationController.submitVerificationDocument,
);

router.get(
  "/me",
  authenticateToken,
  requireRole("listener"),
  listenerVerificationController.getMyVerificationSubmissions,
);

router.get(
  "/admin/all",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  listenerVerificationController.listVerificationSubmissionsAdmin,
);

router.get(
  "/admin/:verificationId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  listenerVerificationController.getVerificationSubmissionAdmin,
);

router.put(
  "/admin/:verificationId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "edit"),
  listenerVerificationController.verifySubmissionAdmin,
);

module.exports = router;
