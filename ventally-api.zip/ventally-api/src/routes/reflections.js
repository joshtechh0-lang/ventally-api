const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  saveReflection,
  getTodayReflection,
  getReflectionHistory,
  updateReflection,
  deleteReflection,
} = require("../controllers/reflectionController");

// Save or update reflection for today
router.post("/save", authenticateToken, saveReflection);

// Get today's reflection
router.get("/today", authenticateToken, getTodayReflection);

// Get reflection history with pagination and date filtering
router.get("/history", authenticateToken, getReflectionHistory);

// Update a specific reflection
// Delete a specific reflection
router.put("/:reflectionId", authenticateToken, updateReflection);
router.delete("/:reflectionId", authenticateToken, deleteReflection);

module.exports = router;
