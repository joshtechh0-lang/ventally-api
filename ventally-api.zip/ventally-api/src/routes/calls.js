const express = require('express');
const router = express.Router();
const { authenticateToken, requireRole } = require('../middleware/auth');
const callController = require('../controllers/callController');

// Create a new voice call (venter only)
router.post('/', authenticateToken, requireRole('venter'), callController.createCall);

// Create broadcast call requests for all available listeners (venter only)
router.post('/broadcast', authenticateToken, requireRole('venter'), callController.createBroadcastCall);

// Get user's active call
router.get('/active', authenticateToken, callController.getActiveCall);

// Get pending call requests for listener (used on app open after notification tap)
router.get('/pending', authenticateToken, requireRole('listener'), callController.getPendingRequests);

// Get call history
router.get('/history', authenticateToken, callController.getCallHistory);

// Get call details
router.get('/:id', authenticateToken, callController.getCall);

// Accept a call (listener only)
router.post('/:id/accept', authenticateToken, requireRole('listener'), callController.acceptCall);

// Decline a call (listener only)
router.post('/:id/decline', authenticateToken, requireRole('listener'), callController.declineCall);

// End a call
router.post('/:id/end', authenticateToken, callController.endCall);

// Get voice provider access token for joining call
router.get('/:id/token', authenticateToken, callController.getCallToken);

module.exports = router;
