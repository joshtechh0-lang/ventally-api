const express = require("express");
const router = express.Router();
const {
  authenticateToken,
  requireRole,
  requireAdminFeaturePermission,
} = require("../middleware/auth");
const crisisController = require("../controllers/crisisController");

/**
 * @swagger
 * /crisis/escalate:
 *   post:
 *     summary: Escalate a call to crisis status (listener only)
 *     tags: [Crisis]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - voiceCallId
 *               - riskCategory
 *             properties:
 *               voiceCallId:
 *                 type: string
 *                 format: uuid
 *               riskCategory:
 *                 type: string
 *                 enum: [self_harm, suicide, harm_to_others, severe_distress, other]
 *               notes:
 *                 type: string
 */
router.post("/escalate", authenticateToken, crisisController.escalateCall);

/**
 * @swagger
 * /crisis/escalation-event:
 *   post:
 *     summary: Record crisis-help escalation against a chat/call session
 *     tags: [Crisis]
 *     security:
 *       - bearerAuth: []
 */
router.post(
  "/escalation-event",
  authenticateToken,
  crisisController.recordEscalationEvent,
);

/**
 * @swagger
 * /crisis/handoff-988:
 *   post:
 *     summary: Transfer call to 988 crisis line (listener only, requires prior escalation)
 *     tags: [Crisis]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - voiceCallId
 *             properties:
 *               voiceCallId:
 *                 type: string
 *                 format: uuid
 *               reason:
 *                 type: string
 */
router.post("/handoff-988", authenticateToken, crisisController.handoff988);

router.get(
  "/admin/stats",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  crisisController.getCrisisAdminStats,
);

/**
 * @swagger
 * /crisis/events/{voiceCallId}:
 *   get:
 *     summary: Get crisis events for a call
 *     tags: [Crisis]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: voiceCallId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 */
router.get(
  "/events/:voiceCallId",
  authenticateToken,
  crisisController.getCrisisEvents,
);

module.exports = router;
