const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  getSobrietyStatus,
  startSobriety,
  logRelapse,
  getSobrietyHistory,
} = require("../controllers/sobrietyController");

// Get sobriety tracking status for the current user
router.get("/status", authenticateToken, getSobrietyStatus);

// Start or update sobriety tracking
router.post("/start", authenticateToken, startSobriety);

// Log relapse and reset streak start date
router.post("/relapse", authenticateToken, logRelapse);

// Get sobriety events history
router.get("/history", authenticateToken, getSobrietyHistory);

module.exports = router;
