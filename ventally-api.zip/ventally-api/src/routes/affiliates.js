const express = require("express");
const router = express.Router();
const { authenticateToken, requireRole } = require("../middleware/auth");
const {
  registerAffiliate,
  getMyStats,
  trackClick,
  listAffiliates,
  submitApplication,
  getApplicationStatus,
} = require("../controllers/affiliateController");

// Public — track a click when someone visits an affiliate link
router.get("/track/:code", trackClick);

// Affiliate self-service
router.get("/my-stats", authenticateToken, getMyStats);
router.get("/application/status", authenticateToken, getApplicationStatus);
router.post("/application", authenticateToken, submitApplication);

// Admin only
router.post("/register", authenticateToken, requireRole("admin"), registerAffiliate);
router.get("/list", authenticateToken, requireRole("admin"), listAffiliates);

module.exports = router;
