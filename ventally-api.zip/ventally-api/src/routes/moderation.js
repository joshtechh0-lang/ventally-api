const express = require("express");
const { authenticateToken, requireRole, requireAdminFeaturePermission } = require("../middleware/auth");
const moderationController = require("../controllers/moderationController");

const router = express.Router();

router.get(
  "/",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  moderationController.getLog,
);

module.exports = router;
