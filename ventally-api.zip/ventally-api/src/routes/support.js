const express = require("express");
const router = express.Router();
const { authenticateToken, requireRole } = require("../middleware/auth");
const { uploadAppealDocumentFile } = require("../middleware/fileUpload");
const {
  submitAppeal,
  submitFeedback,
  submitListenerAppeal,
} = require("../controllers/supportController");

router.post("/appeals", authenticateToken, submitAppeal);
router.post(
  "/listener-appeals",
  authenticateToken,
  requireRole("listener", "venter"),
  uploadAppealDocumentFile,
  submitListenerAppeal,
);
router.post("/feedback", authenticateToken, submitFeedback);

module.exports = router;
