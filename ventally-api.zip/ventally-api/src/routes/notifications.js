const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  registerDeviceToken,
  unregisterDeviceToken,
  sendTestNotificationNoAuth,
  sendNotification,
  sendBulkNotification,
  sendTopicNotification,
  subscribeUserToTopic,
  unsubscribeUserFromTopic,
  getNotificationHistory,
  markNotificationAsRead,
  getUnreadCount,
  getNotificationSettings,
  updateNotificationSettings,
} = require("../controllers/notificationController");
const {
  getFirebaseStatus,
} = require("../controllers/firebaseStatusController");

// Get Firebase Cloud Messaging status
router.get("/status", getFirebaseStatus);

// Register a device token for push notifications
router.post("/register", authenticateToken, registerDeviceToken);

// Unregister a device token
router.delete("/register", authenticateToken, unregisterDeviceToken);

// Send a dummy push notification without authentication (testing)
router.post("/test-send", sendTestNotificationNoAuth);

// Send a push notification to a specific user
router.post("/send", authenticateToken, sendNotification);

// Send a push notification to multiple users
router.post("/send-bulk", authenticateToken, sendBulkNotification);

// Send a push notification to a topic
router.post("/send-topic", authenticateToken, sendTopicNotification);

// Subscribe user's devices to a topic
router.post("/subscribe", authenticateToken, subscribeUserToTopic);

// Unsubscribe user's devices from a topic
router.post("/unsubscribe", authenticateToken, unsubscribeUserFromTopic);

// Get notification history for the authenticated user
router.get("/history", authenticateToken, getNotificationHistory);

// Get and update notification settings for the authenticated user
router.get("/settings", authenticateToken, getNotificationSettings);
router.put("/settings", authenticateToken, updateNotificationSettings);

// Mark a notification as read
router.put("/:id/read", authenticateToken, markNotificationAsRead);

// Get unread notification count
router.get("/unread-count", authenticateToken, getUnreadCount);


router.post('/fcm-diagnostics', async (req, res) => {
  const logger = require('../utils/logger');
  logger.info('[FCM-DIAG] ' + JSON.stringify({ userId: req.user && req.user.id, ...req.body }));
  res.json({ ok: true });
});

module.exports = router;
