const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  getMyStats,
  applyReferral,
} = require("../controllers/referralController");

/**
 * GET /api/v1/referrals/my-stats
 * Get the authenticated user's referral code, totals, and history
 */
router.get("/my-stats", authenticateToken, getMyStats);

/**
 * POST /api/v1/referrals/apply
 * Apply a referral code after signup
 * Body: { referralCode: string }
 */
router.post("/apply", authenticateToken, applyReferral);

module.exports = router;
