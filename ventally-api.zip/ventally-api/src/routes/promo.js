const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const promoController = require("../controllers/promoController");

/**
 * @swagger
 * /promo/validate:
 *   post:
 *     summary: Validate a promo code
 *     tags: [Promo Codes]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - code
 *             properties:
 *               code:
 *                 type: string
 *                 example: WELCOME10
 */
router.post("/validate", promoController.validatePromoCode);

/**
 * @swagger
 * /promo/apply:
 *   post:
 *     summary: Apply a promo code (requires authentication)
 *     tags: [Promo Codes]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - code
 *             properties:
 *               code:
 *                 type: string
 *                 example: WELCOME10
 */
router.post("/apply", authenticateToken, promoController.applyPromoCode);

/**
 * @swagger
 * /promo/history:
 *   get:
 *     summary: Get user's promo code usage history
 *     tags: [Promo Codes]
 *     security:
 *       - bearerAuth: []
 */
router.get("/history", authenticateToken, promoController.getPromoHistory);

module.exports = router;
