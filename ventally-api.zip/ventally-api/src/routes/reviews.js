const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const reviewController = require("../controllers/reviewController");

// Submit a review
router.post("/", authenticateToken, reviewController.submitReview);

// Get reviews for a specific user
router.get("/:userId", reviewController.getUserReviews);

// Get reviews for a specific session
router.get(
  "/session/:sessionType/:sessionId",
  authenticateToken,
  reviewController.getSessionReviews,
);

// Check if user can review a session
router.get(
  "/can-review/:sessionType/:sessionId",
  authenticateToken,
  reviewController.canReviewSession,
);

module.exports = router;
