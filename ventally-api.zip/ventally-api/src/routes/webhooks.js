const express = require("express");
const router = express.Router();
const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const agoraWebhookController = require("../controllers/agoraWebhookController");
const { validateAgoraSignature } = require("../middleware/agoraWebhook");
const logger = require("../utils/logger");
const stripeLogger = require("../utils/stripeLogger");
const {
  completeStripeTipFromPaymentIntent,
  markTipFailedByIntent,
} = require("../services/tipService");
const {
  syncStripeAccountStatus,
} = require("../services/listenerPayoutService");
const { syncStripeCouponToDb } = require("../services/discountService");
const { recordTaxTransaction } = require("../services/stripeTaxService");
const klaviyo = require("../services/klaviyo");

// Agora webhooks are JSON payloads and this router is mounted before global body parsers.
router.use(
  "/agora",
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf.toString("utf8");
    },
  }),
);

// ============================================================================
// AGORA WEBHOOK ROUTES - Voice Calling (voice_calls table)
// ============================================================================

router.post(
  "/agora/events",
  validateAgoraSignature,
  agoraWebhookController.handleAgoraEvent,
);

router.post(
  "/agora/recording",
  validateAgoraSignature,
  agoraWebhookController.handleAgoraRecordingWebhook,
);

// Stripe webhook endpoint (documented in swagger-paths.js)
router.post(
  "/stripe",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const sig = req.headers["stripe-signature"];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event;

    try {
      // Verify webhook signature
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err) {
      logger.error("Stripe webhook signature verification failed", {
        error: err.message,
        signature: sig,
      });
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    logger.info("Stripe webhook received", {
      eventType: event.type,
      eventId: event.id,
    });

    // Check for duplicate events (idempotency)
    try {
      const duplicateCheck = await pool.query(
        "SELECT id FROM stripe_webhook_events WHERE event_id = $1",
        [event.id],
      );

      if (duplicateCheck.rows.length > 0) {
        logger.info("Duplicate Stripe webhook event detected, skipping", {
          eventId: event.id,
        });
        return res.json({ received: true, duplicate: true });
      }

      // Log the webhook event
      await pool.query(
        `INSERT INTO stripe_webhook_events 
         (event_id, event_type, payload, processed) 
         VALUES ($1, $2, $3, $4)`,
        [event.id, event.type, JSON.stringify(event), false],
      );
    } catch (error) {
      logger.error("Error checking/logging Stripe webhook event", {
        error: error.message,
        eventId: event.id,
      });
      // Continue processing even if logging fails
    }

    // Process the event asynchronously
    processWebhookAsync(event)
      .then(() => {
        logger.info("Stripe webhook processed successfully", {
          eventType: event.type,
          eventId: event.id,
        });
      })
      .catch((error) => {
        logger.error("Error processing Stripe webhook", {
          error: error.message,
          eventType: event.type,
          eventId: event.id,
        });
      });

    // Return 200 immediately to acknowledge receipt
    res.json({ received: true });
  },
);

/**
 * Process webhook events asynchronously
 */
async function processWebhookAsync(event) {
  try {
    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(event.data.object);
        break;

      case "payment_intent.succeeded":
        await handlePaymentSucceeded(event.data.object);
        break;

      case "payment_intent.payment_failed":
        await handlePaymentFailed(event.data.object);
        break;

      case "customer.subscription.created":
      case "customer.subscription.updated":
        await handleSubscriptionUpdate(event.data.object);
        break;

      case "customer.subscription.deleted":
        await handleSubscriptionDeleted(event.data.object);
        break;

      case "customer.subscription.trial_will_end":
        await handleSubscriptionTrialWillEnd(event.data.object);
        break;

      case "invoice.payment_succeeded":
      case "invoice.paid":
        await handleInvoicePaymentSucceeded(event.data.object);
        break;

      case "invoice.payment_failed":
        await handleInvoicePaymentFailed(event.data.object);
        break;

      case "setup_intent.succeeded":
        await handleSetupIntentSucceeded(event.data.object);
        break;

      case "account.updated":
        await handleConnectAccountUpdated(event.data.object);
        break;

      case "coupon.created":
        // Sync externally-created Stripe coupons into the Ventally discounts table
        await syncStripeCouponToDb(event.data.object);
        break;

      default:
        logger.info("Unhandled Stripe webhook event type", {
          eventType: event.type,
          eventId: event.id,
        });
    }

    // Mark event as processed
    await pool.query(
      "UPDATE stripe_webhook_events SET processed = true, processed_at = NOW() WHERE event_id = $1",
      [event.id],
    );
  } catch (error) {
    logger.error("Error in processWebhookAsync", {
      error: error.message,
      stack: error.stack,
      eventType: event.type,
      eventId: event.id,
    });
    // Log error in database
    await pool.query(
      "UPDATE stripe_webhook_events SET error_message = $1 WHERE event_id = $2",
      [error.message, event.id],
    );
    throw error;
  }
}

/**
 * Handle successful checkout session completion
 */
async function handleCheckoutCompleted(session) {
  const client = await pool.connect();
  let userId = null;

  try {
    await client.query("BEGIN");

    // Get userId from session metadata or customer metadata
    userId = session.metadata?.user_id;

    // If not in session metadata, try to get from customer
    if (!userId && session.customer) {
      const customer = await stripe.customers.retrieve(session.customer);
      userId = customer.metadata?.user_id;
    }

    if (!userId) {
      throw new Error(
        "User ID not found in session metadata or customer metadata",
      );
    }

    const creditsMinutes = parseFloat(session.metadata?.credits_minutes || 0);
    const amountPaid = session.amount_total / 100; // Convert from cents
    const promoCodeId = session.metadata?.promo_code_id;
    const promoCode = session.metadata?.promo_code;
    const bonusMinutes = parseFloat(session.metadata?.bonus_minutes || 0);
    const originalPrice = parseFloat(session.metadata?.original_price || 0);
    const discountAmount = parseFloat(session.metadata?.discount_amount || 0);

    logger.info("Processing Stripe checkout completion", {
      userId,
      creditsMinutes,
      bonusMinutes,
      amountPaid,
      originalPrice,
      discountAmount,
      promoCode,
      sessionId: session.id,
      mode: session.mode,
    });

    // Update checkout_sessions table status and add payment/subscription identifiers
    const updateSessionResult = await client.query(
      `UPDATE checkout_sessions 
       SET status = $1, 
           completed_at = NOW(), 
           stripe_payment_intent_id = $2,
           stripe_subscription_id = $3,
           updated_at = NOW()
       WHERE stripe_session_id = $4
       RETURNING id`,
      ["completed", session.payment_intent, session.subscription, session.id],
    );

    if (updateSessionResult.rows.length === 0) {
      logger.warn("Checkout session not found in database", {
        sessionId: session.id,
        userId,
      });
    } else {
      logger.info("Updated checkout session status to completed", {
        sessionId: session.id,
        checkoutSessionDbId: updateSessionResult.rows[0].id,
      });
    }

    // Handle subscription checkout
    if (session.mode === "subscription") {
      logger.info("Processing subscription checkout", {
        userId,
        sessionId: session.id,
        subscription: session.subscription,
      });

      // Get the subscription ID from the session
      const stripeSubscriptionId = session.subscription;

      if (!stripeSubscriptionId) {
        logger.error("Subscription ID missing from checkout session", {
          sessionId: session.id,
          userId,
        });
        await client.query("COMMIT");
        return;
      }

      // Get plan_id from session metadata
      const planId = session.metadata?.plan_id;

      if (!planId) {
        logger.error("plan_id missing from checkout session metadata", {
          sessionId: session.id,
          userId,
          metadata: session.metadata,
        });
        await client.query("COMMIT");
        return;
      }

      // Fetch the subscription from Stripe to get period details
      const subscription =
        await stripe.subscriptions.retrieve(stripeSubscriptionId);

      // Check if subscription record already exists
      const existingSubResult = await client.query(
        "SELECT id FROM user_subscriptions WHERE stripe_subscription_id = $1",
        [stripeSubscriptionId],
      );

      if (existingSubResult.rows.length > 0) {
        // checkout.session.completed fires after payment succeeds, so the
        // subscription is now active/trialing. Update the record to reflect
        // the authoritative Stripe status (it may have been inserted as
        // 'incomplete' by the earlier customer.subscription.created event).
        await client.query(
          `UPDATE user_subscriptions
           SET status = $1,
               billing_cycle_start = $2,
               billing_cycle_end = $3,
               trial_start_at = $4,
               trial_end_at = $5,
               updated_at = NOW()
           WHERE stripe_subscription_id = $6`,
          [
            subscription.status,
            new Date(subscription.current_period_start * 1000),
            new Date(subscription.current_period_end * 1000),
            subscription.trial_start
              ? new Date(subscription.trial_start * 1000)
              : null,
            subscription.trial_end
              ? new Date(subscription.trial_end * 1000)
              : null,
            stripeSubscriptionId,
          ],
        );
        logger.info("Updated subscription status from checkout completion", {
          subscriptionId: stripeSubscriptionId,
          userId,
          status: subscription.status,
        });
        await client.query("COMMIT");
        return;
      }

      // Get plan details
      const planResult = await client.query(
        `SELECT included_minutes, included_messages_monthly, overage_rate
         FROM subscription_plans
         WHERE id = $1`,
        [planId],
      );

      if (planResult.rows.length === 0) {
        logger.error("Cannot create subscription - plan not found", {
          subscriptionId: stripeSubscriptionId,
          userId,
          planId,
        });
        await client.query("COMMIT");
        return;
      }

      const plan = planResult.rows[0];

      // Get plan name and price for transaction record
      const planDetailsResult = await client.query(
        "SELECT name, price_monthly FROM subscription_plans WHERE id = $1",
        [planId],
      );

      const planDetails = planDetailsResult.rows[0];
      const billingCycle =
        session.metadata?.billing_cycle === "annual" ? "annual" : "monthly";
      const billedAmount = parseFloat(amountPaid || 0);

      // Create subscription record
      await client.query(
        `INSERT INTO user_subscriptions 
           (user_id, plan_id, status, included_minutes, used_minutes, included_messages, used_messages, overage_rate,
            trial_start_at, trial_end_at, billing_cycle_start, billing_cycle_end, stripe_subscription_id)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          userId,
          planId,
          subscription.status,
          plan.included_minutes,
          0,
          plan.included_messages_monthly || 0,
          0,
          plan.overage_rate,
          subscription.trial_start
            ? new Date(subscription.trial_start * 1000)
            : null,
          subscription.trial_end
            ? new Date(subscription.trial_end * 1000)
            : null,
          new Date(subscription.current_period_start * 1000),
          new Date(subscription.current_period_end * 1000),
          stripeSubscriptionId,
        ],
      );

      // Create transaction record for initial subscription payment
      await client.query(
        `INSERT INTO wallet_transactions 
         (user_id, transaction_type, amount_currency, stripe_payment_intent_id, description, metadata)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          userId,
          "subscription_payment",
          billedAmount,
          session.payment_intent,
          `Subscription started (${billingCycle}): ${planDetails?.name || "Subscription Plan"} - ${plan.included_minutes} minutes included`,
          JSON.stringify({
            plan_id: planId,
            subscription_id: stripeSubscriptionId,
            session_id: session.id,
            billing_cycle: billingCycle,
            included_minutes: plan.included_minutes,
            included_messages: plan.included_messages_monthly || 0,
          }),
        ],
      );

      logger.info("Subscription created successfully from checkout", {
        subscriptionId: stripeSubscriptionId,
        userId,
        planId,
        status: subscription.status,
        includedMinutes: plan.included_minutes,
        includedMessages: plan.included_messages_monthly || 0,
      });

      // Get user email for notification
      const userResult = await client.query(
        `SELECT email, 
                COALESCE(
                  NULLIF(TRIM(first_name || ' ' || last_name), ''),
                  display_name,
                  email
                ) as full_name 
         FROM users WHERE id = $1`,
        [userId],
      );

      await client.query("COMMIT");

      if (userResult.rows.length > 0) {
        const user = userResult.rows[0];
        klaviyo.trackSubscriptionActivated({
          email: user.email,
          planName: planDetails.name,
          monthlyPrice: parseFloat(planDetails.price_monthly),
          includedMinutes: plan.included_minutes,
          nextPayment: subscription.current_period_end
            ? new Date(subscription.current_period_end * 1000).toISOString()
            : undefined,
        });
      }

      return;
    }

    // Only process credit purchases from this point
    if (session.mode !== "payment" || creditsMinutes === 0) {
      logger.info("Skipping - not a credit purchase", {
        mode: session.mode,
        creditsMinutes,
      });
      await client.query("COMMIT");
      return;
    }

    // Get current wallet balance
    const walletResult = await client.query(
      "SELECT balance_minutes, balance_currency FROM user_wallets WHERE user_id = $1",
      [userId],
    );

    if (walletResult.rows.length === 0) {
      throw new Error(`Wallet not found for user ${userId}`);
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance_minutes);
    const totalMinutesToAdd = creditsMinutes + bonusMinutes;
    const newBalance = currentBalance + totalMinutesToAdd;

    // Update wallet balance
    await client.query(
      `UPDATE user_wallets 
       SET balance_minutes = balance_minutes + $1,
           balance_currency = balance_currency + $2,
           updated_at = NOW()
       WHERE user_id = $3`,
      [totalMinutesToAdd, amountPaid, userId],
    );

    // If promo code was used, record the usage
    if (promoCodeId && promoCode) {
      try {
        // Import promo service
        const promoService = require("../services/promoService");
        await promoService.applyPromoCode(promoCodeId, userId);
        logger.info("Promo code usage recorded in webhook", {
          userId,
          promoCode,
          promoCodeId,
        });
      } catch (error) {
        // Log but don't fail the transaction if promo already applied
        logger.warn("Failed to record promo usage (may already be applied)", {
          error: error.message,
          userId,
          promoCode,
        });
      }
    }

    // Build transaction description
    let description = `Purchased ${creditsMinutes} calling minutes via Stripe`;
    if (bonusMinutes > 0 && promoCode) {
      description += ` + ${bonusMinutes} bonus minutes (${promoCode})`;
    }

    // Build transaction metadata
    const transactionMetadata = {
      session_id: session.id,
      invoice_id: session.invoice || null,
      amount_paid: amountPaid,
      minutes_purchased: creditsMinutes,
      bonus_minutes: bonusMinutes,
      total_minutes: totalMinutesToAdd,
    };

    if (promoCode) {
      transactionMetadata.promo_code = promoCode;
      transactionMetadata.promo_code_id = promoCodeId;
      transactionMetadata.original_price = originalPrice;
      transactionMetadata.discount_amount = discountAmount;
    }

    // Create transaction record with invoice reference
    await client.query(
      `INSERT INTO wallet_transactions 
       (user_id, transaction_type, amount_minutes, amount_currency, 
        balance_after_minutes, balance_after_currency, stripe_payment_intent_id, description, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [
        userId,
        "credit_purchase",
        totalMinutesToAdd,
        amountPaid,
        newBalance,
        null, // Will be calculated based on wallet query
        session.payment_intent,
        description,
        JSON.stringify(transactionMetadata),
      ],
    );

    // Get user email for notification
    const userResult = await client.query(
      `SELECT email, 
              COALESCE(
                NULLIF(TRIM(first_name || ' ' || last_name), ''),
                display_name,
                email
              ) as full_name 
       FROM users WHERE id = $1`,
      [userId],
    );

    await client.query("COMMIT");

    logger.info("Stripe checkout: Wallet updated successfully", {
      userId,
      newBalance,
      creditsAdded: creditsMinutes,
    });

    if (userResult.rows.length > 0) {
      const user = userResult.rows[0];
      const pricePerMinute =
        creditsMinutes > 0
          ? Math.round((amountPaid / creditsMinutes) * 100) / 100
          : undefined;
      klaviyo.trackCreditsPurchased({
        email: user.email,
        minutesPurchased: creditsMinutes,
        amountPaid,
        newBalance,
        pricePerMinute,
      });
      klaviyo.trackCreditPurchaseConfirmed({
        email: user.email,
        minutesPurchased: creditsMinutes,
        amountPaid,
        newBalance,
        pricePerMinute,
        uniqueId: `credit-purchase-${session.id}`,
      });
    }
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error handling checkout completed", {
      error: error.message,
      sessionId: session.id,
      metadata: session.metadata,
    });
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Handle successful payment intent
 */
async function handlePaymentSucceeded(paymentIntent) {
  logger.info("Stripe payment succeeded", {
    paymentIntentId: paymentIntent.id,
    amount: paymentIntent.amount / 100,
    currency: paymentIntent.currency,
  });

  if (paymentIntent.metadata?.tip_id) {
    const tip = await completeStripeTipFromPaymentIntent(paymentIntent);

    logger.info("Processed tip payment success", {
      paymentIntentId: paymentIntent.id,
      tipId: paymentIntent.metadata.tip_id,
      tipStatus: tip?.status,
    });
  }

  if (paymentIntent.metadata?.kind === "payg_session") {
    await reconcilePaygPaymentIntent(paymentIntent, "succeeded");
  }

  // Stripe Tax: book the tax transaction for off-session charges (PAYG/tips)
  // that were calculated up front. Idempotent on the PaymentIntent id; failures
  // are logged inside the helper, never thrown.
  if (paymentIntent.metadata?.tax_calculation) {
    await recordTaxTransaction({
      calculationId: paymentIntent.metadata.tax_calculation,
      reference: paymentIntent.id,
    });
  }

  // Additional logic if needed (most processing happens in checkout.session.completed)
}

/**
 * Handle failed payment intent
 */
async function handlePaymentFailed(paymentIntent) {
  const lastError = paymentIntent.last_payment_error;
  logger.warn("Stripe payment failed", {
    paymentIntentId: paymentIntent.id,
    amount: paymentIntent.amount / 100,
    error: lastError?.message,
    code: lastError?.code,
    declineCode: lastError?.decline_code,
    type: lastError?.type,
    paymentMethod: lastError?.payment_method?.id,
  });

  // Update checkout_sessions table to mark as failed
  try {
    await pool.query(
      `UPDATE checkout_sessions 
       SET status = 'failed', updated_at = NOW()
       WHERE stripe_payment_intent_id = $1`,
      [paymentIntent.id],
    );
    logger.info("Updated checkout session status to failed", {
      paymentIntentId: paymentIntent.id,
    });

    if (paymentIntent.metadata?.tip_id) {
      const tip = await markTipFailedByIntent(paymentIntent);

      logger.warn("Processed tip payment failure", {
        paymentIntentId: paymentIntent.id,
        tipId: paymentIntent.metadata.tip_id,
        tipStatus: tip?.status,
      });
    }

    if (paymentIntent.metadata?.kind === "payg_session") {
      await reconcilePaygPaymentIntent(paymentIntent, "failed");
    }
  } catch (error) {
    logger.error("Failed to update checkout session on payment failure", {
      error: error.message,
      paymentIntentId: paymentIntent.id,
    });
  }

  // Notify user about failed payment
  // Could add notification logic here

  // Log the failure
  await pool.query(
    `INSERT INTO wallet_transactions 
     (user_id, transaction_type, amount_currency, stripe_payment_intent_id, description)
     VALUES ($1, $2, $3, $4, $5)`,
    [
      paymentIntent.metadata?.user_id,
      "payment_failed",
      -(paymentIntent.amount / 100),
      paymentIntent.id,
      `Payment failed: ${
        paymentIntent.last_payment_error?.message || "Unknown error"
      }`,
    ],
  );
}

/**
 * Handle subscription creation/update
 */
async function handleSubscriptionUpdate(subscription) {
  logger.info("Stripe subscription event received", {
    subscriptionId: subscription.id,
    status: subscription.status,
    customer: subscription.customer,
    subscriptionMetadata: subscription.metadata,
  });

  // Get userId from subscription metadata or customer metadata
  let userId = subscription.metadata?.user_id;

  if (!userId && subscription.customer) {
    try {
      logger.info("Attempting to get user_id from customer metadata", {
        customerId: subscription.customer,
      });
      const customer = await stripe.customers.retrieve(subscription.customer);
      userId = customer.metadata?.user_id;
      logger.info("Retrieved customer metadata", {
        customerId: customer.id,
        customerMetadata: customer.metadata,
        foundUserId: userId,
      });
    } catch (error) {
      logger.error("Failed to retrieve customer for subscription", {
        subscriptionId: subscription.id,
        customerId: subscription.customer,
        error: error.message,
      });
    }
  }

  if (!userId) {
    logger.error("No user_id in Stripe subscription or customer metadata", {
      subscriptionId: subscription.id,
      customerId: subscription.customer,
      subscriptionMetadata: subscription.metadata,
    });
    return;
  }

  logger.info("Processing subscription for user", {
    subscriptionId: subscription.id,
    userId,
  });

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Check if subscription exists
    const existingSubscription = await client.query(
      "SELECT id FROM user_subscriptions WHERE stripe_subscription_id = $1",
      [subscription.id],
    );

    const planId = subscription.metadata?.plan_id;
    let plan = null;

    if (planId) {
      const planResult = await client.query(
        `SELECT id, included_minutes, included_messages_monthly, overage_rate
         FROM subscription_plans
         WHERE id = $1`,
        [planId],
      );

      if (planResult.rows.length > 0) {
        plan = planResult.rows[0];
      } else {
        logger.warn(
          "Subscription metadata references a plan_id with no matching plan; entitlements left unchanged",
          { subscriptionId: subscription.id, userId, planId },
        );
      }
    }

    if (existingSubscription.rows.length > 0) {
      // Update existing subscription
      logger.info("Updating existing subscription", {
        subscriptionId: subscription.id,
        userId,
        status: subscription.status,
      });

      if (plan) {
        await client.query(
          `UPDATE user_subscriptions 
           SET status = $1,
               plan_id = $2,
               included_minutes = $3,
               included_messages = $4,
               overage_rate = $5,
               trial_start_at = $6,
               trial_end_at = $7,
               billing_cycle_start = $8,
               billing_cycle_end = $9,
               updated_at = NOW()
           WHERE stripe_subscription_id = $10`,
          [
            subscription.status,
            plan.id,
            plan.included_minutes,
            plan.included_messages_monthly || 0,
            plan.overage_rate,
            subscription.trial_start
              ? new Date(subscription.trial_start * 1000)
              : null,
            subscription.trial_end
              ? new Date(subscription.trial_end * 1000)
              : null,
            new Date(subscription.current_period_start * 1000),
            new Date(subscription.current_period_end * 1000),
            subscription.id,
          ],
        );
      } else {
        await client.query(
          `UPDATE user_subscriptions 
           SET status = $1,
               trial_start_at = $2,
               trial_end_at = $3,
               billing_cycle_start = $4,
               billing_cycle_end = $5,
               updated_at = NOW()
           WHERE stripe_subscription_id = $6`,
          [
            subscription.status,
            subscription.trial_start
              ? new Date(subscription.trial_start * 1000)
              : null,
            subscription.trial_end
              ? new Date(subscription.trial_end * 1000)
              : null,
            new Date(subscription.current_period_start * 1000),
            new Date(subscription.current_period_end * 1000),
            subscription.id,
          ],
        );
      }

      logger.info("Subscription updated successfully", {
        subscriptionId: subscription.id,
        userId,
        status: subscription.status,
      });
    } else {
      // Create new subscription record
      // Get plan_id from metadata

      if (!planId) {
        logger.warn(
          "Cannot create subscription - plan_id missing from metadata. This may have been handled by checkout.session.completed",
          {
            subscriptionId: subscription.id,
            userId,
            metadata: subscription.metadata,
          },
        );
        await client.query("COMMIT");
        return;
      }

      const planResult = await client.query(
        `SELECT included_minutes, included_messages_monthly, overage_rate
         FROM subscription_plans
         WHERE id = $1`,
        [planId],
      );

      if (planResult.rows.length === 0) {
        logger.error("Cannot create subscription - plan not found", {
          subscriptionId: subscription.id,
          userId,
          planId,
        });
        await client.query("COMMIT");
        return;
      }

      const plan = planResult.rows[0];

      // Get plan name and price for transaction record
      const planDetailsResult = await client.query(
        "SELECT name, price_monthly FROM subscription_plans WHERE id = $1",
        [planId],
      );

      const planDetails = planDetailsResult.rows[0];

      await client.query(
        `INSERT INTO user_subscriptions 
           (user_id, plan_id, status, included_minutes, used_minutes, included_messages, used_messages, overage_rate,
            trial_start_at, trial_end_at, billing_cycle_start, billing_cycle_end, stripe_subscription_id)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          userId,
          planId,
          subscription.status,
          plan.included_minutes,
          0,
          plan.included_messages_monthly || 0,
          0,
          plan.overage_rate,
          subscription.trial_start
            ? new Date(subscription.trial_start * 1000)
            : null,
          subscription.trial_end
            ? new Date(subscription.trial_end * 1000)
            : null,
          new Date(subscription.current_period_start * 1000),
          new Date(subscription.current_period_end * 1000),
          subscription.id,
        ],
      );

      // Create transaction record for subscription creation
      await client.query(
        `INSERT INTO wallet_transactions 
         (user_id, transaction_type, amount_currency, description, metadata)
         VALUES ($1, $2, $3, $4, $5)`,
        [
          userId,
          "subscription_created",
          planDetails?.price_monthly || 0,
          `Subscription created: ${planDetails?.name || "Subscription Plan"} - ${plan.included_minutes} minutes included`,
          JSON.stringify({
            plan_id: planId,
            subscription_id: subscription.id,
            included_minutes: plan.included_minutes,
            included_messages: plan.included_messages_monthly || 0,
          }),
        ],
      );

      logger.info("Subscription created successfully", {
        subscriptionId: subscription.id,
        userId,
        planId,
        status: subscription.status,
        includedMinutes: plan.included_minutes,
        includedMessages: plan.included_messages_monthly || 0,
      });
    }

    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error handling Stripe subscription update", {
      error: error.message,
      subscriptionId: subscription.id,
      userId,
    });
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Handle subscription deletion
 */
async function handleSubscriptionDeleted(subscription) {
  logger.info("Stripe subscription deleted", {
    subscriptionId: subscription.id,
  });

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Get userId and subscription details before canceling
    const subResult = await client.query(
      `SELECT us.user_id, us.plan_id, us.included_minutes,
              u.email, u.first_name,
              sp.name AS plan_name, sp.price_monthly
       FROM user_subscriptions us
       JOIN users u ON u.id = us.user_id
       LEFT JOIN subscription_plans sp ON sp.id = us.plan_id
       WHERE us.stripe_subscription_id = $1`,
      [subscription.id],
    );

    if (subResult.rows.length > 0) {
      const userSub = subResult.rows[0];

      // Update subscription status
      await client.query(
        `UPDATE user_subscriptions
         SET status = 'canceled', updated_at = NOW()
         WHERE stripe_subscription_id = $1`,
        [subscription.id],
      );

      // Create transaction record for cancellation
      await client.query(
        `INSERT INTO wallet_transactions
         (user_id, transaction_type, amount_currency, description, metadata)
         VALUES ($1, $2, $3, $4, $5)`,
        [
          userSub.user_id,
          "subscription_canceled",
          0,
          `Subscription canceled`,
          JSON.stringify({
            plan_id: userSub.plan_id,
            subscription_id: subscription.id,
            included_minutes: userSub.included_minutes,
          }),
        ],
      );

      logger.info("Subscription canceled and transaction logged", {
        subscriptionId: subscription.id,
        userId: userSub.user_id,
      });

      klaviyo.trackPlanCancelled({
        email: userSub.email,
        firstName: userSub.first_name,
        planName: userSub.plan_name,
        includedMinutes: userSub.included_minutes,
        monthlyPrice: userSub.price_monthly
          ? parseFloat(userSub.price_monthly)
          : undefined,
        nextPayment: subscription.current_period_end
          ? new Date(subscription.current_period_end * 1000).toISOString()
          : undefined,
        uniqueId: `plan-cancelled-${subscription.id}`,
      });
    }

    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error handling subscription deletion", {
      error: error.message,
      subscriptionId: subscription.id,
    });
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Handle successful invoice payment
 * This is triggered when a subscription invoice is paid successfully
 */
async function handleInvoicePaymentSucceeded(invoice) {
  logger.info("Stripe invoice payment succeeded", {
    invoiceId: invoice.id,
    subscriptionId: invoice.subscription,
    amount: invoice.amount_paid / 100,
    customerId: invoice.customer,
  });

  if (!invoice.subscription) {
    logger.debug("Invoice not associated with subscription, skipping");
    return;
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Get userId from subscription or customer
    let userId;

    // Try to get from subscription
    const subscription = await stripe.subscriptions.retrieve(
      invoice.subscription,
    );
    userId = subscription.metadata?.user_id;

    // Fallback to customer metadata
    if (!userId && invoice.customer) {
      const customer = await stripe.customers.retrieve(invoice.customer);
      userId = customer.metadata?.user_id;
    }

    if (!userId) {
      logger.warn("Cannot find user_id for invoice payment", {
        invoiceId: invoice.id,
        subscriptionId: invoice.subscription,
        customerId: invoice.customer,
      });
      await client.query("ROLLBACK");
      return;
    }

    // Renewals (and the initial subscription invoice) reset the usage counters
    // and roll the billing window forward. A mid-cycle proration invoice from an
    // in-place plan change (billing_reason 'subscription_update') must NOT reset
    // usage or shift the cycle dates -- it only records the prorated charge.
    const isRenewal =
      invoice.billing_reason === "subscription_cycle" ||
      invoice.billing_reason === "subscription_create";

    const subResult = isRenewal
      ? await client.query(
          `UPDATE user_subscriptions
           SET status = 'active',
               used_minutes = 0,
               used_messages = 0,
               billing_cycle_start = $1,
               billing_cycle_end = $2,
               updated_at = NOW()
           WHERE stripe_subscription_id = $3
             RETURNING id, plan_id, included_minutes, included_messages`,
          [
            new Date(invoice.period_start * 1000),
            new Date(invoice.period_end * 1000),
            invoice.subscription,
          ],
        )
      : await client.query(
          `UPDATE user_subscriptions
           SET status = 'active',
               updated_at = NOW()
           WHERE stripe_subscription_id = $1
             RETURNING id, plan_id, included_minutes, included_messages`,
          [invoice.subscription],
        );

    if (subResult.rows.length > 0) {
      const userSub = subResult.rows[0];

      // Log the successful payment
      await client.query(
        `INSERT INTO wallet_transactions
         (user_id, transaction_type, amount_currency, stripe_payment_intent_id, description, metadata)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          userId,
          isRenewal ? "subscription_renewal" : "subscription_payment",
          invoice.amount_paid / 100,
          invoice.payment_intent,
          isRenewal
            ? `Subscription renewed: ${userSub.included_minutes} minutes included`
            : "Subscription plan change charge (proration)",
          JSON.stringify({
            plan_id: userSub.plan_id,
            subscription_id: invoice.subscription,
            invoice_id: invoice.id,
            billing_reason: invoice.billing_reason,
            included_minutes: userSub.included_minutes,
            included_messages: userSub.included_messages,
            period_start: new Date(invoice.period_start * 1000).toISOString(),
            period_end: new Date(invoice.period_end * 1000).toISOString(),
          }),
        ],
      );

      logger.info(
        isRenewal
          ? "Subscription renewed successfully"
          : "Subscription proration charge recorded",
        {
          userId,
          subscriptionId: invoice.subscription,
          billingReason: invoice.billing_reason,
          includedMinutes: userSub.included_minutes,
          includedMessages: userSub.included_messages,
        },
      );
    }

    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error handling invoice payment succeeded", {
      error: error.message,
      invoiceId: invoice.id,
      subscriptionId: invoice.subscription,
    });
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Handle failed invoice payment
 * This is triggered when a subscription invoice payment fails
 */
async function handleInvoicePaymentFailed(invoice) {
  logger.warn("Stripe invoice payment failed", {
    invoiceId: invoice.id,
    subscriptionId: invoice.subscription,
    paymentIntentId: invoice.payment_intent,
    chargeId: invoice.charge,
    amount: invoice.amount_due / 100,
    attemptCount: invoice.attempt_count,
    nextPaymentAttempt: invoice.next_payment_attempt,
    finalizationError: invoice.last_finalization_error?.message,
  });

  if (!invoice.subscription) {
    logger.debug("Invoice not associated with subscription, skipping");
    return;
  }

  // Update subscription status to past_due
  await pool.query(
    `UPDATE user_subscriptions
     SET status = 'past_due', updated_at = NOW()
     WHERE stripe_subscription_id = $1`,
    [invoice.subscription],
  );

  const userResult = await pool.query(
    `SELECT u.email, u.first_name
     FROM user_subscriptions us
     JOIN users u ON u.id = us.user_id
     WHERE us.stripe_subscription_id = $1`,
    [invoice.subscription],
  );

  if (userResult.rows.length > 0) {
    const user = userResult.rows[0];
    klaviyo.trackPaymentFailed({
      email: user.email,
      firstName: user.first_name,
      amount: invoice.amount_due / 100,
      attemptCount: invoice.attempt_count,
      uniqueId: `payment-failed-${invoice.id}-${invoice.attempt_count}`,
    });
  }

  logger.info("Subscription marked as past_due due to payment failure", {
    subscriptionId: invoice.subscription,
    attemptCount: invoice.attempt_count,
  });
}

/**
 * Handle Stripe Connect account.updated — keeps listener payout status in sync
 * with Stripe (payouts_enabled, requirements, disabled_reason) without polling.
 */
async function handleConnectAccountUpdated(account) {
  const result = await syncStripeAccountStatus(account);

  if (!result.updated) {
    logger.info("Stripe account.updated received for unknown listener", {
      accountId: account?.id,
      reason: result.reason,
    });
    return;
  }

  logger.info("Synced listener payout status from account.updated", {
    accountId: account.id,
    listenerId: result.listenerId,
    stripeAccountStatus: result.stripeAccountStatus,
    payoutEnabled: result.payoutEnabled,
    chargesEnabled: account.charges_enabled,
    detailsSubmitted: account.details_submitted,
    disabledReason: account.requirements?.disabled_reason,
    currentlyDue: account.requirements?.currently_due,
    pastDue: account.requirements?.past_due,
  });
}

/**
 * Handle trial ending reminder webhook
 */
async function handleSubscriptionTrialWillEnd(subscription) {
  logger.info("Stripe subscription trial ending soon", {
    subscriptionId: subscription.id,
    trialEnd: subscription.trial_end,
  });

  try {
    await pool.query(
      `INSERT INTO wallet_transactions 
       (user_id, transaction_type, amount_currency, description, metadata)
       VALUES (
         (SELECT user_id FROM user_subscriptions WHERE stripe_subscription_id = $1 LIMIT 1),
         $2,
         $3,
         $4,
         $5
       )`,
      [
        subscription.id,
        "subscription_trial_will_end",
        0,
        "Subscription trial will end soon",
        JSON.stringify({
          subscription_id: subscription.id,
          trial_end: subscription.trial_end
            ? new Date(subscription.trial_end * 1000).toISOString()
            : null,
        }),
      ],
    );
  } catch (error) {
    logger.warn("Failed to log trial ending event", {
      subscriptionId: subscription.id,
      error: error.message,
    });
  }
}

/**
 * Reconcile a PAYG session PaymentIntent into the session row + wallet ledger.
 * Idempotent: synchronous callController/chatController path already writes
 * on the happy path; webhook serves as a safety net if Stripe succeeded but
 * the DB update did not.
 */
async function reconcilePaygPaymentIntent(paymentIntent, terminalStatus) {
  const sessionType = paymentIntent.metadata?.session_type;
  const sessionId = paymentIntent.metadata?.session_id;
  const userId = paymentIntent.metadata?.user_id;
  if (!sessionType || !sessionId || !userId) {
    logger.warn("PAYG webhook missing metadata", {
      paymentIntentId: paymentIntent.id,
      metadata: paymentIntent.metadata,
    });
    return;
  }

  const sessionTable = sessionType === "call" ? "voice_calls" : "conversations";
  const amountDollars = -(paymentIntent.amount / 100);

  try {
    await pool.query(
      `UPDATE ${sessionTable}
       SET payg_charge_status = $2,
           payg_payment_intent_id = COALESCE(payg_payment_intent_id, $3)
       WHERE id = $1`,
      [sessionId, terminalStatus, paymentIntent.id],
    );

    if (terminalStatus === "failed") {
      await pool.query(
        `UPDATE user_wallets
         SET payg_locked_at = COALESCE(payg_locked_at, NOW()),
             updated_at = NOW()
         WHERE user_id = $1`,
        [userId],
      );
    }

    const existing = await pool.query(
      `SELECT id FROM wallet_transactions
       WHERE stripe_payment_intent_id = $1 AND transaction_type = 'payg_charge'
       LIMIT 1`,
      [paymentIntent.id],
    );

    if (existing.rows.length === 0) {
      await pool.query(
        `INSERT INTO wallet_transactions
          (user_id, transaction_type, amount_minutes, amount_currency,
           stripe_payment_intent_id, description, metadata)
         VALUES ($1, 'payg_charge', 0, $2, $3, $4, $5::jsonb)`,
        [
          userId,
          amountDollars,
          paymentIntent.id,
          `PAYG ${sessionType} ${String(sessionId).substring(0, 8)} (${terminalStatus}) [webhook reconcile]`,
          JSON.stringify({
            status: terminalStatus,
            session_type: sessionType,
            session_id: sessionId,
            source: "webhook",
          }),
        ],
      );
    }

    logger.info("Reconciled PAYG PaymentIntent", {
      paymentIntentId: paymentIntent.id,
      terminalStatus,
      sessionType,
      sessionId,
    });
  } catch (error) {
    logger.error("Failed to reconcile PAYG PaymentIntent", {
      paymentIntentId: paymentIntent.id,
      error: error.message,
    });
  }
}

/**
 * SetupIntent succeeded: attach PM to customer, set default, flip payg_enabled.
 */
async function handleSetupIntentSucceeded(setupIntent) {
  logger.info("Stripe setup_intent.succeeded", {
    setupIntentId: setupIntent.id,
    customer: setupIntent.customer,
    paymentMethod: setupIntent.payment_method,
  });

  if (setupIntent.metadata?.kind !== "payg_setup") {
    return;
  }

  const customerId = setupIntent.customer;
  const paymentMethodId = setupIntent.payment_method;
  if (!customerId || !paymentMethodId) {
    logger.warn("SetupIntent missing customer/payment_method", {
      setupIntentId: setupIntent.id,
    });
    return;
  }

  try {
    await stripe.customers.update(customerId, {
      invoice_settings: { default_payment_method: paymentMethodId },
    });

    const result = await pool.query(
      `UPDATE user_wallets
       SET default_payment_method = $2,
           payg_enabled = true,
           payg_locked_at = NULL,
           updated_at = NOW()
       WHERE stripe_customer_id = $1
       RETURNING user_id`,
      [customerId, paymentMethodId],
    );

    if (result.rows.length === 0) {
      logger.warn("SetupIntent succeeded but no matching wallet", {
        setupIntentId: setupIntent.id,
        customerId,
      });
    } else {
      logger.info("PAYG enabled via SetupIntent webhook", {
        setupIntentId: setupIntent.id,
        userId: result.rows[0].user_id,
      });
    }
  } catch (error) {
    logger.error("Failed to process setup_intent.succeeded", {
      setupIntentId: setupIntent.id,
      error: error.message,
    });
  }
}

module.exports = router;

// Exposed for unit tests (the router itself is a function object, so attaching
// these named handlers does not affect routing behavior).
module.exports.handleInvoicePaymentSucceeded = handleInvoicePaymentSucceeded;
module.exports.handleSubscriptionUpdate = handleSubscriptionUpdate;
