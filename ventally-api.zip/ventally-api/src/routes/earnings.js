const express = require("express");
const router = express.Router();
const earningsController = require("../controllers/earningsController");
const { authenticateToken } = require("../middleware/auth");

// All earnings routes require authentication
router.use(authenticateToken);

router.post("/bank-account/link", earningsController.createBankAccountLink);
router.post(
  "/bank-account/session",
  earningsController.createBankAccountSession,
);
router.get("/bank-account/status", earningsController.getBankAccountStatus);
router.post("/withdraw", earningsController.requestWithdrawal);
router.get("/summary", earningsController.getEarningsSummary);
router.get("/", earningsController.getEarnings);
router.get("/payouts", earningsController.getPayouts);

module.exports = router;
