const express = require("express");
const router = express.Router();
const sessionController = require("../controllers/sessionController");
const tipController = require("../controllers/tipController");
const { authenticateToken, requireRole } = require("../middleware/auth");

// All session routes require authentication
router.use(authenticateToken);

// Create a new call session
router.post("/", sessionController.createSession);

// Get user's active sessions
router.get("/active", sessionController.getActiveSessions);

// Get specific session details
router.get("/:sessionId", sessionController.getSession);

// Accept a session (listener)
router.post("/:sessionId/accept", sessionController.acceptSession);

// End a session
router.post("/:sessionId/end", sessionController.endSession);

// Send tip for an ended session (venter only)
router.post("/:sessionId/tip", requireRole("venter"), tipController.sendTip);

module.exports = router;
