const express = require("express");
const router = express.Router();
const {
  blockUser,
  unblockUser,
  getBlockedUsers,
  checkIfBlocked,
} = require("../controllers/blockController");
const { authenticateToken } = require("../middleware/auth");

// All block routes require authentication
router.use(authenticateToken);

// Block/unblock specific user
router.post("/users/:userId/block", blockUser);
router.delete("/users/:userId/block", unblockUser);

// Check if user is blocked
router.get("/users/:userId/blocked", checkIfBlocked);

// Get list of blocked users
router.get("/users/blocked", getBlockedUsers);

module.exports = router;
