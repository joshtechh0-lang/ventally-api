const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const { requireRole } = require("../middleware/auth");
const {
  getAllDiscounts,
  getUserDiscountSummary,
  syncStripeCouponToDb,
} = require("../services/discountService");
const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * GET /discounts/my
 * Returns discounts applicable to the authenticated user (for mobile display).
 */
router.get("/my", authenticateToken, async (req, res) => {
  try {
    const discounts = await getUserDiscountSummary(req.user.id);
    res.json({ data: discounts });
  } catch (err) {
    logger.error("Error fetching user discounts:", err);
    res.status(500).json({ error: "Failed to fetch discounts" });
  }
});

/**
 * GET /discounts (admin only)
 * Returns all discount rules with usage counts.
 */
router.get("/", authenticateToken, requireRole("admin", "sub_admin"), async (req, res) => {
  try {
    const discounts = await getAllDiscounts();
    res.json({ data: discounts });
  } catch (err) {
    logger.error("Error fetching all discounts:", err);
    res.status(500).json({ error: "Failed to fetch discounts" });
  }
});

/**
 * POST /discounts (admin only)
 * Create a new discount rule. Automatically creates Stripe coupon.
 */
router.post("/", authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const {
      name,
      description,
      discountType = "percentage",
      discountValue,
      eligibilityType = "all",
      communityType = null,
      appliesTo = "subscription",
      maxUses = null,
      validUntil = null,
    } = req.body;

    if (!name || !discountValue) {
      return res.status(400).json({ error: "name and discountValue are required" });
    }

    const result = await pool.query(
      `INSERT INTO discounts (name, description, source, discount_type, discount_value,
         eligibility_type, community_type, applies_to, max_uses, valid_until)
       VALUES ($1, $2, 'manual', $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [name, description, discountType, discountValue, eligibilityType, communityType, appliesTo, maxUses, validUntil]
    );

    const discount = result.rows[0];

    // Eagerly create the Stripe coupon
    const { ensureStripeCoupon } = require("../services/discountService");
    const couponId = await ensureStripeCoupon(discount);

    res.status(201).json({ data: { ...discount, stripe_coupon_id: couponId } });
  } catch (err) {
    logger.error("Error creating discount:", err);
    res.status(500).json({ error: "Failed to create discount" });
  }
});

/**
 * PATCH /discounts/:id (admin only)
 * Update is_active status of a discount.
 */
router.patch("/:id", authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const { isActive } = req.body;
    const { id } = req.params;

    const result = await pool.query(
      `UPDATE discounts SET is_active = $1, updated_at = NOW() WHERE id = $2 RETURNING *`,
      [isActive, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Discount not found" });
    }

    res.json({ data: result.rows[0] });
  } catch (err) {
    logger.error("Error updating discount:", err);
    res.status(500).json({ error: "Failed to update discount" });
  }
});

/**
 * POST /discounts/sync-stripe (admin only)
 * Manually trigger a sync of all active Stripe coupons into the discounts table.
 */
router.post("/sync-stripe", authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const coupons = await stripe.coupons.list({ limit: 100 });
    let synced = 0;
    for (const coupon of coupons.data) {
      if (coupon.valid) {
        await syncStripeCouponToDb(coupon);
        synced++;
      }
    }
    res.json({ data: { synced, total: coupons.data.length } });
  } catch (err) {
    logger.error("Error syncing Stripe coupons:", err);
    res.status(500).json({ error: "Failed to sync Stripe coupons" });
  }
});

module.exports = router;
