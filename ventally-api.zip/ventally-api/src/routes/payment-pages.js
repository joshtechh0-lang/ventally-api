const express = require("express");
const router = express.Router();
const paymentPagesController = require("../controllers/paymentPagesController");

// Server-rendered payment result pages
router.get("/success", paymentPagesController.creditPurchaseSuccess);
router.get("/subscription-success", paymentPagesController.subscriptionSuccess);
router.get("/cancel", paymentPagesController.paymentCancel);

module.exports = router;
