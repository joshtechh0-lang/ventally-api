const express = require("express");
const router = express.Router();
const { authenticateToken, requireRole } = require("../middleware/auth");
const tipController = require("../controllers/tipController");

router.get(
  "/sent",
  authenticateToken,
  requireRole("venter"),
  tipController.getSentTips,
);

router.get(
  "/received",
  authenticateToken,
  requireRole("listener"),
  tipController.getReceivedTips,
);

router.get("/:id", authenticateToken, tipController.getTipDetails);

module.exports = router;
