const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentController");
const { authenticateToken } = require("../middleware/auth");

router.get("/credit-packs", paymentController.getCreditPacks);
router.get("/subscription-plans", paymentController.getSubscriptionPlans);
router.post(
  "/create-checkout-session",
  authenticateToken,
  paymentController.createCheckoutSession,
);
router.post(
  "/create-subscription-checkout",
  authenticateToken,
  paymentController.createSubscriptionCheckout,
);
router.get(
  "/verify-checkout",
  authenticateToken,
  paymentController.verifyCheckoutSession,
);
router.post(
  "/cancel-subscription",
  authenticateToken,
  paymentController.cancelSubscription,
);
router.get(
  "/checkout-session/:sessionId",
  authenticateToken,
  paymentController.getCheckoutSession,
);
router.get(
  "/checkout-sessions",
  authenticateToken,
  paymentController.getUserCheckoutSessions,
);

router.get(
  "/payg-status",
  authenticateToken,
  paymentController.getPaygStatus,
);
router.post(
  "/payg-setup-intent",
  authenticateToken,
  paymentController.createPaygSetupIntent,
);
router.post(
  "/payg-confirm",
  authenticateToken,
  paymentController.confirmPaygEnrollment,
);

router.post(
  "/activate-free-tier",
  authenticateToken,
  paymentController.activateFreeTier
);


router.post(
  "/top-up-intent",
  authenticateToken,
  paymentController.topUpIntent,
);

module.exports = router;
