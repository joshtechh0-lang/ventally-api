const express = require("express");
const router = express.Router();
const signatureController = require("../controllers/signatureController");
const { authenticateToken } = require("../middleware/auth");
const { uploadSignatureFile } = require("../middleware/fileUpload");

// Swagger documentation is defined in src/config/swagger-paths.js

// POST /api/v1/signatures - Upload or update user signature
router.post(
  "/",
  authenticateToken,
  uploadSignatureFile,
  signatureController.uploadSignature,
);

// GET /api/v1/signatures/:userId - Get user signature (owner + admin)
router.get("/:userId", authenticateToken, signatureController.getSignature);

// DELETE /api/v1/signatures - Delete own signature
router.delete("/", authenticateToken, signatureController.deleteSignature);

module.exports = router;
