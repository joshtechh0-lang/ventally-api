const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const { authenticateToken } = require("../middleware/auth");

router.post("/register", authController.register);
// Public — fires Klaviyo abandoned signup event when user leaves signup screen
router.post("/track-abandoned", authController.trackAbandonedSignup);
router.post("/login", authController.login);
router.post("/google-login", authController.googleLogin);
router.post("/apple-login", authController.appleLogin);
router.post("/refresh-token", authController.refreshToken);
router.post("/verify-email", authController.verifyEmail); // OTP verification
router.post("/resend-verification", authController.resendVerificationEmail);
router.post("/request-password-reset", authController.requestPasswordReset);
router.post("/reset-password", authController.resetPassword);
router.post(
  "/change-password",
  authenticateToken,
  authController.changePassword,
);
router.post(
  "/change-email/request-otp",
  authenticateToken,
  authController.requestEmailChangeOtp,
);
router.post(
  "/change-email/verify-otp",
  authenticateToken,
  authController.verifyEmailChangeOtp,
);
router.post(
  "/change-phone/request-otp",
  authenticateToken,
  authController.requestPhoneChangeOtp,
);
router.post(
  "/change-phone/verify-otp",
  authenticateToken,
  authController.verifyPhoneChangeOtp,
);
router.post("/logout", authenticateToken, authController.logout);
router.delete("/account", authenticateToken, authController.deleteAccount);
router.get("/profile", authenticateToken, authController.getProfile);
router.put("/profile", authenticateToken, authController.updateProfile);
router.get(
  "/security/2fa",
  authenticateToken,
  authController.getTwoFactorAuthentication,
);
router.put(
  "/security/2fa",
  authenticateToken,
  authController.updateTwoFactorAuthentication,
);

// Biometric authentication routes
router.post(
  "/biometric/register",
  authenticateToken,
  authController.registerBiometric,
);
router.post("/biometric/login", authController.loginWithBiometric);
router.post(
  "/biometric/disable",
  authenticateToken,
  authController.disableBiometric,
);
router.get(
  "/biometric/status",
  authenticateToken,
  authController.getBiometricStatus,
);


router.post("/send-sms-otp", authController.sendSmsOtp); // No auth required - pre-verification
router.post("/verify-sms-otp", authController.verifySmsOtp);

module.exports = router;
