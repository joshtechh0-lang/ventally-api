const express = require("express");
const router = express.Router();
const { claimReward } = require("../controllers/adsController");
const { authenticateToken } = require("../middleware/auth");

router.use(authenticateToken);

// POST /ads/claim-reward — credit wallet after user watches 3 ads
router.post("/claim-reward", claimReward);

module.exports = router;
