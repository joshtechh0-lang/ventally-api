const express = require("express");
const router = express.Router();
const { authenticateToken, requireRole } = require("../middleware/auth");
const chatController = require("../controllers/chatController");

// Create a new chat conversation (venter only)
router.post(
  "/",
  authenticateToken,
  requireRole("venter"),
  chatController.createConversation,
);

// Create broadcast chat requests for all available listeners (venter only)
router.post(
  "/broadcast",
  authenticateToken,
  requireRole("venter"),
  chatController.createBroadcastConversation,
);

// Get user's conversations
router.get("/", authenticateToken, chatController.getConversations);

// Get conversation details
router.get("/:id", authenticateToken, chatController.getConversation);

// Accept a chat conversation (listener only)
router.post(
  "/:id/accept",
  authenticateToken,
  requireRole("listener"),
  chatController.acceptConversation,
);

// Decline a chat conversation (listener only)
router.post(
  "/:id/decline",
  authenticateToken,
  requireRole("listener"),
  chatController.declineConversation,
);

// End a chat conversation
router.post("/:id/end", authenticateToken, chatController.endConversation);

// Get messages for a conversation
router.get("/:id/messages", authenticateToken, chatController.getMessages);

module.exports = router;
