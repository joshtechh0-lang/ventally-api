const express = require("express");
const router = express.Router();
const {
  authenticateToken,
  requireRole,
  requireAdminFeaturePermission,
} = require("../middleware/auth");
const reportController = require("../controllers/reportController");

// Submit a report
router.post("/", authenticateToken, reportController.submitReport);

// Get my submitted reports
router.get("/my-reports", authenticateToken, reportController.getMyReports);

// Admin endpoints
router.get(
  "/admin/all",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  reportController.getAllReports,
);

router.get(
  "/admin/stats",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  reportController.getReportsStats,
);

router.get(
  "/admin/:reportId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  reportController.getReportDetails,
);

router.put(
  "/admin/:reportId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "edit"),
  reportController.updateReportStatus,
);

module.exports = router;
