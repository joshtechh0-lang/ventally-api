const express = require("express");
const router = express.Router();
const { authenticateToken, requireRole } = require("../middleware/auth");
const subAdminController = require("../controllers/subAdminController");

router.get(
  "/",
  authenticateToken,
  requireRole("admin"),
  subAdminController.listSubAdmins,
);

router.get(
  "/pending",
  authenticateToken,
  requireRole("admin"),
  subAdminController.listPendingSubAdminRequests,
);

router.get(
  "/:subAdminId",
  authenticateToken,
  requireRole("admin"),
  subAdminController.getSubAdmin,
);

router.post(
  "/",
  authenticateToken,
  requireRole("admin"),
  subAdminController.createSubAdmin,
);

router.put(
  "/:subAdminId",
  authenticateToken,
  requireRole("admin"),
  subAdminController.updateSubAdmin,
);

router.put(
  "/:subAdminId/status",
  authenticateToken,
  requireRole("admin"),
  subAdminController.updateSubAdminStatus,
);

router.delete(
  "/:subAdminId",
  authenticateToken,
  requireRole("admin"),
  subAdminController.deleteSubAdmin,
);

module.exports = router;
