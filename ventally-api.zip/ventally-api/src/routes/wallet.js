const express = require("express");
const router = express.Router();
const walletController = require("../controllers/walletController");
const { authenticateToken, requireVerified } = require("../middleware/auth");

// All wallet routes require authentication
router.use(authenticateToken);

router.get("/balance", walletController.getBalance);
router.get("/subscription", walletController.getSubscriptionStatus);
router.get("/transactions", walletController.getTransactions);
router.put(
  "/auto-recharge",
  requireVerified,
  walletController.updateAutoRecharge,
);

module.exports = router;
