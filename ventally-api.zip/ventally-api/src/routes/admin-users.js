const express = require("express");
const router = express.Router();
const {
  authenticateToken,
  requireRole,
  requireAdminFeaturePermission,
} = require("../middleware/auth");
const adminUserController = require("../controllers/adminUserController");
const listenerVerificationController = require("../controllers/listenerVerificationController");

router.get(
  "/integrations",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.listIntegrations,
);

router.get(
  "/integrations/export/pdf",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.exportIntegrationsPdf,
);

router.put(
  "/integrations/:userId/export-status",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "edit"),
  adminUserController.updateIntegrationExportStatus,
);

router.get(
  "/payments/history/export/pdf",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.exportPaymentHistoryPdf,
);

router.get(
  "/payments/history",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.listPaymentHistory,
);

router.get(
  "/payments/stats",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.getPaymentStats,
);

router.put(
  "/users/roles",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "edit"),
  adminUserController.bulkChangeUserRoles,
);

router.delete(
  "/users",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "delete"),
  adminUserController.bulkDeleteUsers,
);

router.get(
  "/users",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.listUsers,
);

router.get(
  "/users/:userId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  adminUserController.getUserDetail,
);

router.put(
  "/users/:userId/suspend",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "suspend"),
  adminUserController.suspendUser,
);

router.delete(
  "/users/:userId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "delete"),
  adminUserController.deleteUser,
);

router.get(
  "/listener-requests",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  listenerVerificationController.listVerificationSubmissionsAdmin,
);

router.get(
  "/listener-requests/:verificationId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  listenerVerificationController.getVerificationSubmissionAdmin,
);

router.put(
  "/listener-requests/:verificationId",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "edit"),
  listenerVerificationController.verifySubmissionAdmin,
);

// Temporary admin endpoint to verify user email
router.post("/verify-user-email", authenticateToken, requireRole("admin"), async (req, res) => {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: "userId required" });
    const { pool } = require("../database/connection");
    try {
        const result = await pool.query(
            "UPDATE users SET is_verified = true WHERE id = $1 RETURNING id, email, is_verified",
            [userId]
        );
        if (result.rows.length === 0) return res.status(404).json({ error: "User not found" });
        res.json({ success: true, user: result.rows[0] });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
