const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const { getVenterHomeSummary } = require("../controllers/homeController");

// Venter home summary endpoint (progress, highlights, achievements, recent entries)
router.get("/summary", authenticateToken, getVenterHomeSummary);

module.exports = router;
