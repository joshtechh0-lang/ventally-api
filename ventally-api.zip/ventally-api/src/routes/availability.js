const express = require("express");
const router = express.Router();
const { authenticateToken, requireRole } = require("../middleware/auth");
const availabilityController = require("../controllers/availabilityController");

// Mark listener as online
router.post(
  "/online",
  authenticateToken,
  requireRole("listener"),
  availabilityController.goOnline,
);

// Mark listener as offline
router.post(
  "/offline",
  authenticateToken,
  requireRole("listener"),
  availabilityController.goOffline,
);

// Send heartbeat to maintain online status
router.post(
  "/heartbeat",
  authenticateToken,
  requireRole("listener"),
  availabilityController.heartbeat,
);

// Get available listeners (venter only)
router.get(
  "/listeners",
  authenticateToken,
  requireRole("venter"),
  availabilityController.getAvailableListeners,
);

// Update listener rate per minute
router.put(
  "/rate",
  authenticateToken,
  requireRole("listener"),
  availabilityController.updateRate,
);

// Get own listener status
router.get(
  "/status",
  authenticateToken,
  requireRole("listener"),
  availabilityController.getStatus,
);

// Update listener profile (bio, specialties)
router.put(
  "/profile",
  authenticateToken,
  requireRole("listener"),
  availabilityController.updateProfile,
);

module.exports = router;
