const express = require("express");
const router = express.Router();
const {
  authenticateToken,
  requireRole,
  requireAdminFeaturePermission,
} = require("../middleware/auth");
const {
  getAiSettings,
  updateAiSettings,
} = require("../controllers/adminSettingsController");

router.get(
  "/ai",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "view"),
  getAiSettings,
);

router.put(
  "/ai",
  authenticateToken,
  requireRole("admin", "sub_admin"),
  requireAdminFeaturePermission("accessAdminPanel", "edit"),
  updateAiSettings,
);

module.exports = router;
