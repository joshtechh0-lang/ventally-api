const express = require("express");
const router = express.Router();
const agoraController = require("../controllers/agoraController");

// Docs-style token endpoint compatible with Agora token-server examples.
router.post("/token/generate", agoraController.generateToken);

module.exports = router;
