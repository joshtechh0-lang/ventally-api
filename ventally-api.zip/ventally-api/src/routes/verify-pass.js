const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  getStatus,
  getVerifyUrl,
  handleWebhook,
  handleCallback,
  verifyFromMobile,
} = require("../controllers/verifyPassController");

// Get current user's verification status
router.get("/status", authenticateToken, getStatus);

// Get the VerifyPass URL to open in WebView
router.get("/url", authenticateToken, getVerifyUrl);

// VerifyPass webhook — called by VerifyPass when a user verifies (no auth, public)
// Configure this URL in VerifyPass dashboard: Integrations → Webhook
// URL: https://api.ventally.co/api/v1/verify-pass/webhook
router.post("/webhook", handleWebhook);
router.get("/webhook", (req, res) => res.json({ ok: true, message: "VerifyPass webhook endpoint is active" }));

// Browser redirect callback — VerifyPass may redirect the WebView here after verification
router.post("/callback", handleCallback);
router.get("/callback", handleCallback);

// Called from mobile app after WebView completes (legacy / fallback)
router.post("/verify", authenticateToken, verifyFromMobile);

module.exports = router;
