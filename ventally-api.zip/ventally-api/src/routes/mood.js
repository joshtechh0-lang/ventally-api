const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  logMood,
  getTodayMood,
  getMoodHistory,
  updateTodayMood,
  deleteMood,
  getMoodStats,
} = require("../controllers/moodController");

// Log mood for today
router.post("/log", authenticateToken, logMood);

// Get today's mood
router.get("/today", authenticateToken, getTodayMood);

// Get mood history with pagination and date filtering
router.get("/history", authenticateToken, getMoodHistory);

// Update today's mood
router.put("/today", authenticateToken, updateTodayMood);

// Delete a mood entry
router.delete("/:moodId", authenticateToken, deleteMood);

// Get mood statistics
router.get("/stats", authenticateToken, getMoodStats);

module.exports = router;
