/**
 * User Routes
 * Handles user account management endpoints
 */

const express = require("express");
const router = express.Router();
const { authenticateToken } = require("../middleware/auth");
const {
  switchRole,
  getUserRoles,
  updateAvailableRoles,
} = require("../controllers/userController");

/**
 * @route   POST /users/switch-role
 * @desc    Switch user's active role
 * @access  Private
 */
router.post("/switch-role", authenticateToken, switchRole);

/**
 * @route   GET /users/roles
 * @desc    Get user's available and active roles
 * @access  Private
 */
router.get("/roles", authenticateToken, getUserRoles);

/**
 * @route   PUT /users/available-roles
 * @desc    Add or remove roles from user's available roles
 * @access  Private
 */
router.put("/available-roles", authenticateToken, updateAvailableRoles);

module.exports = router;
