/**
 * AsyncAPI 2.6.0 Specification for Ventally Socket.io Events
 * Documentation: https://www.asyncapi.com/docs/reference/specification/v2.6.0
 */

module.exports = {
  asyncapi: "2.6.0",
  info: {
    title: "Ventally WebSocket API",
    version: "1.0.0",
    description:
      "Real-time communication for anonymous calling and chat between venters and listeners",
    contact: {
      name: "Ventally Support",
      email: "support@ventally.com",
    },
  },
  servers: {
    production: {
      url: "wss://api.ventally.com",
      protocol: "wss",
      description: "Production WebSocket server",
    },
    development: {
      url: "ws://localhost:3000",
      protocol: "ws",
      description: "Development WebSocket server",
    },
  },
  defaultContentType: "application/json",
  channels: {
    "/": {
      description: "Root Socket.io namespace for all real-time events",
      subscribe: {
        summary: "Receive events from server",
        message: {
          oneOf: [
            { $ref: "#/components/messages/ChatRequest" },
            { $ref: "#/components/messages/ChatAccepted" },
            { $ref: "#/components/messages/ChatDeclined" },
            { $ref: "#/components/messages/ChatMessage" },
            { $ref: "#/components/messages/ChatTyping" },
            { $ref: "#/components/messages/ChatRead" },
            { $ref: "#/components/messages/ChatEnded" },
            { $ref: "#/components/messages/CallRequest" },
            { $ref: "#/components/messages/CallAccepted" },
            { $ref: "#/components/messages/CallDeclined" },
            { $ref: "#/components/messages/CallCancelled" },
            { $ref: "#/components/messages/CallActive" },
            { $ref: "#/components/messages/CallEnded" },
            { $ref: "#/components/messages/RequestsLatest" },
            { $ref: "#/components/messages/RequestsUpdated" },
            { $ref: "#/components/messages/RequestsRemoved" },
            { $ref: "#/components/messages/ListenersActive" },
            { $ref: "#/components/messages/ListenerStatus" },
            { $ref: "#/components/messages/HeartbeatAck" },
            { $ref: "#/components/messages/Error" },
          ],
        },
      },
      publish: {
        summary: "Send events to server",
        message: {
          oneOf: [
            { $ref: "#/components/messages/ChatMessageSend" },
            { $ref: "#/components/messages/ChatTypingSend" },
            { $ref: "#/components/messages/ChatReadSend" },
            { $ref: "#/components/messages/ChatJoin" },
            { $ref: "#/components/messages/ChatLeave" },
            { $ref: "#/components/messages/CallJoined" },
            { $ref: "#/components/messages/CallLeave" },
            { $ref: "#/components/messages/CallCancel" },
            { $ref: "#/components/messages/RequestsSubscribe" },
            { $ref: "#/components/messages/RequestsUnsubscribe" },
            { $ref: "#/components/messages/ListenersSubscribe" },
            { $ref: "#/components/messages/ListenersUnsubscribe" },
            { $ref: "#/components/messages/Heartbeat" },
          ],
        },
      },
    },
  },
  components: {
    messages: {
      ChatRequest: {
        name: "chat:request",
        title: "Chat Request Received",
        summary: "Listener receives a chat request from a venter",
        contentType: "application/json",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
              description: "Conversation ID",
            },
            requester: {
              $ref: "#/components/schemas/AnonymousIdentity",
            },
            ratePerMinute: {
              type: "number",
              format: "float",
              example: 0.5,
            },
            createdAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      ChatAccepted: {
        name: "chat:accepted",
        title: "Chat Accepted",
        summary: "Venter receives notification that listener accepted chat",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            listenerId: {
              type: "string",
              format: "uuid",
            },
            conversation: {
              type: "object",
              properties: {
                id: {
                  type: "string",
                  format: "uuid",
                },
                status: {
                  type: "string",
                  example: "active",
                },
                listenerId: {
                  type: "string",
                  format: "uuid",
                },
                startedAt: {
                  type: "string",
                  format: "date-time",
                },
              },
            },
            listener: {
              allOf: [
                { $ref: "#/components/schemas/AnonymousIdentity" },
                {
                  type: "object",
                  properties: {
                    id: {
                      type: "string",
                      format: "uuid",
                    },
                  },
                },
              ],
            },
            startedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      ChatDeclined: {
        name: "chat:declined",
        title: "Chat Declined",
        summary: "Venter receives notification that listener declined chat",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            message: {
              type: "string",
              example: "The listener declined your chat request",
            },
          },
        },
      },
      ChatMessage: {
        name: "chat:message",
        title: "Chat Message Received",
        summary: "Receive a message in active conversation",
        payload: {
          type: "object",
          properties: {
            messageId: {
              type: "string",
              format: "uuid",
            },
            conversationId: {
              type: "string",
              format: "uuid",
            },
            content: {
              type: "string",
              example: "Hello, how can I help?",
            },
            senderId: {
              type: "string",
              format: "uuid",
            },
            receiverId: {
              type: "string",
              format: "uuid",
            },
            sender: {
              $ref: "#/components/schemas/AnonymousIdentity",
            },
            deliveredAt: {
              type: "string",
              format: "date-time",
            },
            createdAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      ChatMessageSend: {
        name: "chat:message",
        title: "Send Chat Message",
        summary: "Send a message in conversation",
        payload: {
          type: "object",
          required: ["conversationId", "content"],
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            content: {
              type: "string",
              minLength: 1,
              maxLength: 5000,
            },
          },
        },
      },
      ChatTyping: {
        name: "chat:typing",
        title: "Typing Indicator",
        summary: "Receive typing indicator from other participant",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            user: {
              type: "object",
              properties: {
                anonymousName: {
                  type: "string",
                },
              },
            },
            isTyping: {
              type: "boolean",
            },
          },
        },
      },
      ChatTypingSend: {
        name: "chat:typing",
        title: "Send Typing Indicator",
        summary: "Notify other participant you are typing",
        payload: {
          type: "object",
          required: ["conversationId", "isTyping"],
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            isTyping: {
              type: "boolean",
            },
          },
        },
      },
      ChatRead: {
        name: "chat:read:ack",
        title: "Messages Read Acknowledgement",
        summary: "Notification that your messages were read",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            messageIds: {
              type: "array",
              items: {
                type: "string",
                format: "uuid",
              },
            },
            readAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      ChatReadSend: {
        name: "chat:read",
        title: "Mark Messages as Read",
        summary: "Mark received messages as read",
        payload: {
          type: "object",
          required: ["conversationId", "messageIds"],
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            messageIds: {
              type: "array",
              items: {
                type: "string",
                format: "uuid",
              },
            },
          },
        },
      },
      ChatJoin: {
        name: "chat:join",
        title: "Join Conversation Room",
        summary: "Join Socket.io room for real-time updates",
        payload: {
          type: "object",
          required: ["conversationId"],
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
          },
        },
      },
      ChatLeave: {
        name: "chat:leave",
        title: "Leave Conversation Room",
        payload: {
          type: "object",
          required: ["conversationId"],
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
          },
        },
      },
      ChatEnded: {
        name: "chat:ended",
        title: "Chat Ended",
        summary: "Conversation has ended",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            durationMinutes: {
              type: "integer",
            },
            totalCost: {
              type: "number",
              format: "float",
            },
            earnings: {
              type: "number",
              format: "float",
              description: "Only sent to listener",
            },
            endedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      CallRequest: {
        name: "call:request",
        title: "Voice Call Request Received",
        summary:
          "Listener receives a call request from venter in their personal user room (userId string)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            requester: {
              $ref: "#/components/schemas/AnonymousIdentity",
            },
            ratePerMinute: {
              type: "number",
              format: "float",
            },
            createdAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      CallAccepted: {
        name: "call:accepted",
        title: "Call Accepted",
        summary:
          "Venter receives notification with Twilio room details in their personal user room (userId string)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            roomName: {
              type: "string",
              description: "Twilio room name",
            },
            token: {
              type: "string",
              description: "Twilio access token JWT",
            },
            listener: {
              $ref: "#/components/schemas/AnonymousIdentity",
            },
          },
        },
      },
      CallDeclined: {
        name: "call:declined",
        title: "Call Declined",
        summary:
          "Venter receives notification that listener declined in their personal user room (userId string)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            message: {
              type: "string",
            },
          },
        },
      },
      CallCancelled: {
        name: "call:cancelled",
        title: "Call Cancelled",
        summary:
          "Listener receives notification that venter cancelled in their personal user room (userId string)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            message: {
              type: "string",
            },
          },
        },
      },
      CallCancel: {
        name: "call:cancel",
        title: "Cancel Call Request",
        summary: "Venter cancels call before listener accepts",
        payload: {
          type: "object",
          required: ["callId"],
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
          },
        },
      },
      CallJoined: {
        name: "call:joined",
        title: "Joined Call Room",
        summary: "Notify server that client joined Twilio call",
        payload: {
          type: "object",
          required: ["callId"],
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
          },
        },
      },
      CallActive: {
        name: "call:active",
        title: "Call is Active",
        summary: "Both participants joined, call is active",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            startedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      CallLeave: {
        name: "call:leave",
        title: "Leave Call Room",
        payload: {
          type: "object",
          required: ["callId"],
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
          },
        },
      },
      CallEnded: {
        name: "call:ended",
        title: "Call Ended",
        summary:
          "Voice call has ended; event is delivered to participant personal user rooms (userId string)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            durationSeconds: {
              type: "integer",
            },
            durationMinutes: {
              type: "integer",
            },
            totalCost: {
              type: "number",
              format: "float",
            },
            earnings: {
              type: "number",
              format: "float",
              description: "Only sent to listener",
            },
            endedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      BalanceUpdate: {
        name: "balance:update",
        title: "Balance Update",
        summary:
          "Real-time balance update during active call (sent every 60 seconds)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            remainingMinutes: {
              type: "number",
              format: "float",
              description: "Minutes remaining in wallet balance",
            },
            remainingCurrency: {
              type: "number",
              format: "float",
              description: "Currency value remaining",
            },
            ratePerMinute: {
              type: "number",
              format: "float",
            },
            elapsedMinutes: {
              type: "number",
              format: "float",
              description: "Billable minutes elapsed (excluding grace period)",
            },
            isInGracePeriod: {
              type: "boolean",
              description: "Whether call is currently in grace period",
            },
            gracePeriodRemaining: {
              type: "integer",
              description: "Minutes remaining in grace period",
            },
            warningLevel: {
              type: "string",
              enum: ["none", "warning", "critical", "depleted"],
              description: "Current warning level",
            },
            estimatedDepletionTime: {
              type: "string",
              format: "date-time",
              description: "Estimated time when balance will be depleted",
            },
            timestamp: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      BalanceWarning: {
        name: "balance:warning",
        title: "Balance Warning",
        summary: "Low balance warning (triggered at 5 minutes remaining)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            level: {
              type: "string",
              enum: ["warning"],
              description: "Warning level",
            },
            remainingMinutes: {
              type: "number",
              format: "float",
            },
            remainingCurrency: {
              type: "number",
              format: "float",
            },
            message: {
              type: "string",
              description: "User-friendly warning message",
            },
            estimatedDepletionTime: {
              type: "string",
              format: "date-time",
            },
            timestamp: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      BalanceCritical: {
        name: "balance:critical",
        title: "Balance Critical",
        summary: "Critical balance warning (triggered at 2 minutes remaining)",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            level: {
              type: "string",
              enum: ["critical"],
              description: "Warning level",
            },
            remainingMinutes: {
              type: "number",
              format: "float",
            },
            remainingCurrency: {
              type: "number",
              format: "float",
            },
            message: {
              type: "string",
              description: "User-friendly critical warning message",
            },
            estimatedDepletionTime: {
              type: "string",
              format: "date-time",
            },
            timestamp: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      BalanceDepleted: {
        name: "balance:depleted",
        title: "Balance Depleted",
        summary: "Balance has been depleted, call will end shortly",
        payload: {
          type: "object",
          properties: {
            callId: {
              type: "string",
              format: "uuid",
            },
            level: {
              type: "string",
              enum: ["depleted"],
            },
            remainingMinutes: {
              type: "number",
              format: "float",
              description: "Will be 0 or negative",
            },
            remainingCurrency: {
              type: "number",
              format: "float",
              description: "Will be 0 or negative",
            },
            message: {
              type: "string",
              description: "User-friendly depletion message",
            },
            timestamp: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      RequestsSubscribe: {
        name: "requests:subscribe",
        title: "Subscribe Latest Requests",
        summary: "Subscribe to pending conversation request snapshots",
        payload: {
          type: "object",
          properties: {
            limit: {
              type: "integer",
              minimum: 1,
              maximum: 100,
              default: 20,
            },
            offset: {
              type: "integer",
              minimum: 0,
              default: 0,
            },
          },
        },
      },
      RequestsUnsubscribe: {
        name: "requests:unsubscribe",
        title: "Unsubscribe Latest Requests",
        summary: "Stop realtime pending request updates",
        payload: {
          type: "object",
          properties: {},
        },
      },
      RequestsLatest: {
        name: "requests:latest",
        title: "Latest Requests Snapshot",
        summary: "Current pending conversation requests for authenticated user",
        payload: {
          type: "object",
          properties: {
            count: {
              type: "integer",
            },
            requests: {
              type: "array",
              items: {
                $ref: "#/components/schemas/PendingRequest",
              },
            },
            updatedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      RequestsUpdated: {
        name: "requests:updated",
        title: "Request Updated",
        summary: "Pending request upsert event",
        payload: {
          $ref: "#/components/schemas/PendingRequest",
        },
      },
      RequestsRemoved: {
        name: "requests:removed",
        title: "Request Removed",
        summary: "Pending request removed from latest list",
        payload: {
          type: "object",
          properties: {
            conversationId: {
              type: "string",
              format: "uuid",
            },
            status: {
              type: "string",
              example: "declined",
            },
            reason: {
              type: "string",
              example: "accepted",
            },
            updatedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      ListenersSubscribe: {
        name: "listeners:subscribe",
        title: "Subscribe Active Listeners",
        summary: "Subscribe to active listener list updates",
        payload: {
          type: "object",
          properties: {},
        },
      },
      ListenersUnsubscribe: {
        name: "listeners:unsubscribe",
        title: "Unsubscribe Active Listeners",
        summary: "Stop realtime active listener updates",
        payload: {
          type: "object",
          properties: {},
        },
      },
      ListenersActive: {
        name: "listeners:active",
        title: "Active Listener Snapshot",
        summary: "Filtered available listeners for current venter",
        payload: {
          type: "object",
          properties: {
            count: {
              type: "integer",
            },
            listeners: {
              type: "array",
              items: {
                $ref: "#/components/schemas/AvailableListener",
              },
            },
            reason: {
              type: "string",
            },
            updatedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      ListenerStatus: {
        name: "listener:status",
        title: "Listener Status Changed",
        summary: "Realtime listener availability status delta",
        payload: {
          type: "object",
          properties: {
            listenerId: {
              type: "string",
              format: "uuid",
            },
            isOnline: {
              type: "boolean",
            },
            isBusy: {
              type: "boolean",
            },
            status: {
              type: "string",
              example: "online",
            },
            sessionId: {
              type: "string",
              nullable: true,
            },
            updatedAt: {
              type: "string",
              format: "date-time",
            },
          },
        },
      },
      Heartbeat: {
        name: "heartbeat",
        title: "Send Heartbeat",
        summary: "Keep connection alive",
        payload: {
          type: "object",
          properties: {},
        },
      },
      HeartbeatAck: {
        name: "heartbeat:ack",
        title: "Heartbeat Acknowledgement",
        payload: {
          type: "object",
          properties: {
            timestamp: {
              type: "number",
              description: "Server timestamp in milliseconds",
            },
          },
        },
      },
      Error: {
        name: "error",
        title: "Socket Error",
        summary: "Error occurred during Socket.io operation",
        payload: {
          type: "object",
          properties: {
            event: {
              type: "string",
              description: "Event that caused error",
            },
            message: {
              type: "string",
              description: "Error message",
            },
          },
        },
      },
    },
    schemas: {
      PendingRequest: {
        type: "object",
        properties: {
          conversationId: {
            type: "string",
            format: "uuid",
          },
          status: {
            type: "string",
            example: "pending",
          },
          role: {
            type: "string",
            enum: ["listener", "venter"],
          },
          requester: {
            type: "object",
            properties: {
              id: {
                type: "string",
                format: "uuid",
              },
              anonymousName: {
                type: "string",
              },
              avatarSeed: {
                type: "string",
              },
            },
          },
          listenerId: {
            type: "string",
            format: "uuid",
          },
          ratePerMinute: {
            type: "number",
            format: "float",
          },
          createdAt: {
            type: "string",
            format: "date-time",
          },
          updatedAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      AvailableListener: {
        type: "object",
        properties: {
          listenerId: {
            type: "string",
            format: "uuid",
          },
          ratePerMinute: {
            type: "number",
            format: "float",
          },
          totalSessions: {
            type: "integer",
          },
          averageRating: {
            type: "number",
            format: "float",
          },
          bioAnonymous: {
            type: "string",
          },
          specialties: {
            type: "array",
            items: {
              type: "string",
            },
          },
        },
      },
      AnonymousIdentity: {
        type: "object",
        properties: {
          anonymousName: {
            type: "string",
            description: "Auto-generated friendly name",
            example: "Swift Fox",
          },
          avatarSeed: {
            type: "string",
            description:
              "Seed for avatar generation; may include listener context suffix in the format <seed>:<listener_id>",
            example: "a1b2c3d4e5f6",
          },
        },
      },
    },
    securitySchemes: {
      jwtAuth: {
        type: "userPassword",
        description: "JWT token provided in handshake auth object",
      },
    },
  },
};
