/**
 * Shared Stripe client.
 *
 * Instantiated once for the whole process so we can attach request/response
 * logging in a single place (Layer 1). Every Stripe API call made through this
 * client emits a `[STRIPE] → request` / `[STRIPE] ← response` pair to stdout
 * (which Elastic Beanstalk ships to CloudWatch), including the Stripe
 * `request_id` needed to backtrack a transaction with Stripe Support.
 *
 * Exports `null` when STRIPE_SECRET_KEY is unset, preserving the historical
 * "Stripe disabled" behavior that several services rely on
 * (e.g. tipService, listenerPayoutService, adminFinanceStats).
 *
 * NOTE: the request/response events expose method/path/status/request_id only,
 * NOT request bodies or card data — so no secrets or PII are logged here.
 */
const logger = require("../utils/logger");

let stripe = null;

if (process.env.STRIPE_SECRET_KEY) {
  stripe = require("stripe")(process.env.STRIPE_SECRET_KEY, {
    appInfo: { name: "ventally-backend" },
    maxNetworkRetries: 1,
  });

  stripe.on("request", (request) => {
    logger.info("[STRIPE] → request", {
      method: request.method,
      path: request.path,
    });
  });

  stripe.on("response", (response) => {
    logger.info("[STRIPE] ← response", {
      method: response.method,
      path: response.path,
      status: response.status,
      elapsedMs: response.elapsed,
      requestId: response.request_id,
    });
  });
} else {
  logger.warn("[STRIPE] STRIPE_SECRET_KEY not set — Stripe client disabled");
}

module.exports = stripe;
