const swaggerPaths = require("./swagger-paths");

// Get API base URL from environment or use defaults
const DOMAIN_NAME = process.env.DOMAIN_NAME || "http://localhost:3001";
const SWAGGER_BASE_URL = process.env.SWAGGER_BASE_URL || DOMAIN_NAME;
const API_VERSION = process.env.API_VERSION || "1.0.0";
const API_TITLE = process.env.API_TITLE || "Ventally API";
const API_DESCRIPTION =
  process.env.API_DESCRIPTION ||
  "Emotional support calling platform with per-minute billing";

// Determine server descriptions and URLs
const getServers = () => {
  const servers = [];

  // Add customizable server for testing
  servers.push({
    url: "{protocol}://{host}:{port}",
    description: "Custom Server (for testing)",
    variables: {
      protocol: {
        enum: ["http", "https"],
        default: "https",
        description: "Protocol to use",
      },
      host: {
        default: "api.dev.ventally.co",
        description: "API server host",
      },
      port: {
        enum: ["80", "443", "3000", "8080"],
        default: "443",
        description: "Server port",
      },
    },
  });

  // Add custom Swagger URL if specified
  if (SWAGGER_BASE_URL && SWAGGER_BASE_URL !== DOMAIN_NAME) {
    servers.push({
      url: SWAGGER_BASE_URL,
      description: "Custom API Server",
    });
  }

  // Add environment-based servers
  if (process.env.NODE_ENV === "production") {
    servers.push({
      url: DOMAIN_NAME,
      description: "Production Server",
    });
  } else if (process.env.NODE_ENV === "development") {
    servers.push({
      url: DOMAIN_NAME,
      description: "Development Server",
    });
  } else {
    servers.push({
      url: DOMAIN_NAME,
      description: "API Server",
    });
  }

  // Add localhost for local testing (always available)
  if (
    !DOMAIN_NAME.includes("localhost") &&
    process.env.NODE_ENV !== "production"
  ) {
    servers.push({
      url: "http://localhost:3000",
      description: "Local Development",
    });
  }

  return servers;
};

const swaggerSpec = {
  openapi: "3.0.0",
  info: {
    title: API_TITLE,
    version: API_VERSION,
    description: API_DESCRIPTION,
    contact: {
      name: "Ventally Support",
      email: "support@ventally.com",
    },
    license: {
      name: "ISC",
      url: "https://opensource.org/licenses/ISC",
    },
  },
  servers: getServers(),
  components: {
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
        description: "Enter your JWT token from the login/register response",
      },
    },
    schemas: {
      User: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "User unique identifier",
          },
          email: {
            type: "string",
            format: "email",
            description: "User email address",
          },
          userType: {
            type: "string",
            enum: ["venter", "listener", "admin", "sub_admin"],
            description:
              "User role type (equals activeRole, kept for backward compatibility)",
          },
          activeRole: {
            type: "string",
            enum: ["venter", "listener", "admin", "sub_admin"],
            description: "Currently active role",
          },
          availableRoles: {
            type: "array",
            items: {
              type: "string",
              enum: ["venter", "listener", "admin", "sub_admin"],
            },
            description: "All roles user can switch between",
            example: ["venter", "listener"],
          },
          phone: {
            type: "string",
            description: "User phone number",
          },
          displayName: {
            type: "string",
            nullable: true,
            description: "Public display name of the user",
          },
          preferredLanguage: {
            type: "string",
            nullable: true,
            description: "Preferred language code (for example: en, pt, es)",
            example: "en",
          },
          listenerSignature: {
            type: "string",
            nullable: true,
            description: "Listener signature URL or base64 value",
          },
          verificationDocumentStatus: {
            type: "string",
            nullable: true,
            enum: ["not_submitted", "pending", "approved", "rejected"],
            description: "Current listener verification document status",
          },
          isVerified: {
            type: "boolean",
            description: "Email verification status",
          },
          isActive: {
            type: "boolean",
            description: "Account active status",
          },
          createdAt: {
            type: "string",
            format: "date-time",
            description: "Account creation timestamp",
          },
        },
      },
      Wallet: {
        type: "object",
        properties: {
          balanceMinutes: {
            type: "number",
            description: "Available calling minutes",
          },
          balanceCurrency: {
            type: "number",
            description: "Available currency balance",
          },
          autoRechargeEnabled: {
            type: "boolean",
            description: "Auto-recharge enabled status",
          },
          autoRechargeThreshold: {
            type: "number",
            description: "Minimum balance to trigger auto-recharge",
          },
          autoRechargeAmount: {
            type: "number",
            description: "Amount to recharge automatically",
          },
        },
      },
      Transaction: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Transaction unique identifier",
          },
          type: {
            type: "string",
            enum: [
              "credit_purchase",
              "call_deduction",
              "subscription_charge",
              "refund",
              "auto_recharge",
            ],
            description: "Transaction type",
          },
          amountMinutes: {
            type: "number",
            description:
              "Minutes amount (positive for credits, negative for deductions)",
            example: 10.5,
          },
          amountCurrency: {
            type: "number",
            description: "Currency amount in USD",
            example: 5.25,
          },
          balanceAfterMinutes: {
            type: "number",
            description: "Wallet balance in minutes after transaction",
            example: 120.5,
          },
          balanceAfterCurrency: {
            type: "number",
            description: "Wallet balance in currency after transaction",
            example: 60.0,
          },
          description: {
            type: "string",
            description: "Transaction description",
            example: "Added 10 calling minutes",
          },
          createdAt: {
            type: "string",
            format: "date-time",
            description: "Transaction timestamp",
          },
        },
      },
      MoodEntry: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Mood entry unique identifier",
            example: "550e8400-e29b-41d4-a716-446655440000",
          },
          user_id: {
            type: "string",
            format: "uuid",
            description: "User ID who logged the mood",
          },
          mood_type: {
            type: "string",
            enum: ["Happy", "Neutral", "Sad", "Anxious", "Mad"],
            description: "The mood type",
            example: "Happy",
          },
          category: {
            type: "string",
            enum: ["Work", "Family", "Health", "Unknown"],
            description: "Optional category for mood context",
            example: "Work",
          },
          notes: {
            type: "string",
            description: "Optional notes about the mood",
            example: "Had a productive day",
          },
          logged_date: {
            type: "string",
            format: "date",
            description: "The date for which this mood is logged",
            example: "2026-02-05",
          },
          created_at: {
            type: "string",
            format: "date-time",
            description: "Timestamp when mood was first logged",
          },
          updated_at: {
            type: "string",
            format: "date-time",
            description: "Timestamp when mood was last updated",
          },
        },
      },
      ReflectionEntry: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Reflection entry unique identifier",
            example: "550e8400-e29b-41d4-a716-446655440000",
          },
          user_id: {
            type: "string",
            format: "uuid",
            description: "User ID who created the reflection",
          },
          mood_log_id: {
            type: "string",
            format: "uuid",
            description:
              "Optional reference to linked mood log for the same day",
            example: "650e8400-e29b-41d4-a716-446655440001",
          },
          reflection_text: {
            type: "string",
            description: "The text content of the reflection",
            example:
              "Today I reflected on my progress and felt grateful for how far I've come.",
          },
          reflection_date: {
            type: "string",
            format: "date",
            description: "The date for which this reflection is saved",
            example: "2026-02-10",
          },
          created_at: {
            type: "string",
            format: "date-time",
            description: "Timestamp when reflection was first created",
          },
          updated_at: {
            type: "string",
            format: "date-time",
            description: "Timestamp when reflection was last updated",
          },
        },
      },
      ReflectionEntryWithMood: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Reflection entry unique identifier",
            example: "550e8400-e29b-41d4-a716-446655440000",
          },
          user_id: {
            type: "string",
            format: "uuid",
            description: "User ID who created the reflection",
          },
          mood_log_id: {
            type: "string",
            format: "uuid",
            description:
              "Optional reference to linked mood log for the same day",
            example: "650e8400-e29b-41d4-a716-446655440001",
          },
          reflection_text: {
            type: "string",
            description: "The text content of the reflection",
            example:
              "Today I reflected on my progress and felt grateful for how far I've come.",
          },
          reflection_date: {
            type: "string",
            format: "date",
            description: "The date for which this reflection is saved",
            example: "2026-02-10",
          },
          mood_type: {
            type: "string",
            enum: ["Happy", "Neutral", "Sad", "Anxious", "Mad"],
            description: "Linked mood type (if available)",
            example: "Happy",
          },
          category: {
            type: "string",
            enum: ["Work", "Family", "Health", "Unknown"],
            description: "Linked mood category (if available)",
            example: "Work",
          },
          created_at: {
            type: "string",
            format: "date-time",
            description: "Timestamp when reflection was first created",
          },
          updated_at: {
            type: "string",
            format: "date-time",
            description: "Timestamp when reflection was last updated",
          },
        },
      },
      SobrietyAchievement: {
        type: "object",
        properties: {
          code: {
            type: "string",
            example: "milestone_14",
          },
          label: {
            type: "string",
            example: "14 Days",
          },
          days_required: {
            type: "integer",
            example: 14,
          },
          achieved: {
            type: "boolean",
            example: true,
          },
        },
      },
      SobrietyStatus: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
          },
          user_id: {
            type: "string",
            format: "uuid",
          },
          sober_start_date: {
            type: "string",
            format: "date",
            example: "2026-02-01",
          },
          last_relapse_date: {
            type: "string",
            format: "date",
            nullable: true,
            example: "2026-01-31",
          },
          notes: {
            type: "string",
            nullable: true,
          },
          days_sober: {
            type: "integer",
            example: 14,
          },
          achievements: {
            type: "array",
            items: {
              $ref: "#/components/schemas/SobrietyAchievement",
            },
          },
          created_at: {
            type: "string",
            format: "date-time",
          },
          updated_at: {
            type: "string",
            format: "date-time",
          },
        },
      },
      SobrietyEvent: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
          },
          user_id: {
            type: "string",
            format: "uuid",
          },
          event_type: {
            type: "string",
            enum: ["start", "relapse", "adjustment"],
            example: "relapse",
          },
          event_date: {
            type: "string",
            format: "date",
            example: "2026-02-20",
          },
          restart_date: {
            type: "string",
            format: "date",
            nullable: true,
            example: "2026-02-20",
          },
          notes: {
            type: "string",
            nullable: true,
          },
          created_at: {
            type: "string",
            format: "date-time",
          },
        },
      },
      HomeRecentEntry: {
        type: "object",
        properties: {
          id: {
            type: "string",
          },
          entry_type: {
            type: "string",
            enum: ["mood", "reflection"],
          },
          entry_date: {
            type: "string",
            format: "date",
          },
          created_at: {
            type: "string",
            format: "date-time",
          },
          title: {
            type: "string",
            example: "Happy",
          },
          content: {
            type: "string",
            nullable: true,
          },
          category: {
            type: "string",
            nullable: true,
          },
          mood_type: {
            type: "string",
            nullable: true,
          },
          mood_log_id: {
            type: "string",
            format: "uuid",
            nullable: true,
          },
        },
      },
      AnonymousIdentity: {
        type: "object",
        properties: {
          anonymousName: {
            type: "string",
            description: "Auto-generated friendly name like 'Swift Fox'",
            example: "Swift Fox",
          },
          avatarSeed: {
            type: "string",
            description: "Seed for generating consistent avatar on client",
            example: "a1b2c3d4e5f6",
          },
        },
      },
      ListenerProfile: {
        type: "object",
        properties: {
          listenerId: {
            type: "string",
            format: "uuid",
            description: "Listener user ID",
          },
          ratePerMinute: {
            type: "number",
            format: "float",
            description: "Rate in USD per minute",
            example: 0.5,
          },
          totalSessions: {
            type: "integer",
            description: "Total completed sessions",
            example: 42,
          },
          averageRating: {
            type: "number",
            format: "float",
            description: "Average rating from 1-5",
            example: 4.5,
          },
          bioAnonymous: {
            type: "string",
            description: "Anonymous bio (no identifying info)",
            example: "I'm here to listen and support you",
          },
          specialties: {
            type: "array",
            items: {
              type: "string",
            },
            example: ["anxiety", "relationships", "stress"],
          },
        },
      },
      Conversation: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Conversation ID",
          },
          status: {
            type: "string",
            enum: ["pending", "active", "ended", "declined"],
            description: "Conversation status",
          },
          otherParticipant: {
            $ref: "#/components/schemas/AnonymousIdentity",
          },
          ratePerMinute: {
            type: "number",
            format: "float",
            example: 0.5,
          },
          durationMinutes: {
            type: "integer",
            example: 15,
          },
          totalCost: {
            type: "number",
            format: "float",
            example: 7.5,
          },
          createdAt: {
            type: "string",
            format: "date-time",
          },
          startedAt: {
            type: "string",
            format: "date-time",
          },
          endedAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      Message: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
          },
          content: {
            type: "string",
            example: "Hello, how can I help?",
          },
          sender: {
            allOf: [
              { $ref: "#/components/schemas/AnonymousIdentity" },
              {
                type: "object",
                properties: {
                  isMe: {
                    type: "boolean",
                  },
                },
              },
            ],
          },
          deliveredAt: {
            type: "string",
            format: "date-time",
          },
          readAt: {
            type: "string",
            format: "date-time",
          },
          createdAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      VoiceCall: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
          },
          status: {
            type: "string",
            enum: [
              "requesting",
              "ringing",
              "active",
              "ended",
              "declined",
              "cancelled",
            ],
          },
          otherParticipant: {
            $ref: "#/components/schemas/AnonymousIdentity",
          },
          roomName: {
            type: "string",
            description: "Twilio room name",
          },
          ratePerMinute: {
            type: "number",
            format: "float",
            example: 0.5,
          },
          durationSeconds: {
            type: "integer",
            example: 900,
          },
          totalCost: {
            type: "number",
            format: "float",
            example: 7.5,
          },
          createdAt: {
            type: "string",
            format: "date-time",
          },
          startedAt: {
            type: "string",
            format: "date-time",
          },
          endedAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      Review: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
          },
          sessionType: {
            type: "string",
            enum: ["call", "chat"],
          },
          sessionId: {
            type: "string",
            format: "uuid",
          },
          rating: {
            type: "integer",
            minimum: 1,
            maximum: 5,
            example: 5,
          },
          comment: {
            type: "string",
            example: "Very helpful session",
          },
          reviewer: {
            $ref: "#/components/schemas/AnonymousIdentity",
          },
          createdAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      ListenerEarnings: {
        type: "object",
        properties: {
          totalEarnings: {
            type: "number",
            format: "float",
            example: 125.5,
          },
          pendingBalance: {
            type: "number",
            format: "float",
            example: 75.0,
          },
          paidOut: {
            type: "number",
            format: "float",
            example: 50.5,
          },
          sessionCount: {
            type: "integer",
            example: 15,
          },
        },
      },
      Tokens: {
        type: "object",
        properties: {
          accessToken: {
            type: "string",
            description: "JWT access token (expires in 7 days)",
          },
          refreshToken: {
            type: "string",
            description: "JWT refresh token (expires in 30 days)",
          },
        },
      },
      Review: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Review unique identifier",
          },
          sessionType: {
            type: "string",
            enum: ["call", "chat"],
            description: "Type of session reviewed",
          },
          sessionId: {
            type: "string",
            format: "uuid",
            description: "Session ID that was reviewed",
          },
          reviewerId: {
            type: "string",
            format: "uuid",
            description: "ID of user who submitted the review",
          },
          revieweeId: {
            type: "string",
            format: "uuid",
            description: "ID of user who received the review",
          },
          rating: {
            type: "integer",
            minimum: 1,
            maximum: 5,
            description: "Rating from 1 to 5 stars",
            example: 5,
          },
          comment: {
            type: "string",
            description: "Optional review comment",
            example: "Great listener, very helpful!",
          },
          createdAt: {
            type: "string",
            format: "date-time",
            description: "Review submission timestamp",
          },
        },
      },
      Report: {
        type: "object",
        properties: {
          id: {
            type: "string",
            format: "uuid",
            description: "Report unique identifier",
          },
          reporterId: {
            type: "string",
            format: "uuid",
            description: "ID of user who submitted the report",
          },
          reportedId: {
            type: "string",
            format: "uuid",
            description: "ID of user being reported",
          },
          sessionType: {
            type: "string",
            enum: ["call", "chat"],
            description: "Type of session (if applicable)",
          },
          sessionId: {
            type: "string",
            format: "uuid",
            description: "Session ID where the incident occurred",
          },
          sessionVenterId: {
            type: "string",
            format: "uuid",
            description: "Resolved venter ID from the linked session",
          },
          sessionListenerId: {
            type: "string",
            format: "uuid",
            description: "Resolved listener ID from the linked session",
          },
          reason: {
            type: "string",
            enum: [
              "disruptive_behavior",
              "bullying_or_harassment",
              "danger_to_self_or_others",
              "inappropriate_or_unsafe_response",
            ],
            description: "Reason for report",
            example: "bullying_or_harassment",
          },
          description: {
            type: "string",
            description: "Detailed description of the incident",
          },
          status: {
            type: "string",
            enum: ["pending", "reviewing", "resolved", "dismissed"],
            description: "Current status of the report",
            example: "pending",
          },
          adminNotes: {
            type: "string",
            description: "Admin notes (admin only)",
          },
          reviewedBy: {
            type: "string",
            format: "uuid",
            description: "ID of admin who reviewed the report",
          },
          reviewedAt: {
            type: "string",
            format: "date-time",
            description: "Timestamp when report was reviewed",
          },
          createdAt: {
            type: "string",
            format: "date-time",
            description: "Report submission timestamp",
          },
        },
      },
      Pagination: {
        type: "object",
        properties: {
          limit: {
            type: "integer",
            description: "Number of items per page",
            example: 20,
          },
          offset: {
            type: "integer",
            description: "Number of items to skip",
            example: 0,
          },
          total: {
            type: "integer",
            description: "Total number of items",
            example: 100,
          },
        },
      },
      Error: {
        type: "object",
        properties: {
          error: {
            type: "string",
            description: "Error message",
          },
        },
      },
      AuthTokenExpiredError: {
        type: "object",
        properties: {
          success: {
            type: "boolean",
            example: false,
          },
          error_type: {
            type: "string",
            example: "token_expired",
          },
          message: {
            type: "string",
            example: "Authentication token has expired",
          },
          action_required: {
            type: "string",
            example: "refresh_token",
          },
        },
      },
      TwoFactorAuthentication: {
        type: "object",
        properties: {
          enabled: { type: "boolean", example: true },
          method: {
            type: "string",
            nullable: true,
            enum: ["sms", "email", "authenticator_app"],
            example: "authenticator_app",
          },
        },
      },
      Success: {
        type: "object",
        properties: {
          message: {
            type: "string",
            description: "Success message",
          },
        },
      },
    },
  },
  tags: [
    {
      name: "Authentication",
      description: "User authentication and account management endpoints",
    },
    {
      name: "Wallet",
      description: "Wallet balance and transaction management endpoints",
    },
    {
      name: "Payments",
      description: "Payment processing and wallet recharge endpoints",
    },
    {
      name: "Notifications",
      description:
        "Push notification management via Firebase Cloud Messaging (FCM)",
    },
    {
      name: "Mood",
      description: "Daily mood logging and tracking for venter profiles",
    },
    {
      name: "Reflections",
      description:
        "Daily reflection entries linked to moods for venter profiles",
    },
    {
      name: "Sobriety",
      description: "Sobriety streak tracking and event timeline for venters",
    },
    {
      name: "Home",
      description:
        "Venter home summary endpoints for progress, achievements, and recent entries",
    },
    {
      name: "Availability",
      description: "Listener availability and presence management",
    },
    {
      name: "Chat",
      description: "Anonymous text chat between venters and listeners",
    },
    {
      name: "Calls",
      description: "Anonymous voice calls via Twilio Programmable Voice",
    },
    {
      name: "Crisis",
      description:
        "Crisis escalation events for chat/call sessions and safety analytics",
    },
    {
      name: "Earnings",
      description: "Listener earnings and payout management",
    },
    {
      name: "Reviews",
      description: "Anonymous session reviews and ratings",
    },
    {
      name: "Reports",
      description: "User reporting and moderation system",
    },
    {
      name: "Listener Verification",
      description: "Listener verification document upload and review flows",
    },
    {
      name: "Support",
      description: "User support endpoints for appeals and feedback",
    },
    {
      name: "Blocking",
      description: "User blocking functionality",
    },
    {
      name: "Admin",
      description:
        "Administrative endpoints (admin and permissioned sub-admin)",
    },
    {
      name: "Sub Admin Management",
      description: "Admin-managed sub-admin account and permission lifecycle",
    },
    {
      name: "System",
      description: "System health and monitoring endpoints",
    },
    {
      name: "Webhooks",
      description:
        "External webhook endpoints for Stripe and Twilio integrations",
    },
  ],
  // Import paths from centralized file
  paths: swaggerPaths.paths,
};

module.exports = swaggerSpec;
