/**
 * Centralized OpenAPI/Swagger API definitions
 * This file contains all API path definitions instead of using annotations in route files
 */

module.exports = {
  paths: {
    // ============ Authentication Endpoints ============
    "/api/v1/auth/register": {
      post: {
        tags: ["Authentication"],
        summary: "Register a new user account",
        description:
          "Create a new venter or listener account with email, password, and phone number. Admin accounts cannot be created via signup.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "password", "userType", "phone"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                  },
                  password: {
                    type: "string",
                    format: "password",
                    minLength: 8,
                    example: "SecurePass123!",
                    description:
                      "Must contain uppercase, lowercase, number, and special character",
                  },
                  userType: {
                    type: "string",
                    enum: ["venter", "listener"],
                    example: "venter",
                  },
                  phone: {
                    type: "string",
                    example: "+1234567890",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "User registered successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    user: { $ref: "#/components/schemas/User" },
                    tokens: {
                      allOf: [
                        { $ref: "#/components/schemas/Tokens" },
                        {
                          type: "object",
                          properties: {
                            verificationToken: {
                              type: "string",
                              description: "Email verification token",
                            },
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid input or user already exists",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/login": {
      post: {
        tags: ["Authentication"],
        summary: "Login to existing account",
        description:
          "Authenticate user with email and password, returns JWT tokens",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "password"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                  },
                  password: {
                    type: "string",
                    format: "password",
                    example: "SecurePass123!",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Login successful",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    user: { $ref: "#/components/schemas/User" },
                    tokens: { $ref: "#/components/schemas/Tokens" },
                  },
                },
              },
            },
          },
          401: {
            description: "Invalid credentials",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/google-login": {
      post: {
        tags: ["Authentication"],
        summary: "Login or register with Google OAuth",
        description:
          "Authenticate user using Google ID token. Creates new account if user doesn't exist, or logs in existing user. Google accounts are automatically verified.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["idToken", "userType"],
                properties: {
                  idToken: {
                    type: "string",
                    description: "Google ID token obtained from Google Sign-In",
                    example: "eyJhbGciOiJSUzI1NiIsImtpZCI6IjFlOWdkazcifQ...",
                  },
                  userType: {
                    type: "string",
                    enum: ["venter", "listener"],
                    example: "venter",
                    description:
                      "User type (only required for new registrations)",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Google authentication successful",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Login successful via Google",
                    },
                    user: {
                      allOf: [
                        { $ref: "#/components/schemas/User" },
                        {
                          type: "object",
                          properties: {
                            isVerified: {
                              type: "boolean",
                              example: true,
                              description: "Always true for Google OAuth users",
                            },
                          },
                        },
                      ],
                    },
                    tokens: { $ref: "#/components/schemas/Tokens" },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid request or unverified Google email",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  missingToken: {
                    value: {
                      error: "Missing token",
                      message: "Google ID token is required",
                    },
                  },
                  invalidUserType: {
                    value: {
                      error: "Invalid user type",
                      message:
                        'User type must be either "venter" or "listener"',
                    },
                  },
                  unverifiedEmail: {
                    value: {
                      error: "Email not verified",
                      message: "Please use a verified Google account",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Invalid Google ID token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "Invalid token",
                  message: "Failed to verify Google ID token",
                },
              },
            },
          },
          403: {
            description: "Account disabled",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          503: {
            description: "Google OAuth not configured",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "Service unavailable",
                  message: "Google login is not configured on this server",
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/apple-login": {
      post: {
        tags: ["Authentication"],
        summary: "Login or register with Apple Sign-In",
        description:
          "Authenticate user using an Apple identity token. Creates a new account if the user doesn't exist, or logs in an existing user. Apple accounts are automatically marked as verified. The `user` object (name/email) is only provided by Apple on the very first login.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["identityToken", "userType"],
                properties: {
                  identityToken: {
                    type: "string",
                    description:
                      "Apple identity token (JWT) obtained from Apple Sign-In",
                    example: "eyJraWQiOiJBSURPUEsxIiwiYWxnIjoiUlMyNTYifQ...",
                  },
                  userType: {
                    type: "string",
                    enum: ["venter", "listener"],
                    example: "venter",
                    description:
                      "User type (only required for new registrations)",
                  },
                  user: {
                    type: "object",
                    description:
                      "User info provided by Apple on first login only",
                    properties: {
                      name: {
                        type: "object",
                        properties: {
                          firstName: { type: "string", example: "Jane" },
                          lastName: { type: "string", example: "Doe" },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Apple authentication successful",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Login successful",
                    },
                    user: {
                      allOf: [
                        { $ref: "#/components/schemas/User" },
                        {
                          type: "object",
                          properties: {
                            isVerified: {
                              type: "boolean",
                              example: true,
                              description: "Always true for Apple Sign-In users",
                            },
                          },
                        },
                      ],
                    },
                    tokens: { $ref: "#/components/schemas/Tokens" },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid request or missing email",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  missingToken: {
                    value: {
                      error: "Missing token",
                      message: "Apple identity token is required",
                    },
                  },
                  invalidUserType: {
                    value: {
                      error: "Invalid user type",
                      message: 'User type must be either "venter" or "listener"',
                    },
                  },
                  emailRequired: {
                    value: {
                      error: "Email required",
                      message:
                        "Email address is required to create an account. Please allow email access in your Apple Sign-In settings.",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Invalid Apple identity token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "Invalid token",
                  message: "Failed to verify Apple identity token",
                },
              },
            },
          },
          403: {
            description: "Account disabled",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          503: {
            description: "Apple Sign-In not configured",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "Service unavailable",
                  message: "Apple login is not configured on this server",
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/profile": {
      get: {
        tags: ["Authentication"],
        summary: "Get user profile",
        description:
          "Retrieve authenticated user's profile information including wallet balance",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Profile retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        phone: { type: "string", nullable: true },
                        firstName: { type: "string", nullable: true },
                        lastName: { type: "string", nullable: true },
                        displayName: { type: "string", nullable: true },
                        listenerSignature: { type: "string", nullable: true },
                        verificationDocumentStatus: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "not_submitted",
                            "pending",
                            "approved",
                            "rejected",
                          ],
                        },
                        verificationStatus: {
                          type: "string",
                          nullable: true,
                          description:
                            "Listener verification status (mirrors verificationDocumentStatus). null for non-listeners.",
                          enum: [
                            "not_submitted",
                            "pending",
                            "approved",
                            "rejected",
                          ],
                        },
                        profilePictureUrl: {
                          type: "string",
                          format: "uri",
                          nullable: true,
                        },
                        bio: { type: "string", nullable: true },
                        dateOfBirth: {
                          type: "string",
                          format: "date",
                          nullable: true,
                        },
                        userType: {
                          type: "string",
                          enum: ["venter", "listener"],
                        },
                        isVerified: { type: "boolean" },
                        isActive: { type: "boolean" },
                        createdAt: { type: "string", format: "date-time" },
                        updatedAt: { type: "string", format: "date-time" },
                      },
                    },
                    security: {
                      type: "object",
                      properties: {
                        twoFactorAuthentication: {
                          $ref: "#/components/schemas/TwoFactorAuthentication",
                        },
                      },
                    },
                    preferences: {
                      type: "object",
                      properties: {
                        genderIdentity: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "Man",
                            "Woman",
                            "Non-binary",
                            "Gender non-conforming",
                            "Questioning",
                            "Prefer not to say",
                          ],
                        },
                        culturalBackground: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "Black",
                            "White",
                            "Asian",
                            "Native Indian",
                            "Pacific Islander",
                            "Middle Eastern",
                            "North African",
                            "Multiracial",
                            "Other",
                          ],
                        },
                        ethnicity: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "African Diaspora",
                            "Caribbean",
                            "North African",
                            "Hispanic",
                            "Pacific Islander",
                            "Middle Eastern",
                            "Asian",
                            "Indigenous",
                            "European",
                            "Multiple",
                            "Other",
                            "Prefer not to say",
                          ],
                        },
                        ageGroup: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "18-24",
                            "25-34",
                            "35-44",
                            "45-54",
                            "55-64",
                            "65+",
                            "Prefer not to say",
                          ],
                        },
                        lgbtqIdentity: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "Gay",
                            "Lesbian",
                            "Bisexual",
                            "Pansexual",
                            "Asexual",
                            "Queer",
                            "Questioning",
                            "Straight/Heterosexual",
                            "Prefer not to say",
                          ],
                        },
                        specialTopics: {
                          type: "array",
                          items: {
                            type: "string",
                            enum: [
                              "Mental Health",
                              "Life & Identity",
                              "Relationships",
                              "Work & Money",
                              "Health & Medical",
                              "Work & Finances",
                            ],
                          },
                        },
                        faithOrBelief: {
                          type: "string",
                          nullable: true,
                          enum: [
                            "Christian",
                            "Muslim",
                            "Sikh",
                            "Hindu",
                            "Buddhist",
                            "Jewish",
                            "No religion",
                            "Spiritual (not religious)",
                            "Other",
                          ],
                        },
                        preferredLanguage: {
                          type: "string",
                          default: "en",
                          enum: [
                            "en",
                            "pt",
                            "es",
                            "fr",
                            "it",
                            "de",
                            "nl",
                            "ar",
                            "zh",
                            "ja",
                            "ko",
                            "hi",
                          ],
                        },
                      },
                    },
                    wallet: {
                      type: "object",
                      properties: {
                        balanceMinutes: { type: "number" },
                        balanceCurrency: { type: "number" },
                        autoRechargeEnabled: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          404: {
            description: "Profile not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Authentication"],
        summary: "Update user profile",
        description:
          "Update authenticated user's profile information. All fields are optional.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  firstName: {
                    type: "string",
                    maxLength: 100,
                    example: "John",
                    description: "User's first name",
                  },
                  lastName: {
                    type: "string",
                    maxLength: 100,
                    example: "Doe",
                    description: "User's last name",
                  },
                  displayName: {
                    type: "string",
                    maxLength: 200,
                    example: "JohnD",
                    description: "Public display name",
                  },
                  phone: {
                    type: "string",
                    pattern: "^\\+?[1-9]\\d{1,14}$",
                    example: "+1234567890",
                    description: "Phone number in E.164 format",
                  },
                  profilePictureUrl: {
                    type: "string",
                    format: "uri",
                    example: "https://example.com/profile.jpg",
                    description: "URL to profile picture",
                  },
                  bio: {
                    type: "string",
                    maxLength: 500,
                    example: "Passionate listener with 5 years of experience",
                    description: "User biography or description",
                  },
                  dateOfBirth: {
                    type: "string",
                    format: "date",
                    example: "1990-01-15",
                    description:
                      "Date of birth (must be at least 13 years old)",
                  },
                  genderIdentity: {
                    type: "string",
                    enum: [
                      "Man",
                      "Woman",
                      "Non-binary",
                      "Gender non-conforming",
                      "Questioning",
                      "Prefer not to say",
                    ],
                    example: "Non-binary",
                    description: "User's gender identity",
                  },
                  culturalBackground: {
                    type: "string",
                    enum: [
                      "Black",
                      "White",
                      "Asian",
                      "Native Indian",
                      "Pacific Islander",
                      "Middle Eastern",
                      "North African",
                      "Multiracial",
                      "Other",
                    ],
                    example: "Asian",
                    description: "User's cultural or racial background",
                  },
                  ethnicity: {
                    type: "string",
                    enum: [
                      "African Diaspora",
                      "Caribbean",
                      "North African",
                      "Hispanic",
                      "Pacific Islander",
                      "Middle Eastern",
                      "Asian",
                      "Indigenous",
                      "European",
                      "Multiple",
                      "Other",
                      "Prefer not to say",
                    ],
                    example: "Asian",
                    description: "User's ethnicity",
                  },
                  ageGroup: {
                    type: "string",
                    enum: [
                      "18-24",
                      "25-34",
                      "35-44",
                      "45-54",
                      "55-64",
                      "65+",
                      "Prefer not to say",
                    ],
                    example: "25-34",
                    description: "User's age range",
                  },
                  lgbtqIdentity: {
                    type: "string",
                    enum: [
                      "Gay",
                      "Lesbian",
                      "Bisexual",
                      "Pansexual",
                      "Asexual",
                      "Queer",
                      "Questioning",
                      "Straight/Heterosexual",
                      "Prefer not to say",
                    ],
                    example: "Bisexual",
                    description: "User's LGBTQ+ identity",
                  },
                  specialTopics: {
                    type: "array",
                    items: {
                      type: "string",
                      enum: [
                        "Mental Health",
                        "Life & Identity",
                        "Relationships",
                        "Work & Money",
                        "Health & Medical",
                        "Work & Finances",
                      ],
                    },
                    example: ["Mental Health", "Relationships"],
                    description: "Topics user is interested in discussing",
                  },
                  faithOrBelief: {
                    type: "string",
                    enum: [
                      "Christian",
                      "Muslim",
                      "Sikh",
                      "Hindu",
                      "Buddhist",
                      "Jewish",
                      "No religion",
                      "Spiritual (not religious)",
                      "Other",
                    ],
                    example: "Buddhist",
                    description: "User's faith or belief system",
                  },
                  preferredLanguage: {
                    type: "string",
                    enum: [
                      "en",
                      "pt",
                      "es",
                      "fr",
                      "it",
                      "de",
                      "nl",
                      "ar",
                      "zh",
                      "ja",
                      "ko",
                      "hi",
                    ],
                    example: "en",
                    description: "User's preferred language code (ISO 639-1)",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Profile updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Profile updated successfully",
                    },
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        phone: { type: "string", nullable: true },
                        firstName: { type: "string", nullable: true },
                        lastName: { type: "string", nullable: true },
                        displayName: { type: "string", nullable: true },
                        profilePictureUrl: {
                          type: "string",
                          format: "uri",
                          nullable: true,
                        },
                        bio: { type: "string", nullable: true },
                        dateOfBirth: {
                          type: "string",
                          format: "date",
                          nullable: true,
                        },
                        userType: {
                          type: "string",
                          enum: ["venter", "listener"],
                        },
                        isVerified: { type: "boolean" },
                        isActive: { type: "boolean" },
                        createdAt: { type: "string", format: "date-time" },
                        updatedAt: { type: "string", format: "date-time" },
                      },
                    },
                    preferences: {
                      type: "object",
                      properties: {
                        genderIdentity: { type: "string", nullable: true },
                        culturalBackground: { type: "string", nullable: true },
                        ethnicity: { type: "string", nullable: true },
                        ageGroup: { type: "string", nullable: true },
                        lgbtqIdentity: { type: "string", nullable: true },
                        specialTopics: {
                          type: "array",
                          items: { type: "string" },
                        },
                        faithOrBelief: { type: "string", nullable: true },
                        preferredLanguage: { type: "string" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid input data",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  invalidFirstName: {
                    value: {
                      error: "Invalid first name",
                      message: "First name must be 100 characters or less",
                    },
                  },
                  invalidPhone: {
                    value: {
                      error: "Invalid phone number",
                      message:
                        "Please provide a valid phone number in E.164 format",
                    },
                  },
                  invalidAge: {
                    value: {
                      error: "Invalid date of birth",
                      message:
                        "You must be at least 13 years old to use this service",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Profile not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/security/2fa": {
      get: {
        tags: ["Authentication"],
        summary: "Get two-factor authentication settings",
        description: "Get the authenticated user's 2FA configuration",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "2FA settings retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    twoFactorAuthentication: {
                      $ref: "#/components/schemas/TwoFactorAuthentication",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Authentication"],
        summary: "Update two-factor authentication settings",
        description:
          "Enable or disable 2FA and choose a single active method (sms, email, authenticator_app)",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["enabled"],
                properties: {
                  enabled: { type: "boolean", example: true },
                  method: {
                    type: "string",
                    enum: ["sms", "email", "authenticator_app"],
                    nullable: true,
                    example: "email",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "2FA settings updated successfully",
          },
          400: { description: "Validation error" },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/refresh-token": {
      post: {
        tags: ["Authentication"],
        summary: "Refresh access token",
        description: "Get a new access token using refresh token",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["refreshToken"],
                properties: {
                  refreshToken: {
                    type: "string",
                    description: "Valid refresh token",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Token refreshed successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    accessToken: { type: "string" },
                  },
                },
              },
            },
          },
          401: {
            description: "Invalid or expired refresh token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/verify-email": {
      post: {
        tags: ["Authentication"],
        summary: "Verify email address with OTP",
        description:
          "Verify user email address with a 4-digit OTP. Accepts any active (unexpired, unconsumed) OTP previously issued to this user for the email_verification flow — older OTPs continue working even after a resend.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "otp"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                    description: "User's email address",
                  },
                  otp: {
                    type: "string",
                    pattern: "^[0-9]{4}$",
                    example: "1234",
                    description: "4-digit verification code",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Email verified successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Email verified successfully",
                    },
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string" },
                        email: { type: "string" },
                        isVerified: { type: "boolean", example: true },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid OTP, expired code, or validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  invalidOTP: {
                    value: {
                      error: "Invalid OTP",
                      message:
                        "Incorrect verification code. 4 attempts remaining.",
                    },
                  },
                  expiredOTP: {
                    value: {
                      error: "OTP expired",
                      message:
                        "Verification code has expired. Please request a new one.",
                    },
                  },
                  tooManyAttempts: {
                    value: {
                      error: "Too many attempts",
                      message:
                        "Maximum verification attempts exceeded. Please request a new code.",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/auth/resend-verification": {
      post: {
        tags: ["Authentication"],
        summary: "Resend verification email",
        description:
          "Issue an additional 4-digit verification OTP. Each OTP is valid for 2 hours from its own creation timestamp. Resending does NOT invalidate previously issued OTPs — multiple active OTPs may coexist for the same account and any one of them will verify the email successfully until it expires or is consumed.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                    description: "Email address to send verification link to",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description:
              "Verification email sent (if email exists and is unverified)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example:
                        "If the email exists and is not verified, a verification link has been sent",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid input",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/request-password-reset": {
      post: {
        tags: ["Authentication"],
        summary: "Request password reset",
        description:
          "Send a 4-digit password reset OTP to the user's email. Each OTP is valid for 2 hours. Calling this endpoint repeatedly issues additional OTPs without invalidating previous unexpired ones — any active reset OTP for the account is acceptable until it expires or is consumed.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                    description: "User's email address",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Password reset code sent",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example:
                        "If the email exists, a password reset code has been sent",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/reset-password": {
      post: {
        tags: ["Authentication"],
        summary: "Reset password with OTP",
        description:
          "Reset the account password using any active (unexpired, unconsumed) password_reset OTP. A successful reset revokes all sibling reset OTPs for the account.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "otp", "newPassword"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                    description: "User's email address",
                  },
                  otp: {
                    type: "string",
                    pattern: "^[0-9]{4}$",
                    example: "5678",
                    description: "4-digit password reset code",
                  },
                  newPassword: {
                    type: "string",
                    format: "password",
                    minLength: 8,
                    example: "NewSecurePass123!",
                    description:
                      "Must contain uppercase, lowercase, number, and special character",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Password reset successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example:
                        "Password reset successfully. Please login with your new password.",
                    },
                  },
                },
              },
            },
          },
          400: {
            description:
              "Invalid OTP, expired code, or password requirements not met",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  invalidOTP: {
                    value: {
                      error: "Invalid OTP",
                      message: "Incorrect reset code. 3 attempts remaining.",
                    },
                  },
                  expiredOTP: {
                    value: {
                      error: "OTP expired",
                      message:
                        "Password reset code has expired. Please request a new one.",
                    },
                  },
                  weakPassword: {
                    value: {
                      error: "Weak password",
                      message:
                        "Password must contain at least 8 characters, including uppercase, lowercase, number, and special character.",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/change-password": {
      post: {
        tags: ["Authentication"],
        summary: "Change password",
        description:
          "Change authenticated user's password using current password verification",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["currentPassword", "newPassword"],
                properties: {
                  currentPassword: {
                    type: "string",
                    format: "password",
                    example: "CurrentSecurePass123!",
                    description: "User's current password",
                  },
                  newPassword: {
                    type: "string",
                    format: "password",
                    minLength: 8,
                    example: "NewSecurePass123!",
                    description:
                      "Must contain uppercase, lowercase, number, and special character",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Password changed successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example:
                        "Password changed successfully. Please login again.",
                    },
                  },
                },
              },
            },
          },
          400: {
            description:
              "Missing fields, weak password, or invalid new password",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized or invalid current password",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Internal server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/change-email/request-otp": {
      post: {
        tags: ["Authentication"],
        summary: "Request OTP to change email",
        description:
          "Send a 4-digit OTP to the proposed new email address. OTPs are valid for 2 hours and multiple may be active for the same account simultaneously; requesting another OTP does not invalidate prior ones — any active OTP for this user and new email will verify successfully.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["newEmail"],
                properties: {
                  newEmail: {
                    type: "string",
                    format: "email",
                    example: "new.email@example.com",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Verification code sent",
          },
          400: { description: "Missing or invalid email" },
          401: { description: "Unauthorized" },
          409: { description: "Email already in use" },
        },
      },
    },
    "/api/v1/auth/change-email/verify-otp": {
      post: {
        tags: ["Authentication"],
        summary: "Verify OTP and change email",
        description:
          "Apply an email change by submitting any active (unexpired, unconsumed) 4-digit OTP previously issued for this user and new email. The matched OTP is consumed; other active OTPs for the same change remain usable until they expire.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["newEmail", "otp"],
                properties: {
                  newEmail: {
                    type: "string",
                    format: "email",
                    example: "new.email@example.com",
                  },
                  otp: {
                    type: "string",
                    example: "1234",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Email updated successfully",
          },
          400: { description: "Invalid OTP, expired OTP, or missing request" },
          401: { description: "Unauthorized" },
          409: { description: "Email already in use" },
        },
      },
    },
    "/api/v1/auth/change-phone/request-otp": {
      post: {
        tags: ["Authentication"],
        summary: "Request OTP to change phone",
        description:
          "Send a 4-digit OTP via SMS to the proposed new phone number. OTPs are valid for 2 hours and multiple may be active simultaneously; repeated requests issue additional OTPs without invalidating prior ones.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["newPhone"],
                properties: {
                  newPhone: {
                    type: "string",
                    example: "+15551234567",
                    description: "Phone number in E.164 format",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Verification code sent",
          },
          400: { description: "Missing or invalid phone number" },
          401: { description: "Unauthorized" },
        },
      },
    },
    "/api/v1/auth/change-phone/verify-otp": {
      post: {
        tags: ["Authentication"],
        summary: "Verify OTP and change phone",
        description:
          "Apply a phone change by submitting any active (unexpired, unconsumed) 4-digit OTP previously issued for this user and new phone. The matched OTP is consumed; other active OTPs for the same change remain usable until they expire.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["newPhone", "otp"],
                properties: {
                  newPhone: {
                    type: "string",
                    example: "+15551234567",
                    description: "Phone number in E.164 format",
                  },
                  otp: {
                    type: "string",
                    example: "1234",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Phone number updated successfully",
          },
          400: { description: "Invalid OTP, expired OTP, or missing request" },
          401: { description: "Unauthorized" },
        },
      },
    },
    "/api/v1/auth/logout": {
      post: {
        tags: ["Authentication"],
        summary: "Logout user",
        description: "Invalidate user session and refresh token",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Logged out successfully",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Success" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/auth/account": {
      delete: {
        tags: ["Authentication"],
        summary: "Delete user account",
        description:
          "Permanently delete user account with password verification. This action cannot be undone and will remove all associated data including wallet, reviews, messages, and call history.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["password"],
                properties: {
                  password: {
                    type: "string",
                    description: "User's current password for verification",
                    example: "MySecurePassword123!",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Account deleted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Account deleted successfully",
                    },
                    email: {
                      type: "string",
                      example: "user@example.com",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Bad request - Missing password",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid password or token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Internal server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Biometric Authentication Endpoints ============
    "/api/v1/auth/biometric/register": {
      post: {
        tags: ["Authentication", "Biometric"],
        summary: "Register biometric authentication (Face ID / Fingerprint)",
        description:
          "Register Face ID or Fingerprint authentication for the authenticated user. The mobile app should generate a public/private key pair and send the public key along with device information.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["publicKey", "deviceId"],
                properties: {
                  publicKey: {
                    type: "string",
                    description:
                      "Base64 encoded public key generated by the mobile device",
                    example: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...",
                  },
                  deviceId: {
                    type: "string",
                    description: "Unique device identifier",
                    example: "iPhone12,1_A1B2C3D4E5F6",
                  },
                  deviceName: {
                    type: "string",
                    description: "Human-readable device name (optional)",
                    example: "iPhone 13 Pro",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Biometric authentication registered successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example:
                        "Biometric authentication registered successfully",
                    },
                    biometric: {
                      type: "object",
                      properties: {
                        enabled: { type: "boolean", example: true },
                        deviceName: {
                          type: "string",
                          example: "iPhone 13 Pro",
                        },
                        registeredAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-01-30T12:00:00.000Z",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid input data",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  invalidPublicKey: {
                    value: {
                      error: "Invalid public key",
                      message:
                        "Public key must be a valid base64 encoded string",
                    },
                  },
                  invalidDeviceId: {
                    value: {
                      error: "Invalid device ID",
                      message:
                        "Device ID must be between 10 and 255 characters",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - valid JWT token required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/biometric/login": {
      post: {
        tags: ["Authentication", "Biometric"],
        summary: "Login with biometric authentication",
        description:
          "Authenticate user using Face ID or Fingerprint. The mobile app must sign a challenge with the private key and send the signature for verification.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "deviceId", "challenge", "signature"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "user@example.com",
                    description: "User's email address",
                  },
                  deviceId: {
                    type: "string",
                    description: "Device ID used during biometric registration",
                    example: "iPhone12,1_A1B2C3D4E5F6",
                  },
                  challenge: {
                    type: "string",
                    description:
                      "Random challenge string (should be a timestamp or nonce)",
                    example: "1706616000000",
                  },
                  signature: {
                    type: "string",
                    description:
                      "Base64 encoded signature of the challenge signed with device private key",
                    example: "SGVsbG8gV29ybGQhIFRoaXMgaXMgYSBzaWduYXR1cmU=",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Biometric login successful",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Login successful",
                    },
                    user: { $ref: "#/components/schemas/User" },
                    tokens: { $ref: "#/components/schemas/Tokens" },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid input data",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  missingFields: {
                    value: {
                      error: "Missing required fields",
                      message:
                        "Device ID, signature, challenge, and email are required",
                    },
                  },
                  invalidSignature: {
                    value: {
                      error: "Invalid signature",
                      message:
                        "Signature must be a valid base64 encoded string",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Authentication failed",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  notRegistered: {
                    value: {
                      error: "Invalid credentials",
                      message: "Email or password is incorrect",
                    },
                  },
                },
              },
            },
          },
          403: {
            description: "Account disabled",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/biometric/disable": {
      post: {
        tags: ["Authentication", "Biometric"],
        summary: "Disable biometric authentication",
        description:
          "Disable Face ID / Fingerprint authentication for the authenticated user",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Biometric authentication disabled successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Biometric authentication disabled successfully",
                    },
                    biometric: {
                      type: "object",
                      properties: {
                        enabled: { type: "boolean", example: false },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - valid JWT token required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/auth/biometric/status": {
      get: {
        tags: ["Authentication", "Biometric"],
        summary: "Get biometric authentication status",
        description:
          "Check if biometric authentication is enabled and get device information",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Biometric status retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    biometric: {
                      type: "object",
                      properties: {
                        enabled: {
                          type: "boolean",
                          example: true,
                          description:
                            "Whether biometric authentication is enabled",
                        },
                        deviceName: {
                          type: "string",
                          example: "iPhone 13 Pro",
                          nullable: true,
                          description: "Name of registered device",
                        },
                        registeredAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-01-30T12:00:00.000Z",
                          nullable: true,
                          description: "When biometric auth was registered",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - valid JWT token required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Wallet Endpoints ============
    "/api/v1/wallet/balance": {
      get: {
        tags: ["Wallet"],
        summary: "Get wallet balance",
        description:
          "Retrieve authenticated user's wallet balance and auto-recharge settings",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Wallet information retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    balance: {
                      type: "object",
                      properties: {
                        minutes: { type: "number", example: 120.5 },
                        currency: { type: "number", example: 50.0 },
                        currencyCode: { type: "string", example: "USD" },
                      },
                    },
                    autoRecharge: {
                      type: "object",
                      properties: {
                        enabled: { type: "boolean", example: true },
                        threshold: { type: "number", example: 10 },
                        amount: { type: "number", example: 20.0 },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Wallet not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/wallet/transactions": {
      get: {
        tags: ["Wallet"],
        summary: "Get transaction history",
        description: "Retrieve user's transaction history with pagination",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "limit",
            schema: { type: "integer", default: 50 },
            description: "Number of transactions to return",
          },
          {
            in: "query",
            name: "offset",
            schema: { type: "integer", default: 0 },
            description: "Number of transactions to skip",
          },
        ],
        responses: {
          200: {
            description: "Transactions retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    transactions: {
                      type: "array",
                      items: { $ref: "#/components/schemas/Transaction" },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer" },
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/wallet/subscription": {
      get: {
        tags: ["Wallet"],
        summary: "Get subscription status",
        description: "Retrieve user's active subscription details",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Subscription information retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    hasSubscription: { type: "boolean" },
                    message: { type: "string" },
                    subscription: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        planName: { type: "string", example: "Premium" },
                        status: { type: "string", example: "active" },
                        includedMinutes: { type: "integer", example: 300 },
                        usedMinutes: { type: "number", example: 45.5 },
                        remainingMinutes: { type: "number", example: 254.5 },
                        overageRate: { type: "number", example: 0.25 },
                        billingCycleStart: { type: "string", format: "date" },
                        billingCycleEnd: { type: "string", format: "date" },
                        monthlyPrice: { type: "number", example: 29.99 },
                        features: { type: "object" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/wallet/auto-recharge": {
      put: {
        tags: ["Wallet"],
        summary: "Update auto-recharge settings",
        description:
          "Configure automatic wallet recharge when balance falls below threshold",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["enabled"],
                properties: {
                  enabled: { type: "boolean", example: true },
                  threshold: {
                    type: "number",
                    example: 10,
                    description: "Required if enabled=true",
                  },
                  amount: {
                    type: "number",
                    example: 20.0,
                    description: "Required if enabled=true",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Auto-recharge settings updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    autoRecharge: {
                      type: "object",
                      properties: {
                        enabled: { type: "boolean" },
                        threshold: { type: "number" },
                        amount: { type: "number" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Bad request - missing required fields",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - email not verified",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Wallet not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Payment Endpoints ============
    "/api/v1/payments/credit-packs": {
      get: {
        tags: ["Payments"],
        summary: "Get available credit packs",
        description:
          "Retrieve all available prepaid credit packages for purchasing calling minutes",
        responses: {
          200: {
            description: "Credit packs retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    packs: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: {
                            type: "string",
                            example: "voice_top_up",
                            description: "Pack identifier",
                          },
                          name: {
                            type: "string",
                            example: "Voice Top-Up",
                          },
                          minutes: {
                            type: "integer",
                            example: 15,
                            description: "Number of minutes included",
                          },
                          price: {
                            type: "number",
                            example: 19.99,
                            description: "Price in USD",
                          },
                          pricePerMinute: {
                            type: ["string", "null"],
                            example: "1.333",
                            description:
                              "Price per minute when minutes are included; null for message-only packs",
                          },
                          included_minutes: {
                            type: "integer",
                            nullable: true,
                            example: 15,
                            description:
                              "Optional included voice minutes for this pack",
                          },
                          included_messages: {
                            type: "integer",
                            nullable: true,
                            example: null,
                            description:
                              "Optional included text messages for this pack",
                          },
                          description: {
                            type: "string",
                            example: "Extend your call",
                            description: "Human-readable pack details",
                          },
                        },
                      },
                    },
                  },
                },
                example: {
                  packs: [
                    {
                      id: "voice_top_up",
                      name: "Voice Top-Up",
                      minutes: 15,
                      price: 19.99,
                      pricePerMinute: "1.333",
                      included_minutes: 15,
                      included_messages: null,
                      description: "Extend your call",
                    },
                    {
                      id: "text_top_up",
                      name: "Text Top-Up",
                      minutes: 0,
                      price: 14.99,
                      pricePerMinute: null,
                      included_minutes: null,
                      included_messages: 50,
                      description: "Continue your conversation",
                    },
                    {
                      id: "support_boost",
                      name: "Support Boost",
                      minutes: 30,
                      price: 34.99,
                      pricePerMinute: "1.166",
                      included_minutes: 30,
                      included_messages: 50,
                      description: "Extra time when you need it",
                    },
                  ],
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/payments/subscription-plans": {
      get: {
        tags: ["Payments"],
        summary: "Get subscription plans",
        description:
          "Retrieve all active subscription plans with billing fields and subscription-screen display copy",
        responses: {
          200: {
            description: "Subscription plans retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    plans: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: {
                            type: "string",
                            format: "uuid",
                            description: "Plan unique identifier",
                          },
                          name: {
                            type: "string",
                            example: "Light Support",
                            description: "Plan name",
                          },
                          price_monthly: {
                            type: "number",
                            example: 29.99,
                            description: "Monthly subscription price in USD",
                          },
                          included_minutes: {
                            type: "integer",
                            example: 30,
                            description: "Minutes included per month",
                          },
                          included_messages_monthly: {
                            type: "integer",
                            example: 150,
                            description: "Messages included per month",
                          },
                          overage_rate: {
                            type: "number",
                            example: 0.15,
                            description:
                              "Rate per minute for usage beyond included minutes",
                          },
                          trial_days: {
                            type: "integer",
                            example: 0,
                            description:
                              "Trial duration in days applied at checkout (if > 0)",
                          },
                          features: {
                            type: "object",
                            nullable: true,
                            description: "Additional plan features (JSON)",
                          },
                          is_active: {
                            type: "boolean",
                            example: true,
                          },
                          stripe_price_id: {
                            type: "string",
                            nullable: true,
                            description: "Stripe price ID for billing",
                          },
                          stripe_price_id_annual: {
                            type: "string",
                            nullable: true,
                            description:
                              "Stripe annual price ID for annual billing",
                          },
                          created_at: {
                            type: "string",
                            format: "date-time",
                          },
                          updated_at: {
                            type: "string",
                            format: "date-time",
                          },
                          display: {
                            type: "object",
                            description:
                              "Screen-ready labels and metadata for subscription plan cards",
                            properties: {
                              minuteText: {
                                type: "string",
                                example: "30 minutes",
                              },
                              annualPrice: {
                                type: "number",
                                example: 379,
                              },
                              annualPriceLabel: {
                                type: "string",
                                example: "$379 / year",
                              },
                              annualSavings: {
                                type: "number",
                                example: 83.98,
                              },
                              annualDiscountPercent: {
                                type: "integer",
                                example: 20,
                              },
                              includedMessagesText: {
                                type: "string",
                                example: "150 texts per month",
                              },
                              monthlyPriceLabel: {
                                type: "string",
                                example: "$34.99 / month",
                              },
                              overageText: {
                                type: "string",
                                example: "$0.10 per additional minute",
                              },
                              isMostPopular: {
                                type: "boolean",
                                example: false,
                              },
                              mostPopularBadge: {
                                type: "object",
                                nullable: true,
                                properties: {
                                  text: {
                                    type: "string",
                                    example: "Most Popular",
                                  },
                                  color: {
                                    type: "string",
                                    example: "pale_pink",
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                    screenCopy: {
                      type: "object",
                      description:
                        "Subscription screen copy and layout metadata for mobile UI",
                    },
                    catalogVersion: {
                      type: "string",
                      description:
                        "Version flag for mobile catalog compatibility",
                    },
                  },
                },
                example: {
                  catalogVersion: "2026-03-mobile-v3",
                  plans: [
                    {
                      id: "123e4567-e89b-12d3-a456-426614174000",
                      name: "Free Trial",
                      price_monthly: 0,
                      included_minutes: 10,
                      included_messages_monthly: 30,
                      overage_rate: 0.1,
                      trial_days: 0,
                      features: { emotional_wellness_tools: true },
                      is_active: true,
                      stripe_price_id: null,
                      created_at: "2024-01-01T00:00:00Z",
                      updated_at: "2024-01-01T00:00:00Z",
                    },
                    {
                      id: "223e4567-e89b-12d3-a456-426614174001",
                      name: "Light Support",
                      price_monthly: 34.99,
                      included_minutes: 30,
                      included_messages_monthly: 150,
                      overage_rate: 0.1,
                      trial_days: 0,
                      features: { emotional_wellness_tools: true },
                      is_active: true,
                      stripe_price_id: "price_0987654321",
                      created_at: "2024-01-01T00:00:00Z",
                      updated_at: "2024-01-01T00:00:00Z",
                      display: {
                        minuteText: "30 minutes",
                        annualPrice: 379,
                        annualPriceLabel: "$379 / year",
                        monthlyPriceLabel: "$34.99 / month",
                        overageText: "$0.10 per additional minute",
                        isMostPopular: false,
                        mostPopularBadge: null,
                      },
                    },
                    {
                      id: "323e4567-e89b-12d3-a456-426614174002",
                      name: "Balanced Support",
                      price_monthly: 64.99,
                      included_minutes: 60,
                      included_messages_monthly: 300,
                      overage_rate: 0.1,
                      trial_days: 0,
                      features: { emotional_wellness_tools: true },
                      is_active: true,
                      stripe_price_id: "price_1234567890",
                      created_at: "2024-01-01T00:00:00Z",
                      updated_at: "2024-01-01T00:00:00Z",
                      display: {
                        minuteText: "60 minutes",
                        annualPrice: 699,
                        annualPriceLabel: "$699 / year",
                        monthlyPriceLabel: "$64.99 / month",
                        overageText: "$0.10 per additional minute",
                        isMostPopular: true,
                        mostPopularBadge: {
                          text: "Most Popular",
                          color: "pale_pink",
                        },
                      },
                    },
                  ],
                  screenCopy: {
                    header: {
                      title: "Choose Your Plan",
                      titleAlignment: "center",
                      backArrowAlignment: "left",
                    },
                    planToggle: {
                      defaultCycle: "annual",
                      tabs: [
                        {
                          id: "annual",
                          label: "Annual",
                          badge: {
                            text: "Save 20%",
                            color: "pale_pink",
                            textColor: "white",
                            shape: "pill",
                            size: "small",
                          },
                        },
                        {
                          id: "monthly",
                          label: "Monthly",
                        },
                      ],
                    },
                    promo: {
                      label: "Promo Code",
                      placeholder: "Add promo code",
                      size: "small",
                    },
                    advancedPlansLink: {
                      text: "See advanced plans",
                      placement: "below_plan_cards",
                      style: "subtle",
                    },
                    continueButton: {
                      color: "ventally_pink",
                      alignment: "center",
                      textOptions: [
                        "Continue to Secure Checkout",
                        "Start My Support Plan",
                      ],
                    },
                    trustText: "Cancel anytime. Conversations remain private.",
                    layoutOrder: [
                      "back_arrow",
                      "choose_your_plan",
                      "annual_monthly_toggle",
                      "plan_cards",
                      "see_advanced_plans",
                      "promo_code",
                      "continue_button",
                      "privacy_reassurance_text",
                    ],
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "Failed to fetch subscription plans",
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/payments/create-checkout-session": {
      post: {
        tags: ["Payments"],
        summary: "Create checkout session for credit pack",
        description:
          "Create a Stripe checkout session for purchasing prepaid credit minutes",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["packType"],
                properties: {
                  packType: {
                    type: "string",
                    enum: ["starter", "standard", "pro", "premium"],
                    example: "standard",
                    description: "Credit pack type to purchase",
                  },
                  customMinutes: {
                    type: "integer",
                    description: "Custom minutes for special offers (optional)",
                  },
                  customPrice: {
                    type: "number",
                    description: "Custom price in USD (optional)",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Checkout session created successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    sessionId: {
                      type: "string",
                      description: "Stripe checkout session ID",
                    },
                    url: {
                      type: "string",
                      format: "uri",
                      description: "Stripe checkout URL",
                    },
                    credits: {
                      type: "integer",
                      description: "Minutes included in purchase",
                    },
                    amount: {
                      type: "number",
                      description: "Total amount in USD",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid pack type",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/payments/create-subscription-checkout": {
      post: {
        tags: ["Payments"],
        summary: "Create checkout session for subscription",
        description:
          "Create a Stripe checkout session for subscribing to a monthly plan",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["planId"],
                properties: {
                  planId: {
                    type: "string",
                    format: "uuid",
                    description: "Subscription plan ID",
                  },
                  billingCycle: {
                    type: "string",
                    enum: ["monthly", "annual"],
                    description:
                      "Billing cycle for checkout. Defaults to monthly when omitted.",
                    example: "annual",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Subscription checkout session created successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    sessionId: {
                      type: "string",
                      description: "Stripe checkout session ID",
                    },
                    url: {
                      type: "string",
                      format: "uri",
                      description: "Stripe checkout URL",
                    },
                    planName: {
                      type: "string",
                      description: "Name of the subscription plan",
                    },
                    monthlyPrice: {
                      type: "number",
                      description: "Monthly price in USD",
                    },
                    includedMinutes: {
                      type: "integer",
                      description: "Minutes included per month",
                    },
                    includedMessages: {
                      type: "integer",
                      description: "Messages included per month",
                    },
                    annualPrice: {
                      type: "number",
                      description: "Annual price displayed for selected plan",
                    },
                    annualSavings: {
                      type: "number",
                      description: "Savings compared to monthly x 12",
                    },
                    billingCycle: {
                      type: "string",
                      enum: ["monthly", "annual"],
                      description: "Billing cycle used for this checkout",
                    },
                    catalogVersion: {
                      type: "string",
                      description:
                        "Version flag for mobile catalog compatibility",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid or missing plan ID",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Subscription plan not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/payments/verify-checkout": {
      get: {
        tags: ["Payments"],
        summary: "Verify checkout session",
        description:
          "Verify the status of a Stripe checkout session after payment completion",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "sessionId",
            required: true,
            schema: { type: "string" },
            description: "Stripe checkout session ID",
            example: "cs_test_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8s9T0",
          },
        ],
        responses: {
          200: {
            description: "Checkout session verified successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      description: "Whether payment was successful",
                    },
                    status: {
                      type: "string",
                      enum: ["paid", "unpaid", "no_payment_required"],
                      description: "Payment status from Stripe",
                    },
                    amountPaid: {
                      type: "number",
                      description: "Amount paid in USD",
                    },
                    credits: {
                      type: "integer",
                      description: "Minutes credited to wallet",
                    },
                  },
                },
                example: {
                  success: true,
                  status: "paid",
                  amountPaid: 25.0,
                  credits: 300,
                },
              },
            },
          },
          400: {
            description: "Session ID is required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Failed to verify checkout session",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/payments/cancel-subscription": {
      post: {
        tags: ["Payments"],
        summary: "Cancel active subscription",
        description: "Cancel the user's active subscription immediately.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Subscription cancelled successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Subscription canceled immediately",
                    },
                    canceledAt: {
                      type: "string",
                      format: "date-time",
                      description: "Date when subscription was canceled",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "No active subscription found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "No active subscription found",
                },
              },
            },
          },
          500: {
            description: "Failed to cancel subscription",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ System Endpoints ============
    "/health": {
      get: {
        tags: ["System"],
        summary: "Health check endpoint",
        description:
          "Check the health status of the API and its dependencies (PostgreSQL and Redis)",
        responses: {
          200: {
            description: "All services are healthy",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    status: {
                      type: "string",
                      example: "healthy",
                    },
                    timestamp: {
                      type: "string",
                      format: "date-time",
                    },
                    services: {
                      type: "object",
                      properties: {
                        postgres: {
                          type: "string",
                          example: "connected",
                        },
                        redis: {
                          type: "string",
                          example: "connected",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          503: {
            description: "One or more services are unhealthy",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    status: {
                      type: "string",
                      example: "unhealthy",
                    },
                    error: {
                      type: "string",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ Notifications Endpoints ============
    "/api/v1/notifications/status": {
      get: {
        tags: ["Notifications"],
        summary: "Get Firebase Cloud Messaging status",
        description: "Check if Firebase is initialized and configured",
        responses: {
          200: {
            description: "Firebase status retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean" },
                    firebase: {
                      type: "object",
                      properties: {
                        initialized: { type: "boolean" },
                        credentialsConfigured: { type: "boolean" },
                        status: { type: "string" },
                        message: { type: "string" },
                      },
                    },
                    features: {
                      type: "object",
                      properties: {
                        pushNotifications: { type: "boolean" },
                        deviceTokenRegistration: { type: "boolean" },
                        notificationHistory: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    "/api/v1/notifications/register": {
      post: {
        tags: ["Notifications"],
        summary: "Register a device token for push notifications",
        description: "Register FCM device token to receive push notifications",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["token"],
                properties: {
                  token: {
                    type: "string",
                    description: "FCM device token",
                    example: "fcm_token_12345...",
                  },
                  device_type: {
                    type: "string",
                    enum: ["android", "ios", "web"],
                    description: "Device platform type",
                  },
                  device_info: {
                    type: "object",
                    description: "Additional device information",
                    example: {
                      model: "Pixel 6",
                      os_version: "Android 13",
                      app_version: "1.0.0",
                    },
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Device token registered successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean" },
                    message: { type: "string" },
                  },
                },
              },
            },
          },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
        },
      },
      delete: {
        tags: ["Notifications"],
        summary: "Unregister a device token",
        description: "Remove device token from receiving push notifications",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["token"],
                properties: {
                  token: {
                    type: "string",
                    description: "FCM device token to unregister",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: { description: "Device token unregistered successfully" },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
        },
      },
    },

    "/api/v1/notifications/test-send": {
      post: {
        tags: ["Notifications"],
        summary: "Send dummy push notification (no auth)",
        description:
          "Testing endpoint to send a push notification to a registered device without authentication. Provide either user_id (to target all active tokens for that user) or token (to target one device).",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  user_id: {
                    type: "string",
                    description: "Target user ID with registered device tokens",
                    example: "550e8400-e29b-41d4-a716-446655440000",
                  },
                  token: {
                    type: "string",
                    description:
                      "Direct FCM token target (alternative to user_id)",
                    example: "fcm_token_12345...",
                  },
                  title: {
                    type: "string",
                    example: "Test Notification",
                  },
                  body: {
                    type: "string",
                    example: "This is a test push notification from Swagger",
                  },
                  data: {
                    type: "object",
                    description: "Optional custom data payload",
                    example: { type: "test_notification", source: "swagger" },
                  },
                  image_url: {
                    type: "string",
                    example: "https://example.com/notification.png",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Test notification sent",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    message: { type: "string" },
                    result: {
                      type: "object",
                      properties: {
                        target: { type: "string", example: "user_id" },
                        deviceCount: { type: "integer", example: 2 },
                        successCount: { type: "integer", example: 2 },
                        failureCount: { type: "integer", example: 0 },
                        messageId: { type: "string" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Missing user_id/token" },
          404: { description: "No active device tokens found" },
          500: { description: "Failed to send notification" },
        },
      },
    },

    "/api/v1/notifications/send": {
      post: {
        tags: ["Notifications"],
        summary: "Send a push notification to a specific user",
        description: "Send push notification to all devices of a specific user",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["user_id", "title", "body"],
                properties: {
                  user_id: {
                    type: "integer",
                    description: "Target user ID",
                    example: 123,
                  },
                  title: {
                    type: "string",
                    description: "Notification title",
                    example: "Ventally",
                  },
                  body: {
                    type: "string",
                    description: "Notification body text",
                    example: "You have received a new message",
                  },
                  data: {
                    type: "object",
                    description: "Additional data payload",
                    example: { type: "message", message_id: "456" },
                  },
                  image_url: {
                    type: "string",
                    description: "Optional notification image URL",
                    example: "https://example.com/image.jpg",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Notification sent successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean" },
                    message: { type: "string" },
                    result: {
                      type: "object",
                      properties: {
                        successCount: { type: "integer" },
                        failureCount: { type: "integer" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
          404: { description: "No active devices found" },
          503: {
            description: "Firebase not configured",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: false },
                    message: {
                      type: "string",
                      example:
                        "Firebase not configured - notification saved but not sent",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    "/api/v1/notifications/send-bulk": {
      post: {
        tags: ["Notifications"],
        summary: "Send a push notification to multiple users",
        description: "Send same notification to multiple users at once",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["user_ids", "title", "body"],
                properties: {
                  user_ids: {
                    type: "array",
                    items: { type: "integer" },
                    description: "Array of target user IDs",
                    example: [123, 456, 789],
                  },
                  title: { type: "string", example: "System Maintenance" },
                  body: {
                    type: "string",
                    example: "Scheduled maintenance tonight",
                  },
                  data: { type: "object" },
                  image_url: { type: "string" },
                },
              },
            },
          },
        },
        responses: {
          200: { description: "Bulk notification sent successfully" },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
          404: { description: "No active devices found" },
          503: { description: "Firebase not configured" },
        },
      },
    },

    "/api/v1/notifications/send-topic": {
      post: {
        tags: ["Notifications"],
        summary: "Send a push notification to a topic",
        description: "Send notification to all devices subscribed to a topic",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["topic", "title", "body"],
                properties: {
                  topic: {
                    type: "string",
                    description: "Topic name",
                    example: "promotions",
                  },
                  title: { type: "string", example: "Special Offer!" },
                  body: { type: "string", example: "Get 50% off today" },
                  data: { type: "object" },
                  image_url: { type: "string" },
                },
              },
            },
          },
        },
        responses: {
          200: { description: "Topic notification sent successfully" },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
          503: { description: "Firebase not configured" },
        },
      },
    },

    "/api/v1/notifications/subscribe": {
      post: {
        tags: ["Notifications"],
        summary: "Subscribe user's devices to a topic",
        description:
          "Subscribe all user devices to receive topic notifications",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["topic"],
                properties: {
                  topic: {
                    type: "string",
                    description: "Topic to subscribe to",
                    example: "promotions",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: { description: "Subscribed to topic successfully" },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
          404: { description: "No active devices found" },
        },
      },
    },

    "/api/v1/notifications/unsubscribe": {
      post: {
        tags: ["Notifications"],
        summary: "Unsubscribe user's devices from a topic",
        description: "Unsubscribe all user devices from topic notifications",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["topic"],
                properties: {
                  topic: {
                    type: "string",
                    description: "Topic to unsubscribe from",
                    example: "promotions",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: { description: "Unsubscribed from topic successfully" },
          400: { description: "Invalid request" },
          401: { description: "Unauthorized" },
          404: { description: "No active devices found" },
        },
      },
    },

    "/api/v1/notifications/history": {
      get: {
        tags: ["Notifications"],
        summary: "Get notification history for the authenticated user",
        description:
          "Retrieve paginated notification history with read/unread status",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "limit",
            schema: { type: "integer", default: 50 },
            description: "Maximum number of notifications to return",
          },
          {
            in: "query",
            name: "offset",
            schema: { type: "integer", default: 0 },
            description: "Number of notifications to skip",
          },
        ],
        responses: {
          200: {
            description: "Notification history retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean" },
                    data: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "integer" },
                          title: { type: "string" },
                          body: { type: "string" },
                          data: { type: "object" },
                          type: { type: "string" },
                          status: { type: "string" },
                          created_at: { type: "string", format: "date-time" },
                          read_at: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                        },
                      },
                    },
                    total: { type: "integer" },
                    limit: { type: "integer" },
                    offset: { type: "integer" },
                  },
                },
              },
            },
          },
          401: { description: "Unauthorized" },
        },
      },
    },

    "/api/v1/notifications/{id}/read": {
      put: {
        tags: ["Notifications"],
        summary: "Mark a notification as read",
        description: "Update notification read status",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "id",
            required: true,
            schema: { type: "integer" },
            description: "Notification ID",
          },
        ],
        responses: {
          200: { description: "Notification marked as read" },
          401: { description: "Unauthorized" },
          404: { description: "Notification not found or already read" },
        },
      },
    },

    "/api/v1/notifications/unread-count": {
      get: {
        tags: ["Notifications"],
        summary: "Get unread notification count",
        description: "Get the count of unread notifications for the user",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Unread count retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean" },
                    unreadCount: { type: "integer", example: 5 },
                  },
                },
              },
            },
          },
          401: { description: "Unauthorized" },
        },
      },
    },
    "/api/v1/notifications/settings": {
      get: {
        tags: ["Notifications"],
        summary: "Get notification settings",
        description: "Get notification preferences for the authenticated user",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Settings retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    data: {
                      type: "object",
                      properties: {
                        allNotifications: { type: "boolean" },
                        messageNotifications: { type: "boolean" },
                        callNotifications: { type: "boolean" },
                        reminderNotifications: { type: "boolean" },
                        soundVibration: { type: "boolean" },
                        inAppAlerts: { type: "boolean" },
                        activityStatus: { type: "boolean" },
                        listenerReplyNotifications: { type: "boolean" },
                        moodLogNotifications: { type: "boolean" },
                        reflectionLogNotifications: { type: "boolean" },
                        wellnessNudges: { type: "boolean" },
                        remindMeAtUtc: { type: "string", nullable: true },
                        quietHoursStartUtc: { type: "string", nullable: true },
                        quietHoursEndUtc: { type: "string", nullable: true },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Notifications"],
        summary: "Update notification settings",
        description:
          "Update notification preferences including all notifications, channel toggles, reminder time, and quiet hours in UTC",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  allNotifications: { type: "boolean", example: true },
                  messageNotifications: { type: "boolean", example: true },
                  callNotifications: { type: "boolean", example: true },
                  reminderNotifications: { type: "boolean", example: true },
                  soundVibration: { type: "boolean", example: true },
                  inAppAlerts: { type: "boolean", example: true },
                  activityStatus: { type: "boolean", example: true },
                  listenerReplyNotifications: {
                    type: "boolean",
                    example: true,
                  },
                  moodLogNotifications: { type: "boolean", example: true },
                  reflectionLogNotifications: {
                    type: "boolean",
                    example: true,
                  },
                  wellnessNudges: { type: "boolean", example: true },
                  remindMeAtUtc: {
                    type: "string",
                    example: "20:00",
                    description: "UTC time in HH:MM or HH:MM:SS",
                  },
                  quietHoursStartUtc: {
                    type: "string",
                    example: "22:00",
                    nullable: true,
                  },
                  quietHoursEndUtc: {
                    type: "string",
                    example: "07:00",
                    nullable: true,
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Settings updated successfully",
          },
          400: { description: "Validation error" },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
    },

    // ============ Session Endpoints ============
    "/api/v1/sessions": {
      post: {
        tags: ["Sessions"],
        summary: "Create a new call session",
        description:
          "Create a new call session between venter and listener. Validates wallet balance and payment method before creation.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["listenerId"],
                properties: {
                  listenerId: {
                    type: "string",
                    format: "uuid",
                    example: "123e4567-e89b-12d3-a456-426614174000",
                    description: "ID of the listener to call",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Session created successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    session: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        venterId: { type: "string", format: "uuid" },
                        listenerId: { type: "string", format: "uuid" },
                        status: { type: "string", enum: ["pending"] },
                        ratePerMinute: { type: "number", example: 0.5 },
                        estimatedCost: { type: "number", example: 2.5 },
                        createdAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Invalid request or insufficient balance" },
          402: { description: "Payment required - insufficient balance" },
          403: {
            description:
              "Forbidden - account not verified or invalid user type",
          },
          404: { description: "Listener not found" },
          409: { description: "Active session already exists" },
        },
      },
    },

    "/api/v1/sessions/active": {
      get: {
        tags: ["Sessions"],
        summary: "Get active sessions",
        description:
          "Retrieve all active sessions for the authenticated user (venter or listener)",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Active sessions retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    sessions: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          venterId: { type: "string", format: "uuid" },
                          venterEmail: { type: "string" },
                          listenerId: { type: "string", format: "uuid" },
                          listenerEmail: { type: "string" },
                          status: {
                            type: "string",
                            enum: ["pending", "accepted", "active"],
                          },
                          ratePerMinute: { type: "number" },
                          createdAt: { type: "string", format: "date-time" },
                          acceptedAt: { type: "string", format: "date-time" },
                          startedAt: { type: "string", format: "date-time" },
                        },
                      },
                    },
                    count: { type: "integer" },
                  },
                },
              },
            },
          },
          401: { description: "Unauthorized" },
        },
      },
    },

    "/api/v1/sessions/{sessionId}": {
      get: {
        tags: ["Sessions"],
        summary: "Get session details",
        description: "Retrieve detailed information about a specific session",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "sessionId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Session ID",
          },
        ],
        responses: {
          200: {
            description: "Session details retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    session: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        venterId: { type: "string", format: "uuid" },
                        listenerId: { type: "string", format: "uuid" },
                        status: { type: "string" },
                        twilioCallSid: { type: "string" },
                        durationSeconds: { type: "integer" },
                        ratePerMinute: { type: "number" },
                        estimatedCost: { type: "number" },
                        finalCost: { type: "number" },
                        createdAt: { type: "string", format: "date-time" },
                        acceptedAt: { type: "string", format: "date-time" },
                        startedAt: { type: "string", format: "date-time" },
                        endedAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: { description: "Unauthorized" },
          403: {
            description: "Forbidden - not authorized to view this session",
          },
          404: { description: "Session not found" },
        },
      },
    },

    "/api/v1/sessions/{sessionId}/accept": {
      post: {
        tags: ["Sessions"],
        summary: "Accept a call session",
        description:
          "Accept a pending call session and initiate the Twilio call (listener only)",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "sessionId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Session ID",
          },
        ],
        responses: {
          200: {
            description: "Session accepted and call initiated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    session: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        status: { type: "string", example: "active" },
                        twilioCallSid: { type: "string" },
                        startedAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Invalid session status" },
          403: { description: "Unauthorized - not the assigned listener" },
          404: { description: "Session not found" },
          500: { description: "Call initiation failed" },
        },
      },
    },

    "/api/v1/sessions/{sessionId}/end": {
      post: {
        tags: ["Sessions"],
        summary: "End a call session",
        description:
          "End an active call session and calculate final cost (venter or listener)",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "sessionId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Session ID",
          },
        ],
        responses: {
          200: {
            description: "Session ended successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    session: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        status: { type: "string", example: "ended" },
                        durationSeconds: { type: "integer" },
                        finalCost: { type: "number" },
                        endedAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Invalid session status" },
          403: {
            description: "Unauthorized - not a participant in this session",
          },
          404: { description: "Session not found" },
        },
      },
    },
    // ============ Webhook Endpoints ============
    "/api/v1/webhooks/stripe": {
      post: {
        tags: ["Webhooks"],
        summary: "Stripe webhook endpoint",
        description:
          "Receives and processes Stripe webhook events for payments, subscriptions, and checkout sessions. Requires valid Stripe signature for security.",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                description: "Stripe event object",
                properties: {
                  id: {
                    type: "string",
                    description: "Unique identifier for the event",
                  },
                  type: {
                    type: "string",
                    description: "Event type",
                    example: "checkout.session.completed",
                  },
                  data: {
                    type: "object",
                    description: "Event data payload",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Webhook received and processed successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    received: {
                      type: "boolean",
                      example: true,
                    },
                    duplicate: {
                      type: "boolean",
                      description: "Whether this was a duplicate event",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid signature or webhook error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string" },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/webhooks/twilio/call-status/{sessionId}": {
      post: {
        tags: ["Webhooks"],
        summary: "Twilio call status webhook",
        description:
          "Receives call status updates from Twilio (completed, failed, busy, no-answer). Updates session status accordingly.",
        parameters: [
          {
            in: "path",
            name: "sessionId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Session ID to update",
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/x-www-form-urlencoded": {
              schema: {
                type: "object",
                properties: {
                  CallSid: {
                    type: "string",
                    description: "Twilio call SID",
                  },
                  CallStatus: {
                    type: "string",
                    description: "Call status",
                    enum: ["completed", "failed", "busy", "no-answer"],
                  },
                  CallDuration: {
                    type: "integer",
                    description: "Call duration in seconds",
                  },
                  From: {
                    type: "string",
                    description: "Caller phone number",
                  },
                  To: {
                    type: "string",
                    description: "Callee phone number",
                  },
                  Direction: {
                    type: "string",
                    description: "Call direction",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Webhook processed successfully",
            content: {
              "text/plain": {
                schema: {
                  type: "string",
                  example: "OK",
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/webhooks/twilio/conference/{sessionId}": {
      post: {
        tags: ["Webhooks"],
        summary: "Twilio conference TwiML generator",
        description:
          "Generates TwiML instructions for conference calls. Called by Twilio when a participant joins a conference.",
        parameters: [
          {
            in: "path",
            name: "sessionId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Session ID for the conference",
          },
          {
            in: "query",
            name: "participant",
            required: false,
            schema: { type: "string", enum: ["venter", "listener"] },
            description: "Participant type (venter is host)",
          },
        ],
        responses: {
          200: {
            description: "TwiML response generated",
            content: {
              "text/xml": {
                schema: {
                  type: "string",
                  example:
                    '<?xml version="1.0" encoding="UTF-8"?><Response><Conference>ventally-session-id</Conference></Response>',
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/webhooks/twilio/conference/status": {
      post: {
        tags: ["Webhooks"],
        summary: "Twilio conference status webhook",
        description:
          "Receives conference status updates from Twilio (participant-join, participant-leave, conference-start, conference-end).",
        requestBody: {
          required: true,
          content: {
            "application/x-www-form-urlencoded": {
              schema: {
                type: "object",
                properties: {
                  ConferenceSid: {
                    type: "string",
                    description: "Twilio conference SID",
                  },
                  FriendlyName: {
                    type: "string",
                    description: "Conference name",
                  },
                  StatusCallbackEvent: {
                    type: "string",
                    description: "Event type",
                    enum: [
                      "participant-join",
                      "participant-leave",
                      "conference-start",
                      "conference-end",
                    ],
                  },
                  Timestamp: {
                    type: "string",
                    description: "Event timestamp",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Webhook processed successfully",
            content: {
              "text/plain": {
                schema: {
                  type: "string",
                  example: "OK",
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/webhooks/twilio/recording": {
      post: {
        tags: ["Webhooks"],
        summary: "Twilio recording status webhook",
        description:
          "Receives recording status updates from Twilio. Stores recording information in the database.",
        requestBody: {
          required: true,
          content: {
            "application/x-www-form-urlencoded": {
              schema: {
                type: "object",
                properties: {
                  RecordingSid: {
                    type: "string",
                    description: "Twilio recording SID",
                  },
                  RecordingUrl: {
                    type: "string",
                    description: "URL to access the recording",
                  },
                  RecordingStatus: {
                    type: "string",
                    description: "Recording status",
                    enum: ["completed", "failed"],
                  },
                  RecordingDuration: {
                    type: "integer",
                    description: "Recording duration in seconds",
                  },
                  CallSid: {
                    type: "string",
                    description: "Associated call SID",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Webhook processed successfully",
            content: {
              "text/plain": {
                schema: {
                  type: "string",
                  example: "OK",
                },
              },
            },
          },
        },
      },
    },

    // ============ Mood Endpoints ============
    "/api/v1/mood/log": {
      post: {
        tags: ["Mood"],
        summary: "Log mood for today",
        description:
          "Log a mood entry for the current day. Only one entry per day is allowed. Only available for venter profiles.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["mood_type"],
                properties: {
                  mood_type: {
                    type: "string",
                    enum: ["Happy", "Neutral", "Sad", "Anxious", "Mad"],
                    description: "The mood type",
                    example: "Happy",
                  },
                  category: {
                    type: "string",
                    enum: ["Work", "Family", "Health", "Unknown"],
                    description: "Optional category for the mood context",
                    example: "Work",
                  },
                  notes: {
                    type: "string",
                    description: "Optional notes about the mood",
                    example: "Had a great day at work today!",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Mood logged successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Mood logged successfully",
                    },
                    mood: { $ref: "#/components/schemas/MoodEntry" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized - No valid authentication token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only venter profiles can log moods",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          409: {
            description: "Conflict - Mood already logged for today",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string" },
                    message: { type: "string" },
                    mood_id: {
                      type: "string",
                      format: "uuid",
                      description: "Existing mood entry ID",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/mood/today": {
      get: {
        tags: ["Mood"],
        summary: "Get today's mood",
        description: "Retrieve the mood entry for today if it exists",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Today's mood retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Today's mood retrieved successfully",
                    },
                    logged: {
                      type: "boolean",
                      example: true,
                    },
                    mood: { $ref: "#/components/schemas/MoodEntry" },
                  },
                },
              },
            },
          },
          404: {
            description: "No mood logged for today",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "No mood logged for today",
                    },
                    logged: {
                      type: "boolean",
                      example: false,
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Mood"],
        summary: "Update today's mood",
        description:
          "Update the mood entry for today. Only available for venter profiles.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  mood_type: {
                    type: "string",
                    enum: ["Happy", "Neutral", "Sad", "Anxious", "Mad"],
                    description: "The mood type to update",
                    example: "Neutral",
                  },
                  category: {
                    type: "string",
                    enum: ["Work", "Family", "Health", "Unknown"],
                    description: "Category to update",
                    example: "Family",
                  },
                  notes: {
                    type: "string",
                    description: "Notes to update",
                    example: "Feeling better after talking with family",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Mood updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Mood updated successfully",
                    },
                    mood: { $ref: "#/components/schemas/MoodEntry" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only venter profiles can update moods",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "No mood logged for today to update",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/mood/history": {
      get: {
        tags: ["Mood"],
        summary: "Get mood history",
        description:
          "Retrieve mood history with pagination and optional date filtering",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            description: "Number of entries to return",
            schema: {
              type: "integer",
              default: 30,
              minimum: 1,
              maximum: 100,
            },
          },
          {
            name: "offset",
            in: "query",
            description: "Number of entries to skip",
            schema: {
              type: "integer",
              default: 0,
              minimum: 0,
            },
          },
          {
            name: "start_date",
            in: "query",
            description: "Filter moods from this date onwards (YYYY-MM-DD)",
            schema: {
              type: "string",
              format: "date",
              example: "2026-01-01",
            },
          },
          {
            name: "end_date",
            in: "query",
            description: "Filter moods up to this date (YYYY-MM-DD)",
            schema: {
              type: "string",
              format: "date",
              example: "2026-01-31",
            },
          },
        ],
        responses: {
          200: {
            description: "Mood history retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Mood history retrieved successfully",
                    },
                    moods: {
                      type: "array",
                      items: { $ref: "#/components/schemas/MoodEntry" },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: {
                          type: "integer",
                          description: "Total number of mood entries",
                          example: 45,
                        },
                        limit: {
                          type: "integer",
                          example: 30,
                        },
                        offset: {
                          type: "integer",
                          example: 0,
                        },
                        has_more: {
                          type: "boolean",
                          description: "Whether more entries exist",
                          example: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/mood/stats": {
      get: {
        tags: ["Mood"],
        summary: "Get mood statistics",
        description:
          "Get mood distribution, trends, and streaks for the logged-in user",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "days",
            in: "query",
            description: "Number of days to include in statistics",
            schema: {
              type: "integer",
              default: 30,
              minimum: 1,
              maximum: 365,
            },
          },
        ],
        responses: {
          200: {
            description: "Mood statistics retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Mood statistics retrieved successfully",
                    },
                    period_days: {
                      type: "integer",
                      description: "Number of days included in stats",
                      example: 30,
                    },
                    total_entries: {
                      type: "integer",
                      description: "Total mood entries in period",
                      example: 25,
                    },
                    mood_distribution: {
                      type: "array",
                      description: "Distribution of mood types",
                      items: {
                        type: "object",
                        properties: {
                          mood_type: {
                            type: "string",
                            example: "Happy",
                          },
                          count: {
                            type: "string",
                            example: "10",
                          },
                        },
                      },
                    },
                    category_distribution: {
                      type: "array",
                      description: "Distribution of mood categories",
                      items: {
                        type: "object",
                        properties: {
                          category: {
                            type: "string",
                            example: "Work",
                          },
                          count: {
                            type: "string",
                            example: "8",
                          },
                        },
                      },
                    },
                    streaks: {
                      type: "object",
                      properties: {
                        current: {
                          type: "integer",
                          description: "Current consecutive days streak",
                          example: 5,
                        },
                        longest: {
                          type: "integer",
                          description: "Longest consecutive days streak",
                          example: 12,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/mood/{moodId}": {
      delete: {
        tags: ["Mood"],
        summary: "Delete a mood entry",
        description:
          "Delete a specific mood entry. Users can only delete their own entries. Only available for venter profiles.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "moodId",
            in: "path",
            required: true,
            description: "The mood entry ID",
            schema: {
              type: "string",
              format: "uuid",
              example: "550e8400-e29b-41d4-a716-446655440000",
            },
          },
        ],
        responses: {
          200: {
            description: "Mood deleted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Mood deleted successfully",
                    },
                    mood_id: {
                      type: "string",
                      format: "uuid",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only venter profiles can delete moods",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Mood entry not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Reflection Endpoints ============
    "/api/v1/reflections/save": {
      post: {
        tags: ["Reflections"],
        summary: "Save or update reflection for today",
        description:
          "Save a reflection entry for the current day. Only one reflection per day is allowed. If a reflection already exists for today, it will be updated. Automatically links to today's mood if available. Only available for venter profiles.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["reflection_text"],
                properties: {
                  reflection_text: {
                    type: "string",
                    description: "The text content of the reflection",
                    example:
                      "Today I reflected on my goals and felt grateful for the progress I've made. I realize I need to focus more on self-care.",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Reflection saved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Reflection saved successfully",
                    },
                    reflection: {
                      $ref: "#/components/schemas/ReflectionEntry",
                    },
                  },
                },
              },
            },
          },
          200: {
            description: "Reflection updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Reflection updated successfully",
                    },
                    reflection: {
                      $ref: "#/components/schemas/ReflectionEntry",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized - No valid authentication token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description:
              "Forbidden - Only venter profiles can save reflections",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/reflections/today": {
      get: {
        tags: ["Reflections"],
        summary: "Get today's reflection",
        description:
          "Retrieve the reflection entry for today if it exists, including linked mood information",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Today's reflection retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Today's reflection retrieved successfully",
                    },
                    saved: {
                      type: "boolean",
                      example: true,
                    },
                    reflection: {
                      $ref: "#/components/schemas/ReflectionEntryWithMood",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "No reflection saved for today",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "No reflection saved for today",
                    },
                    saved: {
                      type: "boolean",
                      example: false,
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/reflections/history": {
      get: {
        tags: ["Reflections"],
        summary: "Get reflection history",
        description:
          "Retrieve reflection history with pagination and optional date filtering, including linked mood information",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            description: "Number of entries to return",
            schema: {
              type: "integer",
              default: 30,
              minimum: 1,
              maximum: 100,
            },
          },
          {
            name: "offset",
            in: "query",
            description: "Number of entries to skip",
            schema: {
              type: "integer",
              default: 0,
              minimum: 0,
            },
          },
          {
            name: "start_date",
            in: "query",
            description:
              "Filter reflections from this date onwards (YYYY-MM-DD)",
            schema: {
              type: "string",
              format: "date",
              example: "2026-01-01",
            },
          },
          {
            name: "end_date",
            in: "query",
            description: "Filter reflections up to this date (YYYY-MM-DD)",
            schema: {
              type: "string",
              format: "date",
              example: "2026-01-31",
            },
          },
        ],
        responses: {
          200: {
            description: "Reflection history retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Reflection history retrieved successfully",
                    },
                    reflections: {
                      type: "array",
                      items: {
                        $ref: "#/components/schemas/ReflectionEntryWithMood",
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: {
                          type: "integer",
                          description: "Total number of reflection entries",
                          example: 45,
                        },
                        limit: {
                          type: "integer",
                          example: 30,
                        },
                        offset: {
                          type: "integer",
                          example: 0,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/reflections/{reflectionId}": {
      put: {
        tags: ["Reflections"],
        summary: "Update a specific reflection",
        description:
          "Update the text content of a specific reflection entry. Users can only update their own reflections. Only available for venter profiles.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "reflectionId",
            in: "path",
            required: true,
            description: "The reflection entry ID",
            schema: {
              type: "string",
              format: "uuid",
              example: "550e8400-e29b-41d4-a716-446655440000",
            },
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["reflection_text"],
                properties: {
                  reflection_text: {
                    type: "string",
                    description: "The updated text content of the reflection",
                    example:
                      "Updated reflection: I've been thinking more about my progress and I'm proud of how far I've come.",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Reflection updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Reflection updated successfully",
                    },
                    reflection: {
                      $ref: "#/components/schemas/ReflectionEntry",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description:
              "Forbidden - Only venter profiles can update reflections",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Reflection entry not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      delete: {
        tags: ["Reflections"],
        summary: "Delete a reflection entry",
        description:
          "Delete a specific reflection entry. Users can only delete their own reflections. Only available for venter profiles.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "reflectionId",
            in: "path",
            required: true,
            description: "The reflection entry ID",
            schema: {
              type: "string",
              format: "uuid",
              example: "550e8400-e29b-41d4-a716-446655440000",
            },
          },
        ],
        responses: {
          200: {
            description: "Reflection deleted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Reflection deleted successfully",
                    },
                    reflection_id: {
                      type: "string",
                      format: "uuid",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description:
              "Forbidden - Only venter profiles can delete reflections",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Reflection entry not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Sobriety Endpoints ============
    "/api/v1/sobriety/status": {
      get: {
        tags: ["Sobriety"],
        summary: "Get sobriety status",
        description:
          "Get current sobriety tracking status, days sober, and achieved milestones for the authenticated venter.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Sobriety status retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    tracking_enabled: { type: "boolean" },
                    status: {
                      $ref: "#/components/schemas/SobrietyStatus",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only venter profiles can access",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/sobriety/start": {
      post: {
        tags: ["Sobriety"],
        summary: "Start or update sobriety tracking",
        description:
          "Creates or updates sobriety profile with a streak start date and optional notes.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: false,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  sober_start_date: {
                    type: "string",
                    format: "date",
                    example: "2026-02-01",
                  },
                  notes: {
                    type: "string",
                    example: "Starting fresh today",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Sobriety tracking updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    status: {
                      $ref: "#/components/schemas/SobrietyStatus",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only venter profiles can access",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/sobriety/relapse": {
      post: {
        tags: ["Sobriety"],
        summary: "Log relapse",
        description:
          "Logs a relapse event and resets sober start date to restart_date (or relapse_date when omitted).",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: false,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  relapse_date: {
                    type: "string",
                    format: "date",
                    example: "2026-02-20",
                  },
                  restart_date: {
                    type: "string",
                    format: "date",
                    example: "2026-02-20",
                  },
                  notes: {
                    type: "string",
                    example: "Tough day, restarting immediately",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description:
              "Relapse logged and sobriety streak reset successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    status: {
                      $ref: "#/components/schemas/SobrietyStatus",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Sobriety tracking not configured",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/sobriety/history": {
      get: {
        tags: ["Sobriety"],
        summary: "Get sobriety history",
        description:
          "Get sobriety events timeline for the authenticated venter.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            schema: {
              type: "integer",
              default: 30,
              minimum: 1,
              maximum: 100,
            },
          },
          {
            name: "offset",
            in: "query",
            schema: {
              type: "integer",
              default: 0,
              minimum: 0,
            },
          },
        ],
        responses: {
          200: {
            description: "Sobriety history retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    events: {
                      type: "array",
                      items: {
                        $ref: "#/components/schemas/SobrietyEvent",
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer" },
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                        has_more: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ Venter Home Endpoint ============
    "/api/v1/home/summary": {
      get: {
        tags: ["Home"],
        summary: "Get venter home summary",
        description:
          "Returns progress, highlights, achievements, and merged recent entries (mood + reflections) for the venter home screen.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            description: "Maximum number of recent entries to return",
            schema: {
              type: "integer",
              default: 10,
              minimum: 1,
              maximum: 50,
            },
          },
        ],
        responses: {
          200: {
            description: "Venter home summary retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    progress: {
                      type: "object",
                      properties: {
                        tracking_enabled: { type: "boolean" },
                        days_sober: { type: "integer" },
                        sober_start_date: {
                          type: "string",
                          format: "date",
                          nullable: true,
                        },
                        last_relapse_date: {
                          type: "string",
                          format: "date",
                          nullable: true,
                        },
                      },
                    },
                    highlights: {
                      type: "object",
                      properties: {
                        feeling: {
                          type: "string",
                          nullable: true,
                        },
                        latest_mood_date: {
                          type: "string",
                          format: "date",
                          nullable: true,
                        },
                        achievements_count: { type: "integer" },
                      },
                    },
                    achievements: {
                      type: "array",
                      items: {
                        $ref: "#/components/schemas/SobrietyAchievement",
                      },
                    },
                    recent_entries: {
                      type: "array",
                      items: {
                        $ref: "#/components/schemas/HomeRecentEntry",
                      },
                    },
                  },
                },
              },
            },
          },
          403: {
            description: "Forbidden - Only venter profiles can access",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Listener Availability Endpoints ============
    "/api/v1/availability/online": {
      post: {
        tags: ["Availability"],
        summary: "Go online as listener",
        description:
          "Mark listener as available to receive chat/call requests. Creates or updates listener profile.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Successfully went online",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "You are now online" },
                    profile: { $ref: "#/components/schemas/ListenerProfile" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only listeners can go online",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/availability/offline": {
      post: {
        tags: ["Availability"],
        summary: "Go offline as listener",
        description:
          "Mark listener as unavailable and remove from available listeners list.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Successfully went offline",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "You are now offline" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only listeners can go offline",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/availability/heartbeat": {
      post: {
        tags: ["Availability"],
        summary: "Send presence heartbeat",
        description:
          "Updates listener's last seen timestamp. Should be sent every 30 seconds.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Heartbeat received",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "Heartbeat updated" },
                    lastSeen: { type: "string", format: "date-time" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only listeners can send heartbeats",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/availability/listeners": {
      get: {
        tags: ["Availability"],
        summary: "Get available listeners",
        description:
          "Get list of online listeners who are not currently busy. Returns anonymous profiles only.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "List of available listeners",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    listeners: {
                      type: "array",
                      items: { $ref: "#/components/schemas/ListenerProfile" },
                    },
                    total: { type: "integer", example: 5 },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/availability/rate": {
      put: {
        tags: ["Availability"],
        summary: "Update listener rate",
        description:
          "Update per-minute rate for chat/call sessions. Must be between $0 and $10.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["ratePerMinute"],
                properties: {
                  ratePerMinute: {
                    type: "number",
                    format: "float",
                    minimum: 0,
                    maximum: 10,
                    example: 0.75,
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Rate updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Rate updated successfully",
                    },
                    profile: { $ref: "#/components/schemas/ListenerProfile" },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid rate",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Only listeners can update rate",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/availability/status": {
      get: {
        tags: ["Availability"],
        summary: "Get current availability status",
        description: "Get listener's current online/offline/busy status.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Current availability status",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    status: {
                      type: "string",
                      enum: ["online", "offline", "busy"],
                      example: "online",
                    },
                    isBusy: { type: "boolean", example: false },
                    lastSeen: { type: "string", format: "date-time" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only listeners can check status",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/availability/profile": {
      get: {
        tags: ["Availability"],
        summary: "Get listener profile",
        description:
          "Get listener's complete profile including rate, ratings, and stats.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Listener profile",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    profile: { $ref: "#/components/schemas/ListenerProfile" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only listeners can view profile",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Profile not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Chat/Conversation Endpoints ============
    "/api/v1/conversations": {
      post: {
        tags: ["Chat"],
        summary: "Create chat conversation",
        description:
          "Venter requests a text chat with an available listener. Requires sufficient wallet balance.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["listenerId"],
                properties: {
                  listenerId: {
                    type: "string",
                    format: "uuid",
                    description: "Listener's user ID",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description:
              "Conversation created, waiting for listener acceptance",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "Chat request sent" },
                    conversation: { $ref: "#/components/schemas/Conversation" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error or listener unavailable",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Only venters can create conversations",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      get: {
        tags: ["Chat"],
        summary: "Get conversation history",
        description:
          "Get list of all conversations for current user (venter or listener).",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "status",
            in: "query",
            description: "Filter by status",
            schema: {
              type: "string",
              enum: ["pending", "active", "ended", "declined"],
            },
          },
        ],
        responses: {
          200: {
            description: "List of conversations",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    conversations: {
                      type: "array",
                      items: { $ref: "#/components/schemas/Conversation" },
                    },
                    total: { type: "integer", example: 10 },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/conversations/{conversationId}": {
      get: {
        tags: ["Chat"],
        summary: "Get conversation details",
        description:
          "Get details of a specific conversation including anonymous identities.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "conversationId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Conversation details",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    conversation: { $ref: "#/components/schemas/Conversation" },
                  },
                },
              },
            },
          },
          403: {
            description: "Not a participant in this conversation",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Conversation not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/conversations/{conversationId}/accept": {
      post: {
        tags: ["Chat"],
        summary: "Accept chat request",
        description:
          "Listener accepts pending chat request. Marks conversation as active.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "conversationId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Chat request accepted",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "Chat accepted" },
                    conversation: { $ref: "#/components/schemas/Conversation" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only assigned listener can accept",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Conversation not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/conversations/{conversationId}/decline": {
      post: {
        tags: ["Chat"],
        summary: "Decline chat request",
        description: "Listener declines pending chat request.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "conversationId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Chat request declined",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "Chat declined" },
                  },
                },
              },
            },
          },
          403: {
            description: "Only assigned listener can decline",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/conversations/{conversationId}/end": {
      post: {
        tags: ["Chat"],
        summary: "End conversation",
        description:
          "End active conversation. Calculates duration, deducts from wallet, creates earnings for listener.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "conversationId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Conversation ended successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string", example: "Conversation ended" },
                    durationMinutes: { type: "integer", example: 15 },
                    totalCost: {
                      type: "number",
                      format: "float",
                      example: 7.5,
                    },
                    earnings: {
                      type: "number",
                      format: "float",
                      example: 6.0,
                      description: "Only sent to listener",
                    },
                  },
                },
              },
            },
          },
          403: {
            description: "Not a participant in this conversation",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Conversation not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/conversations/{conversationId}/messages": {
      get: {
        tags: ["Chat"],
        summary: "Get conversation messages",
        description:
          "Get paginated messages for a conversation with anonymous sender identities.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "conversationId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
          {
            name: "limit",
            in: "query",
            description: "Number of messages to return (default: 50)",
            schema: { type: "integer", default: 50 },
          },
          {
            name: "before",
            in: "query",
            description: "Message ID to fetch messages before (for pagination)",
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "List of messages",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    messages: {
                      type: "array",
                      items: { $ref: "#/components/schemas/Message" },
                    },
                    total: { type: "integer", example: 42 },
                    hasMore: { type: "boolean", example: true },
                  },
                },
              },
            },
          },
          403: {
            description: "Not a participant in this conversation",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Voice Call Endpoints ============
    "/api/v1/calls": {
      post: {
        tags: ["Calls"],
        summary: "Create voice call request",
        description:
          "Venter creates a voice call request with an available listener. Requires either an active subscription OR sufficient wallet balance (minimum 5 minutes for prepaid users). Notifies the listener via Socket.io personal user room (userId as string) and triggers FCM push notification fallback for registered devices. Subscribers can make calls using their included minutes or overage.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["listenerId"],
                properties: {
                  listenerId: {
                    type: "string",
                    format: "uuid",
                    description: "Listener's user ID",
                    example: "550e8400-e29b-41d4-a716-446655440000",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Call request created successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    call: {
                      type: "object",
                      properties: {
                        id: {
                          type: "string",
                          format: "uuid",
                          example: "650e8400-e29b-41d4-a716-446655440001",
                        },
                        status: {
                          type: "string",
                          example: "requesting",
                        },
                        listener: {
                          type: "object",
                          properties: {
                            anonymousName: {
                              type: "string",
                              example: "Swift Fox",
                            },
                            avatarSeed: {
                              type: "string",
                              example: "a1b2c3d4e5f6",
                            },
                          },
                        },
                        ratePerMinute: {
                          type: "number",
                          format: "float",
                          example: 0.5,
                        },
                        createdAt: {
                          type: "string",
                          format: "date-time",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error or listener unavailable",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          402: {
            description: "Insufficient balance or no payment method",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: {
                      type: "string",
                      example: "Insufficient balance",
                    },
                    message: {
                      type: "string",
                      example:
                        "You don't have an active subscription or sufficient prepaid balance. You need at least 5 minutes to start a call.",
                    },
                    balance: {
                      type: "number",
                      description:
                        "Current balance in minutes (prepaid users only)",
                    },
                    required: {
                      type: "number",
                      example: 5,
                      description: "Minimum minutes required",
                    },
                    suggestion: {
                      type: "string",
                      example:
                        "Subscribe to a plan or add prepaid minutes to your wallet",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Listener not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/active": {
      get: {
        tags: ["Calls"],
        summary: "Get active call",
        description:
          "Get currently active or pending call for user (if any). Includes requesting, ringing, or active calls.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Active call details or null if no active call",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    activeCall: {
                      oneOf: [
                        {
                          type: "object",
                          properties: {
                            id: {
                              type: "string",
                              format: "uuid",
                            },
                            status: {
                              type: "string",
                              enum: ["requesting", "ringing", "active"],
                            },
                            otherParticipant: {
                              $ref: "#/components/schemas/AnonymousIdentity",
                            },
                            roomName: {
                              type: "string",
                              description: "Twilio room name (if accepted)",
                            },
                            ratePerMinute: {
                              type: "number",
                              format: "float",
                            },
                            createdAt: {
                              type: "string",
                              format: "date-time",
                            },
                            startedAt: {
                              type: "string",
                              format: "date-time",
                            },
                          },
                        },
                        { type: "null" },
                      ],
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/history": {
      get: {
        tags: ["Calls"],
        summary: "Get call history",
        description:
          "Get list of ended voice calls for current user with pagination. Only returns calls with status 'ended'.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            description: "Number of calls to return",
            schema: {
              type: "integer",
              default: 20,
              minimum: 1,
              maximum: 100,
            },
          },
          {
            name: "offset",
            in: "query",
            description: "Number of calls to skip",
            schema: {
              type: "integer",
              default: 0,
              minimum: 0,
            },
          },
        ],
        responses: {
          200: {
            description: "List of voice calls",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    count: {
                      type: "integer",
                      example: 8,
                    },
                    calls: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: {
                            type: "string",
                            format: "uuid",
                          },
                          status: {
                            type: "string",
                            example: "ended",
                          },
                          otherParticipant: {
                            $ref: "#/components/schemas/AnonymousIdentity",
                          },
                          ratePerMinute: {
                            type: "number",
                            format: "float",
                          },
                          durationSeconds: {
                            type: "integer",
                          },
                          durationMinutes: {
                            type: "integer",
                          },
                          totalCost: {
                            type: "number",
                            format: "float",
                          },
                          createdAt: {
                            type: "string",
                            format: "date-time",
                          },
                          startedAt: {
                            type: "string",
                            format: "date-time",
                          },
                          endedAt: {
                            type: "string",
                            format: "date-time",
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/{callId}": {
      get: {
        tags: ["Calls"],
        summary: "Get call details",
        description:
          "Get details of a specific voice call. Only accessible by participants.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "callId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The call ID",
          },
        ],
        responses: {
          200: {
            description: "Call details",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    call: {
                      type: "object",
                      properties: {
                        id: {
                          type: "string",
                          format: "uuid",
                        },
                        status: {
                          type: "string",
                          enum: [
                            "requesting",
                            "ringing",
                            "active",
                            "ended",
                            "declined",
                          ],
                        },
                        otherParticipant: {
                          $ref: "#/components/schemas/AnonymousIdentity",
                        },
                        roomName: {
                          type: "string",
                          description: "Twilio room name",
                        },
                        ratePerMinute: {
                          type: "number",
                          format: "float",
                        },
                        durationSeconds: {
                          type: "integer",
                        },
                        totalCost: {
                          type: "number",
                          format: "float",
                        },
                        createdAt: {
                          type: "string",
                          format: "date-time",
                        },
                        startedAt: {
                          type: "string",
                          format: "date-time",
                        },
                        endedAt: {
                          type: "string",
                          format: "date-time",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          403: {
            description: "Not a participant in this call",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Call not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/{callId}/accept": {
      post: {
        tags: ["Calls"],
        summary: "Accept call request (listener only)",
        description:
          "Listener accepts pending call request. Creates Twilio room, generates tokens for both participants, and notifies venter via Socket.io personal user room (userId as string).",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "callId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The call ID",
          },
        ],
        responses: {
          200: {
            description: "Call accepted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    call: {
                      type: "object",
                      properties: {
                        id: {
                          type: "string",
                          format: "uuid",
                        },
                        status: {
                          type: "string",
                          example: "ringing",
                        },
                        roomName: {
                          type: "string",
                          description: "Twilio room name",
                        },
                        token: {
                          type: "string",
                          description: "Twilio access token for listener",
                        },
                        venter: {
                          $ref: "#/components/schemas/AnonymousIdentity",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid call status",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Only assigned listener can accept",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Call not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          503: {
            description: "Twilio service unavailable",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/{callId}/decline": {
      post: {
        tags: ["Calls"],
        summary: "Decline call request (listener only)",
        description:
          "Listener declines pending call request. Notifies venter via Socket.io personal user room (userId as string).",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "callId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The call ID",
          },
        ],
        responses: {
          200: {
            description: "Call request declined",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    message: {
                      type: "string",
                      example: "Call declined",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid call status",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Only assigned listener can decline",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Call not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/{callId}/end": {
      post: {
        tags: ["Calls"],
        summary: "End voice call",
        description:
          "End active or ringing call. Calculates duration and cost, deducts from venter wallet, creates listener earnings, and notifies both participants via their Socket.io personal user rooms (userId as string).",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "callId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The call ID",
          },
        ],
        responses: {
          200: {
            description: "Call ended successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    call: {
                      type: "object",
                      properties: {
                        id: {
                          type: "string",
                          format: "uuid",
                        },
                        status: {
                          type: "string",
                          example: "ended",
                        },
                        durationSeconds: {
                          type: "integer",
                          example: 900,
                        },
                        durationMinutes: {
                          type: "integer",
                          example: 15,
                        },
                        totalCost: {
                          type: "number",
                          format: "float",
                          example: 7.5,
                        },
                        endedAt: {
                          type: "string",
                          format: "date-time",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid call status",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Not a participant in this call",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Call not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/session/{sessionId}/tip": {
      post: {
        tags: ["Tips"],
        summary: "Send tip to listener for ended session",
        description:
          "Venter sends one tip per ended session (call or chat) within 24 hours. Payment is wallet-first with Stripe fallback.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "sessionId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The call or conversation session ID",
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["amountCurrency"],
                properties: {
                  amountCurrency: {
                    type: "number",
                    format: "float",
                    minimum: 0.5,
                    maximum: 500,
                    example: 3.25,
                  },
                  message: {
                    type: "string",
                    maxLength: 500,
                    example: "Thanks for the support",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Tip completed immediately (wallet)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    status: { type: "string", example: "completed" },
                    paymentSource: { type: "string", example: "wallet" },
                    tip: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        sessionId: { type: "string", format: "uuid" },
                        sessionType: {
                          type: "string",
                          enum: ["call", "chat"],
                        },
                        callId: {
                          type: "string",
                          format: "uuid",
                          nullable: true,
                        },
                        amountCurrency: { type: "number", format: "float" },
                        status: { type: "string", example: "completed" },
                      },
                    },
                  },
                },
              },
            },
          },
          202: {
            description: "Tip created and awaiting Stripe confirmation",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    status: { type: "string", example: "pending" },
                    paymentSource: { type: "string", example: "stripe" },
                    paymentIntent: {
                      type: "object",
                      properties: {
                        id: { type: "string" },
                        status: { type: "string" },
                      },
                    },
                  },
                },
              },
            },
          },
          402: {
            description: "No payment method available for Stripe fallback",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Only venter for this session can tip",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Session not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          409: {
            description: "Session not ended or tip already exists",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          422: {
            description: "Tip validation failed (amount/window/message)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/{callId}/token": {
      get: {
        tags: ["Calls"],
        summary: "Get Twilio access token",
        description:
          "Get Twilio access token for joining an accepted call. Call must be in 'ringing' or 'active' status.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "callId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The call ID",
          },
        ],
        responses: {
          200: {
            description: "Twilio access token",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: {
                      type: "boolean",
                      example: true,
                    },
                    token: {
                      type: "string",
                      description: "Twilio access token JWT",
                    },
                    roomName: {
                      type: "string",
                      description: "Twilio room name",
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Room not ready - call not yet accepted",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Not a participant in this call",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Call not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          503: {
            description: "Twilio service unavailable",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/tips/sent": {
      get: {
        tags: ["Tips"],
        summary: "Get tips sent by authenticated venter",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            schema: { type: "integer", default: 20, minimum: 1, maximum: 100 },
          },
          {
            name: "offset",
            in: "query",
            schema: { type: "integer", default: 0, minimum: 0 },
          },
        ],
        responses: {
          200: {
            description: "Tips retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    tips: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          callId: { type: "string", format: "uuid" },
                          amountCurrency: { type: "number", format: "float" },
                          currency: { type: "string", example: "USD" },
                          paymentSource: {
                            type: "string",
                            enum: ["wallet", "stripe"],
                          },
                          status: { type: "string" },
                          createdAt: { type: "string", format: "date-time" },
                          completedAt: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer" },
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                        hasMore: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/tips/received": {
      get: {
        tags: ["Tips"],
        summary: "Get tips received by authenticated listener",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            schema: { type: "integer", default: 20, minimum: 1, maximum: 100 },
          },
          {
            name: "offset",
            in: "query",
            schema: { type: "integer", default: 0, minimum: 0 },
          },
        ],
        responses: {
          200: {
            description: "Tips retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    tips: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          callId: { type: "string", format: "uuid" },
                          amountCurrency: { type: "number", format: "float" },
                          currency: { type: "string", example: "USD" },
                          paymentSource: {
                            type: "string",
                            enum: ["wallet", "stripe"],
                          },
                          status: { type: "string" },
                          createdAt: { type: "string", format: "date-time" },
                          completedAt: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer" },
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                        hasMore: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/tips/{tipId}": {
      get: {
        tags: ["Tips"],
        summary: "Get tip details",
        description:
          "Retrieve a specific tip. Only the tip sender or receiver can access this record.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "tipId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "The tip ID",
          },
        ],
        responses: {
          200: {
            description: "Tip details",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    tip: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        callId: { type: "string", format: "uuid" },
                        venterId: { type: "string", format: "uuid" },
                        listenerId: { type: "string", format: "uuid" },
                        amountCurrency: { type: "number", format: "float" },
                        currency: { type: "string", example: "USD" },
                        message: { type: "string", nullable: true },
                        paymentSource: {
                          type: "string",
                          enum: ["wallet", "stripe"],
                        },
                        status: { type: "string" },
                        failureReason: { type: "string", nullable: true },
                        createdAt: { type: "string", format: "date-time" },
                        completedAt: {
                          type: "string",
                          format: "date-time",
                          nullable: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          403: {
            description: "Not tip participant",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Tip not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/calls/voice": {
      post: {
        tags: ["Calls"],
        summary: "Twilio voice webhook",
        description:
          "Webhook endpoint called by Twilio when a call is initiated from the mobile app. Returns TwiML response for call routing. No authentication required - Twilio validates the request.",
        requestBody: {
          required: true,
          content: {
            "application/x-www-form-urlencoded": {
              schema: {
                type: "object",
                properties: {
                  To: {
                    type: "string",
                    description: "Call ID or session ID",
                  },
                  From: {
                    type: "string",
                    description: "Caller phone number or client identity",
                  },
                  CallSid: {
                    type: "string",
                    description: "Twilio call SID",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "TwiML response",
            content: {
              "text/xml": {
                schema: {
                  type: "string",
                  example:
                    '<?xml version="1.0" encoding="UTF-8"?><Response><Dial><Conference>ventally-session-id</Conference></Dial></Response>',
                },
              },
            },
          },
        },
      },
    },

    // ============ Review Endpoints ============
    "/api/v1/reviews": {
      post: {
        tags: ["Reviews"],
        summary: "Submit a review",
        description:
          "Submit a rating and optional comment for another user after a call or chat session. Both users must have been participants in the session, which must be ended.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["sessionType", "sessionId", "revieweeId", "rating"],
                properties: {
                  sessionType: {
                    type: "string",
                    enum: ["call", "chat"],
                    example: "call",
                  },
                  sessionId: {
                    type: "string",
                    format: "uuid",
                    example: "123e4567-e89b-12d3-a456-426614174000",
                  },
                  revieweeId: {
                    type: "string",
                    format: "uuid",
                    description: "ID of the user being reviewed",
                    example: "987e6543-e21b-34d5-a678-426614174111",
                  },
                  rating: {
                    type: "integer",
                    minimum: 1,
                    maximum: 5,
                    example: 5,
                  },
                  comment: {
                    oneOf: [
                      {
                        type: "string",
                        maxLength: 500,
                        example: "Great listener, very helpful!",
                      },
                      {
                        type: "object",
                        properties: {
                          text: {
                            type: "string",
                            maxLength: 500,
                            example: "Great listener, very helpful!",
                          },
                        },
                      },
                    ],
                    description:
                      "Optional comment. Canonical format is string; object with text is accepted for backward compatibility.",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Review submitted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    review: { $ref: "#/components/schemas/Review" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Not authorized to review this session",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          409: {
            description: "Already reviewed this session",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/reviews/{userId}": {
      get: {
        tags: ["Reviews"],
        summary: "Get user reviews",
        description:
          "Get all reviews received by a specific user (typically a listener). Includes rating statistics and distribution.",
        parameters: [
          {
            name: "userId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "User ID to get reviews for",
          },
          {
            name: "limit",
            in: "query",
            schema: { type: "integer", default: 20 },
            description: "Number of reviews to return",
          },
          {
            name: "offset",
            in: "query",
            schema: { type: "integer", default: 0 },
            description: "Offset for pagination",
          },
        ],
        responses: {
          200: {
            description: "User reviews with statistics",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    reviews: {
                      type: "array",
                      items: { $ref: "#/components/schemas/Review" },
                    },
                    stats: {
                      type: "object",
                      properties: {
                        averageRating: {
                          type: "number",
                          format: "float",
                          example: 4.5,
                        },
                        totalReviews: { type: "integer", example: 42 },
                        distribution: {
                          type: "object",
                          properties: {
                            5: { type: "integer", example: 30 },
                            4: { type: "integer", example: 8 },
                            3: { type: "integer", example: 3 },
                            2: { type: "integer", example: 1 },
                            1: { type: "integer", example: 0 },
                          },
                        },
                      },
                    },
                    statistics: {
                      type: "object",
                      deprecated: true,
                      description: "Backward-compatible alias of stats.",
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                        total: { type: "integer" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/reviews/session/{sessionType}/{sessionId}": {
      get: {
        tags: ["Reviews"],
        summary: "Get session reviews",
        description:
          "Get all reviews for a specific session (both directions if mutual review).",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "sessionType",
            in: "path",
            required: true,
            schema: { type: "string", enum: ["call", "chat"] },
          },
          {
            name: "sessionId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Session reviews",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    reviews: {
                      type: "array",
                      items: {
                        allOf: [
                          { $ref: "#/components/schemas/Review" },
                          {
                            type: "object",
                            properties: {
                              is_my_review: {
                                type: "boolean",
                                example: true,
                              },
                            },
                          },
                        ],
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/reviews/can-review/{sessionType}/{sessionId}": {
      get: {
        tags: ["Reviews"],
        summary: "Check if can review session",
        description:
          "Check if the authenticated user can submit a review for a specific session.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "sessionType",
            in: "path",
            required: true,
            schema: { type: "string", enum: ["call", "chat"] },
          },
          {
            name: "sessionId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Review eligibility status",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    canReview: { type: "boolean", example: true },
                    reason: {
                      type: "string",
                      example: "Session must be ended before you can review",
                    },
                    otherUserId: {
                      type: "string",
                      format: "uuid",
                      description:
                        "ID of the other participant (if canReview is true)",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ Crisis Endpoints ============
    "/api/v1/crisis/escalate": {
      post: {
        tags: ["Crisis"],
        summary: "Escalate a call to crisis status",
        description:
          "Listener-only endpoint to escalate an active call for crisis intervention.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["voiceCallId", "riskCategory"],
                properties: {
                  voiceCallId: {
                    type: "string",
                    format: "uuid",
                    description: "Voice call ID to escalate",
                  },
                  riskCategory: {
                    type: "string",
                    enum: [
                      "self_harm",
                      "suicide",
                      "harm_to_others",
                      "severe_distress",
                      "other",
                    ],
                  },
                  notes: {
                    type: "string",
                    description: "Optional escalation notes",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Call escalated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    message: {
                      type: "string",
                      example: "Call escalated to crisis status",
                    },
                    crisisEvent: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        riskCategory: { type: "string" },
                        escalatedAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Validation error" },
          403: { description: "Only listener can escalate" },
          404: { description: "Call not found" },
          409: { description: "Already escalated" },
        },
      },
    },
    "/api/v1/crisis/escalation-event": {
      post: {
        tags: ["Crisis"],
        summary: "Record crisis-help escalation event for chat/call session",
        description:
          "Listener-only endpoint to record that crisis help was escalated for a referenced call or chat session.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["sessionType", "sessionId", "riskCategory"],
                properties: {
                  sessionType: {
                    type: "string",
                    enum: ["call", "chat"],
                    description: "Session channel where escalation occurred",
                  },
                  sessionId: {
                    type: "string",
                    format: "uuid",
                    description: "Referenced voice call or conversation ID",
                  },
                  riskCategory: {
                    type: "string",
                    enum: [
                      "self_harm",
                      "suicide",
                      "harm_to_others",
                      "severe_distress",
                      "other",
                    ],
                  },
                  notes: {
                    type: "string",
                    description: "Optional notes used in reporting context",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Crisis escalation event recorded",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    message: {
                      type: "string",
                      example: "Crisis help escalation recorded",
                    },
                    crisisEvent: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        sessionType: { type: "string", enum: ["call", "chat"] },
                        sessionId: { type: "string", format: "uuid" },
                        riskCategory: { type: "string" },
                        actionTaken: {
                          type: "string",
                          example: "help_escalated",
                        },
                        createdAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Validation error" },
          403: { description: "Only listener can record event" },
          404: { description: "Session not found" },
          409: { description: "Escalation already recorded" },
        },
      },
    },
    "/api/v1/crisis/handoff-988": {
      post: {
        tags: ["Crisis"],
        summary: "Transfer escalated call to 988",
        description:
          "Listener-only endpoint to initiate 988 handoff after call escalation.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["voiceCallId"],
                properties: {
                  voiceCallId: {
                    type: "string",
                    format: "uuid",
                    description: "Voice call ID",
                  },
                  reason: {
                    type: "string",
                    description: "Optional handoff reason",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "988 handoff initiated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    message: {
                      type: "string",
                      example: "Call transfer to 988 initiated",
                    },
                    handoff: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        handoffAt: { type: "string", format: "date-time" },
                        crisis988Number: { type: "string", example: "988" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Validation error / not escalated" },
          403: { description: "Only listener can initiate handoff" },
          404: { description: "Call not found" },
          409: { description: "Already transferred" },
        },
      },
    },
    "/api/v1/crisis/events/{voiceCallId}": {
      get: {
        tags: ["Crisis"],
        summary: "Get crisis events for call",
        description:
          "Get crisis events for a voice call. Accessible by call participants and admin/sub-admin.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "voiceCallId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Crisis events",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    voiceCallId: { type: "string", format: "uuid" },
                    events: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          session_type: {
                            type: "string",
                            enum: ["call", "chat"],
                          },
                          session_id: { type: "string", format: "uuid" },
                          risk_category: { type: "string" },
                          action_taken: { type: "string" },
                          created_at: { type: "string", format: "date-time" },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          403: { description: "Not authorized" },
          404: { description: "Call not found" },
        },
      },
    },
    "/api/v1/crisis/admin/stats": {
      get: {
        tags: ["Crisis", "Admin"],
        summary: "Get crisis analytics statistics",
        description:
          "Admin/sub-admin endpoint to analyze crisis events across call and chat sessions.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "from",
            in: "query",
            required: false,
            schema: { type: "string", format: "date-time" },
            description: "Inclusive lower bound for created_at filter",
          },
          {
            name: "to",
            in: "query",
            required: false,
            schema: { type: "string", format: "date-time" },
            description: "Inclusive upper bound for created_at filter",
          },
          {
            name: "sessionType",
            in: "query",
            required: false,
            schema: { type: "string", enum: ["call", "chat"] },
          },
          {
            name: "actionTaken",
            in: "query",
            required: false,
            schema: { type: "string" },
          },
          {
            name: "riskCategory",
            in: "query",
            required: false,
            schema: {
              type: "string",
              enum: [
                "self_harm",
                "suicide",
                "harm_to_others",
                "severe_distress",
                "other",
              ],
            },
          },
        ],
        responses: {
          200: {
            description: "Crisis analytics",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    filters: { type: "object" },
                    stats: {
                      type: "object",
                      properties: {
                        totals: {
                          type: "object",
                          properties: {
                            total_events: { type: "integer", example: 7 },
                            total_sessions: { type: "integer", example: 6 },
                            impacted_users: { type: "integer", example: 6 },
                            triggering_listeners: {
                              type: "integer",
                              example: 4,
                            },
                          },
                        },
                        bySessionType: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              session_type: { type: "string" },
                              count: { type: "integer" },
                            },
                          },
                        },
                        byRiskCategory: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              risk_category: { type: "string" },
                              count: { type: "integer" },
                            },
                          },
                        },
                        byActionTaken: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              action_taken: { type: "string" },
                              count: { type: "integer" },
                            },
                          },
                        },
                        daily: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              date: { type: "string", format: "date" },
                              count: { type: "integer" },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: { description: "Validation error" },
          403: { description: "Admin access required" },
        },
      },
    },

    // ============ Support Endpoints ============
    "/api/v1/support/appeals": {
      post: {
        tags: ["Support"],
        summary: "Submit an appeal",
        description:
          "Submit a platform appeal with reason, description, and optional attachment references",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["reason"],
                properties: {
                  reason: {
                    type: "string",
                    example: "account_restriction",
                  },
                  description: {
                    type: "string",
                    example: "I would like this moderation decision reviewed.",
                  },
                  attachments: {
                    type: "array",
                    items: { type: "string" },
                    example: [
                      "https://example.com/attachment-1.png",
                      "https://example.com/attachment-2.pdf",
                    ],
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Appeal submitted successfully",
          },
          400: { description: "Validation error" },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
    },
    "/api/v1/support/listener-appeals": {
      post: {
        tags: ["Support"],
        summary: "Submit appeal with document (listener or venter)",
        description:
          "Listener or venter endpoint to submit an appeal including contact info, report reference, summary, and a required PDF/DOC/DOCX document",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "multipart/form-data": {
              schema: {
                type: "object",
                required: ["contact", "reportId", "summary", "document"],
                properties: {
                  contact: {
                    type: "string",
                    example: "princesskaguya@gmail.com",
                    description: "Listener email or phone number",
                  },
                  reportId: {
                    type: "string",
                    example: "RPT-2026-00129",
                    description: "Report identifier tied to this appeal",
                  },
                  summary: {
                    type: "string",
                    example:
                      "I want to appeal this report and provide additional context.",
                  },
                  document: {
                    type: "string",
                    format: "binary",
                    description:
                      "Appeal document file (PDF, DOC, DOCX up to 10MB)",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Appeal submitted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    appeal: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        status: {
                          type: "string",
                          example: "submitted",
                        },
                        contact: {
                          type: "string",
                          example: "princesskaguya@gmail.com",
                        },
                        reportId: {
                          type: "string",
                          example: "RPT-2026-00129",
                        },
                        summary: {
                          type: "string",
                          example:
                            "I want to appeal this report and provide additional context.",
                        },
                        documentUrl: {
                          type: "string",
                          example:
                            "https://example-bucket.s3.us-east-1.amazonaws.com/support-appeals/user/file.pdf",
                        },
                        createdAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-02-25T09:30:00.000Z",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error or invalid file",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Validation error" },
                    message: {
                      type: "string",
                      example: "contact is required",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (listener or venter role required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example:
                        "This action requires listener or venter role. Your current role is admin",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Server error" },
                    message: {
                      type: "string",
                      example: "Failed to submit appeal",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/support/feedback": {
      post: {
        tags: ["Support"],
        summary: "Submit platform feedback",
        description:
          "Submit generic product feedback with a rating and optional comment",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["rating"],
                properties: {
                  rating: {
                    type: "number",
                    minimum: 1,
                    maximum: 5,
                    example: 5,
                  },
                  comment: {
                    type: "string",
                    example: "Great app experience overall.",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Feedback submitted successfully",
          },
          400: { description: "Validation error" },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
        },
      },
    },

    // ============ Report Endpoints ============
    "/api/v1/reports": {
      post: {
        tags: ["Reports"],
        summary: "Submit a user report",
        description:
          "Report a user for inappropriate behavior, harassment, or other violations. Reports must be linked to a specific call/chat session.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["reportedId", "sessionType", "sessionId", "reason"],
                properties: {
                  reportedId: {
                    type: "string",
                    format: "uuid",
                    description: "ID of the user being reported",
                    example: "987e6543-e21b-34d5-a678-426614174111",
                  },
                  sessionType: {
                    type: "string",
                    enum: ["call", "chat"],
                    description: "Type of session where incident occurred",
                    example: "call",
                  },
                  sessionId: {
                    type: "string",
                    format: "uuid",
                    description: "ID of session where incident occurred",
                    example: "123e4567-e89b-12d3-a456-426614174000",
                  },
                  reason: {
                    type: "string",
                    enum: [
                      "disruptive_behavior",
                      "bullying_or_harassment",
                      "danger_to_self_or_others",
                      "inappropriate_or_unsafe_response",
                    ],
                    example: "bullying_or_harassment",
                  },
                  description: {
                    type: "string",
                    maxLength: 1000,
                    description: "Detailed description of the incident",
                    example:
                      "User made repeated inappropriate comments during the call",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Report submitted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    report: { $ref: "#/components/schemas/Report" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/reports/my-reports": {
      get: {
        tags: ["Reports"],
        summary: "Get my submitted reports",
        description: "Get all reports submitted by the authenticated user.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            schema: { type: "integer", default: 20 },
          },
          {
            name: "offset",
            in: "query",
            schema: { type: "integer", default: 0 },
          },
          {
            name: "status",
            in: "query",
            schema: {
              type: "string",
              enum: ["pending", "reviewing", "resolved", "dismissed"],
            },
            description: "Filter by report status",
          },
        ],
        responses: {
          200: {
            description: "List of submitted reports",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    reports: {
                      type: "array",
                      items: { $ref: "#/components/schemas/Report" },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                        total: { type: "integer" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/reports/admin/all": {
      get: {
        tags: ["Reports", "Admin"],
        summary: "Get all reports (Admin)",
        description:
          "Get all reports in the system with filtering. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            schema: { type: "integer", default: 50 },
          },
          {
            name: "offset",
            in: "query",
            schema: { type: "integer", default: 0 },
          },
          {
            name: "status",
            in: "query",
            schema: {
              type: "string",
              enum: ["pending", "reviewing", "resolved", "dismissed"],
            },
          },
          {
            name: "reason",
            in: "query",
            schema: {
              type: "string",
              enum: [
                "disruptive_behavior",
                "bullying_or_harassment",
                "danger_to_self_or_others",
                "inappropriate_or_unsafe_response",
              ],
            },
          },
        ],
        responses: {
          200: {
            description: "List of all reports with statistics",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    reports: {
                      type: "array",
                      items: {
                        allOf: [
                          { $ref: "#/components/schemas/Report" },
                          {
                            type: "object",
                            properties: {
                              reporter_email: {
                                type: "string",
                                format: "email",
                              },
                              reported_email: {
                                type: "string",
                                format: "email",
                              },
                            },
                          },
                        ],
                      },
                    },
                    stats: {
                      type: "object",
                      properties: {
                        pending: { type: "integer" },
                        reviewing: { type: "integer" },
                        resolved: { type: "integer" },
                        dismissed: { type: "integer" },
                      },
                    },
                    pagination: { $ref: "#/components/schemas/Pagination" },
                  },
                },
              },
            },
          },
          403: {
            description: "Admin access required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/reports/admin/stats": {
      get: {
        tags: ["Reports", "Admin"],
        summary: "Get report statistics (Admin)",
        description:
          "Get comprehensive statistics about reports. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Report statistics",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    stats: {
                      type: "object",
                      properties: {
                        byStatus: {
                          type: "object",
                          additionalProperties: { type: "integer" },
                        },
                        byReason: {
                          type: "object",
                          additionalProperties: { type: "integer" },
                        },
                        last30Days: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              date: { type: "string", format: "date" },
                              count: { type: "integer" },
                            },
                          },
                        },
                        topReportedUsers: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              reported_id: {
                                type: "string",
                                format: "uuid",
                              },
                              email: { type: "string", format: "email" },
                              user_type: { type: "string" },
                              report_count: { type: "integer" },
                            },
                          },
                        },
                        applicationStatus24h: {
                          type: "object",
                          properties: {
                            window: {
                              type: "string",
                              example: "last_24_hours",
                            },
                            generatedAt: {
                              type: "string",
                              format: "date-time",
                            },
                            cards: {
                              type: "object",
                              properties: {
                                activeUsers: {
                                  type: "object",
                                  properties: {
                                    value: { type: "integer", example: 7265 },
                                    changePercent: {
                                      type: "number",
                                      format: "float",
                                      example: 11.01,
                                    },
                                  },
                                },
                                monthlySessions: {
                                  type: "object",
                                  properties: {
                                    value: { type: "integer", example: 3671 },
                                    changePercent: {
                                      type: "number",
                                      format: "float",
                                      example: -0.03,
                                    },
                                  },
                                },
                                newSignups: {
                                  type: "object",
                                  properties: {
                                    value: { type: "integer", example: 256 },
                                    changePercent: {
                                      type: "number",
                                      format: "float",
                                      example: 15.03,
                                    },
                                  },
                                },
                                listenerOnlineMinutes: {
                                  type: "object",
                                  properties: {
                                    value: { type: "integer", example: 2318 },
                                    changePercent: {
                                      type: "number",
                                      format: "float",
                                      example: 6.08,
                                    },
                                  },
                                },
                              },
                            },
                            userProgressEngagementRatio: {
                              type: "array",
                              items: {
                                type: "object",
                                properties: {
                                  hour: {
                                    type: "string",
                                    format: "date-time",
                                  },
                                  activeUsers: {
                                    type: "integer",
                                    example: 3140,
                                  },
                                  sessions: { type: "integer", example: 1020 },
                                  engagementRatio: {
                                    type: "number",
                                    format: "float",
                                    example: 3.08,
                                  },
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/reports/admin/{reportId}": {
      get: {
        tags: ["Reports", "Admin"],
        summary: "Get report details (Admin)",
        description:
          "Get detailed information about a specific report. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "reportId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Report details",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    report: {
                      allOf: [
                        { $ref: "#/components/schemas/Report" },
                        {
                          type: "object",
                          properties: {
                            reporter_email: {
                              type: "string",
                              format: "email",
                            },
                            reporter_type: { type: "string" },
                            reported_email: {
                              type: "string",
                              format: "email",
                            },
                            reported_type: { type: "string" },
                            reviewer_email: {
                              type: "string",
                              format: "email",
                            },
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Report not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Reports", "Admin"],
        summary: "Update report status (Admin)",
        description:
          "Update the status and add admin notes to a report. Accessible by admin and active sub-admin users with admin-panel edit permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "reportId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["status"],
                properties: {
                  status: {
                    type: "string",
                    enum: ["pending", "reviewing", "resolved", "dismissed"],
                    example: "resolved",
                  },
                  adminNotes: {
                    type: "string",
                    maxLength: 1000,
                    example: "Investigated and took appropriate action",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Report updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    report: { $ref: "#/components/schemas/Report" },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ========================================================================
    // BLOCK USER ENDPOINTS
    // ========================================================================

    "/users/{userId}/block": {
      post: {
        summary: "Block a user",
        description:
          "Block a user to prevent them from initiating calls or chats with you. Blocked users won't be matched in the system.",
        tags: ["Blocking"],
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "userId",
            in: "path",
            required: true,
            description: "ID of the user to block",
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          201: {
            description: "User blocked successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "User blocked successfully",
                    },
                    block: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        blockedAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error (e.g., trying to block yourself)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          409: {
            description: "User is already blocked",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      delete: {
        summary: "Unblock a user",
        description:
          "Remove a user from your blocked list, allowing them to interact with you again.",
        tags: ["Blocking"],
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "userId",
            in: "path",
            required: true,
            description: "ID of the user to unblock",
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "User unblocked successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "User unblocked successfully",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Block relationship not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/users/{userId}/blocked": {
      get: {
        summary: "Check if user is blocked",
        description:
          "Check the block status between you and another user (both directions).",
        tags: ["Blocking"],
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "userId",
            in: "path",
            required: true,
            description: "ID of the user to check",
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Block status",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    isBlocked: { type: "boolean", example: true },
                    blockType: {
                      type: "string",
                      enum: ["you_blocked", "blocked_by_them"],
                      example: "you_blocked",
                    },
                    blockedAt: { type: "string", format: "date-time" },
                  },
                },
              },
            },
          },
        },
      },
    },

    "/users/blocked": {
      get: {
        summary: "Get blocked users list",
        description: "Retrieve a paginated list of users you have blocked.",
        tags: ["Blocking"],
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "page",
            in: "query",
            required: false,
            description: "Page number (starts from 1)",
            schema: { type: "integer", default: 1, minimum: 1 },
          },
          {
            name: "limit",
            in: "query",
            required: false,
            description: "Number of items per page",
            schema: { type: "integer", default: 20, minimum: 1, maximum: 100 },
          },
        ],
        responses: {
          200: {
            description: "List of blocked users",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    blockedUsers: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          blocked_id: { type: "string", format: "uuid" },
                          username: { type: "string", example: "user123" },
                          role: { type: "string", example: "listener" },
                          blocked_at: { type: "string", format: "date-time" },
                        },
                      },
                    },
                    pagination: { $ref: "#/components/schemas/Pagination" },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ User Management Endpoints (Multi-Role) ============
    "/api/v1/users/switch-role": {
      post: {
        tags: ["User Management"],
        summary: "Switch user's active role",
        description:
          "Switch between available roles. Users can be both venter and listener, but only one role is active at a time. Role switching is blocked during active sessions.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["targetRole"],
                properties: {
                  targetRole: {
                    type: "string",
                    enum: ["venter", "listener"],
                    example: "listener",
                    description:
                      "The role to switch to (must be in availableRoles)",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Role switched successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Successfully switched to listener role",
                    },
                    tokens: {
                      type: "object",
                      properties: {
                        accessToken: {
                          type: "string",
                          description: "New JWT access token with updated role",
                        },
                        refreshToken: {
                          type: "string",
                          description: "New refresh token",
                        },
                      },
                    },
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        activeRole: {
                          type: "string",
                          example: "listener",
                          description: "The newly active role",
                        },
                        availableRoles: {
                          type: "array",
                          items: { type: "string" },
                          example: ["venter", "listener"],
                          description: "All roles user can switch between",
                        },
                        userType: {
                          type: "string",
                          description:
                            "Backward compatibility field (equals activeRole)",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid role",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Invalid role" },
                    message: { type: "string" },
                  },
                },
              },
            },
          },
          403: {
            description: "Role not available to user",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Role not available" },
                    message: {
                      type: "string",
                      example:
                        "You don't have access to the listener role. Available roles: venter",
                    },
                  },
                },
              },
            },
          },
          409: {
            description: "Active session prevents role switch",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Active session" },
                    message: {
                      type: "string",
                      example:
                        "Cannot switch roles while you have an active call. Please end your current session first.",
                    },
                    activeSession: {
                      type: "object",
                      properties: {
                        type: {
                          type: "string",
                          enum: ["call", "chat"],
                          example: "call",
                        },
                        id: { type: "string", format: "uuid" },
                        status: { type: "string", example: "in-progress" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/users/roles": {
      get: {
        tags: ["User Management"],
        summary: "Get user's current role configuration",
        description:
          "Returns the user's active role and all available roles they can switch to",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "User role configuration",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    availableRoles: {
                      type: "array",
                      items: { type: "string" },
                      example: ["venter", "listener"],
                      description: "All roles user can switch to",
                    },
                    activeRole: {
                      type: "string",
                      example: "venter",
                      description: "Currently active role",
                    },
                    userType: {
                      type: "string",
                      example: "venter",
                      description:
                        "Backward compatibility field (equals activeRole)",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/users/available-roles": {
      put: {
        tags: ["User Management"],
        summary: "Add or remove roles from user's available roles",
        description:
          "Allows users to add or remove roles from their available roles. Cannot remove currently active role. Cannot add privileged roles (admin, sub_admin) via this endpoint.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  rolesToAdd: {
                    type: "array",
                    items: {
                      type: "string",
                      enum: ["venter", "listener"],
                    },
                    example: ["listener"],
                    description: "Roles to add to available roles",
                    default: [],
                  },
                  rolesToRemove: {
                    type: "array",
                    items: {
                      type: "string",
                      enum: ["venter", "listener"],
                    },
                    example: [],
                    description: "Roles to remove from available roles",
                    default: [],
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Roles updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Available roles updated successfully",
                    },
                    tokens: {
                      type: "object",
                      properties: {
                        accessToken: {
                          type: "string",
                          description: "New JWT with updated available roles",
                        },
                        refreshToken: { type: "string" },
                      },
                    },
                    user: {
                      type: "object",
                      properties: {
                        availableRoles: {
                          type: "array",
                          items: { type: "string" },
                          example: ["venter", "listener"],
                        },
                        activeRole: {
                          type: "string",
                          example: "venter",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid operation (e.g., removing active role)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Invalid operation" },
                    message: {
                      type: "string",
                      example:
                        "Cannot remove your currently active role. Please switch roles first.",
                    },
                  },
                },
              },
            },
          },
          403: {
            description: "Forbidden (e.g., attempting to add privileged role)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example: "Cannot add privileged roles via this endpoint",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    "/api/v1/admin-settings/ai": {
      get: {
        tags: ["Admin", "Settings"],
        summary: "Get AI admin settings",
        description:
          "Fetch current AI settings used by the Admin Settings AI screen. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "AI settings retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    settings: {
                      type: "object",
                      properties: {
                        ai_enabled: { type: "boolean", example: false },
                        ai_crisis_detection_enabled: {
                          type: "boolean",
                          example: false,
                        },
                        ai_crisis_sensitivity: {
                          type: "number",
                          example: 0.7,
                        },
                        ai_auto_escalation_enabled: {
                          type: "boolean",
                          example: false,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example: "This action requires admin or sub-admin access",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Server error" },
                    message: {
                      type: "string",
                      example: "Failed to fetch AI settings",
                    },
                  },
                },
              },
            },
          },
        },
      },
      put: {
        tags: ["Admin", "Settings"],
        summary: "Update AI admin settings",
        description:
          "Update one or more AI settings used by the Admin Settings AI screen. Accessible by admin and active sub-admin users with admin-panel edit permission.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                additionalProperties: false,
                properties: {
                  ai_enabled: { type: "boolean", example: true },
                  ai_crisis_detection_enabled: {
                    type: "boolean",
                    example: true,
                  },
                  ai_crisis_sensitivity: {
                    type: "number",
                    minimum: 0,
                    maximum: 1,
                    example: 0.85,
                  },
                  ai_auto_escalation_enabled: {
                    type: "boolean",
                    example: true,
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "AI settings updated successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    message: {
                      type: "string",
                      example: "AI settings updated successfully",
                    },
                    settings: {
                      type: "object",
                      properties: {
                        ai_enabled: { type: "boolean", example: true },
                        ai_crisis_detection_enabled: {
                          type: "boolean",
                          example: true,
                        },
                        ai_crisis_sensitivity: {
                          type: "number",
                          example: 0.85,
                        },
                        ai_auto_escalation_enabled: {
                          type: "boolean",
                          example: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Validation error" },
                    message: {
                      type: "string",
                      example:
                        "ai_crisis_sensitivity must be less than or equal to 1",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example: "Insufficient permissions",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Server error" },
                    message: {
                      type: "string",
                      example: "Failed to update AI settings",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ Sub Admin Management Endpoints ============
    "/api/v1/sub-admins": {
      get: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "List sub-admin accounts",
        description: "Get all sub-admin users and their permission profiles.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Sub-admin list retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    subAdmins: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          email: { type: "string", format: "email" },
                          phone: { type: "string", nullable: true },
                          userType: {
                            type: "string",
                            enum: ["sub_admin"],
                            example: "sub_admin",
                          },
                          activeRole: {
                            type: "string",
                            enum: ["sub_admin"],
                            example: "sub_admin",
                          },
                          availableRoles: {
                            type: "array",
                            items: { type: "string", enum: ["sub_admin"] },
                            example: ["sub_admin"],
                          },
                          isVerified: { type: "boolean", example: true },
                          isActive: { type: "boolean", example: true },
                          status: {
                            type: "string",
                            enum: ["pending", "active", "suspended"],
                          },
                          permissions: {
                            type: "object",
                            properties: {
                              view: { type: "boolean" },
                              edit: { type: "boolean" },
                              delete: { type: "boolean" },
                              suspend: { type: "boolean" },
                              accessAdminPanel: { type: "boolean" },
                            },
                          },
                          createdBy: {
                            type: "string",
                            format: "uuid",
                            nullable: true,
                          },
                          createdAt: { type: "string", format: "date-time" },
                          updatedAt: { type: "string", format: "date-time" },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden (admin role required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      post: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "Create sub-admin account",
        description:
          "Create a new sub-admin account with initial feature permissions. Newly created sub-admins start with pending status.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "password"],
                properties: {
                  email: {
                    type: "string",
                    format: "email",
                    example: "subadmin@example.com",
                  },
                  password: {
                    type: "string",
                    format: "password",
                    minLength: 8,
                    example: "SubAdmin123",
                  },
                  phone: {
                    type: "string",
                    nullable: true,
                    example: "+15551234567",
                  },
                  permissions: {
                    type: "object",
                    properties: {
                      view: { type: "boolean", example: true },
                      edit: { type: "boolean", example: true },
                      delete: { type: "boolean", example: false },
                      suspend: { type: "boolean", example: false },
                      accessAdminPanel: { type: "boolean", example: true },
                    },
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Sub-admin created",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Sub-admin created successfully",
                    },
                    subAdmin: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        status: {
                          type: "string",
                          enum: ["pending"],
                          example: "pending",
                        },
                        permissions: {
                          type: "object",
                          properties: {
                            view: { type: "boolean" },
                            edit: { type: "boolean" },
                            delete: { type: "boolean" },
                            suspend: { type: "boolean" },
                            accessAdminPanel: { type: "boolean" },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          409: {
            description: "Conflict (email already exists)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/sub-admins/pending": {
      get: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "List pending sub-admin requests",
        description:
          "Get sub-admin accounts currently in pending onboarding status.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Pending sub-admin requests retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    pendingRequests: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          email: { type: "string", format: "email" },
                          status: {
                            type: "string",
                            enum: ["pending"],
                            example: "pending",
                          },
                          permissions: {
                            type: "object",
                            properties: {
                              view: { type: "boolean" },
                              edit: { type: "boolean" },
                              delete: { type: "boolean" },
                              suspend: { type: "boolean" },
                              accessAdminPanel: { type: "boolean" },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/sub-admins/{subAdminId}": {
      get: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "Get sub-admin profile",
        description: "Fetch one sub-admin account with permission profile.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "subAdminId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Sub-admin profile retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    subAdmin: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        status: {
                          type: "string",
                          enum: ["pending", "active", "suspended"],
                        },
                        permissions: {
                          type: "object",
                          properties: {
                            view: { type: "boolean" },
                            edit: { type: "boolean" },
                            delete: { type: "boolean" },
                            suspend: { type: "boolean" },
                            accessAdminPanel: { type: "boolean" },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Sub-admin not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "Update sub-admin permissions",
        description:
          "Update sub-admin feature-level permission toggles (view/edit/delete/suspend/accessAdminPanel). Only provided keys are changed; omitted keys retain existing values.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "subAdminId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["permissions"],
                properties: {
                  permissions: {
                    type: "object",
                    properties: {
                      view: { type: "boolean", example: true },
                      edit: { type: "boolean", example: false },
                      delete: { type: "boolean", example: false },
                      suspend: { type: "boolean", example: true },
                      accessAdminPanel: { type: "boolean", example: true },
                    },
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Sub-admin permissions updated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Sub-admin updated successfully",
                    },
                    subAdmin: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        permissions: {
                          type: "object",
                          properties: {
                            view: { type: "boolean" },
                            edit: { type: "boolean" },
                            delete: { type: "boolean" },
                            suspend: { type: "boolean" },
                            accessAdminPanel: { type: "boolean" },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid permissions payload",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Sub-admin not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      delete: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "Delete sub-admin account",
        description: "Delete a sub-admin account and its permission profile.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "subAdminId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Sub-admin deleted",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Sub-admin deleted successfully",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Sub-admin not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/sub-admins/{subAdminId}/status": {
      put: {
        tags: ["Sub Admin Management", "Admin"],
        summary: "Update sub-admin status",
        description:
          "Update sub-admin lifecycle status (pending, active, suspended).",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "subAdminId",
            in: "path",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["status"],
                properties: {
                  status: {
                    type: "string",
                    enum: ["pending", "active", "suspended"],
                    example: "active",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Sub-admin status updated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Sub-admin status updated successfully",
                    },
                    subAdmin: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        status: {
                          type: "string",
                          enum: ["pending", "active", "suspended"],
                        },
                        isActive: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid status",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Sub-admin not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Listener Verification Endpoints ============
    "/api/v1/listener-verifications": {
      post: {
        tags: ["Listener Verification"],
        summary: "Submit verification document",
        description:
          "Listener uploads a verification document for admin review. Accepts PDF, PNG, JPG, and JPEG files up to 10MB.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "multipart/form-data": {
              schema: {
                type: "object",
                required: ["document"],
                properties: {
                  document: {
                    type: "string",
                    format: "binary",
                    description:
                      "Verification document file. Allowed MIME: application/pdf, image/png, image/jpeg, image/jpg. Max size: 10MB.",
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Verification document submitted",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    verification: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        status: {
                          type: "string",
                          enum: ["pending", "approved", "rejected"],
                          example: "pending",
                        },
                        createdAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-02-25T10:20:30.000Z",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error or invalid file upload",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Invalid file" },
                    message: {
                      type: "string",
                      example:
                        "Invalid file type for verification document. Received: text/plain",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (listener role required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example:
                        "Access denied. This endpoint is for listener users only.",
                    },
                  },
                },
              },
            },
          },
          409: {
            description: "Pending verification already exists",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: {
                      type: "string",
                      example: "Pending verification exists",
                    },
                    message: {
                      type: "string",
                      example:
                        "You already have a pending verification document. Please wait for admin review.",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Submission failed" },
                    message: {
                      type: "string",
                      example: "Failed to upload verification document",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/listener-verifications/me": {
      get: {
        tags: ["Listener Verification"],
        summary: "Get my verification submissions",
        description:
          "List verification document submissions for the authenticated listener",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "limit",
            required: false,
            schema: { type: "integer", minimum: 1, maximum: 100, default: 10 },
            description: "Maximum number of submissions to return",
          },
          {
            in: "query",
            name: "offset",
            required: false,
            schema: { type: "integer", minimum: 0, default: 0 },
            description: "Number of submissions to skip",
          },
        ],
        responses: {
          200: {
            description: "Verification submissions retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submissions: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          status: {
                            type: "string",
                            enum: ["pending", "approved", "rejected"],
                            example: "pending",
                          },
                          admin_notes: {
                            type: "string",
                            nullable: true,
                            example: "Please upload a clearer scan",
                          },
                          reviewed_at: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                          created_at: {
                            type: "string",
                            format: "date-time",
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (listener role required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example:
                        "Access denied. This endpoint is for listener users only.",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Fetch failed" },
                    message: {
                      type: "string",
                      example: "Failed to fetch verification submissions",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/listener-verifications/admin/all": {
      get: {
        tags: ["Listener Verification"],
        summary: "List listener verification submissions (admin)",
        description:
          "Admin endpoint to list listener verification submissions with optional status filtering. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "status",
            required: false,
            schema: {
              type: "string",
              enum: ["pending", "approved", "rejected"],
            },
            description: "Filter by submission status",
          },
          {
            in: "query",
            name: "limit",
            required: false,
            schema: { type: "integer", minimum: 1, maximum: 200, default: 50 },
            description: "Maximum number of submissions to return",
          },
          {
            in: "query",
            name: "offset",
            required: false,
            schema: { type: "integer", minimum: 0, default: 0 },
            description: "Number of submissions to skip",
          },
        ],
        responses: {
          200: {
            description: "Verification submissions retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submissions: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          listener_id: { type: "string", format: "uuid" },
                          listener_email: {
                            type: "string",
                            format: "email",
                            example: "listener@example.com",
                          },
                          status: {
                            type: "string",
                            enum: ["pending", "approved", "rejected"],
                            example: "pending",
                          },
                          mime_type: {
                            type: "string",
                            example: "application/pdf",
                          },
                          original_file_name: {
                            type: "string",
                            example: "license.pdf",
                          },
                          created_at: { type: "string", format: "date-time" },
                          reviewed_at: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                          reviewed_by: {
                            type: "string",
                            format: "uuid",
                            nullable: true,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example: "Insufficient permissions",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Fetch failed" },
                    message: {
                      type: "string",
                      example: "Failed to fetch submissions",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/listener-verifications/admin/{verificationId}": {
      get: {
        tags: ["Listener Verification"],
        summary: "Get verification submission detail (admin)",
        description:
          "Admin endpoint to fetch one verification submission, including document access URL. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "verificationId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Verification submission ID",
          },
        ],
        responses: {
          200: {
            description: "Verification submission retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submission: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        listener_id: { type: "string", format: "uuid" },
                        listener_email: {
                          type: "string",
                          format: "email",
                          example: "listener@example.com",
                        },
                        status: {
                          type: "string",
                          enum: ["pending", "approved", "rejected"],
                        },
                        s3_key: {
                          type: "string",
                          nullable: true,
                          example:
                            "listener-verification/8b5f9f57-a56a-457d-95a6-85023d53a7f7/21de7047-cf31-4f4d-bde2-225a4c74c4d2-license.pdf",
                        },
                        file_url: {
                          type: "string",
                          nullable: true,
                          example:
                            "https://bucket.s3.amazonaws.com/listener-verification/...",
                        },
                        mime_type: {
                          type: "string",
                          example: "application/pdf",
                        },
                        original_file_name: {
                          type: "string",
                          example: "license.pdf",
                        },
                        file_size_bytes: { type: "integer", example: 542111 },
                        admin_notes: {
                          type: "string",
                          nullable: true,
                          example: "Document verified successfully",
                        },
                        reviewed_by: {
                          type: "string",
                          format: "uuid",
                          nullable: true,
                        },
                        reviewed_at: {
                          type: "string",
                          format: "date-time",
                          nullable: true,
                        },
                        s3_deleted_at: {
                          type: "string",
                          format: "date-time",
                          nullable: true,
                        },
                        created_at: { type: "string", format: "date-time" },
                        updated_at: { type: "string", format: "date-time" },
                        document_url: {
                          type: "string",
                          nullable: true,
                          example:
                            "https://bucket.s3.amazonaws.com/listener-verification/...presigned",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example: "Insufficient permissions",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Submission not found",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Not found" },
                    message: {
                      type: "string",
                      example: "Verification submission not found",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Fetch failed" },
                    message: {
                      type: "string",
                      example: "Failed to fetch submission",
                    },
                  },
                },
              },
            },
          },
        },
      },
      put: {
        tags: ["Listener Verification"],
        summary: "Review verification submission (admin)",
        description:
          "Admin approves or rejects a pending listener verification submission. Accessible by admin and active sub-admin users with admin-panel edit permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "verificationId",
            required: true,
            schema: { type: "string", format: "uuid" },
            description: "Verification submission ID",
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["status"],
                properties: {
                  status: {
                    type: "string",
                    enum: ["verified", "rejected"],
                    description:
                      "Admin decision. `verified` is normalized to `approved` in API responses.",
                    example: "verified",
                  },
                  adminNotes: {
                    type: "string",
                    nullable: true,
                    example: "Document is valid and approved.",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Submission reviewed",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submission: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        listener_id: { type: "string", format: "uuid" },
                        status: {
                          type: "string",
                          enum: ["approved", "rejected"],
                          example: "approved",
                        },
                        reviewed_at: {
                          type: "string",
                          format: "date-time",
                        },
                        s3_deleted_at: {
                          type: "string",
                          format: "date-time",
                          nullable: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Validation error" },
                    message: {
                      type: "string",
                      example: "status must be one of: verified, rejected",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Forbidden" },
                    message: {
                      type: "string",
                      example: "Insufficient permissions",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "Submission not found",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Not found" },
                    message: {
                      type: "string",
                      example: "Verification submission not found",
                    },
                  },
                },
              },
            },
          },
          409: {
            description: "Submission is not pending",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Invalid state" },
                    message: {
                      type: "string",
                      example:
                        "Only pending submissions can be reviewed. Current status: rejected",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Review failed" },
                    message: {
                      type: "string",
                      example: "Failed to review verification submission",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ Admin User Management Endpoints ============
    "/api/v1/admin/integrations": {
      get: {
        tags: ["Admin"],
        summary: "List exports and integrations users",
        description:
          "List non-privileged users for admin exports/integrations screens with search, role, status, and pagination.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "search",
            required: false,
            schema: { type: "string" },
          },
          {
            in: "query",
            name: "userId",
            required: false,
            schema: { type: "string", format: "uuid" },
          },
          {
            in: "query",
            name: "role",
            required: false,
            schema: {
              type: "string",
              enum: ["venter", "listener", "both"],
            },
          },
          {
            in: "query",
            name: "status",
            required: false,
            schema: {
              type: "string",
              enum: ["exported", "pending", "not_exported"],
            },
          },
          {
            in: "query",
            name: "limit",
            required: false,
            schema: { type: "integer", minimum: 1, maximum: 100, default: 20 },
          },
          {
            in: "query",
            name: "offset",
            required: false,
            schema: { type: "integer", minimum: 0, default: 0 },
          },
        ],
        responses: {
          200: {
            description: "Integrations list retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    items: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          email: { type: "string", format: "email" },
                          accountType: {
                            type: "string",
                            enum: ["venter", "listener", "both", "unknown"],
                          },
                          stats: {
                            type: "object",
                            properties: {
                              totalSessions: { type: "integer" },
                              totalMinutes: { type: "integer" },
                              totalPayout: { type: "number" },
                            },
                          },
                          exportStatus: {
                            type: "string",
                            enum: ["exported", "pending"],
                          },
                          exportedAt: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer" },
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/admin/integrations/export/pdf": {
      get: {
        tags: ["Admin"],
        summary: "Export integrations as PDF",
        description:
          "Export admin integrations list to a downloadable PDF. Supports the same filters as list integrations.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "search",
            required: false,
            schema: { type: "string" },
          },
          {
            in: "query",
            name: "userId",
            required: false,
            schema: { type: "string", format: "uuid" },
          },
          {
            in: "query",
            name: "role",
            required: false,
            schema: {
              type: "string",
              enum: ["venter", "listener", "both"],
            },
          },
          {
            in: "query",
            name: "status",
            required: false,
            schema: {
              type: "string",
              enum: ["exported", "pending", "not_exported"],
            },
          },
          {
            in: "query",
            name: "maxRows",
            required: false,
            schema: {
              type: "integer",
              minimum: 1,
              maximum: 1000,
              default: 250,
            },
          },
        ],
        responses: {
          200: {
            description: "PDF file generated",
            content: {
              "application/pdf": {
                schema: {
                  type: "string",
                  format: "binary",
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/integrations/{userId}/export-status": {
      put: {
        tags: ["Admin"],
        summary: "Update user export status",
        description:
          "Update export status for a non-privileged user in admin exports/integrations screens.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "userId",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["exported"],
                properties: {
                  exported: { type: "boolean", example: true },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Export status updated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    integration: {
                      type: "object",
                      properties: {
                        userId: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        exportStatus: {
                          type: "string",
                          enum: ["exported", "pending"],
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/payments/history": {
      get: {
        tags: ["Admin"],
        summary: "List payment history",
        description:
          "List checkout payment history across users for admin payment history screens.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "search",
            required: false,
            schema: { type: "string" },
          },
          {
            in: "query",
            name: "userId",
            required: false,
            schema: { type: "string", format: "uuid" },
          },
          {
            in: "query",
            name: "status",
            required: false,
            schema: {
              type: "string",
              enum: ["pending", "completed", "expired", "failed"],
            },
          },
          {
            in: "query",
            name: "from",
            required: false,
            schema: { type: "string", format: "date-time" },
          },
          {
            in: "query",
            name: "to",
            required: false,
            schema: { type: "string", format: "date-time" },
          },
          {
            in: "query",
            name: "limit",
            required: false,
            schema: { type: "integer", minimum: 1, maximum: 100, default: 20 },
          },
          {
            in: "query",
            name: "offset",
            required: false,
            schema: { type: "integer", minimum: 0, default: 0 },
          },
        ],
        responses: {
          200: {
            description: "Payment history retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    payments: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string" },
                          amount: { type: "number", nullable: true },
                          currency: { type: "string", nullable: true },
                          status: { type: "string" },
                          mode: { type: "string", nullable: true },
                          createdAt: { type: "string", format: "date-time" },
                          completedAt: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                          user: {
                            type: "object",
                            properties: {
                              id: { type: "string", format: "uuid" },
                              email: { type: "string", format: "email" },
                            },
                          },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer" },
                        limit: { type: "integer" },
                        offset: { type: "integer" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/payments/history/export/pdf": {
      get: {
        tags: ["Admin"],
        summary: "Export payment history as PDF",
        description:
          "Export admin payment history to a downloadable PDF. Supports the same filters as payment history list.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "search",
            required: false,
            schema: { type: "string" },
          },
          {
            in: "query",
            name: "userId",
            required: false,
            schema: { type: "string", format: "uuid" },
          },
          {
            in: "query",
            name: "status",
            required: false,
            schema: {
              type: "string",
              enum: ["pending", "completed", "expired", "failed"],
            },
          },
          {
            in: "query",
            name: "from",
            required: false,
            schema: { type: "string", format: "date-time" },
          },
          {
            in: "query",
            name: "to",
            required: false,
            schema: { type: "string", format: "date-time" },
          },
          {
            in: "query",
            name: "maxRows",
            required: false,
            schema: {
              type: "integer",
              minimum: 1,
              maximum: 1000,
              default: 250,
            },
          },
        ],
        responses: {
          200: {
            description: "PDF file generated",
            content: {
              "application/pdf": {
                schema: {
                  type: "string",
                  format: "binary",
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/payments/stats": {
      get: {
        tags: ["Admin"],
        summary: "Get admin finance payment stats",
        description:
          "Returns admin finance stats for dashboard cards/charts: weekly revenue increase (last 7 days vs previous 7 days), next expected revenue (next 7 days), and weekly sales trend (last 8 weeks).",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Admin payment stats retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    generatedAt: { type: "string", format: "date-time" },
                    currency: { type: "string", example: "USD" },
                    weeklyRevenueIncrease: {
                      type: "object",
                      properties: {
                        windowDays: { type: "integer", example: 7 },
                        currentRevenue: { type: "number", example: 1234.56 },
                        previousRevenue: {
                          type: "number",
                          example: 1120.12,
                        },
                        increasePercent: { type: "number", example: 10.22 },
                      },
                    },
                    nextExpectedRevenue: {
                      type: "object",
                      properties: {
                        windowDays: { type: "integer", example: 7 },
                        totalRevenue: { type: "number", example: 1500.0 },
                        subscriptionCount: { type: "integer", example: 18 },
                        stripeInvoiceCount: { type: "integer", example: 15 },
                        fallbackEstimateCount: { type: "integer", example: 3 },
                        fromDate: { type: "string", format: "date-time" },
                        toDate: { type: "string", format: "date-time" },
                      },
                    },
                    weeklySalesData: {
                      type: "object",
                      properties: {
                        windowWeeks: { type: "integer", example: 8 },
                        series: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              weekStart: {
                                type: "string",
                                format: "date-time",
                              },
                              weekEnd: {
                                type: "string",
                                format: "date-time",
                              },
                              revenue: { type: "number", example: 2450.75 },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/users": {
      get: {
        tags: ["Admin"],
        summary: "List users for admin moderation",
        description:
          "List non-privileged users for admin moderation screens with search, role filtering, and pagination. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "search",
            required: false,
            schema: { type: "string" },
            description: "Search by user email or user ID",
          },
          {
            in: "query",
            name: "role",
            required: false,
            schema: {
              type: "string",
              enum: ["venter", "listener", "both"],
            },
            description: "Filter by account role composition",
          },
          {
            in: "query",
            name: "limit",
            required: false,
            schema: { type: "integer", minimum: 1, maximum: 100, default: 20 },
            description: "Maximum number of users to return",
          },
          {
            in: "query",
            name: "offset",
            required: false,
            schema: { type: "integer", minimum: 0, default: 0 },
            description: "Number of users to skip",
          },
        ],
        responses: {
          200: {
            description: "Users retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    users: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          email: { type: "string", format: "email" },
                          activeRole: { type: "string" },
                          availableRoles: {
                            type: "array",
                            items: { type: "string" },
                          },
                          accountType: {
                            type: "string",
                            enum: ["venter", "listener", "both", "unknown"],
                          },
                          isActive: { type: "boolean" },
                          stats: {
                            type: "object",
                            properties: {
                              totalSessions: { type: "integer", example: 42 },
                              totalMinutes: { type: "integer", example: 318 },
                              totalPayout: { type: "number", example: 64.5 },
                            },
                          },
                          createdAt: { type: "string", format: "date-time" },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: { type: "integer", example: 125 },
                        limit: { type: "integer", example: 20 },
                        offset: { type: "integer", example: 0 },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      delete: {
        tags: ["Admin"],
        summary: "Bulk delete users",
        description:
          "Delete multiple non-privileged users in one request. Accessible by admin and active sub-admin users with admin-panel delete permission.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["userIds"],
                properties: {
                  userIds: {
                    type: "array",
                    items: { type: "string", format: "uuid" },
                    minItems: 1,
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Users deleted",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    deletedCount: { type: "integer" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/users/roles": {
      put: {
        tags: ["Admin"],
        summary: "Bulk change user roles",
        description:
          "Update available roles for multiple non-privileged users. targetRole supports venter, listener, or both.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["userIds", "targetRole"],
                properties: {
                  userIds: {
                    type: "array",
                    items: { type: "string", format: "uuid" },
                    minItems: 1,
                  },
                  targetRole: {
                    type: "string",
                    enum: ["venter", "listener", "both"],
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "User roles updated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: { type: "string" },
                    updatedCount: { type: "integer" },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/users/{userId}": {
      get: {
        tags: ["Admin"],
        summary: "Get comprehensive user detail for moderation",
        description:
          "Get comprehensive non-sensitive user profile data, listener attributes, engagement stats, and document metadata for admin moderation screens, including verification document links/states and signature document state. Response includes both the new documents object and backward-compatible verificationDocuments array. Accessible by admin and active sub-admin users with admin-panel view permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "userId",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "User detail retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        phone: { type: "string", nullable: true },
                        firstName: { type: "string", nullable: true },
                        lastName: { type: "string", nullable: true },
                        displayName: { type: "string", nullable: true },
                        profilePictureUrl: { type: "string", nullable: true },
                        bio: { type: "string", nullable: true },
                        dateOfBirth: {
                          type: "string",
                          format: "date",
                          nullable: true,
                        },
                        userType: { type: "string" },
                        activeRole: { type: "string" },
                        availableRoles: {
                          type: "array",
                          items: { type: "string" },
                        },
                        accountType: {
                          type: "string",
                          enum: ["venter", "listener", "both", "unknown"],
                        },
                        isVerified: { type: "boolean" },
                        isActive: { type: "boolean" },
                        listenerSignature: { type: "string", nullable: true },
                        security: {
                          type: "object",
                          properties: {
                            twoFactorAuthentication: {
                              type: "object",
                              properties: {
                                enabled: { type: "boolean" },
                                method: {
                                  type: "string",
                                  nullable: true,
                                  enum: ["sms", "email", "authenticator_app"],
                                },
                              },
                            },
                          },
                        },
                        stats: {
                          type: "object",
                          properties: {
                            totalSessions: { type: "integer" },
                            totalMinutes: { type: "integer" },
                            totalPayout: { type: "number" },
                          },
                        },
                        listenerInfo: {
                          type: "object",
                          properties: {
                            genderIdentity: { type: "string", nullable: true },
                            culturalBackground: {
                              type: "string",
                              nullable: true,
                            },
                            language: { type: "string", nullable: true },
                            ethnicity: { type: "string", nullable: true },
                            ageGroup: { type: "string", nullable: true },
                            lgbtqIdentity: { type: "string", nullable: true },
                            specialTopics: {
                              type: "array",
                              items: { type: "string" },
                            },
                            faithOrBelief: { type: "string", nullable: true },
                            verificationStatus: {
                              type: "string",
                              enum: [
                                "not_submitted",
                                "pending",
                                "approved",
                                "rejected",
                              ],
                            },
                          },
                        },
                        documents: {
                          type: "object",
                          properties: {
                            verification: {
                              type: "array",
                              items: {
                                type: "object",
                                properties: {
                                  id: { type: "string", format: "uuid" },
                                  status: {
                                    type: "string",
                                    enum: ["pending", "approved", "rejected"],
                                  },
                                  state: {
                                    type: "string",
                                    enum: ["pending", "approved", "rejected"],
                                  },
                                  fileUrl: { type: "string", nullable: true },
                                  originalFileName: {
                                    type: "string",
                                    nullable: true,
                                  },
                                  mimeType: { type: "string", nullable: true },
                                  fileSizeBytes: {
                                    type: "integer",
                                    nullable: true,
                                  },
                                  reviewedBy: {
                                    type: "string",
                                    format: "uuid",
                                    nullable: true,
                                  },
                                  reviewedAt: {
                                    type: "string",
                                    format: "date-time",
                                    nullable: true,
                                  },
                                  adminNotes: {
                                    type: "string",
                                    nullable: true,
                                  },
                                  isDeleted: { type: "boolean" },
                                  deletedAt: {
                                    type: "string",
                                    format: "date-time",
                                    nullable: true,
                                  },
                                  createdAt: {
                                    type: "string",
                                    format: "date-time",
                                  },
                                },
                              },
                            },
                            signature: {
                              type: "object",
                              properties: {
                                type: { type: "string", enum: ["signature"] },
                                status: {
                                  type: "string",
                                  enum: ["available", "missing"],
                                },
                                state: {
                                  type: "string",
                                  enum: ["available", "missing"],
                                },
                                fileUrl: { type: "string", nullable: true },
                                createdAt: {
                                  type: "string",
                                  format: "date-time",
                                },
                                updatedAt: {
                                  type: "string",
                                  format: "date-time",
                                },
                              },
                            },
                          },
                        },
                        verificationDocuments: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              id: { type: "string", format: "uuid" },
                              status: {
                                type: "string",
                                enum: ["pending", "approved", "rejected"],
                              },
                              state: {
                                type: "string",
                                enum: ["pending", "approved", "rejected"],
                              },
                              fileUrl: { type: "string", nullable: true },
                              originalFileName: {
                                type: "string",
                                nullable: true,
                              },
                              mimeType: { type: "string", nullable: true },
                              fileSizeBytes: {
                                type: "integer",
                                nullable: true,
                              },
                              reviewedBy: {
                                type: "string",
                                format: "uuid",
                                nullable: true,
                              },
                              reviewedAt: {
                                type: "string",
                                format: "date-time",
                                nullable: true,
                              },
                              adminNotes: { type: "string", nullable: true },
                              isDeleted: { type: "boolean" },
                              deletedAt: {
                                type: "string",
                                format: "date-time",
                                nullable: true,
                              },
                              createdAt: {
                                type: "string",
                                format: "date-time",
                              },
                            },
                          },
                        },
                        createdAt: { type: "string", format: "date-time" },
                        updatedAt: { type: "string", format: "date-time" },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      delete: {
        tags: ["Admin"],
        summary: "Delete user account",
        description:
          "Delete a non-privileged user account. Admin and sub-admin users cannot be deleted by this endpoint. Accessible by admin and active sub-admin users with admin-panel delete permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "userId",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "User deleted",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "User deleted successfully",
                    },
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid operation (self-delete attempted)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description:
              "Forbidden (admin/sub-admin target or insufficient permission)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/users/{userId}/suspend": {
      put: {
        tags: ["Admin"],
        summary: "Suspend or reactivate a user",
        description:
          "Suspend or reactivate a non-privileged user account by toggling isActive. Accessible by admin and active sub-admin users with admin-panel suspend permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "userId",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        requestBody: {
          required: false,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  suspended: {
                    type: "boolean",
                    default: true,
                    description:
                      "When true, suspend user. When false, reactivate user.",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "User suspension state updated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "User suspended successfully",
                    },
                    user: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        email: { type: "string", format: "email" },
                        isActive: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid operation (self-suspend attempted)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description:
              "Forbidden (admin/sub-admin target or insufficient permission)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "User not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/listener-requests": {
      get: {
        tags: ["Admin", "Listener Verification"],
        summary: "List listener requests (admin alias)",
        description:
          "Alias endpoint for listing listener verification submissions for admin moderation screens. Response matches /api/v1/listener-verifications/admin/all.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "query",
            name: "status",
            required: false,
            schema: {
              type: "string",
              enum: ["pending", "approved", "rejected"],
            },
          },
          {
            in: "query",
            name: "limit",
            required: false,
            schema: { type: "integer", minimum: 1, maximum: 200, default: 50 },
          },
          {
            in: "query",
            name: "offset",
            required: false,
            schema: { type: "integer", minimum: 0, default: 0 },
          },
        ],
        responses: {
          200: {
            description: "Listener requests retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submissions: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: { type: "string", format: "uuid" },
                          listener_id: { type: "string", format: "uuid" },
                          listener_email: { type: "string", format: "email" },
                          gender_identity: { type: "string", nullable: true },
                          preferred_language: {
                            type: "string",
                            nullable: true,
                          },
                          ethnicity: { type: "string", nullable: true },
                          age_group: { type: "string", nullable: true },
                          lgbtq_identity: { type: "string", nullable: true },
                          special_topics: {
                            type: "array",
                            items: { type: "string" },
                          },
                          faith_or_belief: { type: "string", nullable: true },
                          status: {
                            type: "string",
                            enum: ["pending", "approved", "rejected"],
                          },
                          mime_type: { type: "string" },
                          original_file_name: { type: "string" },
                          created_at: { type: "string", format: "date-time" },
                          reviewed_at: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                          },
                          reviewed_by: {
                            type: "string",
                            format: "uuid",
                            nullable: true,
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
    "/api/v1/admin/listener-requests/{verificationId}": {
      get: {
        tags: ["Admin", "Listener Verification"],
        summary: "Get listener request detail (admin alias)",
        description:
          "Alias endpoint for retrieving one listener verification submission and related verification history for moderation screens.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "verificationId",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        responses: {
          200: {
            description: "Listener request detail retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submission: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        listener_id: { type: "string", format: "uuid" },
                        listener_email: { type: "string", format: "email" },
                        gender_identity: { type: "string", nullable: true },
                        preferred_language: { type: "string", nullable: true },
                        ethnicity: { type: "string", nullable: true },
                        age_group: { type: "string", nullable: true },
                        lgbtq_identity: { type: "string", nullable: true },
                        special_topics: {
                          type: "array",
                          items: { type: "string" },
                        },
                        faith_or_belief: { type: "string", nullable: true },
                        status: {
                          type: "string",
                          enum: ["pending", "approved", "rejected"],
                        },
                        file_url: { type: "string", nullable: true },
                        original_file_name: { type: "string" },
                        mime_type: { type: "string" },
                        file_size_bytes: { type: "integer" },
                        admin_notes: { type: "string", nullable: true },
                        reviewed_by: {
                          type: "string",
                          format: "uuid",
                          nullable: true,
                        },
                        reviewed_at: {
                          type: "string",
                          format: "date-time",
                          nullable: true,
                        },
                        document_url: { type: "string", nullable: true },
                        verificationDocuments: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              id: { type: "string", format: "uuid" },
                              status: {
                                type: "string",
                                enum: ["pending", "approved", "rejected"],
                              },
                              original_file_name: { type: "string" },
                              mime_type: { type: "string" },
                              file_size_bytes: { type: "integer" },
                              created_at: {
                                type: "string",
                                format: "date-time",
                              },
                              reviewed_at: {
                                type: "string",
                                format: "date-time",
                                nullable: true,
                              },
                              admin_notes: { type: "string", nullable: true },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Submission not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
      put: {
        tags: ["Admin", "Listener Verification"],
        summary: "Review listener request (admin alias)",
        description:
          "Alias endpoint to approve or reject pending listener verification submissions. Accessible by admin and active sub-admin users with admin-panel edit permission.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "verificationId",
            required: true,
            schema: { type: "string", format: "uuid" },
          },
        ],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["status"],
                properties: {
                  status: {
                    type: "string",
                    enum: ["verified", "rejected"],
                    example: "verified",
                  },
                  adminNotes: {
                    type: "string",
                    nullable: true,
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Listener request reviewed",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    submission: {
                      type: "object",
                      properties: {
                        id: { type: "string", format: "uuid" },
                        listener_id: { type: "string", format: "uuid" },
                        status: {
                          type: "string",
                          enum: ["approved", "rejected"],
                        },
                        reviewed_at: { type: "string", format: "date-time" },
                        s3_deleted_at: {
                          type: "string",
                          format: "date-time",
                          nullable: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Validation error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          401: {
            description: "Unauthorized",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/AuthTokenExpiredError" },
              },
            },
          },
          403: {
            description: "Forbidden (admin or eligible sub-admin required)",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          404: {
            description: "Submission not found",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          409: {
            description: "Submission is not pending",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    // ============ Signature Endpoints ============
    "/api/v1/signatures": {
      post: {
        tags: ["Signatures"],
        summary: "Upload or update user signature",
        description:
          "Upload a signature image (PNG, JPEG, or SVG) for the authenticated user. If a signature already exists, it will be replaced and the old file will be deleted from S3.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            "multipart/form-data": {
              schema: {
                type: "object",
                required: ["signature"],
                properties: {
                  signature: {
                    type: "string",
                    format: "binary",
                    description:
                      "Signature image file (PNG, JPEG, or SVG, max 5MB)",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Signature uploaded successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Signature uploaded successfully",
                    },
                    signature: {
                      type: "object",
                      properties: {
                        url: {
                          type: "string",
                          example:
                            "https://ventally-uploads.s3.us-east-1.amazonaws.com/signatures/user-uuid/file-uuid.png",
                        },
                        fileName: {
                          type: "string",
                          example: "abc123-uuid.png",
                        },
                        uploadedAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-02-11T23:45:00.000Z",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          400: {
            description: "Invalid file or missing file",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: {
                      type: "string",
                      example: "Invalid file",
                    },
                    message: {
                      type: "string",
                      example:
                        "Invalid file type. Only PNG, JPEG, and SVG files are allowed.",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Access denied" },
                    message: { type: "string", example: "No token provided" },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Upload failed" },
                    message: {
                      type: "string",
                      example: "Failed to upload signature. Please try again.",
                    },
                  },
                },
              },
            },
          },
        },
      },
      delete: {
        tags: ["Signatures"],
        summary: "Delete own signature",
        description:
          "Delete the authenticated user's signature. Removes the database reference and deletes the file from S3.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Signature deleted successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    message: {
                      type: "string",
                      example: "Signature deleted successfully",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "No signature to delete",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: {
                      type: "string",
                      example: "Signature not found",
                    },
                    message: {
                      type: "string",
                      example: "No signature to delete",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Access denied" },
                    message: { type: "string", example: "No token provided" },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Deletion failed" },
                    message: {
                      type: "string",
                      example: "Failed to delete signature. Please try again.",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/v1/signatures/{userId}": {
      get: {
        tags: ["Signatures"],
        summary: "Get user signature",
        description:
          "Retrieve a user's signature. Access is restricted: users can only view their own signature, and admins can view any user's signature.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            in: "path",
            name: "userId",
            required: true,
            schema: {
              type: "string",
              format: "uuid",
            },
            description: "User ID (must be own ID or requester must be admin)",
          },
        ],
        responses: {
          200: {
            description: "Signature retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    signature: {
                      type: "object",
                      properties: {
                        url: {
                          type: "string",
                          example:
                            "https://ventally-uploads.s3.us-east-1.amazonaws.com/signatures/user-uuid/file-uuid.png",
                        },
                        updatedAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-02-11T23:45:00.000Z",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          403: {
            description:
              "Access denied - Non-owner trying to access signature (non-admin)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Access denied" },
                    message: {
                      type: "string",
                      example:
                        "You do not have permission to view this signature",
                    },
                  },
                },
              },
            },
          },
          404: {
            description: "User not found or signature not uploaded",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: {
                      type: "string",
                      example: "Signature not found",
                    },
                    message: {
                      type: "string",
                      example: "User has not uploaded a signature",
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Access denied" },
                    message: { type: "string", example: "No token provided" },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Retrieval failed" },
                    message: {
                      type: "string",
                      example:
                        "Failed to retrieve signature. Please try again.",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },

    // ============ Earnings Endpoints ============
    "/api/v1/earnings/bank-account/link": {
      post: {
        tags: ["Earnings"],
        summary: "Create listener bank-account onboarding link",
        description:
          "Create or reuse a Stripe Connect account and return an onboarding URL for listener bank-account setup. returnUrl/refreshUrl are optional overrides; backend defaults are used for mobile webview flow.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: false,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  platform: {
                    type: "string",
                    enum: ["ios", "android", "web"],
                    example: "ios",
                  },
                  returnUrl: {
                    type: "string",
                    description:
                      "Optional override. If omitted, backend default callback URL is used.",
                    example:
                      "https://api.ventally.com/api/billing/cancel?flow=bank_link&result=return",
                  },
                  refreshUrl: {
                    type: "string",
                    description:
                      "Optional override. If omitted, backend default callback URL is used.",
                    example:
                      "https://api.ventally.com/api/billing/cancel?flow=bank_link&result=refresh",
                  },
                },
              },
              examples: {
                webviewDefault: {
                  summary: "Webview flow with backend defaults",
                  value: {
                    platform: "ios",
                  },
                },
                explicitOverrides: {
                  summary: "Optional explicit callback overrides",
                  value: {
                    platform: "ios",
                    returnUrl:
                      "https://api.ventally.com/api/billing/cancel?flow=bank_link&result=return",
                    refreshUrl:
                      "https://api.ventally.com/api/billing/cancel?flow=bank_link&result=refresh",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Bank onboarding link generated",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    bankLink: {
                      type: "object",
                      properties: {
                        accountId: {
                          type: "string",
                          example: "acct_1ABCxyz...",
                        },
                        onboardingUrl: {
                          type: "string",
                          example: "https://connect.stripe.com/...",
                        },
                        expiresAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-03-15T10:30:00.000Z",
                        },
                        platform: {
                          type: "string",
                          example: "ios",
                        },
                        returnUrl: {
                          type: "string",
                          example:
                            "https://api.ventally.com/api/billing/cancel?flow=bank_link&result=return",
                        },
                        refreshUrl: {
                          type: "string",
                          example:
                            "https://api.ventally.com/api/billing/cancel?flow=bank_link&result=refresh",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Listener role required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          503: {
            description: "Payout service unavailable",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/earnings/bank-account/status": {
      get: {
        tags: ["Earnings"],
        summary: "Get listener bank-account status",
        description:
          "Return current payout account readiness for listener bank-account linking status.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Bank-account status retrieved",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    status: {
                      type: "object",
                      properties: {
                        stripeAccountStatus: {
                          type: "string",
                          example: "active",
                        },
                        payoutEnabled: {
                          type: "boolean",
                          example: true,
                        },
                        requirementsDue: {
                          type: "array",
                          items: { type: "string" },
                          example: [],
                        },
                        accountId: {
                          type: "string",
                          nullable: true,
                          example: "acct_1ABCxyz...",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Listener role required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/earnings/withdraw": {
      post: {
        tags: ["Earnings"],
        summary: "Withdraw listener earnings",
        description:
          "Create an immediate payout transfer for listener earnings. If request body includes amount, that exact amount is withdrawn; otherwise full available balance is withdrawn.",
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: false,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  amount: {
                    type: "number",
                    format: "float",
                    minimum: 0.01,
                    description:
                      "Optional exact amount to withdraw. Must be > 0 and <= available balance.",
                    example: 45.25,
                  },
                },
                example: {
                  amount: 45.25,
                },
              },
              examples: {
                partialAmount: {
                  summary: "Withdraw exact custom amount",
                  value: {
                    amount: 45.25,
                  },
                },
                smallAmount: {
                  summary: "Withdraw another valid amount",
                  value: {
                    amount: 10,
                  },
                },
              },
            },
          },
        },
        responses: {
          201: {
            description: "Withdrawal processed successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", example: true },
                    payout: {
                      type: "object",
                      properties: {
                        id: {
                          type: "string",
                          format: "uuid",
                          example: "d4e5f6a7-b8c9-0123-def4-567890abcdef",
                        },
                        amount: {
                          type: "number",
                          format: "float",
                          example: 118.5,
                        },
                        requestedAmount: {
                          type: "number",
                          format: "float",
                          example: 45.25,
                        },
                        processedAmount: {
                          type: "number",
                          format: "float",
                          example: 45.25,
                        },
                        status: {
                          type: "string",
                          enum: ["completed"],
                          example: "completed",
                        },
                        stripeTransferId: {
                          type: "string",
                          example: "tr_1234567890abcdef",
                        },
                        createdAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-03-15T09:40:12.000Z",
                        },
                        processedAt: {
                          type: "string",
                          format: "date-time",
                          example: "2026-03-15T09:40:13.000Z",
                        },
                        earningsCount: {
                          type: "integer",
                          example: 6,
                        },
                        allocationCount: {
                          type: "integer",
                          example: 2,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Listener role or verification required",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  wrongRole: {
                    value: {
                      error: "Permission denied",
                      message: "Only listeners can request withdrawals",
                    },
                  },
                  notVerified: {
                    value: {
                      error: "LISTENER_NOT_VERIFIED",
                      message: "Only verified listeners can withdraw earnings",
                    },
                  },
                },
              },
            },
          },
          422: {
            description:
              "Unprocessable request - payout prerequisites or balance not met",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  noBalance: {
                    value: {
                      error: "NO_AVAILABLE_EARNINGS",
                      message: "No available earnings to withdraw",
                    },
                  },
                  invalidAmount: {
                    value: {
                      error: "INVALID_WITHDRAWAL_AMOUNT",
                      message:
                        "Withdrawal amount must be a positive number with up to 2 decimals",
                    },
                  },
                  amountExceedsAvailable: {
                    value: {
                      error: "WITHDRAWAL_AMOUNT_EXCEEDS_AVAILABLE",
                      message: "Requested amount exceeds available earnings",
                      details: {
                        requestedAmount: 200,
                        availableAmount: 118.5,
                      },
                    },
                  },
                  allocationFailed: {
                    value: {
                      error: "WITHDRAWAL_ALLOCATION_FAILED",
                      message: "Unable to allocate requested withdrawal amount",
                    },
                  },
                  stripeNotConnected: {
                    value: {
                      error: "STRIPE_ACCOUNT_NOT_CONNECTED",
                      message:
                        "Connect your Stripe payout account before withdrawing",
                    },
                  },
                  payoutsDisabled: {
                    value: {
                      error: "PAYOUT_NOT_ENABLED",
                      message:
                        "Payouts are not enabled for this listener account",
                      details: {
                        stripeAccountStatus: "incomplete",
                        requirementsDue: ["external_account"],
                      },
                    },
                  },
                },
              },
            },
          },
          503: {
            description: "Payout service unavailable",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                examples: {
                  notConfigured: {
                    value: {
                      error: "PAYOUT_SERVICE_UNAVAILABLE",
                      message: "Payout service is not configured",
                    },
                  },
                  accountSyncFailed: {
                    value: {
                      error: "PAYOUT_SERVICE_UNAVAILABLE",
                      message:
                        "Unable to verify payout account status. Please try again.",
                    },
                  },
                },
              },
            },
          },
          502: {
            description: "Stripe transfer failed",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
                example: {
                  error: "PAYOUT_TRANSFER_FAILED",
                  message: "Payout transfer failed",
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/earnings/summary": {
      get: {
        tags: ["Earnings"],
        summary: "Get listener earnings summary",
        description:
          "Get overview of listener's earnings including pending, available, and paid balances. Only accessible by listeners.",
        security: [{ bearerAuth: [] }],
        responses: {
          200: {
            description: "Earnings summary retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    pendingBalance: {
                      type: "number",
                      format: "float",
                      description: "Earnings not yet available for payout",
                      example: 45.5,
                    },
                    availableBalance: {
                      type: "number",
                      format: "float",
                      description: "Earnings available for payout",
                      example: 123.75,
                    },
                    totalPaid: {
                      type: "number",
                      format: "float",
                      description: "Total amount already paid out",
                      example: 1250.0,
                    },
                    lifetimeEarnings: {
                      type: "number",
                      format: "float",
                      description: "Total earnings across all time",
                      example: 1419.25,
                    },
                    pendingSessions: {
                      type: "integer",
                      description:
                        "Number of sessions with pending/available earnings",
                      example: 12,
                    },
                    totalSessions: {
                      type: "integer",
                      description: "Total number of earning sessions",
                      example: 87,
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only listeners can access earnings",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    error: { type: "string", example: "Permission denied" },
                    message: {
                      type: "string",
                      example: "Only listeners can view earnings",
                    },
                  },
                },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/earnings": {
      get: {
        tags: ["Earnings"],
        summary: "Get listener earnings transactions",
        description:
          "Get detailed list of listener's earnings from individual sessions with pagination and filtering. Only accessible by listeners.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            description: "Number of transactions to return",
            schema: {
              type: "integer",
              default: 50,
              minimum: 1,
              maximum: 100,
            },
          },
          {
            name: "offset",
            in: "query",
            description: "Number of transactions to skip for pagination",
            schema: {
              type: "integer",
              default: 0,
              minimum: 0,
            },
          },
          {
            name: "status",
            in: "query",
            description: "Filter by earning status",
            schema: {
              type: "string",
              enum: ["pending", "available", "paid", "cancelled"],
            },
          },
          {
            name: "sessionType",
            in: "query",
            description: "Filter by session type",
            schema: {
              type: "string",
              enum: ["call", "chat"],
            },
          },
        ],
        responses: {
          200: {
            description: "Earnings transactions retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    earnings: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: {
                            type: "string",
                            format: "uuid",
                            example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                          },
                          sessionType: {
                            type: "string",
                            enum: ["call", "chat"],
                            example: "call",
                          },
                          sessionId: {
                            type: "string",
                            format: "uuid",
                            example: "b2c3d4e5-f6g7-8901-bcde-f12345678901",
                          },
                          grossAmount: {
                            type: "number",
                            format: "float",
                            description: "Total session cost before fees",
                            example: 15.0,
                          },
                          platformFee: {
                            type: "number",
                            format: "float",
                            description: "Platform fee deducted",
                            example: 3.0,
                          },
                          netAmount: {
                            type: "number",
                            format: "float",
                            description: "Amount listener receives",
                            example: 12.0,
                          },
                          paidAmount: {
                            type: "number",
                            format: "float",
                            description:
                              "Amount already paid out from this earning",
                            example: 5.5,
                          },
                          remainingAmount: {
                            type: "number",
                            format: "float",
                            description:
                              "Amount still available to withdraw from this earning",
                            example: 6.5,
                          },
                          platformFeePercentage: {
                            type: "number",
                            format: "float",
                            description: "Platform fee percentage (0.20 = 20%)",
                            example: 0.2,
                          },
                          status: {
                            type: "string",
                            enum: ["pending", "available", "paid", "cancelled"],
                            example: "available",
                          },
                          payoutId: {
                            type: "string",
                            format: "uuid",
                            nullable: true,
                            description:
                              "ID of payout this earning is included in",
                            example: null,
                          },
                          createdAt: {
                            type: "string",
                            format: "date-time",
                            example: "2026-02-12T10:30:00.000Z",
                          },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: {
                          type: "integer",
                          example: 87,
                        },
                        limit: {
                          type: "integer",
                          example: 50,
                        },
                        offset: {
                          type: "integer",
                          example: 0,
                        },
                        hasMore: {
                          type: "boolean",
                          example: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only listeners can access earnings",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },

    "/api/v1/earnings/payouts": {
      get: {
        tags: ["Earnings"],
        summary: "Get listener payout history",
        description:
          "Get list of all payouts made to the listener with pagination and filtering. Only accessible by listeners.",
        security: [{ bearerAuth: [] }],
        parameters: [
          {
            name: "limit",
            in: "query",
            description: "Number of payouts to return",
            schema: {
              type: "integer",
              default: 50,
              minimum: 1,
              maximum: 100,
            },
          },
          {
            name: "offset",
            in: "query",
            description: "Number of payouts to skip for pagination",
            schema: {
              type: "integer",
              default: 0,
              minimum: 0,
            },
          },
          {
            name: "status",
            in: "query",
            description: "Filter by payout status",
            schema: {
              type: "string",
              enum: [
                "pending",
                "processing",
                "completed",
                "failed",
                "cancelled",
              ],
            },
          },
        ],
        responses: {
          200: {
            description: "Payout history retrieved successfully",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    payouts: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          id: {
                            type: "string",
                            format: "uuid",
                            example: "c3d4e5f6-g7h8-9012-cdef-123456789012",
                          },
                          amount: {
                            type: "number",
                            format: "float",
                            description: "Payout amount",
                            example: 250.0,
                          },
                          stripeTransferId: {
                            type: "string",
                            nullable: true,
                            description: "Stripe transfer ID if processed",
                            example: "tr_1234567890abcdef",
                          },
                          status: {
                            type: "string",
                            enum: [
                              "pending",
                              "processing",
                              "completed",
                              "failed",
                              "cancelled",
                            ],
                            example: "completed",
                          },
                          failureReason: {
                            type: "string",
                            nullable: true,
                            description: "Reason if payout failed",
                            example: null,
                          },
                          processedAt: {
                            type: "string",
                            format: "date-time",
                            nullable: true,
                            description: "When payout was processed",
                            example: "2026-02-10T15:45:00.000Z",
                          },
                          createdAt: {
                            type: "string",
                            format: "date-time",
                            example: "2026-02-10T14:30:00.000Z",
                          },
                        },
                      },
                    },
                    pagination: {
                      type: "object",
                      properties: {
                        total: {
                          type: "integer",
                          example: 15,
                        },
                        limit: {
                          type: "integer",
                          example: 50,
                        },
                        offset: {
                          type: "integer",
                          example: 0,
                        },
                        hasMore: {
                          type: "boolean",
                          example: false,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          401: {
            description: "Unauthorized - Invalid or missing token",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          403: {
            description: "Forbidden - Only listeners can access payouts",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
          500: {
            description: "Server error",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Error" },
              },
            },
          },
        },
      },
    },
  },
};
