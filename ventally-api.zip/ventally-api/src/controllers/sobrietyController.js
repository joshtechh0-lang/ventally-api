const { pool } = require("../database/connection");
const logger = require("../utils/logger");

const ACHIEVEMENT_MILESTONES = [1, 3, 7, 14, 30, 60, 90, 180, 365];

function getAchievements(daysSober) {
  return ACHIEVEMENT_MILESTONES.filter((days) => days <= daysSober).map(
    (days) => ({
      code: `milestone_${days}`,
      label: `${days} Day${days === 1 ? "" : "s"}`,
      days_required: days,
      achieved: true,
    }),
  );
}

function getDaysSoberFromDate(soberStartDate) {
  if (!soberStartDate) return 0;
  const start = new Date(soberStartDate);
  const today = new Date();

  start.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);

  const diffDays = Math.floor((today - start) / (1000 * 60 * 60 * 24));
  return Math.max(diffDays + 1, 0);
}

function ensureVenter(req, res) {
  if (req.user.user_type !== "venter") {
    res.status(403).json({
      error: "Permission denied",
      message: "Only venter profiles can use sobriety tracking",
    });
    return false;
  }
  return true;
}

async function getSobrietyStatus(req, res) {
  try {
    if (!ensureVenter(req, res)) return;

    const userId = req.user.id;
    const result = await pool.query(
      `SELECT id, user_id, sober_start_date, last_relapse_date, notes, created_at, updated_at
       FROM sobriety_profiles
       WHERE user_id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.json({
        message: "Sobriety status retrieved successfully",
        tracking_enabled: false,
        status: {
          days_sober: 0,
          sober_start_date: null,
          last_relapse_date: null,
          achievements: [],
        },
      });
    }

    const profile = result.rows[0];
    const daysSober = getDaysSoberFromDate(profile.sober_start_date);

    res.json({
      message: "Sobriety status retrieved successfully",
      tracking_enabled: true,
      status: {
        ...profile,
        days_sober: daysSober,
        achievements: getAchievements(daysSober),
      },
    });
  } catch (error) {
    logger.error("Error fetching sobriety status:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch sobriety status",
    });
  }
}

async function startSobriety(req, res) {
  const client = await pool.connect();

  try {
    if (!ensureVenter(req, res)) return;

    const userId = req.user.id;
    const { sober_start_date, notes } = req.body;
    const startDate = sober_start_date || new Date().toISOString().slice(0, 10);

    await client.query("BEGIN");

    const upsertResult = await client.query(
      `INSERT INTO sobriety_profiles (user_id, sober_start_date, notes)
       VALUES ($1, $2::date, $3)
       ON CONFLICT (user_id)
       DO UPDATE SET sober_start_date = EXCLUDED.sober_start_date,
                     notes = EXCLUDED.notes,
                     updated_at = CURRENT_TIMESTAMP
       RETURNING id, user_id, sober_start_date, last_relapse_date, notes, created_at, updated_at`,
      [userId, startDate, notes || null],
    );

    await client.query(
      `INSERT INTO sobriety_events (user_id, event_type, event_date, restart_date, notes)
       VALUES ($1, 'start', $2::date, $2::date, $3)`,
      [userId, startDate, notes || null],
    );

    await client.query("COMMIT");

    const profile = upsertResult.rows[0];
    const daysSober = getDaysSoberFromDate(profile.sober_start_date);

    res.status(201).json({
      message: "Sobriety tracking updated successfully",
      status: {
        ...profile,
        days_sober: daysSober,
        achievements: getAchievements(daysSober),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error starting sobriety tracking:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to start sobriety tracking",
    });
  } finally {
    client.release();
  }
}

async function logRelapse(req, res) {
  const client = await pool.connect();

  try {
    if (!ensureVenter(req, res)) return;

    const userId = req.user.id;
    const { relapse_date, restart_date, notes } = req.body;

    const effectiveRelapseDate =
      relapse_date || new Date().toISOString().slice(0, 10);
    const effectiveRestartDate = restart_date || effectiveRelapseDate;

    await client.query("BEGIN");

    const hasProfile = await client.query(
      `SELECT id FROM sobriety_profiles WHERE user_id = $1`,
      [userId],
    );

    if (hasProfile.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "Sobriety tracking is not set up yet",
      });
    }

    const updateResult = await client.query(
      `UPDATE sobriety_profiles
       SET sober_start_date = $1::date,
           last_relapse_date = $2::date,
           notes = COALESCE($3, notes),
           updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $4
       RETURNING id, user_id, sober_start_date, last_relapse_date, notes, created_at, updated_at`,
      [effectiveRestartDate, effectiveRelapseDate, notes || null, userId],
    );

    await client.query(
      `INSERT INTO sobriety_events (user_id, event_type, event_date, restart_date, notes)
       VALUES ($1, 'relapse', $2::date, $3::date, $4)`,
      [userId, effectiveRelapseDate, effectiveRestartDate, notes || null],
    );

    await client.query("COMMIT");

    const profile = updateResult.rows[0];
    const daysSober = getDaysSoberFromDate(profile.sober_start_date);

    res.json({
      message: "Relapse logged and sobriety streak reset successfully",
      status: {
        ...profile,
        days_sober: daysSober,
        achievements: getAchievements(daysSober),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error logging relapse:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to log relapse",
    });
  } finally {
    client.release();
  }
}

async function getSobrietyHistory(req, res) {
  try {
    if (!ensureVenter(req, res)) return;

    const userId = req.user.id;
    const { limit = 30, offset = 0 } = req.query;

    const result = await pool.query(
      `SELECT id, user_id, event_type, event_date, restart_date, notes, created_at
       FROM sobriety_events
       WHERE user_id = $1
       ORDER BY event_date DESC, created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, parseInt(limit), parseInt(offset)],
    );

    const countResult = await pool.query(
      `SELECT COUNT(*) FROM sobriety_events WHERE user_id = $1`,
      [userId],
    );

    const total = parseInt(countResult.rows[0].count);

    res.json({
      message: "Sobriety history retrieved successfully",
      events: result.rows,
      pagination: {
        total,
        limit: parseInt(limit),
        offset: parseInt(offset),
        has_more: parseInt(offset) + result.rows.length < total,
      },
    });
  } catch (error) {
    logger.error("Error fetching sobriety history:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch sobriety history",
    });
  }
}

module.exports = {
  getSobrietyStatus,
  startSobriety,
  logRelapse,
  getSobrietyHistory,
  getAchievements,
  getDaysSoberFromDate,
};
