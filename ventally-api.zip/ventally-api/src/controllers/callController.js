const { pool } = require("../database/connection");
const anonymizer = require("../services/anonymizer");
const presence = require("../services/presence");
const { redisClient } = require("../services/redis");
const { getSetting } = require("../services/settings");
const {
  sendUserPushNotification,
} = require("../services/listenerNotifications");
const callProvider = require("../services/callProvider");
const agoraService = require("../services/agora");
const logger = require("../utils/logger");
const {
  getGracePeriodConfig,
  calculateBillableDuration,
  checkGracePeriodRateLimit,
  recordGracePeriodUsage,
  formatTransactionDescription,
} = require("../utils/gracePeriod");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const klaviyo = require("../services/klaviyo");
const {
  getSurgeMultiplier,
  calculateSurgeCost,
  formatSurgeDescription,
  getSurgeExplanation,
} = require("../utils/surgePricing");
const { canMakeCall, canUsePayg } = require("./walletController");
const { v4: uuidv4 } = require("uuid");
const agoraAppId = process.env.AGORA_APP_ID || null;
const MAX_AGORA_TOKEN_TTL_SECONDS = 24 * 60 * 60;

function getAgoraTokenCacheTtlSeconds() {
  const parsed = Number(process.env.AGORA_TOKEN_TTL_SECONDS || 3600);

  if (!Number.isFinite(parsed) || parsed <= 0) {
    return 3600;
  }

  return Math.min(Math.floor(parsed), MAX_AGORA_TOKEN_TTL_SECONDS);
}

function buildCallTokenCacheKey(callId, userId) {
  return `agora:call-token:${callId}:${userId}`;
}

async function cacheCallToken(callId, userId, payload) {
  const ttlSeconds = getAgoraTokenCacheTtlSeconds();
  const expiresAt = new Date(Date.now() + ttlSeconds * 1000);

  try {
    await redisClient.setEx(
      buildCallTokenCacheKey(callId, userId),
      ttlSeconds,
      JSON.stringify(payload),
    );
  } catch (error) {
    logger.warn("Failed to cache Agora call token", {
      callId,
      userId,
      error: error.message,
    });
  }

  try {
    await pool.query(
      `INSERT INTO voice_call_tokens (call_id, user_id, token, uid, join_mode, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (call_id, user_id)
       DO UPDATE SET
         token = EXCLUDED.token,
         uid = EXCLUDED.uid,
         join_mode = EXCLUDED.join_mode,
         expires_at = EXCLUDED.expires_at,
         updated_at = NOW()`,
      [callId, userId, payload.token, payload.uid, payload.joinMode, expiresAt],
    );
  } catch (error) {
    logger.warn("Failed to persist Agora call token in database", {
      callId,
      userId,
      error: error.message,
    });
  }
}

async function getAnyCachedCallTokenForCall(callId) {
  try {
    const result = await pool.query(
      `SELECT token, uid, join_mode
       FROM voice_call_tokens
       WHERE call_id = $1
         AND expires_at > NOW()
       ORDER BY updated_at DESC
       LIMIT 1`,
      [callId],
    );

    if (result.rows.length === 0) {
      return null;
    }

    const tokenRow = result.rows[0];
    return {
      token: tokenRow.token,
      uid: Number(tokenRow.uid),
      joinMode: tokenRow.join_mode,
    };
  } catch (error) {
    logger.warn("Failed to read any cached call token for call", {
      callId,
      error: error.message,
    });
    return null;
  }
}

async function clearCallTokenCache(callId, userId) {
  try {
    await redisClient.del(buildCallTokenCacheKey(callId, userId));
  } catch (error) {
    logger.warn("Failed to clear cached Agora call token", {
      callId,
      userId,
      error: error.message,
    });
  }

  try {
    await pool.query(
      `DELETE FROM voice_call_tokens WHERE call_id = $1 AND user_id = $2`,
      [callId, userId],
    );
  } catch (error) {
    logger.warn("Failed to clear persisted Agora call token from database", {
      callId,
      userId,
      error: error.message,
    });
  }
}

async function getOrCreateCallJoinCredentials({ callId, userId, channelName }) {
  const normalizedUserId = String(userId);
  // Generate unique uid per user from userId hash
  const uid = Math.abs(normalizedUserId.split('').reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 0)) % 100000 + 1;
  // Check if this user already has a token for this call
  try {
    const result = await pool.query(
      `SELECT token, uid, join_mode FROM voice_call_tokens WHERE call_id = $1 AND user_id = $2 LIMIT 1`,
      [callId, normalizedUserId]
    );
    if (result.rows.length > 0) {
      const row = result.rows[0];
      return {
        token: row.token,
        joinIdentity: { joinMode: row.join_mode || "uid", uid: Number(row.uid), userAccount: null, normalizedIdentity: normalizedUserId },
      };
    }
  } catch (e) {
    logger.warn("Failed to check existing call token", { error: e.message });
  }
  const ttlSeconds = getAgoraTokenCacheTtlSeconds();
  const userToken = agoraService.generateTokenWithUid({ channelName, uid, role: 1, tokenExpireTs: ttlSeconds, privilegeExpireTs: ttlSeconds });
  await cacheCallToken(callId, normalizedUserId, { token: userToken.token, uid, joinMode: "uid" });
  return {
    token: userToken.token,
    joinIdentity: { joinMode: "uid", uid, userAccount: null, normalizedIdentity: normalizedUserId },
  };
}

function summarizeToken(token) {
  const value = String(token || "");
  if (!value) {
    return "";
  }

  if (value.length <= 24) {
    return `${value.slice(0, 12)}...${value.slice(-6)}`;
  }

  return `${value.slice(0, 16)}...${value.slice(-10)}`;
}

function buildAgoraJoinPayload({
  token,
  joinIdentity,
  channelName,
  provider,
  callId,
}) {
  return {
    callId,
    id: callId,
    roomName: channelName,
    channelName,
    agoraAppId,
    provider,
    token,
    identity: joinIdentity.normalizedIdentity,
    joinMode: joinIdentity.joinMode,
    agoraUid: joinIdentity.uid,
    uid: joinIdentity.uid,
    // Keep legacy field for compatibility with existing clients.
    agoraUserAccount: null,
  };
}

async function emitCallEventToUser(io, userId, eventName, payload) {
  if (!io || !userId || !eventName) {
    return {
      delivered: false,
      roomSize: 0,
      directSocketId: null,
      matchedSockets: 0,
    };
  }

  const userRoom = String(userId);
  const normalizedUserId = String(userId);
  io.to(userRoom).emit(eventName, payload);

  let directSocketId = null;
  try {
    directSocketId = await redisClient.get(`socket:${userId}`);
    if (directSocketId) {
      io.to(directSocketId).emit(eventName, payload);
    }
  } catch (error) {
    logger.warn("Failed to resolve direct socket mapping", {
      userId,
      eventName,
      error: error.message,
    });
  }

  const matchedSocketIds = [];
  for (const socket of io.sockets.sockets.values()) {
    if (String(socket.userId) === normalizedUserId) {
      matchedSocketIds.push(socket.id);
      io.to(socket.id).emit(eventName, payload);
    }
  }

  const roomSize = io.sockets.adapter.rooms.get(userRoom)?.size || 0;
  const delivered =
    roomSize > 0 || !!directSocketId || matchedSocketIds.length > 0;

  logger.info("Call socket event dispatched", {
    userId,
    eventName,
    roomSize,
    hasDirectSocketId: !!directSocketId,
    matchedSocketCount: matchedSocketIds.length,
    delivered,
  });

  return {
    delivered,
    roomSize,
    directSocketId,
    matchedSockets: matchedSocketIds.length,
  };
}

async function sendIncomingCallPushNotification(
  listenerId,
  callId,
  requester,
  ratePerMinute,
) {
  try {
    // Push reaches offline/backgrounded listeners — do not gate on presence.
    const response = await sendUserPushNotification({
      userId: listenerId,
      channel: "call",
      title: "Incoming call",
      body: `${requester.anonymousName || "A venter"} is calling you`,
      data: {
        type: "incoming_call",
        notification_channel: "call",
        callId: String(callId),
        ratePerMinute: String(ratePerMinute),
      },
    });

    logger.info("Incoming call push dispatch completed", {
      listenerId,
      callId,
      successCount: response.successCount,
      failureCount: response.failureCount,
    });
  } catch (error) {
    logger.error("Incoming call push dispatch failed", {
      listenerId,
      callId,
      error: error.message,
    });
  }
}

/**
 * Create a voice call request
 * POST /api/v1/calls
 */
async function createCall(req, res) {
  const client = await pool.connect();

  try {
    const { listenerId, paymentMode: rawPaymentMode } = req.body;
    const venterId = req.user.id;
    const paymentMode = rawPaymentMode === "payg" ? "payg" : "prepaid";

    if (!listenerId) {
      return res.status(400).json({
        error: "Missing listener ID",
        message: "Listener ID is required",
      });
    }

    if (venterId === listenerId) {
      return res.status(400).json({
        error: "Invalid request",
        message: "Cannot call yourself",
      });
    }

    // Check if listener is available
    const available = await presence.isListenerAvailable(listenerId);
    if (!available) {
      return res.status(400).json({
        error: "Listener unavailable",
        message: "This listener is currently offline or busy",
      });
    }

    await client.query("BEGIN");

    // Get listener rate
    const listenerResult = await client.query(
      "SELECT rate_per_minute FROM listener_profiles WHERE listener_id = $1",
      [listenerId],
    );

    if (listenerResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Listener not found",
        message: "Listener profile not found",
      });
    }

    const ratePerMinute = parseFloat(listenerResult.rows[0].rate_per_minute);

    // Get surge pricing information
    const surgeInfo = await getSurgeMultiplier(venterId, client);
    const effectiveRate = ratePerMinute * surgeInfo.multiplier;

    /**
     * Check call eligibility - validates user can make a call
     * This checks BOTH subscription status AND wallet balance:
     *
     * 1. First checks user_subscriptions table for active subscription
     *    - If active subscription with remaining minutes: Allow (uses subscription)
     *    - If active subscription with 0 minutes: Allow (uses overage/wallet)
     *
     * 2. If no active subscription, checks user_wallets table
     *    - If balance >= 1 minute: Allow (uses prepaid wallet)
     *    - If balance < 1 minute: Reject
     *
     * This ensures subscribers can always call (with overage if needed),
     * while prepaid users need sufficient balance.
     */
    const minMinutes = await getSetting("min_call_balance_minutes", 5);
    const minBalance = minMinutes * effectiveRate;

    // Branch eligibility on requested payment mode
    let eligibility;
    if (paymentMode === "payg") {
      eligibility = await canUsePayg(venterId);
      if (!eligibility.allowed) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "PAYG unavailable",
          message:
            eligibility.reason === "not_enrolled"
              ? "Enable Pay-as-you-go and save a card before starting a PAYG call"
              : eligibility.reason === "payg_locked"
                ? "Your PAYG account is locked due to a previous declined charge. Update your card to continue."
                : eligibility.reason === "no_payment_method"
                  ? "Add a payment method to use Pay-as-you-go"
                  : "Pay-as-you-go is not available right now",
          reason: eligibility.reason,
        });
      }
    } else {
      eligibility = await canMakeCall(venterId);
      if (!eligibility.allowed) {
        await client.query("ROLLBACK");
        const reason =
          eligibility.reason === "insufficient_balance"
            ? "You don't have an active subscription or sufficient prepaid balance"
            : "Unable to verify call eligibility";
        return res.status(402).json({
          error: "Insufficient balance",
          message: `${reason}. You need at least ${minMinutes} minutes to start a call.`,
          required: minMinutes,
          suggestion:
            "Subscribe to a plan, add prepaid minutes, or enable Pay-as-you-go",
        });
      }
    }

    /**
     * For prepaid users only: enforce minimum balance and payment method
     *
     * Subscribers (source = 'subscription' or 'overage') bypass these checks because:
     * - They already have payment method on file via Stripe
     * - They can use overage if minutes run out
     *
     * Prepaid users must have:
     * - Minimum balance (5 minutes by default)
     * - Payment method on file for auto-recharge
     */
    if (eligibility.source === "prepaid") {
      // Enforce minimum balance for prepaid users
      if (eligibility.remainingMinutes < minMinutes) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "Insufficient balance",
          message: `You need at least ${minMinutes} minutes ($${minBalance.toFixed(2)}) to start a call`,
          balance: eligibility.remainingMinutes,
          required: minMinutes,
        });
      }

      // Check if payment method is available for prepaid users
      const walletResult = await client.query(
        "SELECT default_payment_method FROM user_wallets WHERE user_id = $1",
        [venterId],
      );

      const wallet = walletResult.rows[0];
      if (!wallet?.default_payment_method) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "No payment method",
          message:
            "Please add a payment method to your wallet before starting a call",
        });
      }
    }

    /**
     * Store payment source for billing when call ends
     * - 'subscription': User has active subscription with remaining minutes
     * - 'overage': User has subscription but exhausted included minutes
     * - 'prepaid': User has no subscription, using wallet balance
     */
    const paymentSource = eligibility.source;

    // Check grace period rate limit
    const gracePeriodConfig = getGracePeriodConfig();
    if (gracePeriodConfig.enabled) {
      const rateLimitCheck = await checkGracePeriodRateLimit(venterId, client);
      if (!rateLimitCheck.allowed) {
        await client.query("ROLLBACK");
        return res.status(429).json({
          error: "Rate limit exceeded",
          message: `Grace period rate limit reached. Please wait ${Math.ceil(rateLimitCheck.waitSeconds / 60)} minutes before starting another call.`,
          waitSeconds: rateLimitCheck.waitSeconds,
        });
      }
    }

    // Create voice call
    const callResult = await client.query(
      `INSERT INTO voice_calls
        (venter_id, listener_id, status, rate_per_minute, payment_mode)
       VALUES ($1, $2, 'requesting', $3, $4)
       RETURNING *`,
      [venterId, listenerId, ratePerMinute, paymentMode],
    );

    const call = callResult.rows[0];

    // Create anonymous identities
    const venterIdentity = await anonymizer.createSessionIdentity(
      venterId,
      call.id,
      "call",
    );

    const listenerIdentity = await anonymizer.createSessionIdentity(
      listenerId,
      call.id,
      "call",
    );

    await client.query("COMMIT");

    logger.info(`Voice call ${call.id} created: ${venterId} -> ${listenerId}`);

    // Emit Socket.io event to listener (user personal room)
    // Backward compatible payload for older mobile clients:
    // - event aliases: call:request and call:incoming
    // - id aliases: callId and id
    // - participant aliases: requester and venter
    const io = req.app.get("io");
    const incomingCallPayload = {
      callId: call.id,
      id: call.id,
      venterId,
      listenerId,
      requester: {
        id: venterId,
        anonymousName: venterIdentity.anonymousName,
        avatarSeed: venterIdentity.avatarSeed,
      },
      venter: {
        anonymousName: venterIdentity.anonymousName,
        avatarSeed: venterIdentity.avatarSeed,
      },
      ratePerMinute: ratePerMinute,
      createdAt: call.created_at,
    };

    const requestDelivery = await emitCallEventToUser(
      io,
      listenerId,
      "call:request",
      incomingCallPayload,
    );
    await emitCallEventToUser(
      io,
      listenerId,
      "call:incoming",
      incomingCallPayload,
    );
    await emitCallEventToUser(
      io,
      listenerId,
      "incoming_call",
      incomingCallPayload,
    );

    if (!requestDelivery.delivered) {
      logger.warn("No active socket target for listener incoming call event", {
        callId: call.id,
        listenerId,
      });

      setTimeout(() => {
        emitCallEventToUser(
          io,
          listenerId,
          "call:request",
          incomingCallPayload,
        ).catch((retryError) => {
          logger.warn("Incoming call retry emit failed", {
            callId: call.id,
            listenerId,
            error: retryError.message,
          });
        });
      }, 1500);
    }

    await emitCallEventToUser(io, venterId, "call:outgoing", {
      callId: call.id,
      id: call.id,
      venterId,
      listenerId,
      ratePerMinute,
      createdAt: call.created_at,
    });

    await sendIncomingCallPushNotification(
      listenerId,
      call.id,
      {
        anonymousName: venterIdentity.anonymousName,
      },
      ratePerMinute,
    );

    res.json({
      success: true,
      call: {
        id: call.id,
        status: call.status,
        venterId,
        listenerId,
        listener: {
          anonymousName: listenerIdentity.anonymousName,
          avatarSeed: listenerIdentity.avatarSeed,
        },
        ratePerMinute: ratePerMinute,
        surgeInfo: getSurgeExplanation(surgeInfo),
        effectiveRate: effectiveRate,
        createdAt: call.created_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error creating call: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to create call",
    });
  } finally {
    client.release();
  }
}

/**
 * Create voice call requests for all currently available listeners
 * POST /api/v1/calls/broadcast
 */
async function createBroadcastCall(req, res) {
  const client = await pool.connect();

  try {
    const venterId = req.user.id;
    const listeners = await presence.getAvailableListeners(venterId);

    if (listeners.length === 0) {
      return res.status(404).json({
        error: "No listeners available",
        message: "No listeners are currently available",
      });
    }

    await client.query("BEGIN");

    const surgeInfo = await getSurgeMultiplier(venterId, client);
    const maxRatePerMinute = listeners.reduce(
      (currentMax, listener) =>
        Math.max(currentMax, parseFloat(listener.ratePerMinute || 0)),
      0,
    );
    const maxEffectiveRate = maxRatePerMinute * surgeInfo.multiplier;

    const minMinutes = await getSetting("min_call_balance_minutes", 5);
    const minBalance = minMinutes * maxEffectiveRate;
    const eligibility = await canMakeCall(venterId);

    if (!eligibility.allowed) {
      await client.query("ROLLBACK");
      return res.status(402).json({
        error: "Insufficient balance",
        message: `You don't have an active subscription or sufficient prepaid balance. You need at least ${minMinutes} minutes to start a call.`,
        required: minMinutes,
        suggestion: "Subscribe to a plan or add prepaid minutes to your wallet",
      });
    }

    if (eligibility.source === "prepaid") {
      if (eligibility.remainingMinutes < minMinutes) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "Insufficient balance",
          message: `You need at least ${minMinutes} minutes ($${minBalance.toFixed(2)}) to start a call`,
          balance: eligibility.remainingMinutes,
          required: minMinutes,
        });
      }

      const walletResult = await client.query(
        "SELECT default_payment_method FROM user_wallets WHERE user_id = $1",
        [venterId],
      );

      const wallet = walletResult.rows[0];
      if (!wallet?.default_payment_method) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "No payment method",
          message:
            "Please add a payment method to your wallet before starting a call",
        });
      }
    }

    const gracePeriodConfig = getGracePeriodConfig();
    if (gracePeriodConfig.enabled) {
      const rateLimitCheck = await checkGracePeriodRateLimit(venterId, client);
      if (!rateLimitCheck.allowed) {
        await client.query("ROLLBACK");
        return res.status(429).json({
          error: "Rate limit exceeded",
          message: `Grace period rate limit reached. Please wait ${Math.ceil(rateLimitCheck.waitSeconds / 60)} minutes before starting another call.`,
          waitSeconds: rateLimitCheck.waitSeconds,
        });
      }
    }

    const requestGroupId = uuidv4();
    const createdCalls = [];

    for (const listener of listeners) {
      const listenerId = listener.listenerId;
      const ratePerMinute = parseFloat(listener.ratePerMinute);

      const callResult = await client.query(
        `INSERT INTO voice_calls
          (venter_id, listener_id, status, rate_per_minute, request_group_id)
         VALUES ($1, $2, 'requesting', $3, $4)
         RETURNING *`,
        [venterId, listenerId, ratePerMinute, requestGroupId],
      );

      const call = callResult.rows[0];

      const venterIdentity = await anonymizer.createSessionIdentity(
        venterId,
        call.id,
        "call",
      );

      await anonymizer.createSessionIdentity(listenerId, call.id, "call");

      createdCalls.push({
        call,
        listenerId,
        ratePerMinute,
        venterIdentity,
      });
    }

    await client.query("COMMIT");

    const io = req.app.get("io");

    for (const item of createdCalls) {
      const incomingCallPayload = {
        callId: item.call.id,
        id: item.call.id,
        venterId,
        listenerId: item.listenerId,
        requester: {
          id: venterId,
          anonymousName: item.venterIdentity.anonymousName,
          avatarSeed: item.venterIdentity.avatarSeed,
        },
        venter: {
          anonymousName: item.venterIdentity.anonymousName,
          avatarSeed: item.venterIdentity.avatarSeed,
        },
        ratePerMinute: item.ratePerMinute,
        createdAt: item.call.created_at,
      };

      await emitCallEventToUser(
        io,
        item.listenerId,
        "call:request",
        incomingCallPayload,
      );
      await emitCallEventToUser(
        io,
        item.listenerId,
        "call:incoming",
        incomingCallPayload,
      );
      await emitCallEventToUser(
        io,
        item.listenerId,
        "incoming_call",
        incomingCallPayload,
      );

      await emitCallEventToUser(io, venterId, "call:outgoing", {
        callId: item.call.id,
        id: item.call.id,
        venterId,
        listenerId: item.listenerId,
        ratePerMinute: item.ratePerMinute,
        createdAt: item.call.created_at,
      });

      await sendIncomingCallPushNotification(
        item.listenerId,
        item.call.id,
        {
          anonymousName: item.venterIdentity.anonymousName,
        },
        item.ratePerMinute,
      );
    }

    res.json({
      success: true,
      requestGroupId,
      count: createdCalls.length,
      surgeInfo: getSurgeExplanation(surgeInfo),
      calls: createdCalls.map((item) => ({
        id: item.call.id,
        status: item.call.status,
        venterId,
        listenerId: item.listenerId,
        ratePerMinute: item.ratePerMinute,
        effectiveRate: item.ratePerMinute * surgeInfo.multiplier,
        createdAt: item.call.created_at,
      })),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error creating broadcast call: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to create broadcast call",
    });
  } finally {
    client.release();
  }
}

/**
 * Accept a voice call (listener)
 * POST /api/v1/calls/:id/accept
 */
// New simplified acceptCall function
async function acceptCall(req, res) {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const listenerId = req.user.id;

    await client.query("BEGIN");

    const callResult = await client.query(
      "SELECT * FROM voice_calls WHERE id = $1 FOR UPDATE",
      [id]
    );

    if (callResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Call not found" });
    }

    const call = callResult.rows[0];

    if (call.listener_id !== listenerId) {
      await client.query("ROLLBACK");
      return res.status(403).json({ error: "Permission denied" });
    }

    if (call.status !== "requesting") {
      await client.query("ROLLBACK");
      if (call.status === "active" || call.status === "ringing") {
        return res.status(409).json({ error: "Call already accepted" });
      }
      return res.status(400).json({ error: `Call is ${call.status}` });
    }

    const roomName = `ventally-call-${id}`;

    // Update call status
    await client.query(
      "UPDATE voice_calls SET status = 'active', started_at = NOW(), twilio_room_name = $1 WHERE id = $2",
      [roomName, id]
    );

    // Cancel other pending calls in the same broadcast group
    if (call.request_group_id) {
      await client.query(
        "UPDATE voice_calls SET status = 'cancelled', ended_at = NOW() WHERE request_group_id = $1 AND id != $2 AND status = 'requesting'",
        [call.request_group_id, id]
      );
    }

    await client.query("COMMIT");

    // Generate unique Agora tokens for each user
    const ttl = 3600;
    const venterUid = 1;
    const listenerUid = 2;

    const agoraService = require("../services/agora");
    const venterToken = agoraService.generateTokenWithUid({
      channelName: roomName,
      uid: venterUid,
      role: 1,
      tokenExpireTs: ttl,
      privilegeExpireTs: ttl,
    });

    const listenerToken = agoraService.generateTokenWithUid({
      channelName: roomName,
      uid: listenerUid,
      role: 1,
      tokenExpireTs: ttl,
      privilegeExpireTs: ttl,
    });

    const io = req.app.get("io");

    // Notify listener with their token
    io.to(String(listenerId)).emit("call:ready", {
      id,
      callId: id,
      token: listenerToken.token,
      channelName: roomName,
      uid: listenerUid,
      agoraUid: listenerUid,
      agoraAppId: process.env.AGORA_APP_ID,
    });

    // Notify venter
    io.to(String(call.venter_id)).emit("call:accepted", {
      id,
      callId: id,
      token: venterToken.token,
      channelName: roomName,
      uid: venterUid,
      agoraUid: venterUid,
      agoraAppId: process.env.AGORA_APP_ID,
      venterId: call.venter_id,
      listenerId,
    });

    // Respond to listener
    res.json({
      success: true,
      call: {
        id,
        callId: id,
        status: "active",
        token: listenerToken.token,
        channelName: roomName,
        uid: listenerUid,
        agoraUid: listenerUid,
        agoraAppId: process.env.AGORA_APP_ID,
        venterId: call.venter_id,
        listenerId,
      },
    });

  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error accepting call: ${error.message}`);
    res.status(500).json({ error: "Failed to accept call" });
  } finally {
    client.release();
  }
}

async function declineCall(req, res) {
  try {
    const { id } = req.params;
    const listenerId = req.user.id;

    const callResult = await pool.query(
      "SELECT * FROM voice_calls WHERE id = $1",
      [id],
    );

    if (callResult.rows.length === 0) {
      return res.status(404).json({
        error: "Call not found",
        message: "Call not found",
      });
    }

    const call = callResult.rows[0];

    if (call.listener_id !== listenerId) {
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not the listener for this call",
      });
    }

    if (call.status !== "requesting") {
      return res.status(400).json({
        error: "Invalid status",
        message: `Call is ${call.status}, cannot decline`,
      });
    }

    await pool.query(
      "UPDATE voice_calls SET status = 'declined', ended_at = NOW() WHERE id = $1",
      [id],
    );

    // Defensive cleanup: decline can be a terminal state and listener must remain available.
    const activeSession = await presence.getActiveListenerSession(listenerId);
    if (!activeSession) {
      await presence.clearListenerBusy(listenerId);
    }

    logger.info(`Listener ${listenerId} declined call ${id}`);

    let shouldNotifyVenterDeclined = true;

    if (call.request_group_id) {
      const remainingResult = await pool.query(
        `SELECT 1
         FROM voice_calls
         WHERE request_group_id = $1
           AND status = 'requesting'
         LIMIT 1`,
        [call.request_group_id],
      );

      shouldNotifyVenterDeclined = remainingResult.rows.length === 0;
    }

    // Notify venter (user personal room)
    // Backward compatible aliases for older mobile clients:
    // - id aliases: callId and id
    // - event aliases: call:declined and call:rejected
    const io = req.app.get("io");
    const declinedPayload = {
      callId: id,
      id: id,
      message: "The listener declined your call",
    };

    if (shouldNotifyVenterDeclined) {
      await emitCallEventToUser(
        io,
        call.venter_id,
        "call:declined",
        declinedPayload,
      );
      await emitCallEventToUser(
        io,
        call.venter_id,
        "call:rejected",
        declinedPayload,
      );
    }

    res.json({
      success: true,
      message: "Call declined",
    });
  } catch (error) {
    logger.error(`Error declining call: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to decline call",
    });
  }
}

/**
 * End a voice call
 * POST /api/v1/calls/:id/end
 */
async function endCall(req, res) {
  const client = await pool.connect();

  try {
    const { id } = req.params;
    const userId = req.user.id;

    // Stop balance monitoring for this call
    try {
      await stopBalanceMonitoring(id);
      logger.info(`Balance monitoring stopped for call ${id}`);
    } catch (monitorError) {
      logger.error(
        `Error stopping balance monitoring for call ${id}:`,
        monitorError,
      );
      // Non-fatal, continue with call end
    }

    await client.query("BEGIN");

    const callResult = await client.query(
      "SELECT * FROM voice_calls WHERE id = $1 FOR UPDATE",
      [id],
    );

    if (callResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Call not found",
        message: "Call not found",
      });
    }

    const call = callResult.rows[0];

    logger.info("[minutes-debug] endCall invoked", {
      callId: id,
      requestedBy: userId,
      status: call.status,
      startedAt: call.started_at,
      paymentMode: call.payment_mode,
      ratePerMinute: call.rate_per_minute,
      venterId: call.venter_id,
      listenerId: call.listener_id,
    });

    // Verify participant
    if (call.venter_id !== userId && call.listener_id !== userId) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not a participant in this call",
      });
    }

    if (call.status !== "active" && call.status !== "ringing") {
      if (["ended", "cancelled", "declined"].includes(call.status)) {
        await client.query("ROLLBACK");
        await presence.clearListenerBusy(call.listener_id);

        logger.warn(
          "[minutes-debug] endCall skipped — call already terminal (NO deduction)",
          {
            callId: id,
            requestedBy: userId,
            status: call.status,
            startedAt: call.started_at,
            endedAt: call.ended_at,
            venterId: call.venter_id,
          },
        );

        return res.json({
          success: true,
          call: {
            id,
            status: call.status,
            endedAt: call.ended_at,
          },
          message: "Call already ended",
        });
      }

      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid status",
        message: `Call is ${call.status}, cannot end`,
      });
    }

    // End provider room/channel if exists
    const activeRoomName = call.voice_channel_name || call.twilio_room_name;
    if (activeRoomName) {
      try {
        const result = await callProvider.endVoiceRoom(activeRoomName);
        if (result.testMode) {
          logger.info(
            "Call ended (Twilio test mode - room will end naturally)",
          );
        }
      } catch (twilioError) {
        // Gracefully handle provider errors - don't block call ending
        if (
          twilioError.message &&
          twilioError.message.includes("Test Account Credentials")
        ) {
          logger.warn(`Twilio test account limitation: ${twilioError.message}`);
        } else {
          logger.error(`Error ending Twilio room: ${twilioError.message}`);
        }
      }
    }

    // Calculate duration
    const endTime = new Date();
    const startTime = call.started_at ? new Date(call.started_at) : endTime;
    const durationMs = endTime - startTime;
    const durationSeconds = Math.floor(durationMs / 1000);

    // Apply grace period
    const gracePeriodConfig = getGracePeriodConfig();
    const gracePeriodSeconds = gracePeriodConfig.enabled
      ? gracePeriodConfig.seconds
      : 0;
    const billingResult = calculateBillableDuration(
      durationSeconds,
      gracePeriodSeconds,
    );
    const durationMinutes = Math.ceil(durationSeconds / 60); // Total duration for display
    const billableMinutes = billingResult.billableMinutes; // Billable duration after grace period

    logger.info("[minutes-debug] endCall duration computed", {
      callId: id,
      venterId: call.venter_id,
      statusAtEnd: call.status,
      startedAt: call.started_at,
      durationSeconds,
      durationMinutes,
      billableMinutes,
      gracePeriodEnabled: gracePeriodConfig.enabled,
      gracePeriodSeconds,
    });

    // Calculate surge pricing
    const surgeInfo = await getSurgeMultiplier(call.venter_id, client);
    const baseRate = parseFloat(call.rate_per_minute);
    const surgeCost = calculateSurgeCost(
      baseRate,
      billableMinutes,
      surgeInfo.multiplier,
    );
    const totalCost = surgeCost.finalCost;

    logger.info("Call billing calculated", {
      callId: id,
      venterId: call.venter_id,
      billableMinutes,
      baseRate,
      surgeMultiplier: surgeInfo.multiplier,
      surgeRuleName: surgeInfo.ruleName,
      baseCost: surgeCost.baseCost,
      finalCost: surgeCost.finalCost,
      surgeAmount: surgeCost.surgeAmount,
      isSubscribed: surgeInfo.isSubscribed,
    });

    // Update call with grace period and surge info
    await client.query(
      `UPDATE voice_calls 
       SET status = 'ended', ended_at = NOW(), duration_seconds = $1, total_cost = $2,
           grace_period_seconds = $3, grace_period_applied = $4,
           surge_multiplier = $5, surge_rule_id = $6
       WHERE id = $7`,
      [
        durationSeconds,
        totalCost,
        billingResult.gracePeriodSeconds,
        billingResult.gracePeriodApplied,
        surgeInfo.multiplier,
        surgeInfo.ruleId,
        id,
      ],
    );

    /**
     * Bill the venter for the call
     *
     * Billing logic depends on user's payment source:
     *
     * 1. Subscription users:
     *    - Deduct from user_subscriptions.used_minutes first
     *    - If exceeds included_minutes, charge overage to wallet
     *    - Overage rate is defined per subscription plan
     *
     * 2. Prepaid users (no subscription):
     *    - Deduct from user_wallets.balance_minutes
     *    - Must have sufficient balance or call won't start
     *
     * This ensures proper billing regardless of payment method
     * and allows subscribers to go over their included minutes.
     */
    if (!(call.status === "active" && billableMinutes > 0)) {
      logger.warn(
        "[minutes-debug] billing branch SKIPPED (no deduction)",
        {
          callId: id,
          venterId: call.venter_id,
          statusAtEnd: call.status,
          billableMinutes,
          reason:
            call.status !== "active"
              ? `status is '${call.status}' (not active)`
              : "billableMinutes is 0 (grace period or zero duration)",
        },
      );
    }

    if (call.status === "active" && billableMinutes > 0) {
      logger.info("[minutes-debug] billing branch entered", {
        callId: id,
        venterId: call.venter_id,
        billableMinutes,
        paymentMode: call.payment_mode,
      });
      // PAYG branch: charge saved card off-session, skip subscription/wallet
      if (call.payment_mode === "payg") {
        if (gracePeriodConfig.enabled && billingResult.gracePeriodApplied) {
          await recordGracePeriodUsage(call.venter_id, client);
        }

        const { chargePaygSession, PaygError } = require("../services/paygService");
        try {
          const result = await chargePaygSession({
            userId: call.venter_id,
            sessionType: "call",
            sessionId: id,
            billableMinutes,
            dbClient: client,
          });
          logger.info("PAYG call charged", {
            callId: id,
            venterId: call.venter_id,
            amountCents: result.amountCents,
            paymentIntentId: result.paymentIntentId,
          });
        } catch (paygErr) {
          if (paygErr instanceof PaygError) {
            logger.warn("PAYG charge failure (call ends regardless)", {
              callId: id,
              code: paygErr.code,
              message: paygErr.message,
            });
          } else {
            throw paygErr;
          }
        }
      } else try {
        // Record grace period usage for rate limiting
        if (gracePeriodConfig.enabled && billingResult.gracePeriodApplied) {
          await recordGracePeriodUsage(call.venter_id, client);
        }

        /**
         * Check if user has active subscription
         * This determines how the call will be billed:
         * - Subscription: Deduct from included_minutes
         * - Overage: Deduct partial from subscription, rest from wallet
         * - Prepaid: Deduct from wallet only
         */
        const subResult = await client.query(
          `SELECT id, included_minutes, used_minutes, overage_rate
           FROM user_subscriptions
           WHERE user_id = $1 AND status IN ('active', 'trialing')
           ORDER BY created_at DESC
           LIMIT 1`,
          [call.venter_id],
        );

        let paymentSource = "prepaid";

        if (subResult.rows.length > 0) {
          // User has active subscription - handle subscription billing
          const subscription = subResult.rows[0];
          const remainingMinutes =
            subscription.included_minutes -
            parseFloat(subscription.used_minutes);

          if (remainingMinutes >= billableMinutes) {
            /**
             * Case 1: Subscription has enough included minutes
             * Deduct entirely from subscription.used_minutes
             * No wallet charges needed
             */
            const subDeductResult = await client.query(
              `UPDATE user_subscriptions
               SET used_minutes = used_minutes + $1
               WHERE id = $2
               RETURNING used_minutes, included_minutes`,
              [billableMinutes, subscription.id],
            );
            paymentSource = "subscription";

            logger.info(
              `[minutes-debug] Deducted ${billableMinutes} minutes from subscription`,
              {
                subscriptionId: subscription.id,
                venterId: call.venter_id,
                callId: id,
                usedMinutesAfter: subDeductResult.rows[0]?.used_minutes,
                includedMinutes: subDeductResult.rows[0]?.included_minutes,
              },
            );
          } else {
            /**
             * Case 2: Subscription doesn't have enough minutes (overage)
             * - Deduct remaining subscription minutes (if any)
             * - Charge excess to wallet at overage_rate
             * This allows subscribers to continue calling even after
             * using all included minutes
             */
            if (remainingMinutes > 0) {
              // Use up remaining subscription minutes first
              await client.query(
                `UPDATE user_subscriptions 
                 SET used_minutes = used_minutes + $1 
                 WHERE id = $2`,
                [remainingMinutes, subscription.id],
              );
            }

            // Calculate overage minutes and cost
            const overageMinutes =
              billableMinutes - Math.max(remainingMinutes, 0);
            const overageCost =
              overageMinutes * parseFloat(subscription.overage_rate);

            // Deduct overage from wallet at overage rate
            const walletOverageResult = await client.query(
              `UPDATE user_wallets 
               SET balance_minutes = balance_minutes - $1 
               WHERE user_id = $2`,
              [overageMinutes, call.venter_id],
            );

            if (walletOverageResult.rowCount === 0) {
              throw new Error(
                `Wallet not found for venter ${call.venter_id} during overage deduction`,
              );
            }

            paymentSource = "overage";

            logger.info(`Deducted overage minutes from wallet`, {
              subscriptionId: subscription.id,
              venterId: call.venter_id,
              callId: id,
              overageMinutes,
              overageCost,
            });
          }
        } else {
          /**
           * Case 3: No active subscription (prepaid user)
           * Deduct entirely from wallet balance
           * User must have had sufficient balance to start call
           */
          const prepaidResult = await client.query(
            `UPDATE user_wallets
             SET balance_minutes = balance_minutes - $1
             WHERE user_id = $2
             RETURNING balance_minutes`,
            [billableMinutes, call.venter_id],
          );

          if (prepaidResult.rowCount === 0) {
            throw new Error(
              `Wallet not found for venter ${call.venter_id} during prepaid deduction`,
            );
          }

          logger.info("[minutes-debug] prepaid wallet deducted", {
            callId: id,
            venterId: call.venter_id,
            deductedMinutes: billableMinutes,
            balanceAfterMinutes: prepaidResult.rows[0]?.balance_minutes,
            rowCount: prepaidResult.rowCount,
          });
        }

        /**
         * Record transaction for audit trail
         * Transaction description includes:
         * - Call ID
         * - Duration (actual and billable)
         * - Grace period (if applied)
         * - Surge pricing (if applied)
         * - Payment source (subscription/overage/prepaid)
         */
        const baseDesc = formatTransactionDescription(
          `Voice call ${id.substring(0, 8)}`,
          durationMinutes,
          Math.ceil(billingResult.gracePeriodSeconds / 60),
          billableMinutes,
        );

        // Append payment source to description for clarity
        const transactionDesc =
          formatSurgeDescription(baseDesc, surgeInfo, surgeCost) +
          ` (${paymentSource})`;

        await client.query(
          `INSERT INTO wallet_transactions 
            (user_id, transaction_type, amount_minutes, amount_currency, description)
           VALUES ($1, 'call_deduction', $2, $3, $4)`,
          [call.venter_id, -billableMinutes, -totalCost, transactionDesc],
        );
      } catch (walletError) {
        logger.error(
          `Wallet/subscription deduction failed: ${walletError.message}`,
        );
      }

      // Calculate listener earnings
      const platformFeePercentage = await getSetting(
        "platform_fee_percentage",
        0.2,
      );
      const platformFee = totalCost * platformFeePercentage;
      const listenerEarnings = totalCost - platformFee;

      await client.query(
        `INSERT INTO listener_earnings 
          (listener_id, session_type, session_id, gross_amount, platform_fee, net_amount, platform_fee_percentage, status)
         VALUES ($1, 'call', $2, $3, $4, $5, $6, 'pending')`,
        [
          call.listener_id,
          id,
          totalCost,
          platformFee,
          listenerEarnings,
          platformFeePercentage,
        ],
      );
    }

    // Clear listener busy status in DB within the same transaction so it
    // cannot be skipped by transient Redis failures.
    await client.query(
      `UPDATE listener_profiles
       SET is_busy = false
       WHERE listener_id = $1`,
      [call.listener_id],
    );

    await client.query("COMMIT");

    // Post-commit cleanup for Redis busy marker and availability broadcast.
    await presence.clearListenerBusy(call.listener_id);

    await clearCallTokenCache(id, String(call.venter_id));
    await clearCallTokenCache(id, String(call.listener_id));

    logger.info(
      `Call ${id} ended: ${durationMinutes}min, $${totalCost.toFixed(2)}`,
    );

    pool
      .query("SELECT email FROM users WHERE id = $1", [call.venter_id])
      .then((r) => r.rows[0] && klaviyo.trackSessionCompleted({
        email: r.rows[0].email,
        sessionType: "voice",
        durationSeconds,
        totalCost,
      }))
      .catch((err) => logger.error(`Klaviyo session lookup: ${err.message}`));

    // Notify both participants (user personal rooms)
    const io = req.app.get("io");

    const endData = {
      callId: id,
      durationSeconds: durationSeconds,
      durationMinutes: durationMinutes,
      totalCost: totalCost,
      endedAt: endTime.toISOString(),
    };

    await emitCallEventToUser(io, call.venter_id, "call:ended", endData);

    const platformFeePercentage = await getSetting(
      "platform_fee_percentage",
      0.2,
    );
    const listenerEarnings = totalCost * (1 - platformFeePercentage);

    await emitCallEventToUser(io, call.listener_id, "call:ended", {
      ...endData,
      earnings: listenerEarnings,
    });

    res.json({
      success: true,
      call: {
        id: id,
        status: "ended",
        durationSeconds: durationSeconds,
        durationMinutes: durationMinutes,
        totalCost: totalCost,
        endedAt: endTime.toISOString(),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error ending call: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to end call",
    });
  } finally {
    client.release();
  }
}

/**
 * Get call token for joining
 * GET /api/v1/calls/:id/token
 */
async function getCallToken(req, res) {
  let callId;
  let userId;

  try {
    const { id } = req.params;
    callId = id;
    userId = req.user.id;

    const callResult = await pool.query(
      "SELECT * FROM voice_calls WHERE id = $1",
      [callId],
    );

    if (callResult.rows.length === 0) {
      return res.status(404).json({
        error: "Call not found",
        message: "Call not found",
      });
    }

    const call = callResult.rows[0];

    if (call.venter_id !== userId && call.listener_id !== userId) {
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not a participant in this call",
      });
    }

    const roomName = call.voice_channel_name || call.twilio_room_name;

    if (!roomName) {
      return res.status(400).json({
        error: "Room not ready",
        message: "Call room has not been created yet",
      });
    }

    const provider = call.call_provider || callProvider.getProviderName();
    const credentials = await getOrCreateCallJoinCredentials({
      callId,
      userId,
      channelName: roomName,
    });

    res.json({
      success: true,
      ...buildAgoraJoinPayload({
        token: credentials.token,
        joinIdentity: credentials.joinIdentity,
        channelName: roomName,
        provider,
        callId,
      }),
    });

    logger.debug("Agora token payload emitted", {
      callId,
      recipientUserId: String(userId),
      channelName: roomName,
      joinMode: credentials.joinIdentity.joinMode,
      uid: credentials.joinIdentity.uid,
      agoraAppId,
      tokenRef: summarizeToken(credentials.token),
      source: "getCallToken:http",
    });
  } catch (error) {
    logger.error(`Error getting call token: ${error.message}`, {
      callId,
      userId,
      error: error.stack,
    });

    // Return specific error for voice provider configuration issues
    if (
      error.message &&
      (error.message.includes("Twilio") ||
        error.message.includes("Agora") ||
        error.message.includes("configured"))
    ) {
      const providerName = callProvider.getProviderName();

      return res.status(503).json({
        error: "Service unavailable",
        message: error.message,
        details: {
          provider: providerName,
          required_env_vars:
            providerName === "agora"
              ? [
                  "AGORA_APP_ID",
                  "AGORA_APP_CERTIFICATE",
                  "AGORA_TOKEN_TTL_SECONDS (optional)",
                ]
              : [
                  "TWILIO_ACCOUNT_SID (starts with AC)",
                  "TWILIO_API_KEY_SID (starts with SK, NOT Auth Token)",
                  "TWILIO_API_SECRET (API Secret, NOT Auth Token)",
                  "TWILIO_TWIML_APP_SID (starts with AP)",
                ],
          common_mistake:
            providerName === "agora"
              ? "Missing Agora App ID/App Certificate pair"
              : "Using TWILIO_AUTH_TOKEN instead of API Key credentials",
        },
      });
    }

    res.status(500).json({
      error: "Server error",
      message: "Failed to get call token",
    });
  }
}

/**
 * Get user's active call
 * GET /api/v1/calls/active
 */
async function getActiveCall(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT vc.*, si.anonymous_name as other_name, si.avatar_seed as other_avatar
       FROM voice_calls vc
       LEFT JOIN session_identities si ON si.session_id = vc.id AND si.session_type = 'call'
         AND si.user_id != $1
       WHERE (vc.venter_id = $1 OR vc.listener_id = $1)
         AND vc.status IN ('requesting', 'ringing', 'active')
       ORDER BY vc.created_at DESC
       LIMIT 1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.json({
        success: true,
        activeCall: null,
      });
    }

    const call = result.rows[0];
    const provider = call.call_provider || callProvider.getProviderName();
    const roomName = call.voice_channel_name || call.twilio_room_name;

    res.json({
      success: true,
      activeCall: {
        id: call.id,
        status: call.status,
        otherParticipant: {
          anonymousName: call.other_name,
          avatarSeed: call.other_avatar,
        },
        roomName: roomName,
        channelName: roomName,
        provider,
        ratePerMinute: parseFloat(call.rate_per_minute),
        createdAt: call.created_at,
        startedAt: call.started_at,
      },
    });
  } catch (error) {
    logger.error(`Error getting active call: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch active call",
    });
  }
}

/**
 * Get call history
 * GET /api/v1/calls/history
 */
async function getCallHistory(req, res) {
  try {
    const userId = req.user.id;
    const { limit = 20, offset = 0 } = req.query;

    const result = await pool.query(
      `SELECT vc.*, si.anonymous_name as other_name, si.avatar_seed as other_avatar
       FROM voice_calls vc
       LEFT JOIN session_identities si ON si.session_id = vc.id AND si.session_type = 'call'
         AND si.user_id != $1
       WHERE (vc.venter_id = $1 OR vc.listener_id = $1)
         AND vc.status = 'ended'
       ORDER BY vc.created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, parseInt(limit), parseInt(offset)],
    );

    const calls = result.rows.map((row) => ({
      id: row.id,
      status: row.status,
      otherParticipant: {
        anonymousName: row.other_name,
        avatarSeed: row.other_avatar,
      },
      ratePerMinute: parseFloat(row.rate_per_minute),
      durationSeconds: row.duration_seconds,
      durationMinutes: Math.ceil(row.duration_seconds / 60),
      totalCost: row.total_cost ? parseFloat(row.total_cost) : null,
      createdAt: row.created_at,
      startedAt: row.started_at,
      endedAt: row.ended_at,
    }));

    res.json({
      success: true,
      count: calls.length,
      calls: calls,
    });
  } catch (error) {
    logger.error(`Error getting call history: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch call history",
    });
  }
}

/**
 * Get call details
 * GET /api/v1/calls/:id
 */
async function getCall(req, res) {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT vc.*, si.anonymous_name as other_name, si.avatar_seed as other_avatar
       FROM voice_calls vc
       LEFT JOIN session_identities si ON si.session_id = vc.id AND si.session_type = 'call'
         AND si.user_id != $1
       WHERE vc.id = $2 AND (vc.venter_id = $1 OR vc.listener_id = $1)`,
      [userId, id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Call not found",
        message: "Call not found or access denied",
      });
    }

    const call = result.rows[0];
    const provider = call.call_provider || callProvider.getProviderName();
    const roomName = call.voice_channel_name || call.twilio_room_name;

    res.json({
      success: true,
      call: {
        id: call.id,
        status: call.status,
        otherParticipant: {
          anonymousName: call.other_name,
          avatarSeed: call.other_avatar,
        },
        roomName: roomName,
        channelName: roomName,
        provider,
        ratePerMinute: parseFloat(call.rate_per_minute),
        durationSeconds: call.duration_seconds,
        totalCost: call.total_cost ? parseFloat(call.total_cost) : null,
        createdAt: call.created_at,
        startedAt: call.started_at,
        endedAt: call.ended_at,
      },
    });
  } catch (error) {
    logger.error(`Error getting call: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch call",
    });
  }
}

async function getPendingRequests(req, res) {
  try {
    const listenerId = req.user.id;
    const result = await pool.query(
      `SELECT vc.id, vc.venter_id, vc.rate_per_minute, vc.request_group_id,
              u.id as requester_id, us.anonymous_name, us.avatar_seed
       FROM voice_calls vc
       JOIN users u ON u.id = vc.venter_id
       LEFT JOIN user_sessions us ON us.user_id = vc.venter_id
       WHERE vc.listener_id = $1
         AND vc.status = 'requesting'
         AND vc.expires_at > NOW()
       ORDER BY vc.created_at DESC`,
      [listenerId]
    );
    const chatResult = await pool.query(
      `SELECT c.id, c.venter_id, c.rate_per_minute, c.request_group_id,
              u.id as requester_id, us.anonymous_name, us.avatar_seed
       FROM conversations c
       JOIN users u ON u.id = c.venter_id
       LEFT JOIN user_sessions us ON us.user_id = c.venter_id
       WHERE c.listener_id = $1
         AND c.status = 'pending'
         AND c.created_at > NOW() - INTERVAL '60 seconds'
       ORDER BY c.created_at DESC`,
      [listenerId]
    );
    const callRequests = result.rows.map(row => ({
      id: row.id, requestId: row.id, requestType: 'call', listenerId,
      venterId: row.venter_id, ratePerMinute: parseFloat(row.rate_per_minute),
      requester: { id: row.requester_id, anonymousName: row.anonymous_name || 'Anonymous', avatarSeed: row.avatar_seed || row.venter_id },
    }));
    const chatRequests = chatResult.rows.map(row => ({
      id: row.id, requestId: row.id, requestType: 'chat', listenerId,
      venterId: row.venter_id, ratePerMinute: parseFloat(row.rate_per_minute),
      requester: { id: row.requester_id, anonymousName: row.anonymous_name || 'Anonymous', avatarSeed: row.avatar_seed || row.venter_id },
    }));
    res.json({ requests: [...callRequests, ...chatRequests] });
  } catch (err) {
    console.error('[getPendingRequests] Error:', err);
    res.status(500).json({ error: 'Failed to fetch pending requests' });
  }
}

module.exports = {
  getPendingRequests,
  createCall,
  createBroadcastCall,
  acceptCall,
  declineCall,
  endCall,
  getCallToken,
  getActiveCall,
  getCallHistory,
  getCall,
};
