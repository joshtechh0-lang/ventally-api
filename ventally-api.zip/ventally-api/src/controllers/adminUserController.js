const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const { getAdminFinanceStats } = require("../services/adminFinanceStats");

const UUID_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function parsePagination(query) {
  const limit = Math.min(Math.max(parseInt(query.limit || "20", 10), 1), 100);
  const offset = Math.max(parseInt(query.offset || "0", 10), 0);
  return { limit, offset };
}

function buildRoleFilter(role, params) {
  if (!role) {
    return "";
  }

  if (role === "both") {
    return `AND 'venter' = ANY(u.available_roles) AND 'listener' = ANY(u.available_roles)`;
  }

  if (["venter", "listener"].includes(role)) {
    params.push(role);
    return `AND $${params.length} = ANY(u.available_roles)`;
  }

  return "";
}

function mapAccountType(availableRoles = []) {
  const hasVenter = availableRoles.includes("venter");
  const hasListener = availableRoles.includes("listener");

  if (hasVenter && hasListener) {
    return "both";
  }

  if (hasListener) {
    return "listener";
  }

  if (hasVenter) {
    return "venter";
  }

  return "unknown";
}

function normalizeVerificationStatus(status) {
  if (!status) {
    return "not_submitted";
  }

  return status === "verified" ? "approved" : status;
}

function normalizeUserIds(userIds) {
  if (!Array.isArray(userIds) || userIds.length === 0) {
    return { valid: false, message: "userIds must be a non-empty array" };
  }

  const normalized = [...new Set(userIds.map((id) => String(id).trim()))];

  if (normalized.some((id) => !UUID_REGEX.test(id))) {
    return { valid: false, message: "userIds must contain valid UUID values" };
  }

  return { valid: true, userIds: normalized };
}

function resolveRolesForTarget(targetRole, existingUserType) {
  if (targetRole === "listener") {
    return {
      availableRoles: ["listener"],
      activeRole: "listener",
      userType: "listener",
    };
  }

  if (targetRole === "venter") {
    return {
      availableRoles: ["venter"],
      activeRole: "venter",
      userType: "venter",
    };
  }

  return {
    availableRoles: ["venter", "listener"],
    activeRole: "venter",
    userType:
      existingUserType === "listener" || existingUserType === "venter"
        ? existingUserType
        : "venter",
  };
}

function escapePdfText(value) {
  return (value == null ? "" : String(value))
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/\r/g, "")
    .replace(/\n/g, " ")
    .replace(/[\x00-\x1F\x7F]/g, "");
}

function buildPdfBufferFromLines(title, lines) {
  const safeLines = Array.isArray(lines) ? lines : [];
  const textOps = [];

  textOps.push("BT");
  textOps.push("/F1 16 Tf");
  textOps.push("50 780 Td");
  textOps.push(`(${escapePdfText(title)}) Tj`);
  textOps.push("0 -22 Td");
  textOps.push("/F1 10 Tf");

  for (let index = 0; index < safeLines.length; index += 1) {
    textOps.push(`(${escapePdfText(safeLines[index])}) Tj`);
    if (index < safeLines.length - 1) {
      textOps.push("0 -14 Td");
    }
  }

  textOps.push("ET");
  const stream = `${textOps.join("\n")}\n`;

  const objects = {
    1: "<< /Type /Catalog /Pages 2 0 R >>",
    2: "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    3: "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    4: `<< /Length ${Buffer.byteLength(stream, "utf8")} >>\nstream\n${stream}endstream`,
    5: "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  };

  let pdf = "%PDF-1.4\n";
  const offsets = [0];

  for (let objectId = 1; objectId <= 5; objectId += 1) {
    offsets[objectId] = Buffer.byteLength(pdf, "utf8");
    pdf += `${objectId} 0 obj\n${objects[objectId]}\nendobj\n`;
  }

  const xrefOffset = Buffer.byteLength(pdf, "utf8");
  pdf += "xref\n0 6\n0000000000 65535 f \n";

  for (let objectId = 1; objectId <= 5; objectId += 1) {
    pdf += `${String(offsets[objectId]).padStart(10, "0")} 00000 n \n`;
  }

  pdf += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return Buffer.from(pdf, "utf8");
}

async function listUsers(req, res) {
  try {
    const { search = "", role } = req.query;
    const { limit, offset } = parsePagination(req.query);

    const params = [];
    let whereClause = `
      WHERE NOT ('admin' = ANY(u.available_roles) OR 'sub_admin' = ANY(u.available_roles))
    `;

    if (search) {
      params.push(`%${String(search).trim()}%`);
      whereClause += ` AND (u.email ILIKE $${params.length} OR u.id::text ILIKE $${params.length})`;
    }

    whereClause += ` ${buildRoleFilter(role, params)}`;

    params.push(limit);
    params.push(offset);

    const query = `
      SELECT
        u.id,
        u.email,
        u.active_role,
        u.available_roles,
        u.is_active,
        u.created_at,
        COALESCE(lp.total_sessions, 0) AS total_sessions,
        COALESCE(minutes.total_minutes, 0) AS total_minutes,
        COALESCE(payouts.total_payout, 0) AS total_payout
      FROM users u
      LEFT JOIN listener_profiles lp ON lp.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, FLOOR(COALESCE(SUM(duration_seconds), 0) / 60)::INTEGER AS total_minutes
        FROM call_logs
        GROUP BY listener_id
      ) minutes ON minutes.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, ROUND(COALESCE(SUM(net_amount), 0), 2) AS total_payout
        FROM listener_earnings
        GROUP BY listener_id
      ) payouts ON payouts.listener_id = u.id
      ${whereClause}
      ORDER BY u.created_at DESC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `;

    const totalParams = params.slice(0, params.length - 2);
    const totalQuery = `
      SELECT COUNT(*)::INTEGER AS total
      FROM users u
      ${whereClause}
    `;

    const [result, totalResult] = await Promise.all([
      pool.query(query, params),
      pool.query(totalQuery, totalParams),
    ]);

    return res.status(200).json({
      users: result.rows.map((row) => ({
        id: row.id,
        email: row.email,
        activeRole: row.active_role,
        availableRoles: row.available_roles,
        accountType: mapAccountType(row.available_roles || []),
        isActive: row.is_active,
        stats: {
          totalSessions: parseInt(row.total_sessions, 10) || 0,
          totalMinutes: parseInt(row.total_minutes, 10) || 0,
          totalPayout: Number(row.total_payout) || 0,
        },
        createdAt: row.created_at,
      })),
      pagination: {
        total: totalResult.rows[0]?.total || 0,
        limit,
        offset,
      },
    });
  } catch (error) {
    console.error("Error listing admin users:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch users",
    });
  }
}

async function getUserDetail(req, res) {
  try {
    const { userId } = req.params;

    const detailQuery = `
      SELECT
        u.id,
        u.email,
        u.phone,
        u.first_name,
        u.last_name,
        u.display_name,
        u.profile_picture_url,
        u.bio,
        u.date_of_birth,
        u.user_type,
        u.active_role,
        u.available_roles,
        u.is_verified,
        u.is_active,
        u.two_factor_enabled,
        u.two_factor_method,
        u.gender_identity,
        u.cultural_background,
        u.preferred_language,
        u.ethnicity,
        u.age_group,
        u.lgbtq_identity,
        u.special_topics,
        u.faith_or_belief,
        u.signature_url,
        u.created_at,
        u.updated_at,
        COALESCE(lp.total_sessions, 0) AS total_sessions,
        COALESCE(minutes.total_minutes, 0) AS total_minutes,
        COALESCE(payouts.total_payout, 0) AS total_payout,
        latest_verification.status AS latest_verification_status
      FROM users u
      LEFT JOIN listener_profiles lp ON lp.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, FLOOR(COALESCE(SUM(duration_seconds), 0) / 60)::INTEGER AS total_minutes
        FROM call_logs
        GROUP BY listener_id
      ) minutes ON minutes.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, ROUND(COALESCE(SUM(net_amount), 0), 2) AS total_payout
        FROM listener_earnings
        GROUP BY listener_id
      ) payouts ON payouts.listener_id = u.id
      LEFT JOIN LATERAL (
        SELECT status
        FROM listener_verification_documents
        WHERE listener_id = u.id
        ORDER BY created_at DESC
        LIMIT 1
      ) latest_verification ON true
      WHERE u.id = $1
      LIMIT 1
    `;

    const documentsQuery = `
      SELECT
        id,
        status,
        file_url,
        original_file_name,
        mime_type,
        file_size_bytes,
        created_at,
        reviewed_by,
        reviewed_at,
        admin_notes,
        s3_deleted_at
      FROM listener_verification_documents
      WHERE listener_id = $1
      ORDER BY created_at DESC
    `;

    const [detailResult, documentsResult] = await Promise.all([
      pool.query(detailQuery, [userId]),
      pool.query(documentsQuery, [userId]),
    ]);

    if (detailResult.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "User not found",
      });
    }

    const user = detailResult.rows[0];
    const verificationDocuments = documentsResult.rows.map((document) => ({
      id: document.id,
      status: normalizeVerificationStatus(document.status),
      state: normalizeVerificationStatus(document.status),
      fileUrl: document.file_url,
      originalFileName: document.original_file_name,
      mimeType: document.mime_type,
      fileSizeBytes: document.file_size_bytes,
      reviewedBy: document.reviewed_by,
      reviewedAt: document.reviewed_at,
      adminNotes: document.admin_notes,
      isDeleted: Boolean(document.s3_deleted_at),
      deletedAt: document.s3_deleted_at,
      createdAt: document.created_at,
    }));

    const signatureDocument = {
      type: "signature",
      status: user.signature_url ? "available" : "missing",
      state: user.signature_url ? "available" : "missing",
      fileUrl: user.signature_url || null,
      createdAt: user.created_at,
      updatedAt: user.updated_at,
    };

    return res.status(200).json({
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        firstName: user.first_name,
        lastName: user.last_name,
        displayName: user.display_name,
        profilePictureUrl: user.profile_picture_url,
        bio: user.bio,
        dateOfBirth: user.date_of_birth,
        userType: user.user_type,
        activeRole: user.active_role,
        availableRoles: user.available_roles,
        accountType: mapAccountType(user.available_roles || []),
        isVerified: user.is_verified,
        isActive: user.is_active,
        listenerSignature: user.signature_url,
        security: {
          twoFactorAuthentication: {
            enabled: user.two_factor_enabled || false,
            method: user.two_factor_method || null,
          },
        },
        stats: {
          totalSessions: parseInt(user.total_sessions, 10) || 0,
          totalMinutes: parseInt(user.total_minutes, 10) || 0,
          totalPayout: Number(user.total_payout) || 0,
        },
        listenerInfo: {
          genderIdentity: user.gender_identity,
          culturalBackground: user.cultural_background,
          language: user.preferred_language || "en",
          ethnicity: user.ethnicity,
          ageGroup: user.age_group,
          lgbtqIdentity: user.lgbtq_identity,
          specialTopics: user.special_topics || [],
          faithOrBelief: user.faith_or_belief,
          verificationStatus: normalizeVerificationStatus(
            user.latest_verification_status,
          ),
        },
        documents: {
          verification: verificationDocuments,
          signature: signatureDocument,
        },
        verificationDocuments,
        createdAt: user.created_at,
        updatedAt: user.updated_at,
      },
    });
  } catch (error) {
    console.error("Error fetching admin user detail:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch user detail",
    });
  }
}

async function suspendUser(req, res) {
  const client = await pool.connect();

  try {
    const { userId } = req.params;
    const suspended =
      req.body.suspended !== undefined ? Boolean(req.body.suspended) : true;

    if (req.user.id === userId) {
      return res.status(400).json({
        error: "Invalid operation",
        message: "You cannot suspend your own account",
      });
    }

    await client.query("BEGIN");

    const targetResult = await client.query(
      `SELECT id, email, user_type, available_roles, is_active
       FROM users
       WHERE id = $1
       FOR UPDATE`,
      [userId],
    );

    if (targetResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "User not found",
      });
    }

    const target = targetResult.rows[0];
    const roles = target.available_roles || [];

    if (roles.includes("admin") || roles.includes("sub_admin")) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message: "Privileged accounts cannot be suspended from this endpoint",
      });
    }

    const nextIsActive = !suspended;

    await client.query(
      `UPDATE users
       SET is_active = $2,
           updated_at = NOW()
       WHERE id = $1`,
      [userId, nextIsActive],
    );

    if (suspended) {
      await client.query(
        `UPDATE listener_profiles
         SET is_online = false,
             is_busy = false,
             last_online_at = NOW(),
             updated_at = NOW()
         WHERE listener_id = $1`,
        [userId],
      );

      try {
        await redisClient.del(`refresh_token:${userId}`);
      } catch (redisError) {
        console.warn(
          "Failed to remove suspended user refresh token:",
          redisError.message,
        );
      }
    }

    await client.query("COMMIT");

    return res.status(200).json({
      message: suspended
        ? "User suspended successfully"
        : "User reactivated successfully",
      user: {
        id: target.id,
        email: target.email,
        isActive: nextIsActive,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error suspending user:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to update user suspension",
    });
  } finally {
    client.release();
  }
}

async function deleteUser(req, res) {
  const client = await pool.connect();

  try {
    const { userId } = req.params;

    if (req.user.id === userId) {
      return res.status(400).json({
        error: "Invalid operation",
        message: "You cannot delete your own account from this endpoint",
      });
    }

    await client.query("BEGIN");

    const targetResult = await client.query(
      `SELECT id, email, available_roles
       FROM users
       WHERE id = $1
       FOR UPDATE`,
      [userId],
    );

    if (targetResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "User not found",
      });
    }

    const target = targetResult.rows[0];
    const roles = target.available_roles || [];

    if (roles.includes("admin") || roles.includes("sub_admin")) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message: "Privileged accounts cannot be deleted from this endpoint",
      });
    }

    await client.query(`DELETE FROM users WHERE id = $1`, [userId]);
    await client.query("COMMIT");

    try {
      await redisClient.del(`refresh_token:${userId}`);
    } catch (redisError) {
      console.warn(
        "Failed to remove deleted user refresh token:",
        redisError.message,
      );
    }

    return res.status(200).json({
      message: "User deleted successfully",
      user: {
        id: target.id,
        email: target.email,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error deleting user:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete user",
    });
  } finally {
    client.release();
  }
}

async function listIntegrations(req, res) {
  try {
    const { search = "", role, status, userId } = req.query;
    const { limit, offset } = parsePagination(req.query);

    const params = [];
    let whereClause = `
      WHERE NOT ('admin' = ANY(u.available_roles) OR 'sub_admin' = ANY(u.available_roles))
    `;

    if (search) {
      params.push(`%${String(search).trim()}%`);
      whereClause += ` AND (u.email ILIKE $${params.length} OR u.id::text ILIKE $${params.length})`;
    }

    if (userId) {
      params.push(String(userId).trim());
      whereClause += ` AND u.id = $${params.length}`;
    }

    whereClause += ` ${buildRoleFilter(role, params)}`;

    if (status === "exported") {
      whereClause += ` AND COALESCE(aue.exported, false) = true`;
    } else if (status === "pending" || status === "not_exported") {
      whereClause += ` AND COALESCE(aue.exported, false) = false`;
    }

    params.push(limit);
    params.push(offset);

    const query = `
      SELECT
        u.id,
        u.email,
        u.active_role,
        u.available_roles,
        COALESCE(lp.total_sessions, 0) AS total_sessions,
        COALESCE(minutes.total_minutes, 0) AS total_minutes,
        COALESCE(payouts.total_payout, 0) AS total_payout,
        COALESCE(aue.exported, false) AS exported,
        aue.exported_at
      FROM users u
      LEFT JOIN listener_profiles lp ON lp.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, FLOOR(COALESCE(SUM(duration_seconds), 0) / 60)::INTEGER AS total_minutes
        FROM call_logs
        GROUP BY listener_id
      ) minutes ON minutes.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, ROUND(COALESCE(SUM(net_amount), 0), 2) AS total_payout
        FROM listener_earnings
        GROUP BY listener_id
      ) payouts ON payouts.listener_id = u.id
      LEFT JOIN admin_user_exports aue ON aue.user_id = u.id
      ${whereClause}
      ORDER BY u.created_at DESC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `;

    const totalParams = params.slice(0, params.length - 2);
    const totalQuery = `
      SELECT COUNT(*)::INTEGER AS total
      FROM users u
      LEFT JOIN admin_user_exports aue ON aue.user_id = u.id
      ${whereClause}
    `;

    const [result, totalResult] = await Promise.all([
      pool.query(query, params),
      pool.query(totalQuery, totalParams),
    ]);

    return res.status(200).json({
      items: result.rows.map((row) => ({
        id: row.id,
        email: row.email,
        activeRole: row.active_role,
        availableRoles: row.available_roles,
        accountType: mapAccountType(row.available_roles || []),
        stats: {
          totalSessions: parseInt(row.total_sessions, 10) || 0,
          totalMinutes: parseInt(row.total_minutes, 10) || 0,
          totalPayout: Number(row.total_payout) || 0,
        },
        exportStatus: row.exported ? "exported" : "pending",
        exportedAt: row.exported_at,
      })),
      pagination: {
        total: totalResult.rows[0]?.total || 0,
        limit,
        offset,
      },
    });
  } catch (error) {
    console.error("Error listing admin integrations:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch integrations",
    });
  }
}

async function exportIntegrationsPdf(req, res) {
  try {
    const { search = "", role, status, userId } = req.query;
    const maxRows = Math.min(
      Math.max(parseInt(req.query.maxRows || "250", 10), 1),
      1000,
    );

    const params = [];
    let whereClause = `
      WHERE NOT ('admin' = ANY(u.available_roles) OR 'sub_admin' = ANY(u.available_roles))
    `;

    if (search) {
      params.push(`%${String(search).trim()}%`);
      whereClause += ` AND (u.email ILIKE $${params.length} OR u.id::text ILIKE $${params.length})`;
    }

    if (userId) {
      params.push(String(userId).trim());
      whereClause += ` AND u.id = $${params.length}`;
    }

    whereClause += ` ${buildRoleFilter(role, params)}`;

    if (status === "exported") {
      whereClause += ` AND COALESCE(aue.exported, false) = true`;
    } else if (status === "pending" || status === "not_exported") {
      whereClause += ` AND COALESCE(aue.exported, false) = false`;
    }

    params.push(maxRows);

    const query = `
      SELECT
        u.id,
        u.email,
        u.available_roles,
        COALESCE(lp.total_sessions, 0) AS total_sessions,
        COALESCE(minutes.total_minutes, 0) AS total_minutes,
        COALESCE(payouts.total_payout, 0) AS total_payout,
        COALESCE(aue.exported, false) AS exported,
        aue.exported_at
      FROM users u
      LEFT JOIN listener_profiles lp ON lp.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, FLOOR(COALESCE(SUM(duration_seconds), 0) / 60)::INTEGER AS total_minutes
        FROM call_logs
        GROUP BY listener_id
      ) minutes ON minutes.listener_id = u.id
      LEFT JOIN (
        SELECT listener_id, ROUND(COALESCE(SUM(net_amount), 0), 2) AS total_payout
        FROM listener_earnings
        GROUP BY listener_id
      ) payouts ON payouts.listener_id = u.id
      LEFT JOIN admin_user_exports aue ON aue.user_id = u.id
      ${whereClause}
      ORDER BY u.created_at DESC
      LIMIT $${params.length}
    `;

    const result = await pool.query(query, params);

    const lines = [
      `Generated at: ${new Date().toISOString()}`,
      `Generated by: ${req.user?.email || req.user?.id || "admin"}`,
      `Filters: role=${role || "all"}, status=${status || "all"}, userId=${userId || "all"}, search=${search || "none"}`,
      `Total rows: ${result.rows.length}`,
      "",
      "ID | Email | Type | Sessions | Minutes | Payout | Export",
    ];

    for (const row of result.rows) {
      lines.push(
        `${row.id} | ${row.email || "-"} | ${mapAccountType(row.available_roles || [])} | ${parseInt(row.total_sessions, 10) || 0} | ${parseInt(row.total_minutes, 10) || 0} | ${Number(row.total_payout) || 0} | ${row.exported ? "exported" : "pending"}`,
      );
    }

    if (result.rows.length === maxRows) {
      lines.push(`(truncated to maxRows=${maxRows})`);
    }

    const pdfBuffer = buildPdfBufferFromLines(
      "Ventally Admin Integrations Export",
      lines,
    );

    const dateKey = new Date().toISOString().slice(0, 10);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="admin-integrations-${dateKey}.pdf"`,
    );

    return res.status(200).send(pdfBuffer);
  } catch (error) {
    console.error("Error exporting integrations PDF:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to export integrations PDF",
    });
  }
}

async function updateIntegrationExportStatus(req, res) {
  const client = await pool.connect();

  try {
    const { userId } = req.params;
    const { exported } = req.body;

    if (!UUID_REGEX.test(String(userId))) {
      return res.status(400).json({
        error: "Validation error",
        message: "Invalid userId",
      });
    }

    if (typeof exported !== "boolean") {
      return res.status(400).json({
        error: "Validation error",
        message: "exported must be a boolean",
      });
    }

    await client.query("BEGIN");

    const targetResult = await client.query(
      `SELECT id, email, available_roles
       FROM users
       WHERE id = $1
       FOR UPDATE`,
      [userId],
    );

    if (targetResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "User not found",
      });
    }

    const target = targetResult.rows[0];
    const roles = target.available_roles || [];

    if (roles.includes("admin") || roles.includes("sub_admin")) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message: "Privileged accounts are not supported on this endpoint",
      });
    }

    await client.query(
      `INSERT INTO admin_user_exports (user_id, exported, exported_at, exported_by)
       VALUES ($1, $2, CASE WHEN $2 THEN NOW() ELSE NULL END, $3)
       ON CONFLICT (user_id)
       DO UPDATE SET
         exported = EXCLUDED.exported,
         exported_at = CASE WHEN EXCLUDED.exported THEN NOW() ELSE NULL END,
         exported_by = EXCLUDED.exported_by,
         updated_at = NOW()`,
      [userId, exported, req.user.id],
    );

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Export status updated successfully",
      integration: {
        userId: target.id,
        email: target.email,
        exportStatus: exported ? "exported" : "pending",
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error updating export status:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to update export status",
    });
  } finally {
    client.release();
  }
}

async function listPaymentHistory(req, res) {
  try {
    const { search = "", userId, status, from, to } = req.query;
    const { limit, offset } = parsePagination(req.query);

    const params = [];
    let whereClause = `WHERE 1=1`;

    if (search) {
      params.push(`%${String(search).trim()}%`);
      whereClause += ` AND (u.email ILIKE $${params.length} OR cs.stripe_session_id ILIKE $${params.length})`;
    }

    if (userId) {
      params.push(String(userId).trim());
      whereClause += ` AND cs.user_id = $${params.length}`;
    }

    if (
      status &&
      ["pending", "completed", "expired", "failed"].includes(status)
    ) {
      params.push(status);
      whereClause += ` AND cs.status = $${params.length}`;
    }

    if (from) {
      params.push(from);
      whereClause += ` AND cs.created_at >= $${params.length}::timestamptz`;
    }

    if (to) {
      params.push(to);
      whereClause += ` AND cs.created_at <= $${params.length}::timestamptz`;
    }

    params.push(limit);
    params.push(offset);

    const query = `
      SELECT
        cs.stripe_session_id,
        cs.status,
        cs.amount_total,
        cs.currency,
        cs.mode,
        cs.created_at,
        cs.completed_at,
        u.id AS user_id,
        u.email
      FROM checkout_sessions cs
      JOIN users u ON u.id = cs.user_id
      ${whereClause}
      ORDER BY cs.created_at DESC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `;

    const totalParams = params.slice(0, params.length - 2);
    const totalQuery = `
      SELECT COUNT(*)::INTEGER AS total
      FROM checkout_sessions cs
      JOIN users u ON u.id = cs.user_id
      ${whereClause}
    `;

    const [result, totalResult] = await Promise.all([
      pool.query(query, params),
      pool.query(totalQuery, totalParams),
    ]);

    return res.status(200).json({
      payments: result.rows.map((row) => ({
        id: row.stripe_session_id,
        amount: row.amount_total ? row.amount_total / 100 : null,
        currency: row.currency,
        status: row.status,
        mode: row.mode,
        createdAt: row.created_at,
        completedAt: row.completed_at,
        user: {
          id: row.user_id,
          email: row.email,
        },
      })),
      pagination: {
        total: totalResult.rows[0]?.total || 0,
        limit,
        offset,
      },
    });
  } catch (error) {
    console.error("Error listing admin payment history:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch payment history",
    });
  }
}

async function exportPaymentHistoryPdf(req, res) {
  try {
    const { search = "", userId, status, from, to } = req.query;
    const maxRows = Math.min(
      Math.max(parseInt(req.query.maxRows || "250", 10), 1),
      1000,
    );

    const params = [];
    let whereClause = `WHERE 1=1`;

    if (search) {
      params.push(`%${String(search).trim()}%`);
      whereClause += ` AND (u.email ILIKE $${params.length} OR cs.stripe_session_id ILIKE $${params.length})`;
    }

    if (userId) {
      params.push(String(userId).trim());
      whereClause += ` AND cs.user_id = $${params.length}`;
    }

    if (
      status &&
      ["pending", "completed", "expired", "failed"].includes(status)
    ) {
      params.push(status);
      whereClause += ` AND cs.status = $${params.length}`;
    }

    if (from) {
      params.push(from);
      whereClause += ` AND cs.created_at >= $${params.length}::timestamptz`;
    }

    if (to) {
      params.push(to);
      whereClause += ` AND cs.created_at <= $${params.length}::timestamptz`;
    }

    params.push(maxRows);

    const query = `
      SELECT
        cs.stripe_session_id,
        cs.status,
        cs.amount_total,
        cs.currency,
        cs.mode,
        cs.created_at,
        cs.completed_at,
        u.id AS user_id,
        u.email
      FROM checkout_sessions cs
      JOIN users u ON u.id = cs.user_id
      ${whereClause}
      ORDER BY cs.created_at DESC
      LIMIT $${params.length}
    `;

    const result = await pool.query(query, params);

    const lines = [
      `Generated at: ${new Date().toISOString()}`,
      `Generated by: ${req.user?.email || req.user?.id || "admin"}`,
      `Filters: status=${status || "all"}, search=${search || "none"}, userId=${userId || "all"}, from=${from || "none"}, to=${to || "none"}`,
      `Total rows: ${result.rows.length}`,
      "",
      "Session ID | User Email | Amount | Currency | Status | Created At",
    ];

    for (const row of result.rows) {
      const amount = row.amount_total ? row.amount_total / 100 : 0;
      lines.push(
        `${row.stripe_session_id} | ${row.email || "-"} | ${amount} | ${row.currency || "USD"} | ${row.status || "-"} | ${row.created_at || "-"}`,
      );
    }

    if (result.rows.length === maxRows) {
      lines.push(`(truncated to maxRows=${maxRows})`);
    }

    const pdfBuffer = buildPdfBufferFromLines(
      "Ventally Admin Payment History Export",
      lines,
    );

    const dateKey = new Date().toISOString().slice(0, 10);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="admin-payment-history-${dateKey}.pdf"`,
    );

    return res.status(200).send(pdfBuffer);
  } catch (error) {
    console.error("Error exporting payment history PDF:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to export payment history PDF",
    });
  }
}

async function getPaymentStats(req, res) {
  try {
    const stats = await getAdminFinanceStats();
    return res.status(200).json(stats);
  } catch (error) {
    console.error("Error fetching admin payment stats:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch payment statistics",
    });
  }
}

async function bulkChangeUserRoles(req, res) {
  const client = await pool.connect();

  try {
    const { userIds, targetRole } = req.body;
    const normalizedIds = normalizeUserIds(userIds);

    if (!normalizedIds.valid) {
      return res.status(400).json({
        error: "Validation error",
        message: normalizedIds.message,
      });
    }

    if (!["venter", "listener", "both"].includes(targetRole)) {
      return res.status(400).json({
        error: "Validation error",
        message: "targetRole must be one of: venter, listener, both",
      });
    }

    await client.query("BEGIN");

    const usersResult = await client.query(
      `SELECT id, email, user_type, available_roles
       FROM users
       WHERE id = ANY($1::uuid[])
       FOR UPDATE`,
      [normalizedIds.userIds],
    );

    if (usersResult.rows.length !== normalizedIds.userIds.length) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "One or more users were not found",
      });
    }

    const privileged = usersResult.rows.filter((row) => {
      const roles = row.available_roles || [];
      return roles.includes("admin") || roles.includes("sub_admin");
    });

    if (privileged.length > 0) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message: "Privileged accounts cannot be updated from this endpoint",
      });
    }

    for (const row of usersResult.rows) {
      const next = resolveRolesForTarget(targetRole, row.user_type);

      await client.query(
        `UPDATE users
         SET available_roles = $2::text[],
             active_role = $3,
             user_type = $4,
             updated_at = NOW()
         WHERE id = $1`,
        [row.id, next.availableRoles, next.activeRole, next.userType],
      );
    }

    await client.query("COMMIT");

    return res.status(200).json({
      message: "User roles updated successfully",
      updatedCount: usersResult.rows.length,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error bulk changing user roles:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to update user roles",
    });
  } finally {
    client.release();
  }
}

async function bulkDeleteUsers(req, res) {
  const client = await pool.connect();

  try {
    const { userIds } = req.body;
    const normalizedIds = normalizeUserIds(userIds);

    if (!normalizedIds.valid) {
      return res.status(400).json({
        error: "Validation error",
        message: normalizedIds.message,
      });
    }

    if (normalizedIds.userIds.includes(req.user.id)) {
      return res.status(400).json({
        error: "Invalid operation",
        message: "You cannot delete your own account from this endpoint",
      });
    }

    await client.query("BEGIN");

    const usersResult = await client.query(
      `SELECT id, email, available_roles
       FROM users
       WHERE id = ANY($1::uuid[])
       FOR UPDATE`,
      [normalizedIds.userIds],
    );

    if (usersResult.rows.length !== normalizedIds.userIds.length) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "One or more users were not found",
      });
    }

    const privileged = usersResult.rows.filter((row) => {
      const roles = row.available_roles || [];
      return roles.includes("admin") || roles.includes("sub_admin");
    });

    if (privileged.length > 0) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message: "Privileged accounts cannot be deleted from this endpoint",
      });
    }

    await client.query(`DELETE FROM users WHERE id = ANY($1::uuid[])`, [
      normalizedIds.userIds,
    ]);

    await client.query("COMMIT");

    for (const userId of normalizedIds.userIds) {
      try {
        await redisClient.del(`refresh_token:${userId}`);
      } catch (redisError) {
        console.warn(
          "Failed to remove deleted user refresh token:",
          redisError.message,
        );
      }
    }

    return res.status(200).json({
      message: "Users deleted successfully",
      deletedCount: normalizedIds.userIds.length,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error bulk deleting users:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete users",
    });
  } finally {
    client.release();
  }
}

module.exports = {
  listUsers,
  getUserDetail,
  suspendUser,
  deleteUser,
  listIntegrations,
  exportIntegrationsPdf,
  updateIntegrationExportStatus,
  listPaymentHistory,
  exportPaymentHistoryPdf,
  getPaymentStats,
  bulkChangeUserRoles,
  bulkDeleteUsers,
};
