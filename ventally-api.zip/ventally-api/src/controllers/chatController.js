const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const anonymizer = require("../services/anonymizer");
const presence = require("../services/presence");
const { getSetting } = require("../services/settings");
const {
  getConversationParticipants,
  isConversationParticipant,
  getConversationMessages,
} = require("../services/chatHistory");
const walletController = require("../controllers/walletController");
const {
  sendUserPushNotification,
} = require("../services/listenerNotifications");
const logger = require("../utils/logger");
const { v4: uuidv4 } = require("uuid");
const klaviyo = require("../services/klaviyo");

async function sendChatRequestPushNotification(
  listenerId,
  conversationId,
  requester,
  ratePerMinute,
) {
  const isAvailable = await presence.isListenerAvailable(listenerId);

  if (!isAvailable) {
    logger.info("Skipping chat request push for unavailable listener", {
      listenerId,
      conversationId,
    });
    return {
      userId: listenerId,
      skipped: true,
      successCount: 0,
      failureCount: 0,
      reason: "listener_unavailable",
    };
  }

  return sendUserPushNotification({
    userId: listenerId,
    channel: "message",
    title: "New chat request",
    body: `${requester?.anonymousName || "A venter"} sent a chat request`,
    data: {
      type: "chat_request",
      notification_channel: "message",
      conversationId: String(conversationId),
      ratePerMinute: String(ratePerMinute),
    },
  });
}

async function emitChatRequestToListener(io, listenerId, payload) {
  // Emit to the listener user room so all active sockets get request updates.
  io.to(String(listenerId)).emit("chat:request", payload);

  io.to(String(listenerId)).emit("requests:updated", {
    conversationId: payload.conversationId,
    status: "pending",
    role: "listener",
    requester: payload.requester,
    listenerId,
    ratePerMinute: payload.ratePerMinute,
    createdAt: payload.createdAt,
    updatedAt: payload.createdAt,
  });

  await sendChatRequestPushNotification(
    listenerId,
    payload.conversationId,
    payload.requester,
    payload.ratePerMinute,
  );
}

/**
 * Create a chat conversation (venter requests chat with listener)
 * POST /api/v1/conversations
 */
async function createConversation(req, res) {
  const client = await pool.connect();

  try {
    const { listenerId, paymentMode: rawPaymentMode } = req.body;
    const venterId = req.user.id;
    const paymentMode = rawPaymentMode === "payg" ? "payg" : "prepaid";

    // Validation
    if (!listenerId) {
      return res.status(400).json({
        error: "Missing listener ID",
        message: "Listener ID is required",
      });
    }

    if (venterId === listenerId) {
      return res.status(400).json({
        error: "Invalid request",
        message: "Cannot chat with yourself",
      });
    }

    // Check if listener is available
    const available = await presence.isListenerAvailable(listenerId);
    if (!available) {
      return res.status(400).json({
        error: "Listener unavailable",
        message: "This listener is currently offline or busy",
      });
    }

    await client.query("BEGIN");

    // Get listener rate
    const listenerResult = await client.query(
      `SELECT lp.rate_per_minute
       FROM listener_profiles lp
       INNER JOIN users u ON u.id = lp.listener_id
       WHERE lp.listener_id = $1
         AND u.is_active = true
         AND u.is_verified = true`,
      [listenerId],
    );

    if (listenerResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Listener not found",
        message: "Listener profile not found or listener is inactive",
      });
    }

    const ratePerMinute = parseFloat(listenerResult.rows[0].rate_per_minute);

    // Check venter eligibility (subscription first, then prepaid balance)
    const minMinutes = await getSetting("min_call_balance_minutes", 5);
    const minBalance = minMinutes * ratePerMinute;

    let eligibility;
    if (paymentMode === "payg") {
      eligibility = await walletController.canUsePayg(venterId);
      if (!eligibility.allowed) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "PAYG unavailable",
          message:
            eligibility.reason === "not_enrolled"
              ? "Enable Pay-as-you-go and save a card before starting a PAYG chat"
              : eligibility.reason === "payg_locked"
                ? "Your PAYG account is locked due to a previous declined charge. Update your card to continue."
                : eligibility.reason === "no_payment_method"
                  ? "Add a payment method to use Pay-as-you-go"
                  : "Pay-as-you-go is not available right now",
          reason: eligibility.reason,
        });
      }
    } else {
      eligibility = await walletController.canMakeCall(venterId);

      if (!eligibility.allowed) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "Insufficient balance",
          message: `You don't have an active subscription or sufficient prepaid balance. You need at least ${minMinutes} minutes to start a chat.`,
          required: minMinutes,
          suggestion:
            "Subscribe to a plan, add prepaid minutes, or enable Pay-as-you-go",
        });
      }

      // Enforce minimum balance only for prepaid users
      if (
        eligibility.source === "prepaid" &&
        eligibility.remainingMinutes < minMinutes
      ) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "Insufficient balance",
          message: `You need at least ${minMinutes} minutes ($${minBalance.toFixed(2)}) to start a chat`,
          balance: eligibility.remainingMinutes,
          required: minMinutes,
        });
      }
    }

    // Create conversation
    const convResult = await client.query(
      `INSERT INTO conversations
        (venter_id, listener_id, status, rate_per_minute, payment_mode)
       VALUES ($1, $2, 'pending', $3, $4)
       RETURNING *`,
      [venterId, listenerId, ratePerMinute, paymentMode],
    );

    const conversation = convResult.rows[0];

    // Create anonymous identities
    const venterIdentity = await anonymizer.createSessionIdentity(
      venterId,
      conversation.id,
      "chat",
    );

    const listenerIdentity = await anonymizer.createSessionIdentity(
      listenerId,
      conversation.id,
      "chat",
    );

    await client.query("COMMIT");

    logger.info(
      `Chat conversation ${conversation.id} created: ${venterId} -> ${listenerId}`,
    );

    // Emit listener request notifications
    const io = req.app.get("io");
    await emitChatRequestToListener(io, listenerId, {
      conversationId: conversation.id,
      requester: {
        id: venterId,
        anonymousName: venterIdentity.anonymousName,
        avatarSeed: venterIdentity.avatarSeed,
      },
      ratePerMinute: ratePerMinute,
      createdAt: conversation.created_at,
    });

    const requestUpdateEvent = {
      conversationId: conversation.id,
      status: conversation.status,
      role: "listener",
      venterId,
      listenerId,
      requester: {
        id: venterId,
        anonymousName: venterIdentity.anonymousName,
        avatarSeed: venterIdentity.avatarSeed,
      },
      listenerId,
      ratePerMinute: ratePerMinute,
      createdAt: conversation.created_at,
      updatedAt: conversation.updated_at,
    };

    io.to(String(listenerId)).emit("requests:updated", requestUpdateEvent);
    io.to(String(venterId)).emit("requests:updated", {
      ...requestUpdateEvent,
      role: "venter",
    });

    res.json({
      success: true,
      conversation: {
        id: conversation.id,
        status: conversation.status,
        venterId,
        listenerId,
        listener: {
          anonymousName: listenerIdentity.anonymousName,
          avatarSeed: listenerIdentity.avatarSeed,
        },
        ratePerMinute: ratePerMinute,
        createdAt: conversation.created_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error creating conversation: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to create conversation",
    });
  } finally {
    client.release();
  }
}

/**
 * Create chat requests for all currently available listeners
 * POST /api/v1/conversations/broadcast
 */
async function createBroadcastConversation(req, res) {
  const client = await pool.connect();

  try {
    const venterId = req.user.id;
    const listeners = await presence.getAvailableListeners(venterId);

    if (listeners.length === 0) {
      return res.status(404).json({
        error: "No listeners available",
        message: "No listeners are currently available",
      });
    }

    const maxRatePerMinute = listeners.reduce(
      (currentMax, listener) =>
        Math.max(currentMax, parseFloat(listener.ratePerMinute || 0)),
      0,
    );

    const minMinutes = await getSetting("min_call_balance_minutes", 5);
    const minBalance = minMinutes * maxRatePerMinute;
    const eligibility = await walletController.canMakeCall(venterId);

    if (!eligibility.allowed) {
      return res.status(402).json({
        error: "Insufficient balance",
        message: `You don't have an active subscription or sufficient prepaid balance. You need at least ${minMinutes} minutes to start a chat.`,
        required: minMinutes,
        suggestion: "Subscribe to a plan or add prepaid minutes to your wallet",
      });
    }

    if (
      eligibility.source === "prepaid" &&
      eligibility.remainingMinutes < minMinutes
    ) {
      return res.status(402).json({
        error: "Insufficient balance",
        message: `You need at least ${minMinutes} minutes ($${minBalance.toFixed(2)}) to start a chat`,
        balance: eligibility.remainingMinutes,
        required: minMinutes,
      });
    }

    const requestGroupId = uuidv4();
    await client.query("BEGIN");

    const createdConversations = [];

    for (const listener of listeners) {
      const listenerId = listener.listenerId;
      const ratePerMinute = parseFloat(listener.ratePerMinute);

      const convResult = await client.query(
        `INSERT INTO conversations
          (venter_id, listener_id, status, rate_per_minute, request_group_id)
         VALUES ($1, $2, 'pending', $3, $4)
         RETURNING *`,
        [venterId, listenerId, ratePerMinute, requestGroupId],
      );

      const conversation = convResult.rows[0];

      const venterIdentity = await anonymizer.createSessionIdentity(
        venterId,
        conversation.id,
        "chat",
      );

      await anonymizer.createSessionIdentity(
        listenerId,
        conversation.id,
        "chat",
      );

      createdConversations.push({
        conversation,
        listenerId,
        ratePerMinute,
        venterIdentity,
      });
    }

    await client.query("COMMIT");

    const io = req.app.get("io");
    for (const item of createdConversations) {
      await emitChatRequestToListener(io, item.listenerId, {
        conversationId: item.conversation.id,
        requester: {
          id: venterId,
          anonymousName: item.venterIdentity.anonymousName,
          avatarSeed: item.venterIdentity.avatarSeed,
        },
        ratePerMinute: item.ratePerMinute,
        createdAt: item.conversation.created_at,
      });

      io.to(String(venterId)).emit("requests:updated", {
        conversationId: item.conversation.id,
        status: item.conversation.status,
        role: "venter",
        requester: {
          id: venterId,
          anonymousName: item.venterIdentity.anonymousName,
          avatarSeed: item.venterIdentity.avatarSeed,
        },
        listenerId: item.listenerId,
        ratePerMinute: item.ratePerMinute,
        createdAt: item.conversation.created_at,
        updatedAt: item.conversation.updated_at,
      });
    }

    res.json({
      success: true,
      requestGroupId,
      count: createdConversations.length,
      conversations: createdConversations.map((item) => ({
        id: item.conversation.id,
        status: item.conversation.status,
        listenerId: item.listenerId,
        ratePerMinute: item.ratePerMinute,
        createdAt: item.conversation.created_at,
      })),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error creating broadcast conversation: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to create broadcast conversation",
    });
  } finally {
    client.release();
  }
}

/**
 * Accept a chat conversation (listener)
 * POST /api/v1/conversations/:id/accept
 */
async function acceptConversation(req, res) {
  const client = await pool.connect();

  try {
    const { id } = req.params;
    const listenerId = req.user.id;

    await client.query("BEGIN");

    // Get conversation
    const convResult = await client.query(
      "SELECT * FROM conversations WHERE id = $1 FOR UPDATE",
      [id],
    );

    if (convResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Conversation not found",
        message: "Conversation not found",
      });
    }

    const conversation = convResult.rows[0];

    // Verify listener
    if (conversation.listener_id !== listenerId) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not the listener for this conversation",
      });
    }

    // Check status
    if (conversation.status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid status",
        message: `Conversation is ${conversation.status}, cannot accept`,
      });
    }

    let closedRequestIds = [];

    if (conversation.request_group_id) {
      const activeInGroupResult = await client.query(
        `SELECT id
         FROM conversations
         WHERE request_group_id = $1
           AND status = 'active'
           AND id != $2
         LIMIT 1`,
        [conversation.request_group_id, id],
      );

      if (activeInGroupResult.rows.length > 0) {
        await client.query("ROLLBACK");
        return res.status(409).json({
          error: "Request already claimed",
          message: "Another listener already accepted this request",
        });
      }

      const closeOthersResult = await client.query(
        `UPDATE conversations
         SET status = 'declined', ended_at = NOW()
         WHERE request_group_id = $1
           AND id != $2
           AND status = 'pending'
         RETURNING id, listener_id`,
        [conversation.request_group_id, id],
      );

      closedRequestIds = closeOthersResult.rows;
    }

    // Update conversation status
    await client.query(
      "UPDATE conversations SET status = 'active', started_at = NOW() WHERE id = $1",
      [id],
    );

    if (conversation.request_group_id) {
      await client.query(
        `UPDATE socket_broadcast_requests
         SET status = 'claimed',
             claimed_listener_id = $1,
             claimed_request_id = $2,
             claimed_at = NOW()
         WHERE id = $3
           AND status = 'open'`,
        [listenerId, id, conversation.request_group_id],
      );

      await client.query(
        `UPDATE listener_request_deliveries
         SET status = CASE
             WHEN listener_id = $1 AND request_type = 'chat' AND request_id = $2
               THEN 'acknowledged'
             ELSE 'cancelled'
           END,
           acknowledged_at = CASE
             WHEN listener_id = $1 AND request_type = 'chat' AND request_id = $2
               THEN COALESCE(acknowledged_at, NOW())
             ELSE acknowledged_at
           END
         WHERE request_group_id = $3
           AND status = 'sent'`,
        [listenerId, id, conversation.request_group_id],
      );
    }

    // Mark listener as busy
    await presence.setListenerBusy(listenerId, id);

    await client.query("COMMIT");

    logger.info(`Listener ${listenerId} accepted chat ${id}`);

    // Get or create identities
    let venterIdentity = await anonymizer.getSessionIdentity(id, conversation.venter_id);
    if (!venterIdentity) {
      venterIdentity = await anonymizer.createSessionIdentity(conversation.venter_id, id, "chat");
    }
    let listenerIdentity = await anonymizer.getSessionIdentity(id, listenerId);
    if (!listenerIdentity) {
      listenerIdentity = await anonymizer.createSessionIdentity(listenerId, id, "chat");
    }
    const io = req.app.get("io");
    const startedAt = new Date().toISOString();
    io.to(String(conversation.venter_id)).emit("chat:accepted", {
      conversationId: id,
      listenerId,
      venterId: conversation.venter_id,
      conversation: {
        id,
        status: "active",
        listenerId,
        venterId: conversation.venter_id,
        startedAt,
      },
      listener: {
        id: listenerId,
        anonymousName: listenerIdentity.anonymousName,
        avatarSeed: listenerIdentity.avatarSeed,
      },
      startedAt,
    });

    const requestRemovedEvent = {
      conversationId: id,
      status: "active",
      reason: "accepted",
      updatedAt: startedAt,
    };

    io.to(String(listenerId)).emit("requests:removed", requestRemovedEvent);
    io.to(String(conversation.venter_id)).emit(
      "requests:removed",
      requestRemovedEvent,
    );

    for (const closedRequest of closedRequestIds) {
      io.to(String(closedRequest.listener_id)).emit("requests:removed", {
        conversationId: closedRequest.id,
        status: "declined",
        reason: "claimed_by_other_listener",
        updatedAt: startedAt,
      });

      io.to(String(closedRequest.listener_id)).emit("chat:request:closed", {
        conversationId: closedRequest.id,
        reason: "claimed_by_other_listener",
        acceptedConversationId: id,
      });

      io.to(String(conversation.venter_id)).emit("requests:removed", {
        conversationId: closedRequest.id,
        status: "declined",
        reason: "claimed_by_other_listener",
        updatedAt: startedAt,
      });
    }

    res.json({
      success: true,
      conversation: {
        id: id,
        status: "active",
        listenerId,
        venterId: conversation.venter_id,
        venter: {
          id: conversation.venter_id,
          anonymousName: venterIdentity.anonymousName,
          avatarSeed: venterIdentity.avatarSeed,
        },
        startedAt,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error accepting conversation: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to accept conversation",
    });
  } finally {
    client.release();
  }
}

/**
 * Decline a chat conversation (listener)
 * POST /api/v1/conversations/:id/decline
 */
async function declineConversation(req, res) {
  try {
    const { id } = req.params;
    const listenerId = req.user.id;

    const convResult = await pool.query(
      "SELECT * FROM conversations WHERE id = $1",
      [id],
    );

    if (convResult.rows.length === 0) {
      return res.status(404).json({
        error: "Conversation not found",
        message: "Conversation not found",
      });
    }

    const conversation = convResult.rows[0];

    if (conversation.listener_id !== listenerId) {
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not the listener for this conversation",
      });
    }

    if (conversation.status !== "pending") {
      return res.status(400).json({
        error: "Invalid status",
        message: `Conversation is ${conversation.status}, cannot decline`,
      });
    }

    await pool.query(
      "UPDATE conversations SET status = 'declined', ended_at = NOW() WHERE id = $1",
      [id],
    );

    // Defensive cleanup: release busy only when no other active session exists.
    const activeSession = await presence.getActiveListenerSession(listenerId);
    if (!activeSession) {
      await presence.clearListenerBusy(listenerId);
    }

    logger.info(`Listener ${listenerId} declined chat ${id}`);

    // Notify venter
    const io = req.app.get("io");
    const venterSocketId = await redisClient.get(
      `socket:${conversation.venter_id}`,
    );

    let shouldNotifyVenterDeclined = true;

    if (conversation.request_group_id) {
      const remainingResult = await pool.query(
        `SELECT 1
         FROM conversations
         WHERE request_group_id = $1
           AND status = 'pending'
         LIMIT 1`,
        [conversation.request_group_id],
      );

      shouldNotifyVenterDeclined = remainingResult.rows.length === 0;
    }

    if (venterSocketId && shouldNotifyVenterDeclined) {
      io.to(venterSocketId).emit("chat:declined", {
        conversationId: id,
        message: "All listeners declined your chat request",
      });
    }

    const declinedAt = new Date().toISOString();
    const requestRemovedEvent = {
      conversationId: id,
      status: "declined",
      reason: "declined",
      updatedAt: declinedAt,
    };

    io.to(String(listenerId)).emit("requests:removed", requestRemovedEvent);
    io.to(String(conversation.venter_id)).emit(
      "requests:removed",
      requestRemovedEvent,
    );

    res.json({
      success: true,
      message: "Conversation declined",
    });
  } catch (error) {
    logger.error(`Error declining conversation: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to decline conversation",
    });
  }
}

/**
 * End a chat conversation
 * POST /api/v1/conversations/:id/end
 */
async function endConversation(req, res) {
  const client = await pool.connect();

  try {
    const { id } = req.params;
    const userId = req.user.id;

    await client.query("BEGIN");

    const convResult = await client.query(
      "SELECT * FROM conversations WHERE id = $1 FOR UPDATE",
      [id],
    );

    if (convResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Conversation not found",
        message: "Conversation not found",
      });
    }

    const conversation = convResult.rows[0];

    // Verify participant
    if (
      conversation.venter_id !== userId &&
      conversation.listener_id !== userId
    ) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not a participant in this conversation",
      });
    }

    if (conversation.status !== "active") {
      // Idempotent end: if already finished, still ensure listener is not stuck busy.
      if (["ended", "cancelled", "declined"].includes(conversation.status)) {
        await client.query("ROLLBACK");
        await presence.clearListenerBusy(conversation.listener_id);

        return res.json({
          success: true,
          conversation: {
            id,
            status: conversation.status,
            endedAt: conversation.ended_at,
          },
          message: "Conversation already ended",
        });
      }

      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid status",
        message: `Conversation is ${conversation.status}, cannot end`,
      });
    }

    // Calculate duration and cost
    const endTime = new Date();
    const startTime = new Date(conversation.started_at);
    const durationMs = endTime - startTime;
    const durationMinutes = Math.ceil(durationMs / 1000 / 60); // Round up

    const totalCost =
      durationMinutes * parseFloat(conversation.rate_per_minute);

    // Update conversation
    await client.query(
      `UPDATE conversations 
       SET status = 'ended', ended_at = NOW(), duration_minutes = $1, total_cost = $2
       WHERE id = $3`,
      [durationMinutes, totalCost, id],
    );

    // PAYG branch: charge saved card off-session, skip subscription/wallet

    // Check if venter has an active referral discount (first session only)
    const referralDiscountRow = await client.query(
      `SELECT referee_discount_pct FROM referrals
        WHERE referred_id = $1 AND status = 'pending' AND reward_granted = false
        LIMIT 1`,
      [conversation.venter_id]
    );
    const referralDiscountPct = referralDiscountRow.rows[0]?.referee_discount_pct ?? 0;
    const discountMultiplier = referralDiscountPct > 0 ? (1 - referralDiscountPct / 100) : 1;
    if (conversation.payment_mode === "payg") {
      const { chargePaygSession, PaygError } = require("../services/paygService");
      try {
        const result = await chargePaygSession({
          userId: conversation.venter_id,
          sessionType: "chat",
          sessionId: id,
          billableMinutes: durationMinutes,
          discountPercent: referralDiscountPct,
          dbClient: client,
        });
        logger.info("PAYG chat charged", {
          conversationId: id,
          venterId: conversation.venter_id,
          amountCents: result.amountCents,
          paymentIntentId: result.paymentIntentId,
        });
      } catch (paygErr) {
        if (paygErr instanceof PaygError) {
          logger.warn("PAYG chat charge failure (chat ends regardless)", {
            conversationId: id,
            code: paygErr.code,
            message: paygErr.message,
          });
        } else {
          throw paygErr;
        }
      }
    } else try {
      const subResult = await client.query(
        `SELECT id, included_minutes, used_minutes, overage_rate
         FROM user_subscriptions
         WHERE user_id = $1 AND status IN ('active', 'trialing')
         ORDER BY created_at DESC
         LIMIT 1`,
        [conversation.venter_id],
      );

      let paymentSource = "prepaid";

      if (subResult.rows.length > 0) {
        const subscription = subResult.rows[0];
        const remainingMinutes =
          subscription.included_minutes - parseFloat(subscription.used_minutes);

        if (remainingMinutes >= durationMinutes) {
          await client.query(
            `UPDATE user_subscriptions
             SET used_minutes = used_minutes + $1,
                 updated_at = NOW()
             WHERE id = $2`,
            [durationMinutes, subscription.id],
          );
          paymentSource = "subscription";
        } else {
          if (remainingMinutes > 0) {
            await client.query(
              `UPDATE user_subscriptions
               SET used_minutes = used_minutes + $1,
                   updated_at = NOW()
               WHERE id = $2`,
              [remainingMinutes, subscription.id],
            );
          }

          const overageMinutes =
            durationMinutes - Math.max(remainingMinutes, 0);
          const walletOverageResult = await client.query(
            `UPDATE user_wallets
             SET balance_minutes = balance_minutes - $1
             WHERE user_id = $2`,
            [overageMinutes, conversation.venter_id],
          );

          if (walletOverageResult.rowCount === 0) {
            throw new Error(
              `Wallet not found for venter ${conversation.venter_id} during chat overage deduction`,
            );
          }

          paymentSource = "overage";
        }
      } else {
        const prepaidResult = await client.query(
          `UPDATE user_wallets
           SET balance_minutes = balance_minutes - $1
           WHERE user_id = $2`,
          [durationMinutes, conversation.venter_id],
        );

        if (prepaidResult.rowCount === 0) {
          throw new Error(
            `Wallet not found for venter ${conversation.venter_id} during chat prepaid deduction`,
          );
        }
      }

      // Record transaction
      await client.query(
        `INSERT INTO wallet_transactions 
          (user_id, transaction_type, amount_minutes, amount_currency, description)
         VALUES ($1, 'chat_deduction', $2, $3, $4)`,
        [
          conversation.venter_id,
          -durationMinutes,
          -totalCost,
          `Chat session ${id.substring(0, 8)} (${paymentSource})`,
        ],
      );
    } catch (walletError) {
      logger.error(`Wallet deduction failed: ${walletError.message}`);
      // Continue anyway - we'll handle this manually if needed
    }

    // Calculate listener earnings
    const platformFeePercentage = await getSetting(
      "platform_fee_percentage",
      0.2,
    );
    const platformFee = totalCost * platformFeePercentage;
    const listenerEarnings = totalCost - platformFee;

    // Record earnings
    await client.query(
      `INSERT INTO listener_earnings 
        (listener_id, session_type, session_id, gross_amount, platform_fee, net_amount, platform_fee_percentage, status)
       VALUES ($1, 'chat', $2, $3, $4, $5, $6, 'pending')`,
      [
        conversation.listener_id,
        id,
        totalCost,
        platformFee,
        listenerEarnings,
        platformFeePercentage,
      ],
    );

    // Clear listener busy status
    await presence.clearListenerBusy(conversation.listener_id);

    await client.query("COMMIT");

    logger.info(
      `Chat ${id} ended: ${durationMinutes}min, $${totalCost.toFixed(2)}`,
    );

    pool
      .query("SELECT email FROM users WHERE id = $1", [conversation.venter_id])
      .then((r) => r.rows[0] && klaviyo.trackSessionCompleted({
        email: r.rows[0].email,
        sessionType: "chat",
        durationSeconds: durationMinutes * 60,
        totalCost,
      }))
      .catch((err) => logger.error(`Klaviyo session lookup: ${err.message}`));

    // Notify both participants
    const io = req.app.get("io");
    const venterSocketId = await redisClient.get(
      `socket:${conversation.venter_id}`,
    );
    const listenerSocketId = await redisClient.get(
      `socket:${conversation.listener_id}`,
    );

    const endData = {
      conversationId: id,
      durationMinutes: durationMinutes,
      totalCost: totalCost,
      endedAt: endTime.toISOString(),
    };

    if (venterSocketId) {
      io.to(venterSocketId).emit("chat:ended", endData);
    }

    if (listenerSocketId) {
      io.to(listenerSocketId).emit("chat:ended", {
        ...endData,
        earnings: listenerEarnings,
      });
    }

    res.json({
      success: true,
      conversation: {
        id: id,
        status: "ended",
        durationMinutes: durationMinutes,
        totalCost: totalCost,
        earnings:
          userId === conversation.listener_id ? listenerEarnings : undefined,
        endedAt: endTime.toISOString(),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error ending conversation: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to end conversation",
    });
  } finally {
    client.release();
  }
}

/**
 * Get user's conversations
 * GET /api/v1/conversations
 */
async function getConversations(req, res) {
  try {
    const userId = req.user.id;
    const { status, limit = 20, offset = 0 } = req.query;

    let query = `
      SELECT
        c.*, si1.anonymous_name as other_name, si1.avatar_seed as other_avatar,
        lm.id as last_message_id,
        lm.content as last_message_content,
        lm.sender_id as last_message_sender_id,
        lm.delivered_at as last_message_delivered_at,
        lm.read_at as last_message_read_at,
        lm.created_at as last_message_at,
        si_sender.anonymous_name as last_message_sender_name,
        si_sender.avatar_seed as last_message_sender_avatar,
        COALESCE(lm.created_at, c.ended_at, c.started_at, c.created_at) as last_activity_at
      FROM conversations c
      LEFT JOIN session_identities si1 ON si1.session_id = c.id AND si1.session_type = 'chat'
        AND si1.user_id != $1
      LEFT JOIN LATERAL (
        SELECT m.id, m.content, m.sender_id, m.delivered_at, m.read_at, m.created_at
        FROM messages m
        WHERE m.conversation_id = c.id
        ORDER BY m.created_at DESC
        LIMIT 1
      ) lm ON true
      LEFT JOIN session_identities si_sender ON si_sender.session_id = c.id
        AND si_sender.session_type = 'chat'
        AND si_sender.user_id = lm.sender_id
      INNER JOIN users other_user ON other_user.id = CASE
        WHEN c.venter_id = $1 THEN c.listener_id
        ELSE c.venter_id
      END
      WHERE (c.venter_id = $1 OR c.listener_id = $1)
        AND other_user.is_active = true
    `;

    const params = [userId];

    if (status) {
      query += ` AND c.status = $${params.length + 1}`;
      params.push(status);
    }

    query += ` ORDER BY
      CASE WHEN lm.created_at IS NULL THEN 1 ELSE 0 END,
      lm.created_at DESC,
      COALESCE(c.started_at, c.created_at) DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    const conversations = result.rows.map((row) => ({
      id: row.id,
      status: row.status,
      otherParticipant: {
        anonymousName: row.other_name,
        avatarSeed: row.other_avatar,
      },
      ratePerMinute: parseFloat(row.rate_per_minute),
      durationMinutes: row.duration_minutes,
      totalCost: row.total_cost ? parseFloat(row.total_cost) : null,
      createdAt: row.created_at,
      startedAt: row.started_at,
      endedAt: row.ended_at,
      latestMessage: row.last_message_id
        ? {
            id: row.last_message_id,
            content: row.last_message_content,
            sender: {
              anonymousName: row.last_message_sender_name,
              avatarSeed: row.last_message_sender_avatar,
              isMe: row.last_message_sender_id === userId,
            },
            deliveredAt: row.last_message_delivered_at,
            readAt: row.last_message_read_at,
            createdAt: row.last_message_at,
          }
        : null,
      lastMessageAt: row.last_message_at,
      lastActivityAt: row.last_activity_at,
    }));

    res.json({
      success: true,
      count: conversations.length,
      conversations: conversations,
    });
  } catch (error) {
    logger.error(`Error getting conversations: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch conversations",
    });
  }
}

/**
 * Get conversation messages
 * GET /api/v1/conversations/:id/messages
 */
async function getMessages(req, res) {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const { limit = 50, before } = req.query;

    // Verify user is participant
    const conversation = await getConversationParticipants(id);

    if (!conversation) {
      return res.status(404).json({
        error: "Conversation not found",
        message: "Conversation not found",
      });
    }

    if (!isConversationParticipant(conversation, userId)) {
      return res.status(403).json({
        error: "Permission denied",
        message: "You are not a participant in this conversation",
      });
    }

    const history = await getConversationMessages({
      conversationId: id,
      userId,
      limit,
      before,
    });

    res.json({
      success: true,
      count: history.count,
      hasMore: history.hasMore,
      before: history.before,
      messages: history.messages,
    });
  } catch (error) {
    logger.error(`Error getting messages: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch messages",
    });
  }
}

/**
 * Get conversation details
 * GET /api/v1/conversations/:id
 */
async function getConversation(req, res) {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT c.*, si1.anonymous_name as other_name, si1.avatar_seed as other_avatar
       FROM conversations c
       LEFT JOIN session_identities si1 ON si1.session_id = c.id AND si1.session_type = 'chat'
         AND si1.user_id != $2
       WHERE c.id = $1 AND (c.venter_id = $2 OR c.listener_id = $2)`,
      [id, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Conversation not found",
        message: "Conversation not found or access denied",
      });
    }

    const conv = result.rows[0];

    res.json({
      success: true,
      conversation: {
        id: conv.id,
        status: conv.status,
        otherParticipant: {
          anonymousName: conv.other_name,
          avatarSeed: conv.other_avatar,
        },
        ratePerMinute: parseFloat(conv.rate_per_minute),
        durationMinutes: conv.duration_minutes,
        totalCost: conv.total_cost ? parseFloat(conv.total_cost) : null,
        createdAt: conv.created_at,
        startedAt: conv.started_at,
        endedAt: conv.ended_at,
      },
    });
  } catch (error) {
    logger.error(`Error getting conversation: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch conversation",
    });
  }
}

module.exports = {
  createConversation,
  createBroadcastConversation,
  acceptConversation,
  declineConversation,
  endConversation,
  getConversations,
  getMessages,
  getConversation,
};
