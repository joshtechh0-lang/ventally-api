const promoService = require("../services/promoService");
const logger = require("../utils/logger");

/**
 * Validate a promo code
 * POST /api/v1/promo/validate
 */
async function validatePromoCode(req, res) {
  try {
    const { code } = req.body;
    const userId = req.user ? req.user.id : null;

    if (!code) {
      return res.status(400).json({
        error: "Missing code",
        message: "Promo code is required",
      });
    }

    const result = await promoService.validatePromoCode(code, userId);

    if (!result.valid) {
      return res.status(400).json({
        valid: false,
        error: result.error,
      });
    }

    // Calculate example discount for display (using $10 as example)
    const examplePrice = 1000; // $10 in cents
    const discount = promoService.calculateDiscount(result.promo, examplePrice);

    res.json({
      valid: true,
      promo: {
        code: result.promo.code,
        discountType: result.promo.discountType,
        discountValue: result.promo.discountValue,
        freeMinutes: result.promo.freeMinutes,
        validUntil: result.promo.validUntil,
      },
      exampleDiscount: {
        originalPrice: discount.originalPrice / 100,
        discountAmount: discount.discountAmount / 100,
        finalPrice: discount.finalPrice / 100,
        freeMinutes: discount.freeMinutes,
      },
    });
  } catch (error) {
    logger.error("Error validating promo code:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to validate promo code",
    });
  }
}

/**
 * Apply a promo code (record usage)
 * POST /api/v1/promo/apply
 */
async function applyPromoCode(req, res) {
  try {
    const { code } = req.body;
    const userId = req.user.id;

    if (!code) {
      return res.status(400).json({
        error: "Missing code",
        message: "Promo code is required",
      });
    }

    // Validate promo code first
    const validation = await promoService.validatePromoCode(code, userId);

    if (!validation.valid) {
      return res.status(400).json({
        success: false,
        error: validation.error,
      });
    }

    // Apply the promo code
    const usage = await promoService.applyPromoCode(
      validation.promo.id,
      userId,
    );

    logger.info(`User ${userId} applied promo code: ${code}`);

    res.json({
      success: true,
      message: "Promo code applied successfully",
      usage: {
        id: usage.id,
        appliedAt: usage.applied_at,
      },
      promo: validation.promo,
    });
  } catch (error) {
    if (error.message === "Code already used by this user") {
      return res.status(409).json({
        success: false,
        error: "Code already used",
        message: "You have already used this promo code",
      });
    }

    logger.error("Error applying promo code:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to apply promo code",
    });
  }
}

/**
 * Get user's promo code history
 * GET /api/v1/promo/history
 */
async function getPromoHistory(req, res) {
  try {
    const userId = req.user.id;

    const history = await promoService.getUserPromoHistory(userId);

    res.json({
      success: true,
      promos: history.map((promo) => ({
        code: promo.code,
        discountType: promo.discount_type,
        discountValue: promo.discount_value
          ? parseFloat(promo.discount_value)
          : null,
        freeMinutes: promo.free_minutes,
        appliedAt: promo.applied_at,
      })),
    });
  } catch (error) {
    logger.error("Error fetching promo history:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch promo history",
    });
  }
}

module.exports = {
  validatePromoCode,
  applyPromoCode,
  getPromoHistory,
};
