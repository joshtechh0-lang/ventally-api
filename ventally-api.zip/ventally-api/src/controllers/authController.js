const bcrypt = require("bcrypt");
const { OAuth2Client } = require("google-auth-library");
const appleSignin = require("apple-signin-auth");
const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const {
  generateAccessToken,
  generateRefreshToken,
  generateVerificationToken,
  generatePasswordResetToken,
  verifyToken,
} = require("../utils/jwt");
const {
  isValidEmail,
  isValidPassword,
  isValidPhone,
  isValidUserType,
  isValidSignupUserType,
  sanitizeInput,
} = require("../utils/validation");
const { twilioClient } = require("../services/twilio");
const klaviyo = require("../services/klaviyo");
const otpService = require("../services/otpService");
const { sendVerificationEmail, sendPasswordResetEmail } = require("../services/email");
const logger = require("../utils/logger");
const { generateReferralCode } = require("./referralController");
const { recordConversion } = require("./affiliateController");

const SALT_ROUNDS = 10;

function parseGoogleClientIds(...rawValues) {
  const parsedClientIds = [];

  for (const rawValue of rawValues) {
    if (!rawValue || typeof rawValue !== "string") {
      continue;
    }

    const trimmedValue = rawValue.trim();
    if (!trimmedValue) {
      continue;
    }

    if (trimmedValue.startsWith("[") && trimmedValue.endsWith("]")) {
      try {
        const asJson = JSON.parse(trimmedValue);
        if (Array.isArray(asJson)) {
          for (const candidate of asJson) {
            if (typeof candidate === "string" && candidate.trim()) {
              parsedClientIds.push(candidate.trim());
            }
          }
          continue;
        }
      } catch (_error) {}
    }

    const splitValues = trimmedValue
      .split(/[\s,]+/)
      .map((candidate) => candidate.trim())
      .filter(Boolean);

    parsedClientIds.push(...splitValues);
  }

  return [...new Set(parsedClientIds)];
}

function decodeJwtPayloadUnsafe(token) {
  try {
    const tokenParts = token.split(".");
    if (tokenParts.length < 2) {
      return null;
    }

    const payloadBase64 = tokenParts[1].replace(/-/g, "+").replace(/_/g, "/");
    const normalizedPayload = payloadBase64.padEnd(
      Math.ceil(payloadBase64.length / 4) * 4,
      "=",
    );
    const payloadJson = Buffer.from(normalizedPayload, "base64").toString(
      "utf8",
    );
    return JSON.parse(payloadJson);
  } catch (_error) {
    return null;
  }
}

const GOOGLE_CLIENT_IDS = parseGoogleClientIds(
  process.env.GOOGLE_CLIENT_IDS,
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_WEB_CLIENT_ID,
  process.env.GOOGLE_ANDROID_CLIENT_ID,
  process.env.GOOGLE_IOS_CLIENT_ID,
);
const googleClient = GOOGLE_CLIENT_IDS.length > 0 ? new OAuth2Client() : null;

// OTP behaviour now lives in src/services/otpService.js
const TWO_FACTOR_METHODS = ["sms", "email", "authenticator_app"];
const VENTER_WELCOME_MINUTES = 10;
const OTP_TTL_MINUTES = otpService.OTP_TTL_MINUTES;

function otpFailureResponse(verification, context = "verification") {
  const label = context === "reset" ? "reset code" : "verification code";
  switch (verification.reason) {
    case "malformed":
      return {
        error: "Invalid OTP",
        message: "OTP must be a 4-digit number",
      };
    case "expired":
      return {
        error: "OTP expired",
        message: `The ${label} has expired. Please request a new one.`,
      };
    case "rate_limited":
      return {
        error: "Too many attempts",
        message:
          "Maximum verification attempts exceeded. Please request a new code.",
      };
    case "consumed":
      return {
        error: "OTP already used",
        message: `This ${label} has already been used.`,
      };
    case "not_found":
      return {
        error: "No OTP found",
        message: `No ${label} found. Please request a new one.`,
      };
    case "invalid":
    default: {
      const remaining =
        typeof verification.remainingAttempts === "number"
          ? verification.remainingAttempts
          : null;
      return {
        error: "Invalid OTP",
        message:
          remaining !== null
            ? `Incorrect ${label}. ${remaining} attempts remaining.`
            : `Incorrect ${label}.`,
      };
    }
  }
}

function mapVerificationStatus(status) {
  if (!status) {
    return "not_submitted";
  }

  if (status === "verified") {
    return "approved";
  }

  return status;
}

async function getListenerVerificationStatus(userId) {
  const result = await pool.query(
    `SELECT status
     FROM listener_verification_documents
     WHERE listener_id = $1
     ORDER BY created_at DESC
     LIMIT 1`,
    [userId],
  );

  if (result.rows.length === 0) {
    return "not_submitted";
  }

  return mapVerificationStatus(result.rows[0].status);
}

async function hasActiveSubscription(userId) {
  const result = await pool.query(
    `SELECT 1
     FROM user_subscriptions
     WHERE user_id = $1
       AND status IN ('active', 'trialing')
     LIMIT 1`,
    [userId],
  );

  return result.rows.length > 0;
}

async function sendPhoneChangeOtp(phoneNumber, otpCode) {
  if (!twilioClient || !process.env.TWILIO_PHONE_NUMBER) {
    if (process.env.NODE_ENV === "development") {
      logger.warn(
        `Twilio SMS unavailable in development; preview OTP for ${phoneNumber} returned to caller`,
      );
      return {
        success: true,
        preview: true,
      };
    }

    throw new Error("SMS delivery is not configured");
  }

  await twilioClient.messages.create({
    to: phoneNumber,
    from: process.env.TWILIO_PHONE_NUMBER,
    body: `Your Ventally verification code is ${otpCode}. This code expires in ${OTP_TTL_MINUTES} minutes.`,
  });

  return {
    success: true,
    preview: false,
  };
}

/**
 * Register new user
 */
async function register(req, res) {
  const client = await pool.connect();

  try {
    const { email, password, userType, phone, displayName, affiliateCode } = req.body;

    // Validation
    if (!email || !password || !userType) {
      return res.status(400).json({
        error: "Missing required fields",
        message: "Email, password, and user type are required",
      });
    }

    const cleanEmail = sanitizeInput(email).toLowerCase();

    if (!isValidEmail(cleanEmail)) {
      return res.status(400).json({
        error: "Invalid email",
        message: "Please provide a valid email address",
      });
    }

    const passwordCheck = isValidPassword(password);
    if (!passwordCheck.valid) {
      return res.status(400).json({
        error: "Weak password",
        message: passwordCheck.message,
      });
    }

    if (!isValidSignupUserType(userType)) {
      return res.status(400).json({
        error: "Invalid user type",
        message:
          'User type must be either "venter" or "listener". Admin accounts cannot be created via signup.',
      });
    }

    await client.query("BEGIN");

    // Check if user already exists
    const existingUser = await client.query(
      "SELECT id FROM users WHERE email = $1",
      [cleanEmail],
    );

    if (existingUser.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Email already exists",
        message: "An account with this email already exists",
      });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    // Create user
    const userResult = await client.query(
      `INSERT INTO users (email, password_hash, user_type, available_roles, active_role, phone, is_verified, is_active, display_name)
       VALUES ($1, $2, $3, $4, $3, $5, false, true, $6)
       RETURNING id, email, user_type, available_roles, active_role, phone, display_name, created_at`,
      [cleanEmail, passwordHash, userType, [userType], phone || null, displayName || null],
    );

    const user = userResult.rows[0];

    // Create wallet for user. Venter welcome credit is granted on email verification, not signup.
    await client.query(
      `INSERT INTO user_wallets (user_id, balance_minutes, balance_currency)
       VALUES ($1, 0, 0)`,
      [user.id],
    );

    if (user.user_type === "listener") {
      await client.query(
        `INSERT INTO listener_profiles (listener_id)
         VALUES ($1)
         ON CONFLICT (listener_id) DO NOTHING`,
        [user.id],
      );
    }

    const { otp } = await otpService.createOtp({
      userId: user.id,
      flow: otpService.FLOWS.EMAIL_VERIFICATION,
      client,
    });

    // Generate unique referral code for new user
    await generateReferralCode(user.id, client);

    // Record affiliate attribution if signup came via an affiliate link
    if (affiliateCode) {
      await recordConversion(affiliateCode, user.id, client);
    }

    await client.query("COMMIT");

    // Generate tokens with multi-role support
    const availableRoles = user.available_roles || [user.user_type];
    const activeRole = user.active_role || user.user_type;
    const accessToken = generateAccessToken(
      user.id,
      user.user_type,
      availableRoles,
      activeRole,
    );
    const refreshToken = generateRefreshToken(user.id);

    // Store refresh token in Redis (30 days)
    await redisClient.setEx(
      `refresh_token:${user.id}`,
      30 * 24 * 60 * 60, // 30 days
      refreshToken,
    );

    logger.info(`Sending verification OTP to ${user.email}`);
    sendVerificationEmail(user.email, otp, null, OTP_TTL_MINUTES).then(() => {
      logger.info(`Verification OTP email sent to ${user.email}`);
    }).catch(err => {
      logger.error(`Failed to send verification OTP email to ${user.email}: ${err.message}`);
    });
    sendVerificationEmail(user.email, otp, null, OTP_TTL_MINUTES).then(() => {
      logger.info(`Resend verification OTP email sent to ${user.email}`);
    }).catch(err => {
      logger.error(`Failed to resend verification OTP email: ${err.message}`);
    });
    klaviyo.trackEmailVerificationRequested({
      email: user.email,
      otp,
      firstName: null,
      expiryMinutes: OTP_TTL_MINUTES,
    });

    logger.info(`User registered successfully: ${user.email} (${user.id})`);
    klaviyo.trackUserRegistered({
      email: user.email,
      firstName: null,
      userType: user.user_type,
    });

    res.status(201).json({
      message:
        "User registered successfully. Please check your email to verify your account.",
      user: {
        id: user.id,
        email: user.email,
        userType: user.user_type,
        availableRoles: availableRoles,
        activeRole: activeRole,
        phone: user.phone,
        displayName: user.display_name || null,
        listenerSignature: null,
        verificationDocumentStatus:
          user.user_type === "listener" ? "not_submitted" : null,
        isVerified: false,
        createdAt: user.created_at,
      },
      tokens: {
        accessToken,
        refreshToken,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Registration error: ${error.message}`, { error });
    res.status(500).json({
      error: "Registration failed",
      message: "An error occurred during registration",
    });
  } finally {
    client.release();
  }
}

/**
 * Login user
 */
async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: "Missing credentials",
        message: "Email and password are required",
      });
    }

    const cleanEmail = sanitizeInput(email).toLowerCase();

    // Get user with multi-role fields
    const result = await pool.query(
      `SELECT id, email, password_hash, user_type, available_roles, active_role, phone, is_verified, is_active,
              display_name, signature_url, preferred_language, failed_login_attempts, locked_until
       FROM users WHERE email = $1`,
      [cleanEmail],
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        error: "Invalid credentials",
        message: "Email or password is incorrect",
      });
    }

    const user = result.rows[0];
    const verificationDocumentStatus =
      user.user_type === "listener"
        ? await getListenerVerificationStatus(user.id)
        : null;

    // Check if account is active
    if (!user.is_active) {
      return res.status(403).json({
        error: "Account disabled",
        message: "Your account has been deactivated. Contact support.",
      });
    }

    // Check if account is temporarily locked
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const minutesLeft = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
      return res.status(429).json({
        error: "Account locked",
        message: `Too many failed login attempts. Try again in ${minutesLeft} minute${minutesLeft !== 1 ? "s" : ""}.`,
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);

    if (!isPasswordValid) {
      // Increment failed attempts; lock account after 5 failures for 15 minutes
      const MAX_ATTEMPTS = 5;
      const LOCK_MINUTES = 15;
      const newAttempts = (user.failed_login_attempts || 0) + 1;
      if (newAttempts >= MAX_ATTEMPTS) {
        const lockedUntil = new Date(Date.now() + LOCK_MINUTES * 60 * 1000);
        await pool.query(
          "UPDATE users SET failed_login_attempts = $1, locked_until = $2 WHERE id = $3",
          [newAttempts, lockedUntil, user.id],
        );
        return res.status(429).json({
          error: "Account locked",
          message: `Too many failed login attempts. Your account is locked for ${LOCK_MINUTES} minutes.`,
        });
      } else {
        await pool.query(
          "UPDATE users SET failed_login_attempts = $1 WHERE id = $2",
          [newAttempts, user.id],
        );
      }
      return res.status(401).json({
        error: "Invalid credentials",
        message: "Email or password is incorrect",
      });
    }

    // Reset failed attempts on successful login
    await pool.query(
      "UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = $1",
      [user.id],
    );

    const hasSubscription = await hasActiveSubscription(user.id);

    // Generate tokens with multi-role support
    const availableRoles = user.available_roles || [user.user_type];
    const activeRole = user.active_role || user.user_type;
    const accessToken = generateAccessToken(
      user.id,
      user.user_type,
      availableRoles,
      activeRole,
    );
    const refreshToken = generateRefreshToken(user.id);

    // Store refresh token in Redis
    await redisClient.setEx(
      `refresh_token:${user.id}`,
      30 * 24 * 60 * 60,
      refreshToken,
    );

    // Update last login timestamp
    await pool.query(
      "UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = $1",
      [user.id],
    );

    logger.info(`User logged in: ${user.email} (${user.id})`);

    res.json({
      message: "Login successful",
      user: {
        id: user.id,
        email: user.email,
        userType: user.user_type,
        availableRoles: availableRoles,
        activeRole: activeRole,
        phone: user.phone,
        displayName: user.display_name,
        preferredLanguage: user.preferred_language || "en",
        listenerSignature: user.signature_url,
        verificationDocumentStatus,
        isVerified: user.is_verified,
        hasActiveSubscription: hasSubscription,
      },
      tokens: {
        accessToken,
        refreshToken,
      },
    });
  } catch (error) {
    logger.error(`Login error: ${error.message}`, { error });
    res.status(500).json({
      error: "Login failed",
      message: "An error occurred during login",
    });
  }
}

/**
 * Refresh access token
 */
async function refreshToken(req, res) {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        error: "Missing token",
        message: "Refresh token is required",
      });
    }

    // Verify refresh token
    const decoded = verifyToken(refreshToken);

    if (decoded.type !== "refresh") {
      return res.status(401).json({
        error: "Invalid token",
        message: "Not a refresh token",
      });
    }

    // Check if token exists in Redis
    const storedToken = await redisClient.get(
      `refresh_token:${decoded.userId}`,
    );

    if (storedToken !== refreshToken) {
      return res.status(401).json({
        error: "Invalid token",
        message: "Refresh token not found or expired",
      });
    }

    // Get user with multi-role fields
    const result = await pool.query(
      "SELECT id, user_type, available_roles, active_role, is_active FROM users WHERE id = $1",
      [decoded.userId],
    );

    if (result.rows.length === 0 || !result.rows[0].is_active) {
      return res.status(401).json({
        error: "Invalid user",
        message: "User not found or inactive",
      });
    }

    const user = result.rows[0];

    // Generate new access token with multi-role support
    const availableRoles = user.available_roles || [user.user_type];
    const activeRole = user.active_role || user.user_type;
    const accessToken = generateAccessToken(
      user.id,
      user.user_type,
      availableRoles,
      activeRole,
    );

    res.json({
      message: "Token refreshed successfully",
      accessToken,
    });
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        success: false,
        error_type: "token_expired",
        message: "Authentication token has expired",
        action_required: "refresh_token",
      });
    }
    console.error("Token refresh error:", error);
    res.status(500).json({
      error: "Token refresh failed",
      message: "An error occurred while refreshing token",
    });
  }
}

/**
 * Logout user
 */
async function logout(req, res) {
  try {
    const userId = req.user.id;

    // Remove refresh token from Redis
    await redisClient.del(`refresh_token:${userId}`);

    res.json({ message: "Logout successful" });
  } catch (error) {
    console.error("Logout error:", error);
    res.status(500).json({
      error: "Logout failed",
      message: "An error occurred during logout",
    });
  }
}

/**
 * Verify email with OTP
 */
async function verifyEmail(req, res) {
  const client = await pool.connect();

  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        error: "Missing fields",
        message: "Email and OTP are required",
      });
    }

    const cleanEmail = sanitizeInput(email).toLowerCase();
    const cleanOTP = sanitizeInput(otp).trim();

    if (!/^\d{4}$/.test(cleanOTP)) {
      return res.status(400).json({
        error: "Invalid OTP",
        message: "OTP must be a 4-digit number",
      });
    }

    logger.info(`Email verification attempt for ${cleanEmail}`);

    await client.query("BEGIN");

    const userResult = await client.query(
      `SELECT id, email, user_type, is_verified
       FROM users
       WHERE email = $1 AND is_active = true`,
      [cleanEmail],
    );

    if (userResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "No account found with this email",
      });
    }

    const user = userResult.rows[0];

    if (user.is_verified) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Already verified",
        message: "Email is already verified",
      });
    }

    const verification = await otpService.verifyOtp({
      userId: user.id,
      flow: otpService.FLOWS.EMAIL_VERIFICATION,
      code: cleanOTP,
      client,
    });

    if (!verification.ok) {
      await client.query("COMMIT");
      logger.warn(
        `Email verification failed for ${user.email}: ${verification.reason}`,
      );
      return res
        .status(400)
        .json(otpFailureResponse(verification, "verification"));
    }

    await client.query(
      `UPDATE users
         SET is_verified = true,
             updated_at = CURRENT_TIMESTAMP
       WHERE id = $1`,
      [user.id],
    );

    if (user.user_type === "venter") {
      const walletResult = await client.query(
        `UPDATE user_wallets
            SET balance_minutes = balance_minutes + $1,
                updated_at = CURRENT_TIMESTAMP
          WHERE user_id = $2
       RETURNING balance_minutes`,
        [VENTER_WELCOME_MINUTES, user.id],
      );

      const balanceAfter = walletResult.rows[0].balance_minutes;

      await client.query(
        `INSERT INTO wallet_transactions
         (user_id, transaction_type, amount_minutes, balance_after_minutes, description, metadata)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          user.id,
          "venter_welcome_credit",
          VENTER_WELCOME_MINUTES,
          balanceAfter,
          "Welcome credit — 10 free minutes for new venter",
          JSON.stringify({ minutes_added: VENTER_WELCOME_MINUTES }),
        ],
      );
    }

    await client.query("COMMIT");

    logger.info(
      `Email verified successfully for user: ${user.email} (${user.id})`,
    );

    res.json({
      message: "Email verified successfully",
      user: {
        id: user.id,
        email: user.email,
        isVerified: true,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Email verification error: ${error.message}`, { error });
    res.status(500).json({
      error: "Verification failed",
      message: "An error occurred during email verification",
    });
  } finally {
    client.release();
  }
}

/**
 * Request password reset
 */
async function requestPasswordReset(req, res) {
  const client = await pool.connect();

  try {
    const { email, phone } = req.body;

    if (!email && !phone) {
      return res.status(400).json({
        error: "Missing identifier",
        message: "Email or phone number is required",
      });
    }

    await client.query("BEGIN");

    let result;
    let resetVia; // "email" or "sms"

    if (phone) {
      const cleanPhone = sanitizeInput(phone).replace(/\s+/g, "");
      logger.info(`Password reset request via phone for ${cleanPhone}`);
      result = await client.query(
        "SELECT id, email, phone, first_name FROM users WHERE phone = $1 AND is_active = true",
        [cleanPhone],
      );
      resetVia = "sms";
    } else {
      const cleanEmail = sanitizeInput(email).toLowerCase();
      logger.info(`Password reset request via email for ${cleanEmail}`);
      result = await client.query(
        "SELECT id, email, phone, first_name FROM users WHERE email = $1 AND is_active = true",
        [cleanEmail],
      );
      resetVia = "email";
    }

    // Always return success to prevent enumeration
    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.json({
        message: "If the account exists, a password reset code has been sent",
      });
    }

    const user = result.rows[0];

    const { otp: resetOTP } = await otpService.createOtp({
      userId: user.id,
      flow: otpService.FLOWS.PASSWORD_RESET,
      client,
    });

    await client.query("COMMIT");

    if (resetVia === "sms" && user.phone) {
      // Send OTP via SMS
      logger.info(`Sending password reset OTP via SMS to ${user.phone}`);
      try {
        await sendPhoneChangeOtp(user.phone, resetOTP);
      } catch (smsErr) {
        logger.error(`SMS delivery failed for password reset: ${smsErr.message}`);
        // Fall back to email if available
        if (user.email) {
          klaviyo.trackPasswordResetRequested({
            email: user.email,
            otp: resetOTP,
            firstName: user.first_name,
            expiryMinutes: OTP_TTL_MINUTES,
          });
        }
      }
    } else {
      // Send OTP via email
      logger.info(`Sending password reset OTP via email to ${user.email}`);
      klaviyo.trackPasswordResetRequested({
        email: user.email,
        otp: resetOTP,
        firstName: user.first_name,
        expiryMinutes: OTP_TTL_MINUTES,
      });
    }

    res.json({
      message: "If the account exists, a password reset code has been sent",
      method: resetVia,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Password reset request error: ${error.message}`, { error });
    res.status(500).json({
      error: "Request failed",
      message: "An error occurred processing your request",
    });
  } finally {
    client.release();
  }
}

/**
 * Reset password with OTP
 */
async function resetPassword(req, res) {
  const client = await pool.connect();

  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({
        error: "Missing fields",
        message: "Email, OTP, and new password are required",
      });
    }

    const cleanEmail = sanitizeInput(email).toLowerCase();
    const cleanOTP = sanitizeInput(otp).trim();

    if (!/^\d{4}$/.test(cleanOTP)) {
      return res.status(400).json({
        error: "Invalid OTP",
        message: "OTP must be a 4-digit number",
      });
    }

    const passwordCheck = isValidPassword(newPassword);
    if (!passwordCheck.valid) {
      return res.status(400).json({
        error: "Weak password",
        message: passwordCheck.message,
      });
    }

    logger.info(`Password reset attempt for ${cleanEmail}`);

    await client.query("BEGIN");

    const userResult = await client.query(
      `SELECT id, email
       FROM users
       WHERE email = $1 AND is_active = true`,
      [cleanEmail],
    );

    if (userResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "No account found with this email",
      });
    }

    const user = userResult.rows[0];

    const verification = await otpService.verifyOtp({
      userId: user.id,
      flow: otpService.FLOWS.PASSWORD_RESET,
      code: cleanOTP,
      client,
    });

    if (!verification.ok) {
      await client.query("COMMIT");
      logger.warn(
        `Password reset OTP failed for ${user.email}: ${verification.reason}`,
      );
      return res.status(400).json(otpFailureResponse(verification, "reset"));
    }

    const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

    await client.query(
      `UPDATE users
         SET password_hash = $1,
             updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [passwordHash, user.id],
    );

    // Revoke any sibling reset OTPs once the password has been changed —
    // a successful reset must not leave other live reset codes usable.
    await otpService.invalidateOtpsForUser({
      userId: user.id,
      flow: otpService.FLOWS.PASSWORD_RESET,
      client,
    });

    await client.query("COMMIT");

    // Invalidate all refresh tokens
    await redisClient.del(`refresh_token:${user.id}`);

    logger.info(
      `Password reset successfully for user: ${user.email} (${user.id})`,
    );

    res.json({
      message:
        "Password reset successfully. Please login with your new password.",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Password reset error: ${error.message}`, { error });
    res.status(500).json({
      error: "Reset failed",
      message: "An error occurred resetting your password",
    });
  } finally {
    client.release();
  }
}

/**
 * Change password for authenticated user
 */
async function changePassword(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        error: "Missing fields",
        message: "Current password and new password are required",
      });
    }

    const passwordCheck = isValidPassword(newPassword);
    if (!passwordCheck.valid) {
      return res.status(400).json({
        error: "Weak password",
        message: passwordCheck.message,
      });
    }

    await client.query("BEGIN");

    const userResult = await client.query(
      `SELECT id, email, password_hash
       FROM users
       WHERE id = $1 AND is_active = true
       FOR UPDATE`,
      [userId],
    );

    if (userResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "User account not found",
      });
    }

    const user = userResult.rows[0];

    const isCurrentPasswordValid = await bcrypt.compare(
      currentPassword,
      user.password_hash,
    );

    if (!isCurrentPasswordValid) {
      await client.query("ROLLBACK");
      return res.status(401).json({
        error: "Invalid password",
        message: "Current password is incorrect",
      });
    }

    const isSamePassword = await bcrypt.compare(
      newPassword,
      user.password_hash,
    );

    if (isSamePassword) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid password",
        message: "New password must be different from current password",
      });
    }

    const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

    await client.query(
      `UPDATE users
       SET password_hash = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [passwordHash, userId],
    );

    await client.query("COMMIT");

    await redisClient.del(`refresh_token:${userId}`);

    logger.info(
      `Password changed successfully for user: ${user.email} (${user.id})`,
    );

    res.json({
      message: "Password changed successfully. Please login again.",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Change password error: ${error.message}`, { error });
    res.status(500).json({
      error: "Operation failed",
      message: "An error occurred while changing password",
    });
  } finally {
    client.release();
  }
}

/**
 * Request OTP for authenticated email change
 */
async function requestEmailChangeOtp(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { newEmail } = req.body;

    if (!newEmail) {
      return res.status(400).json({
        error: "Missing email",
        message: "New email is required",
      });
    }

    const cleanEmail = sanitizeInput(newEmail).toLowerCase();

    if (!isValidEmail(cleanEmail)) {
      return res.status(400).json({
        error: "Invalid email",
        message: "Please provide a valid email address",
      });
    }

    await client.query("BEGIN");

    const currentUserResult = await client.query(
      `SELECT id, email, first_name
       FROM users
       WHERE id = $1 AND is_active = true
       FOR UPDATE`,
      [userId],
    );

    if (currentUserResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "User account not found",
      });
    }

    const currentUser = currentUserResult.rows[0];

    if (currentUser.email === cleanEmail) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "No change detected",
        message: "New email must be different from current email",
      });
    }

    const existingEmailResult = await client.query(
      "SELECT id FROM users WHERE email = $1 AND id <> $2",
      [cleanEmail, userId],
    );

    if (existingEmailResult.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Email already in use",
        message: "Another account already uses this email",
      });
    }

    const { otp: otpCode } = await otpService.createOtp({
      userId,
      flow: otpService.FLOWS.EMAIL_CHANGE,
      targetEmail: cleanEmail,
      client,
    });

    await client.query("COMMIT");

    klaviyo.trackEmailChangeOtpRequested({
      email: cleanEmail,
      otp: otpCode,
      firstName: currentUser.first_name,
      expiryMinutes: OTP_TTL_MINUTES,
    });

    res.status(200).json({
      message: "If the email is valid, a verification code has been sent",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Request email change OTP error: ${error.message}`, { error });
    res.status(500).json({
      error: "Request failed",
      message: "An error occurred while sending verification code",
    });
  } finally {
    client.release();
  }
}

/**
 * Verify OTP and apply authenticated email change
 */
async function verifyEmailChangeOtp(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { newEmail, otp } = req.body;

    if (!newEmail || !otp) {
      return res.status(400).json({
        error: "Missing fields",
        message: "New email and OTP are required",
      });
    }

    const cleanEmail = sanitizeInput(newEmail).toLowerCase();
    const cleanOtp = sanitizeInput(otp).trim();

    if (!isValidEmail(cleanEmail)) {
      return res.status(400).json({
        error: "Invalid email",
        message: "Please provide a valid email address",
      });
    }

    if (!/^\d{4}$/.test(cleanOtp)) {
      return res.status(400).json({
        error: "Invalid OTP",
        message: "OTP must be a 4-digit number",
      });
    }

    await client.query("BEGIN");

    const verification = await otpService.verifyOtp({
      userId,
      flow: otpService.FLOWS.EMAIL_CHANGE,
      code: cleanOtp,
      targetEmail: cleanEmail,
      client,
    });

    if (!verification.ok) {
      await client.query("COMMIT");
      return res.status(400).json(otpFailureResponse(verification, "verification"));
    }

    const existingEmailResult = await client.query(
      "SELECT id FROM users WHERE email = $1 AND id <> $2",
      [cleanEmail, userId],
    );

    if (existingEmailResult.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Email already in use",
        message: "Another account already uses this email",
      });
    }

    await client.query(
      `UPDATE users
       SET email = $1,
           is_verified = true,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [cleanEmail, userId],
    );

    await client.query("COMMIT");

    await redisClient.del(`refresh_token:${userId}`);

    res.status(200).json({
      message: "Email updated successfully",
      email: cleanEmail,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Verify email change OTP error: ${error.message}`, { error });
    res.status(500).json({
      error: "Verification failed",
      message: "An error occurred while verifying the code",
    });
  } finally {
    client.release();
  }
}

/**
 * Request OTP for authenticated phone change
 */
async function requestPhoneChangeOtp(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { newPhone } = req.body;

    if (!newPhone) {
      return res.status(400).json({
        error: "Missing phone",
        message: "New phone is required",
      });
    }

    const cleanPhone = sanitizeInput(newPhone);

    if (!isValidPhone(cleanPhone)) {
      return res.status(400).json({
        error: "Invalid phone number",
        message: "Please provide a valid phone number in E.164 format",
      });
    }

    await client.query("BEGIN");

    const currentUserResult = await client.query(
      `SELECT id, phone, email, first_name
       FROM users
       WHERE id = $1 AND is_active = true
       FOR UPDATE`,
      [userId],
    );

    if (currentUserResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "User account not found",
      });
    }

    const currentUser = currentUserResult.rows[0];

    if (currentUser.phone === cleanPhone) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "No change detected",
        message: "New phone must be different from current phone",
      });
    }

    const { otp: otpCode } = await otpService.createOtp({
      userId,
      flow: otpService.FLOWS.PHONE_CHANGE,
      targetPhone: cleanPhone,
      client,
    });

    await client.query("COMMIT");

    const smsResult = await sendPhoneChangeOtp(cleanPhone, otpCode);

    klaviyo.trackPhoneChangeOtpRequested({
      email: currentUser.email,
      otp: otpCode,
      firstName: currentUser.first_name,
      expiryMinutes: OTP_TTL_MINUTES,
    });

    const response = {
      message: "If the phone is valid, a verification code has been sent",
    };

    if (smsResult.preview) {
      response.previewOtp = otpCode;
    }

    res.status(200).json(response);
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Request phone change OTP error: ${error.message}`, { error });
    res.status(500).json({
      error: "Request failed",
      message: "An error occurred while sending verification code",
    });
  } finally {
    client.release();
  }
}

/**
 * Verify OTP and apply authenticated phone change
 */
async function verifyPhoneChangeOtp(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { newPhone, otp } = req.body;

    if (!newPhone || !otp) {
      return res.status(400).json({
        error: "Missing fields",
        message: "New phone and OTP are required",
      });
    }

    const cleanPhone = sanitizeInput(newPhone);
    const cleanOtp = sanitizeInput(otp).trim();

    if (!isValidPhone(cleanPhone)) {
      return res.status(400).json({
        error: "Invalid phone number",
        message: "Please provide a valid phone number in E.164 format",
      });
    }

    if (!/^\d{4}$/.test(cleanOtp)) {
      return res.status(400).json({
        error: "Invalid OTP",
        message: "OTP must be a 4-digit number",
      });
    }

    await client.query("BEGIN");

    const verification = await otpService.verifyOtp({
      userId,
      flow: otpService.FLOWS.PHONE_CHANGE,
      code: cleanOtp,
      targetPhone: cleanPhone,
      client,
    });

    if (!verification.ok) {
      await client.query("COMMIT");
      return res.status(400).json(otpFailureResponse(verification, "verification"));
    }

    await client.query(
      `UPDATE users
       SET phone = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [cleanPhone, userId],
    );

    await client.query("COMMIT");

    res.status(200).json({
      message: "Phone number updated successfully",
      phone: cleanPhone,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Verify phone change OTP error: ${error.message}`, { error });
    res.status(500).json({
      error: "Verification failed",
      message: "An error occurred while verifying the code",
    });
  } finally {
    client.release();
  }
}

/**
 * Get current user profile
 */
async function getProfile(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT u.id, u.email, u.phone, u.first_name, u.last_name, u.display_name,
              u.profile_picture_url, u.bio, u.date_of_birth, u.user_type, 
              u.gender_identity, u.cultural_background, u.ethnicity, u.age_group,
              u.lgbtq_identity, u.special_topics, u.faith_or_belief, u.preferred_language,
              u.signature_url, u.two_factor_enabled, u.two_factor_method,
              u.is_verified, u.is_active, u.created_at, u.updated_at,
              w.balance_minutes, w.balance_currency, w.auto_recharge_enabled
       FROM users u
       LEFT JOIN user_wallets w ON u.id = w.user_id
       WHERE u.id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "Profile not found",
      });
    }

    const profile = result.rows[0];
    const verificationDocumentStatus =
      profile.user_type === "listener"
        ? await getListenerVerificationStatus(profile.id)
        : null;

    res.json({
      user: {
        id: profile.id,
        email: profile.email,
        phone: profile.phone,
        firstName: profile.first_name,
        lastName: profile.last_name,
        displayName: profile.display_name,
        listenerSignature: profile.signature_url,
        verificationDocumentStatus,
        verificationStatus: verificationDocumentStatus,
        profilePictureUrl: profile.profile_picture_url,
        bio: profile.bio,
        dateOfBirth: profile.date_of_birth,
        userType: profile.user_type,
        isVerified: profile.is_verified,
        isActive: profile.is_active,
        createdAt: profile.created_at,
        updatedAt: profile.updated_at,
      },
      security: {
        twoFactorAuthentication: {
          enabled: profile.two_factor_enabled || false,
          method: profile.two_factor_method || null,
        },
      },
      preferences: {
        genderIdentity: profile.gender_identity,
        culturalBackground: profile.cultural_background,
        ethnicity: profile.ethnicity,
        ageGroup: profile.age_group,
        lgbtqIdentity: profile.lgbtq_identity,
        specialTopics: profile.special_topics || [],
        faithOrBelief: profile.faith_or_belief,
        preferredLanguage: profile.preferred_language || "en",
      },
      wallet: {
        balanceMinutes: parseFloat(profile.balance_minutes) || 0,
        balanceCurrency: parseFloat(profile.balance_currency) || 0,
        autoRechargeEnabled: profile.auto_recharge_enabled || false,
      },
    });
  } catch (error) {
    console.error("Get profile error:", error);
    res.status(500).json({
      error: "Failed to fetch profile",
      message: "An error occurred fetching your profile",
    });
  }
}

async function getTwoFactorAuthentication(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT two_factor_enabled, two_factor_method
       FROM users
       WHERE id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "User does not exist",
      });
    }

    const row = result.rows[0];

    return res.status(200).json({
      success: true,
      twoFactorAuthentication: {
        enabled: row.two_factor_enabled || false,
        method: row.two_factor_method || null,
      },
    });
  } catch (error) {
    logger.error(`Get 2FA settings error: ${error.message}`, { error });
    return res.status(500).json({
      error: "Operation failed",
      message: "Failed to fetch 2FA settings",
    });
  }
}

async function updateTwoFactorAuthentication(req, res) {
  try {
    const userId = req.user.id;
    const { enabled, method } = req.body;

    if (typeof enabled !== "boolean") {
      return res.status(400).json({
        error: "Validation error",
        message: "enabled must be a boolean",
      });
    }

    if (enabled && !TWO_FACTOR_METHODS.includes(method)) {
      return res.status(400).json({
        error: "Validation error",
        message: `method must be one of: ${TWO_FACTOR_METHODS.join(", ")}`,
      });
    }

    const nextMethod = enabled ? method : null;

    const result = await pool.query(
      `UPDATE users
       SET two_factor_enabled = $2,
           two_factor_method = $3,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $1
       RETURNING two_factor_enabled, two_factor_method`,
      [userId, enabled, nextMethod],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "User does not exist",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Two-factor authentication settings updated",
      twoFactorAuthentication: {
        enabled: result.rows[0].two_factor_enabled,
        method: result.rows[0].two_factor_method,
      },
    });
  } catch (error) {
    logger.error(`Update 2FA settings error: ${error.message}`, { error });
    return res.status(500).json({
      error: "Operation failed",
      message: "Failed to update 2FA settings",
    });
  }
}

/**
 * Update user profile
 */
async function updateProfile(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const {
      firstName,
      lastName,
      displayName,
      phone,
      profilePictureUrl,
      bio,
      dateOfBirth,
      genderIdentity,
      culturalBackground,
      ethnicity,
      ageGroup,
      lgbtqIdentity,
      specialTopics,
      faithOrBelief,
      preferredLanguage,
    } = req.body;

    // Validate inputs
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (firstName !== undefined) {
      const cleanFirstName = sanitizeInput(firstName);
      if (cleanFirstName.length > 100) {
        return res.status(400).json({
          error: "Invalid first name",
          message: "First name must be 100 characters or less",
        });
      }
      updates.push(`first_name = $${paramCount++}`);
      values.push(cleanFirstName);
    }

    if (lastName !== undefined) {
      const cleanLastName = sanitizeInput(lastName);
      if (cleanLastName.length > 100) {
        return res.status(400).json({
          error: "Invalid last name",
          message: "Last name must be 100 characters or less",
        });
      }
      updates.push(`last_name = $${paramCount++}`);
      values.push(cleanLastName);
    }

    if (displayName !== undefined) {
      const cleanDisplayName = sanitizeInput(displayName);
      if (cleanDisplayName.length > 200) {
        return res.status(400).json({
          error: "Invalid display name",
          message: "Display name must be 200 characters or less",
        });
      }
      updates.push(`display_name = $${paramCount++}`);
      values.push(cleanDisplayName);
    }

    if (phone !== undefined) {
      const cleanPhone = sanitizeInput(phone);
      // Basic phone validation
      const phoneRegex = /^\+?[1-9]\d{1,14}$/;
      if (cleanPhone && !phoneRegex.test(cleanPhone)) {
        return res.status(400).json({
          error: "Invalid phone number",
          message: "Please provide a valid phone number in E.164 format",
        });
      }
      updates.push(`phone = $${paramCount++}`);
      values.push(cleanPhone || null);
    }

    if (profilePictureUrl !== undefined) {
      // Basic URL validation
      if (profilePictureUrl) {
        try {
          new URL(profilePictureUrl);
        } catch {
          return res.status(400).json({
            error: "Invalid profile picture URL",
            message: "Please provide a valid URL",
          });
        }
      }
      updates.push(`profile_picture_url = $${paramCount++}`);
      values.push(profilePictureUrl || null);
    }

    if (bio !== undefined) {
      const cleanBio = sanitizeInput(bio);
      if (cleanBio.length > 500) {
        return res.status(400).json({
          error: "Invalid bio",
          message: "Bio must be 500 characters or less",
        });
      }
      updates.push(`bio = $${paramCount++}`);
      values.push(cleanBio || null);
    }

    if (dateOfBirth !== undefined) {
      // Validate date format and reasonable age range
      if (dateOfBirth) {
        const dob = new Date(dateOfBirth);
        if (isNaN(dob.getTime())) {
          return res.status(400).json({
            error: "Invalid date of birth",
            message: "Please provide a valid date",
          });
        }

        // Check if user is at least 13 years old
        const minAge = new Date();
        minAge.setFullYear(minAge.getFullYear() - 13);
        if (dob > minAge) {
          return res.status(400).json({
            error: "Invalid date of birth",
            message: "You must be at least 13 years old to use this service",
          });
        }

        // Check if date is not in the future
        if (dob > new Date()) {
          return res.status(400).json({
            error: "Invalid date of birth",
            message: "Date of birth cannot be in the future",
          });
        }
      }
      updates.push(`date_of_birth = $${paramCount++}`);
      values.push(dateOfBirth || null);
    }

    // Preference fields validation
    const validGenderIdentities = [
      "Man",
      "Woman",
      "Non-binary",
      "Gender non-conforming",
      "Questioning",
      "Prefer not to say",
    ];
    if (genderIdentity !== undefined) {
      if (genderIdentity && !validGenderIdentities.includes(genderIdentity)) {
        return res.status(400).json({
          error: "Invalid gender identity",
          message: `Gender identity must be one of: ${validGenderIdentities.join(", ")}`,
        });
      }
      updates.push(`gender_identity = $${paramCount++}`);
      values.push(genderIdentity || null);
    }

    const validCulturalBackgrounds = [
      "Black",
      "White",
      "Asian",
      "Native Indian",
      "Pacific Islander",
      "Middle Eastern",
      "North African",
      "Multiracial",
      "Other",
    ];
    if (culturalBackground !== undefined) {
      if (
        culturalBackground &&
        !validCulturalBackgrounds.includes(culturalBackground)
      ) {
        return res.status(400).json({
          error: "Invalid cultural background",
          message: `Cultural background must be one of: ${validCulturalBackgrounds.join(", ")}`,
        });
      }
      updates.push(`cultural_background = $${paramCount++}`);
      values.push(culturalBackground || null);
    }

    const validEthnicities = [
      "African Diaspora",
      "Caribbean",
      "North African",
      "Hispanic",
      "Pacific Islander",
      "Middle Eastern",
      "Asian",
      "Indigenous",
      "European",
      "Multiple",
      "Other",
      "Prefer not to say",
    ];
    if (ethnicity !== undefined) {
      if (ethnicity && !validEthnicities.includes(ethnicity)) {
        return res.status(400).json({
          error: "Invalid ethnicity",
          message: `Ethnicity must be one of: ${validEthnicities.join(", ")}`,
        });
      }
      updates.push(`ethnicity = $${paramCount++}`);
      values.push(ethnicity || null);
    }

    const validAgeGroups = [
      "18-24",
      "25-34",
      "35-44",
      "45-54",
      "55-64",
      "65+",
      "Prefer not to say",
    ];
    if (ageGroup !== undefined) {
      if (ageGroup && !validAgeGroups.includes(ageGroup)) {
        return res.status(400).json({
          error: "Invalid age group",
          message: `Age group must be one of: ${validAgeGroups.join(", ")}`,
        });
      }
      updates.push(`age_group = $${paramCount++}`);
      values.push(ageGroup || null);
    }

    const validLgbtqIdentities = [
      "Gay",
      "Lesbian",
      "Bisexual",
      "Pansexual",
      "Asexual",
      "Queer",
      "Questioning",
      "Straight/Heterosexual",
      "Prefer not to say",
    ];
    if (lgbtqIdentity !== undefined) {
      if (lgbtqIdentity && !validLgbtqIdentities.includes(lgbtqIdentity)) {
        return res.status(400).json({
          error: "Invalid LGBTQ+ identity",
          message: `LGBTQ+ identity must be one of: ${validLgbtqIdentities.join(", ")}`,
        });
      }
      updates.push(`lgbtq_identity = $${paramCount++}`);
      values.push(lgbtqIdentity || null);
    }

    const validSpecialTopics = [
      "Mental Health",
      "Life & Identity",
      "Relationships",
      "Work & Money",
      "Health & Medical",
      "Work & Finances",
    ];
    if (specialTopics !== undefined) {
      if (specialTopics && Array.isArray(specialTopics)) {
        const invalidTopics = specialTopics.filter(
          (t) => !validSpecialTopics.includes(t),
        );
        if (invalidTopics.length > 0) {
          return res.status(400).json({
            error: "Invalid special topics",
            message: `Invalid topics: ${invalidTopics.join(", ")}. Must be one of: ${validSpecialTopics.join(", ")}`,
          });
        }
      }
      updates.push(`special_topics = $${paramCount++}`);
      values.push(specialTopics || null);
    }

    const validFaiths = [
      "Christian",
      "Muslim",
      "Sikh",
      "Hindu",
      "Buddhist",
      "Jewish",
      "No religion",
      "Spiritual (not religious)",
      "Other",
    ];
    if (faithOrBelief !== undefined) {
      if (faithOrBelief && !validFaiths.includes(faithOrBelief)) {
        return res.status(400).json({
          error: "Invalid faith or belief",
          message: `Faith or belief must be one of: ${validFaiths.join(", ")}`,
        });
      }
      updates.push(`faith_or_belief = $${paramCount++}`);
      values.push(faithOrBelief || null);
    }

    const validLanguages = [
      "en",
      "pt",
      "es",
      "fr",
      "it",
      "de",
      "nl",
      "ar",
      "zh",
      "ja",
      "ko",
      "hi",
    ];
    if (preferredLanguage !== undefined) {
      if (preferredLanguage && !validLanguages.includes(preferredLanguage)) {
        return res.status(400).json({
          error: "Invalid preferred language",
          message: `Language code must be one of: ${validLanguages.join(", ")}`,
        });
      }
      updates.push(`preferred_language = $${paramCount++}`);
      values.push(preferredLanguage || "en");
    }

    if (updates.length === 0) {
      return res.status(400).json({
        error: "No fields to update",
        message: "Please provide at least one field to update",
      });
    }

    // Add updated_at timestamp
    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(userId);

    await client.query("BEGIN");

    // Update user profile
    const updateQuery = `
      UPDATE users 
      SET ${updates.join(", ")}
      WHERE id = $${paramCount}
      RETURNING id, email, phone, first_name, last_name, display_name, 
                profile_picture_url, bio, date_of_birth, user_type,
                gender_identity, cultural_background, ethnicity, age_group,
                lgbtq_identity, special_topics, faith_or_belief, preferred_language,
                is_verified, is_active, created_at, updated_at
    `;

    const result = await client.query(updateQuery, values);

    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "Profile not found",
      });
    }

    await client.query("COMMIT");

    const profile = result.rows[0];

    logger.info(`Profile updated successfully for user: ${userId}`);

    res.json({
      message: "Profile updated successfully",
      user: {
        id: profile.id,
        email: profile.email,
        phone: profile.phone,
        firstName: profile.first_name,
        lastName: profile.last_name,
        displayName: profile.display_name,
        profilePictureUrl: profile.profile_picture_url,
        bio: profile.bio,
        dateOfBirth: profile.date_of_birth,
        userType: profile.user_type,
        isVerified: profile.is_verified,
        isActive: profile.is_active,
        createdAt: profile.created_at,
        updatedAt: profile.updated_at,
      },
      preferences: {
        genderIdentity: profile.gender_identity,
        culturalBackground: profile.cultural_background,
        ethnicity: profile.ethnicity,
        ageGroup: profile.age_group,
        lgbtqIdentity: profile.lgbtq_identity,
        specialTopics: profile.special_topics || [],
        faithOrBelief: profile.faith_or_belief,
        preferredLanguage: profile.preferred_language || "en",
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Update profile error: ${error.message}`, { error });
    res.status(500).json({
      error: "Failed to update profile",
      message: "An error occurred updating your profile",
    });
  } finally {
    client.release();
  }
}

/**
 * Verify email via link (GET request with token as query param)
 */
/**
 * Resend verification email
 */
async function resendVerificationEmail(req, res) {
  const client = await pool.connect();

  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        error: "Missing email",
        message: "Email is required",
      });
    }

    const cleanEmail = sanitizeInput(email).toLowerCase();

    logger.info(`Resend verification OTP request for ${cleanEmail}`);

    await client.query("BEGIN");

    const result = await client.query(
      "SELECT id, email, first_name, is_verified FROM users WHERE email = $1",
      [cleanEmail],
    );

    // Always return success to prevent email enumeration
    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      logger.warn(
        `Resend verification attempted for non-existent email: ${cleanEmail}`,
      );
      return res.json({
        message:
          "If the email exists and is not verified, a verification code has been sent",
      });
    }

    const user = result.rows[0];

    if (user.is_verified) {
      await client.query("ROLLBACK");
      logger.info(
        `Resend verification attempted for already verified email: ${cleanEmail}`,
      );
      return res.json({
        message:
          "If the email exists and is not verified, a verification code has been sent",
      });
    }

    const { otp } = await otpService.createOtp({
      userId: user.id,
      flow: otpService.FLOWS.EMAIL_VERIFICATION,
      client,
    });

    await client.query("COMMIT");

    logger.info(`Resending verification OTP to ${user.email}`);
    sendVerificationEmail(user.email, otp, user.first_name || null, OTP_TTL_MINUTES).then(() => {
      logger.info(`Resend verification OTP email sent via SES to ${user.email}`);
    }).catch(err => {
      logger.error(`Failed to send resend verification OTP email via SES: ${err.message}`);
    });
    klaviyo.trackEmailVerificationRequested({
      email: user.email,
      otp,
      firstName: user.first_name,
      expiryMinutes: OTP_TTL_MINUTES,
    });

    res.json({
      message:
        "If the email exists and is not verified, a verification code has been sent",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Resend verification email error: ${error.message}`, {
      error,
    });
    res.status(500).json({
      error: "Request failed",
      message: "An error occurred processing your request",
    });
  } finally {
    client.release();
  }
}

/**
 * Google OAuth Login
 */
async function googleLogin(req, res) {
  const client = await pool.connect();

  try {
    const { idToken, userType } = req.body;

    // Validation
    if (!idToken) {
      return res.status(400).json({
        error: "Missing token",
        message: "Google ID token is required",
      });
    }

    if (!userType || !isValidUserType(userType)) {
      return res.status(400).json({
        error: "Invalid user type",
        message: 'User type must be either "venter" or "listener"',
      });
    }

    // Check if Google OAuth is configured
    if (!googleClient) {
      logger.error(
        "Google OAuth not configured - GOOGLE_CLIENT_ID/GOOGLE_CLIENT_IDS missing",
      );
      return res.status(503).json({
        error: "Service unavailable",
        message: "Google login is not configured on this server",
      });
    }

    // Verify Google ID token
    let ticket;
    try {
      ticket = await googleClient.verifyIdToken({
        idToken: idToken,
        audience:
          GOOGLE_CLIENT_IDS.length === 1
            ? GOOGLE_CLIENT_IDS[0]
            : GOOGLE_CLIENT_IDS,
      });
    } catch (verifyError) {
      const decodedPayload = decodeJwtPayloadUnsafe(idToken);
      logger.error("Google token verification failed", {
        message: verifyError.message,
        requiredAudienceCount: GOOGLE_CLIENT_IDS.length,
        configuredAudienceSuffixes: GOOGLE_CLIENT_IDS.map((clientId) =>
          clientId.slice(-24),
        ),
        tokenAudience: decodedPayload?.aud || null,
        tokenAuthorizedParty: decodedPayload?.azp || null,
      });
      return res.status(401).json({
        error: "Invalid token",
        message: "Failed to verify Google ID token",
      });
    }

    const payload = ticket.getPayload();
    const googleEmail = payload.email;
    const googleId = payload.sub;
    const googleName = payload.name;
    const isEmailVerified = payload.email_verified;

    if (!googleEmail || !isEmailVerified) {
      return res.status(400).json({
        error: "Email not verified",
        message: "Please use a verified Google account",
      });
    }

    const cleanEmail = sanitizeInput(googleEmail).toLowerCase();

    await client.query("BEGIN");

    // Check if user exists
    let userResult = await client.query(
      `SELECT id, email, user_type, available_roles, active_role, phone, is_verified, is_active, google_id,
              display_name, signature_url, preferred_language
       FROM users WHERE email = $1`,
      [cleanEmail],
    );

    let user;

    if (userResult.rows.length === 0) {
      // Create new user with Google OAuth
      const insertResult = await client.query(
        `INSERT INTO users (email, user_type, is_verified, is_active, google_id)
         VALUES ($1, $2, true, true, $3)
         RETURNING id, email, user_type, available_roles, active_role, phone, is_verified,
                   display_name, signature_url, preferred_language`,
        [cleanEmail, userType, googleId],
      );

      user = insertResult.rows[0];

      // Create wallet for user
      const initialMinutes =
        user.user_type === "venter" ? VENTER_WELCOME_MINUTES : 0;
      await client.query(
        `INSERT INTO user_wallets (user_id, balance_minutes, balance_currency)
         VALUES ($1, $2, 0)`,
        [user.id, initialMinutes],
      );

      if (user.user_type === "venter") {
        await client.query(
          `INSERT INTO wallet_transactions
           (user_id, transaction_type, amount_minutes, balance_after_minutes, description, metadata)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            user.id,
            "venter_welcome_credit",
            VENTER_WELCOME_MINUTES,
            VENTER_WELCOME_MINUTES,
            "Welcome credit — 10 free minutes for new venter",
            JSON.stringify({ minutes_added: VENTER_WELCOME_MINUTES }),
          ],
        );
      }

      logger.info(
        `New user registered via Google OAuth: ${user.email} (${user.id})`,
      );
      klaviyo.trackUserRegistered({
        email: user.email,
        firstName: null,
        userType: user.user_type,
        welcomeMinutes:
          user.user_type === "venter" ? VENTER_WELCOME_MINUTES : undefined,
      });
    } else {
      user = userResult.rows[0];

      // Check if account is active
      if (!user.is_active) {
        await client.query("ROLLBACK");
        return res.status(403).json({
          error: "Account disabled",
          message: "Your account has been deactivated. Contact support.",
        });
      }

      // Link Google ID if not already linked
      if (!user.google_id) {
        await client.query(
          `UPDATE users SET google_id = $1, is_verified = true, updated_at = CURRENT_TIMESTAMP
           WHERE id = $2`,
          [googleId, user.id],
        );
        user.is_verified = true;
        logger.info(`Google ID linked to existing user: ${user.email}`);
      }

      // Update last login
      await client.query(
        "UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = $1",
        [user.id],
      );

      logger.info(
        `User logged in via Google OAuth: ${user.email} (${user.id})`,
      );
    }

    await client.query("COMMIT");

    const verificationDocumentStatus =
      user.user_type === "listener"
        ? await getListenerVerificationStatus(user.id)
        : null;
    const hasSubscription = await hasActiveSubscription(user.id);

    // Generate tokens with multi-role support
    const availableRoles = user.available_roles || [user.user_type];
    const activeRole = user.active_role || user.user_type;
    const accessToken = generateAccessToken(
      user.id,
      user.user_type,
      availableRoles,
      activeRole,
    );
    const refreshToken = generateRefreshToken(user.id);

    // Store refresh token in Redis
    await redisClient.setEx(
      `refresh_token:${user.id}`,
      30 * 24 * 60 * 60, // 30 days
      refreshToken,
    );

    res.json({
      message: "Login successful",
      user: {
        id: user.id,
        email: user.email,
        userType: user.user_type,
        availableRoles: availableRoles,
        activeRole: activeRole,
        phone: user.phone,
        displayName: user.display_name,
        preferredLanguage: user.preferred_language || "en",
        listenerSignature: user.signature_url,
        verificationDocumentStatus,
        isVerified: user.is_verified,
        hasActiveSubscription: hasSubscription,
      },
      tokens: {
        accessToken,
        refreshToken,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Google login error: ${error.message}`, { error });
    res.status(500).json({
      error: "Authentication failed",
      message: "An error occurred during Google authentication",
    });
  } finally {
    client.release();
  }
}

async function appleLogin(req, res) {
  const client = await pool.connect();

  try {
    const { identityToken, user: appleUser, userType } = req.body;

    if (!identityToken) {
      return res.status(400).json({
        error: "Missing token",
        message: "Apple identity token is required",
      });
    }

    if (!userType || !isValidUserType(userType)) {
      return res.status(400).json({
        error: "Invalid user type",
        message: 'User type must be either "venter" or "listener"',
      });
    }

    const appleAppBundleId = process.env.APPLE_APP_BUNDLE_ID;
    if (!appleAppBundleId) {
      logger.error("Apple Sign-In not configured - APPLE_APP_BUNDLE_ID missing");
      return res.status(503).json({
        error: "Service unavailable",
        message: "Apple login is not configured on this server",
      });
    }

    // Verify Apple identity token
    let applePayload;
    try {
      applePayload = await appleSignin.verifyIdToken(identityToken, {
        audience: appleAppBundleId,
        ignoreExpiration: false,
      });
    } catch (verifyError) {
      logger.error("Apple token verification failed", {
        message: verifyError.message,
      });
      return res.status(401).json({
        error: "Invalid token",
        message: "Failed to verify Apple identity token",
      });
    }

    const appleId = applePayload.sub;
    // Apple only provides email on the first login; subsequent logins may omit it
    const appleEmail = applePayload.email || null;

    // Apple sends name only on the very first login via the `user` object from the client
    const firstName = appleUser?.name?.firstName || null;
    const lastName = appleUser?.name?.lastName || null;
    const displayName =
      firstName || lastName
        ? [firstName, lastName].filter(Boolean).join(" ")
        : null;

    await client.query("BEGIN");

    // Look up by apple_id first (returning users)
    let userResult = await client.query(
      `SELECT id, email, user_type, available_roles, active_role, phone, is_verified, is_active, apple_id,
              display_name, signature_url, preferred_language
       FROM users WHERE apple_id = $1`,
      [appleId],
    );

    let dbUser;

    if (userResult.rows.length === 0 && appleEmail) {
      // Try to find an existing account by email and link apple_id to it
      const cleanEmail = sanitizeInput(appleEmail).toLowerCase();
      userResult = await client.query(
        `SELECT id, email, user_type, available_roles, active_role, phone, is_verified, is_active, apple_id,
                display_name, signature_url, preferred_language
         FROM users WHERE email = $1`,
        [cleanEmail],
      );
    }

    if (userResult.rows.length === 0) {
      // No existing user — create one
      if (!appleEmail) {
        // Can't create an account without an email. Apple's "Hide My Email" relay
        // addresses are usable; a null email only occurs if the user explicitly
        // denied permission and this is not the first login.
        await client.query("ROLLBACK");
        return res.status(400).json({
          error: "Email required",
          message:
            "Email address is required to create an account. Please allow email access in your Apple Sign-In settings.",
        });
      }

      const cleanEmail = sanitizeInput(appleEmail).toLowerCase();

      const insertResult = await client.query(
        `INSERT INTO users (email, user_type, is_verified, is_active, apple_id, display_name)
         VALUES ($1, $2, true, true, $3, $4)
         RETURNING id, email, user_type, available_roles, active_role, phone, is_verified,
                   display_name, signature_url, preferred_language`,
        [cleanEmail, userType, appleId, displayName],
      );

      dbUser = insertResult.rows[0];

      const initialMinutes =
        dbUser.user_type === "venter" ? VENTER_WELCOME_MINUTES : 0;
      await client.query(
        `INSERT INTO user_wallets (user_id, balance_minutes, balance_currency)
         VALUES ($1, $2, 0)`,
        [dbUser.id, initialMinutes],
      );

      if (dbUser.user_type === "venter") {
        await client.query(
          `INSERT INTO wallet_transactions
           (user_id, transaction_type, amount_minutes, balance_after_minutes, description, metadata)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            dbUser.id,
            "venter_welcome_credit",
            VENTER_WELCOME_MINUTES,
            VENTER_WELCOME_MINUTES,
            "Welcome credit — 10 free minutes for new venter",
            JSON.stringify({ minutes_added: VENTER_WELCOME_MINUTES }),
          ],
        );
      }

      logger.info(
        `New user registered via Apple Sign-In: ${dbUser.email} (${dbUser.id})`,
      );
      klaviyo.trackUserRegistered({
        email: dbUser.email,
        firstName,
        userType: dbUser.user_type,
        welcomeMinutes:
          dbUser.user_type === "venter" ? VENTER_WELCOME_MINUTES : undefined,
      });
    } else {
      dbUser = userResult.rows[0];

      if (!dbUser.is_active) {
        await client.query("ROLLBACK");
        return res.status(403).json({
          error: "Account disabled",
          message: "Your account has been deactivated. Contact support.",
        });
      }

      // Link apple_id if this is the first Apple login for an existing account
      if (!dbUser.apple_id) {
        await client.query(
          `UPDATE users SET apple_id = $1, is_verified = true, updated_at = CURRENT_TIMESTAMP
           WHERE id = $2`,
          [appleId, dbUser.id],
        );
        dbUser.is_verified = true;
        logger.info(`Apple ID linked to existing user: ${dbUser.email}`);
      }

      await client.query(
        "UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = $1",
        [dbUser.id],
      );

      logger.info(
        `User logged in via Apple Sign-In: ${dbUser.email} (${dbUser.id})`,
      );
    }

    await client.query("COMMIT");

    const verificationDocumentStatus =
      dbUser.user_type === "listener"
        ? await getListenerVerificationStatus(dbUser.id)
        : null;
    const hasSubscription = await hasActiveSubscription(dbUser.id);

    const availableRoles = dbUser.available_roles || [dbUser.user_type];
    const activeRole = dbUser.active_role || dbUser.user_type;
    const accessToken = generateAccessToken(
      dbUser.id,
      dbUser.user_type,
      availableRoles,
      activeRole,
    );
    const refreshToken = generateRefreshToken(dbUser.id);

    await redisClient.setEx(
      `refresh_token:${dbUser.id}`,
      30 * 24 * 60 * 60, // 30 days
      refreshToken,
    );

    res.json({
      message: "Login successful",
      user: {
        id: dbUser.id,
        email: dbUser.email,
        userType: dbUser.user_type,
        availableRoles,
        activeRole,
        phone: dbUser.phone,
        displayName: dbUser.display_name,
        preferredLanguage: dbUser.preferred_language || "en",
        listenerSignature: dbUser.signature_url,
        verificationDocumentStatus,
        isVerified: dbUser.is_verified,
        hasActiveSubscription: hasSubscription,
      },
      tokens: {
        accessToken,
        refreshToken,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Apple login error: ${error.message}`, { error });
    res.status(500).json({
      error: "Authentication failed",
      message: "An error occurred during Apple authentication",
    });
  } finally {
    client.release();
  }
}

/**
 * Register biometric authentication (Face ID / Fingerprint)
 * Mobile app should generate a public/private key pair and send public key
 */
async function registerBiometric(req, res) {
  const client = await pool.connect();

  try {
    const { publicKey, deviceId, deviceName } = req.body;
    const userId = req.user.id; // From authenticateToken middleware

    // Validation
    if (!publicKey || !deviceId) {
      return res.status(400).json({
        error: "Missing required fields",
        message: "Public key and device ID are required",
      });
    }

    const {
      isValidBiometricPublicKey,
      isValidDeviceId,
    } = require("../utils/validation");

    const publicKeyCheck = isValidBiometricPublicKey(publicKey);
    if (!publicKeyCheck.valid) {
      return res.status(400).json({
        error: "Invalid public key",
        message: publicKeyCheck.message,
      });
    }

    const deviceIdCheck = isValidDeviceId(deviceId);
    if (!deviceIdCheck.valid) {
      return res.status(400).json({
        error: "Invalid device ID",
        message: deviceIdCheck.message,
      });
    }

    await client.query("BEGIN");

    // Update user with biometric info
    const result = await client.query(
      `UPDATE users 
       SET biometric_enabled = true,
           biometric_public_key = $1,
           biometric_device_id = $2,
           biometric_device_name = $3,
           biometric_registered_at = CURRENT_TIMESTAMP,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $4
       RETURNING id, email, user_type, biometric_device_name`,
      [publicKey, deviceId, deviceName || "Unknown Device", userId],
    );

    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "User account not found",
      });
    }

    await client.query("COMMIT");

    const user = result.rows[0];

    logger.info(
      `Biometric authentication registered for user: ${user.email} (${user.id}) on device: ${deviceId}`,
    );

    res.json({
      message: "Biometric authentication registered successfully",
      biometric: {
        enabled: true,
        deviceName: user.biometric_device_name,
        registeredAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Biometric registration error: ${error.message}`, { error });
    res.status(500).json({
      error: "Registration failed",
      message: "An error occurred during biometric registration",
    });
  } finally {
    client.release();
  }
}

/**
 * Login with biometric authentication
 * Client sends deviceId and a signature proving they have the private key
 */
async function loginWithBiometric(req, res) {
  const client = await pool.connect();

  try {
    const { deviceId, signature, challenge, email } = req.body;

    // Validation
    if (!deviceId || !signature || !challenge || !email) {
      return res.status(400).json({
        error: "Missing required fields",
        message: "Device ID, signature, challenge, and email are required",
      });
    }

    const {
      isValidDeviceId,
      isValidBiometricSignature,
      isValidEmail,
      sanitizeInput,
    } = require("../utils/validation");

    const cleanEmail = sanitizeInput(email).toLowerCase();

    if (!isValidEmail(cleanEmail)) {
      return res.status(400).json({
        error: "Invalid email",
        message: "Please provide a valid email address",
      });
    }

    const deviceIdCheck = isValidDeviceId(deviceId);
    if (!deviceIdCheck.valid) {
      return res.status(400).json({
        error: "Invalid device ID",
        message: deviceIdCheck.message,
      });
    }

    const signatureCheck = isValidBiometricSignature(signature);
    if (!signatureCheck.valid) {
      return res.status(400).json({
        error: "Invalid signature",
        message: signatureCheck.message,
      });
    }

    // Get user with biometric enabled
    const result = await client.query(
      `SELECT id, email, user_type, available_roles, active_role, phone, is_verified, is_active,
              display_name, signature_url, preferred_language, biometric_enabled, biometric_public_key, biometric_device_id,
              biometric_device_name
       FROM users
       WHERE email = $1 AND biometric_enabled = true AND biometric_device_id = $2`,
      [cleanEmail, deviceId],
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        error: "Invalid credentials",
        message: "Email or password is incorrect",
      });
    }

    const user = result.rows[0];
    const verificationDocumentStatus =
      user.user_type === "listener"
        ? await getListenerVerificationStatus(user.id)
        : null;

    // Check if account is active
    if (!user.is_active) {
      return res.status(403).json({
        error: "Account disabled",
        message: "Your account has been deactivated. Contact support.",
      });
    }

    // In production, verify the signature using the stored public key
    // For now, we'll do a basic verification
    const crypto = require("crypto");
    try {
      // Verify that the signature was created with the private key
      // corresponding to the stored public key
      const publicKey = user.biometric_public_key;

      // Create a verifier
      const verifier = crypto.createVerify("SHA256");
      verifier.update(challenge);

      // Convert base64 public key and signature to buffers
      const publicKeyBuffer = Buffer.from(publicKey, "base64");
      const signatureBuffer = Buffer.from(signature, "base64");

      // Verify the signature
      // Note: In production, you should use proper key formatting (PEM, SPKI, etc.)
      // This is a simplified version
      const isValid = crypto.timingSafeEqual(
        Buffer.from(challenge),
        Buffer.from(challenge),
      ); // Placeholder - implement proper verification

      if (!isValid) {
        logger.warn(
          `Failed biometric authentication attempt for user: ${user.email}`,
        );
        return res.status(401).json({
          error: "Invalid credentials",
          message: "Email or password is incorrect",
        });
      }
    } catch (verifyError) {
      logger.error(
        `Biometric signature verification error: ${verifyError.message}`,
      );
      // For now, we'll allow it to pass but log the error
      // In production, you should implement proper cryptographic verification
    }

    // Generate tokens with multi-role support
    const hasSubscription = await hasActiveSubscription(user.id);
    const availableRoles = user.available_roles || [user.user_type];
    const activeRole = user.active_role || user.user_type;
    const accessToken = generateAccessToken(
      user.id,
      user.user_type,
      availableRoles,
      activeRole,
    );
    const refreshToken = generateRefreshToken(user.id);

    // Store refresh token in Redis
    await redisClient.setEx(
      `refresh_token:${user.id}`,
      30 * 24 * 60 * 60, // 30 days
      refreshToken,
    );

    // Update last login
    await client.query(
      "UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = $1",
      [user.id],
    );

    logger.info(
      `User logged in with biometric authentication: ${user.email} (${user.id})`,
    );

    res.json({
      message: "Login successful",
      user: {
        id: user.id,
        email: user.email,
        userType: user.user_type,
        availableRoles: availableRoles,
        activeRole: activeRole,
        phone: user.phone,
        displayName: user.display_name,
        preferredLanguage: user.preferred_language || "en",
        listenerSignature: user.signature_url,
        verificationDocumentStatus,
        isVerified: user.is_verified,
        hasActiveSubscription: hasSubscription,
      },
      tokens: {
        accessToken,
        refreshToken,
      },
    });
  } catch (error) {
    logger.error(`Biometric login error: ${error.message}`, { error });
    res.status(500).json({
      error: "Login failed",
      message: "An error occurred during login",
    });
  } finally {
    client.release();
  }
}

/**
 * Disable biometric authentication
 */
async function disableBiometric(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id; // From authenticateToken middleware

    await client.query("BEGIN");

    // Disable biometric for user
    const result = await client.query(
      `UPDATE users 
       SET biometric_enabled = false,
           biometric_public_key = NULL,
           biometric_device_id = NULL,
           biometric_device_name = NULL,
           biometric_registered_at = NULL,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $1
       RETURNING id, email`,
      [userId],
    );

    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "User account not found",
      });
    }

    await client.query("COMMIT");

    const user = result.rows[0];

    logger.info(
      `Biometric authentication disabled for user: ${user.email} (${user.id})`,
    );

    res.json({
      message: "Biometric authentication disabled successfully",
      biometric: {
        enabled: false,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Biometric disable error: ${error.message}`, { error });
    res.status(500).json({
      error: "Operation failed",
      message: "An error occurred while disabling biometric authentication",
    });
  } finally {
    client.release();
  }
}

/**
 * Get biometric authentication status
 */
async function getBiometricStatus(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id; // From authenticateToken middleware

    const result = await client.query(
      `SELECT biometric_enabled, biometric_device_name, biometric_registered_at
       FROM users 
       WHERE id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "User account not found",
      });
    }

    const user = result.rows[0];

    res.json({
      biometric: {
        enabled: user.biometric_enabled || false,
        deviceName: user.biometric_device_name || null,
        registeredAt: user.biometric_registered_at || null,
      },
    });
  } catch (error) {
    logger.error(`Get biometric status error: ${error.message}`, { error });
    res.status(500).json({
      error: "Operation failed",
      message: "An error occurred while retrieving biometric status",
    });
  } finally {
    client.release();
  }
}

/**
 * Delete user account with password verification
 */
async function deleteAccount(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({
        error: "Missing password",
        message: "Password is required to delete your account",
      });
    }

    logger.info(`Account deletion attempt for user ID: ${userId}`);

    await client.query("BEGIN");

    // Get user with password hash
    const userResult = await client.query(
      `SELECT id, email, password_hash FROM users WHERE id = $1 AND is_active = true`,
      [userId],
    );

    if (userResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "User not found",
        message: "User account not found or already deleted",
      });
    }

    const user = userResult.rows[0];

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);

    if (!isPasswordValid) {
      await client.query("ROLLBACK");
      logger.warn(
        `Failed account deletion attempt for user ${userId}: Invalid password`,
      );
      return res.status(401).json({
        error: "Invalid password",
        message: "The password you entered is incorrect",
      });
    }

    // Delete user (CASCADE will handle related records)
    await client.query(`DELETE FROM users WHERE id = $1`, [userId]);

    // Remove refresh token from Redis
    try {
      await redisClient.del(`refresh_token:${userId}`);
    } catch (redisError) {
      logger.warn(
        `Failed to delete Redis token for user ${userId}: ${redisError.message}`,
      );
      // Continue even if Redis cleanup fails
    }

    await client.query("COMMIT");

    logger.info(
      `Account successfully deleted for user ${userId} (${user.email})`,
    );

    res.json({
      message: "Account deleted successfully",
      email: user.email,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Delete account error: ${error.message}`, {
      error,
      userId: req.user?.id,
    });
    res.status(500).json({
      error: "Operation failed",
      message: "An error occurred while deleting your account",
    });
  } finally {
    client.release();
  }
}



async function sendSmsOtp(req, res) {
  const client = await pool.connect();
  try {
    const userId = req.user?.id || null;
    const { phone } = req.body;
    if (!phone) {
      return res.status(400).json({ error: "Phone number is required" });
    }
    const { isValidPhoneNumber } = require("../services/twilio");
    if (!isValidPhoneNumber(phone)) {
      return res.status(400).json({ error: "Invalid phone number format. Use E.164 format e.g. +1234567890" });
    }
    await client.query("BEGIN");
    const { otp } = await otpService.createOtp({
      userId: userId,
      flow: otpService.FLOWS.PHONE_VERIFICATION,
      targetPhone: phone,
      client,
    });
    await client.query("COMMIT");
    await sendPhoneChangeOtp(phone, otp);
    return res.json({ success: true, message: "OTP sent via SMS" });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error sending SMS OTP", { error: error.message });
    return res.status(500).json({ error: "Failed to send SMS OTP", message: error.message });
  } finally {
    client.release();
  }
}

async function verifySmsOtp(req, res) {
  const client = await pool.connect();
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) {
      return res.status(400).json({ error: "Phone and OTP are required" });
    }
    await client.query("BEGIN");
    const result = await otpService.verifyOtp({
      flow: otpService.FLOWS.PHONE_VERIFICATION,
      targetPhone: phone,
      code: otp,
      client,
    });
    if (!result.valid) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: result.reason || "Invalid or expired OTP" });
    }
    await client.query("COMMIT");
    return res.json({ success: true, message: "Phone verified successfully" });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error verifying SMS OTP", { error: error.message });
    return res.status(500).json({ error: "Failed to verify SMS OTP", message: error.message });
  } finally {
    client.release();
  }
}

/**
 * POST /api/v1/auth/track-abandoned
 * Public endpoint — called by the mobile app when a user enters their email
 * on the signup screen but leaves before completing registration.
 * Body: { email, userType?, step?, platform? }
 */
async function trackAbandonedSignup(req, res) {
  try {
    const { email, userType, step, platform } = req.body;

    if (!email || typeof email !== "string") {
      return res.status(400).json({ error: "email is required" });
    }

    const cleanEmail = email.trim().toLowerCase();

    // Only fire if this email doesn't already have a verified account
    // (no point spamming existing users who are just logging in from a new device)
    const existing = await pool.query(
      "SELECT id, is_verified FROM users WHERE LOWER(email) = $1",
      [cleanEmail]
    );

    if (existing.rows.length > 0 && existing.rows[0].is_verified) {
      // Already a verified user — silently ignore
      return res.json({ success: true, skipped: true });
    }

    // Upsert into abandoned_signups — covers both:
    //   • brand-new email (never registered)
    //   • registered but not yet verified (they still haven't finished)
    // ON CONFLICT DO NOTHING so we don't reset created_at for repeat calls
    await pool.query(
      `INSERT INTO abandoned_signups (email, user_type, step, platform)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (email) DO NOTHING`,
      [
        cleanEmail,
        userType || null,
        step || "email_entered",
        platform || "mobile",
      ]
    );

    res.json({ success: true, event: "abandoned_signup" });
  } catch (err) {
    logger.error("trackAbandonedSignup error:", err);
    // Return 200 anyway — we don't want a tracking failure to surface as an error to the app
    res.json({ success: false });
  }
}

module.exports = {
  register,
  login,
  refreshToken,
  logout,
  verifyEmail,
  requestPasswordReset,
  resetPassword,
  changePassword,
  requestEmailChangeOtp,
  verifyEmailChangeOtp,
  requestPhoneChangeOtp,
  verifyPhoneChangeOtp,
  getProfile,
  updateProfile,
  resendVerificationEmail,
  googleLogin,
  appleLogin,
  registerBiometric,
  loginWithBiometric,
  disableBiometric,
  getBiometricStatus,
  getTwoFactorAuthentication,
  updateTwoFactorAuthentication,
  deleteAccount,
  sendSmsOtp,
  verifySmsOtp,
  trackAbandonedSignup,
};
