const { pool } = require("../database/connection");
const logger = require("../utils/logger");

// Reward values
const VOICE_REWARD_CURRENCY = 3.45; // 5 min × $0.69/min
const CHAT_REWARD_CURRENCY = 7.80;  // 20 messages × $0.39/msg

/**
 * POST /ads/claim-reward
 * Credits the user's wallet after watching 3 ads.
 * Enforces a once-per-calendar-day limit server-side.
 */
async function claimReward(req, res) {
  const userId = req.user.id;
  const { rewardType } = req.body;

  if (!["voice", "chat"].includes(rewardType)) {
    return res.status(400).json({
      error: "Invalid reward type",
      message: "rewardType must be 'voice' or 'chat'",
    });
  }

  const rewardAmount =
    rewardType === "voice" ? VOICE_REWARD_CURRENCY : CHAT_REWARD_CURRENCY;
  const description =
    rewardType === "voice"
      ? "Ad reward: 5 free voice minutes ($3.45)"
      : "Ad reward: 20 free chat messages ($7.80)";

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // ── Daily duplicate guard ────────────────────────────────────────────────
    // Check if user already claimed an ad reward today (UTC day boundary).
    const dupCheck = await client.query(
      `SELECT id FROM wallet_transactions
       WHERE user_id = $1
         AND transaction_type = 'ad_reward'
         AND created_at >= date_trunc('day', NOW() AT TIME ZONE 'UTC')
       LIMIT 1`,
      [userId],
    );

    if (dupCheck.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Already claimed",
        message: "You have already claimed your ad reward today. Come back tomorrow.",
      });
    }

    // ── Fetch current wallet balance ────────────────────────────────────────
    const walletResult = await client.query(
      "SELECT balance_minutes, balance_currency FROM user_wallets WHERE user_id = $1 FOR UPDATE",
      [userId],
    );

    if (walletResult.rows.length === 0) {
      await client.query("ROLLBACK");
      logger.warn("claimReward: wallet not found", { userId });
      return res.status(404).json({
        error: "Wallet not found",
        message: "Could not locate wallet for this account.",
      });
    }

    const currentMinutes = parseFloat(walletResult.rows[0].balance_minutes);
    const currentCurrency = parseFloat(walletResult.rows[0].balance_currency);
    const newCurrency = currentCurrency + rewardAmount;

    // ── Credit the wallet ────────────────────────────────────────────────────
    await client.query(
      `UPDATE user_wallets
       SET balance_currency = $1,
           updated_at = NOW()
       WHERE user_id = $2`,
      [newCurrency, userId],
    );

    // ── Record transaction ───────────────────────────────────────────────────
    await client.query(
      `INSERT INTO wallet_transactions
         (user_id, transaction_type, amount_minutes, amount_currency,
          balance_after_minutes, balance_after_currency, description)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        userId,
        "ad_reward",
        0,
        rewardAmount,
        currentMinutes,
        newCurrency,
        description,
      ],
    );

    await client.query("COMMIT");

    logger.info("Ad reward claimed", {
      userId,
      rewardType,
      rewardAmount,
      newCurrency,
    });

    return res.status(200).json({
      success: true,
      rewardType,
      amountCredited: rewardAmount,
      newBalance: newCurrency,
      message: description,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("claimReward error", {
      error: error.message,
      stack: error.stack,
      userId,
    });
    return res.status(500).json({
      error: "Server error",
      message: "Failed to credit reward. Please try again.",
    });
  } finally {
    client.release();
  }
}

module.exports = { claimReward };
