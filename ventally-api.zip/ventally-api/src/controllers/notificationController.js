const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const {
  sendNotificationToDevice,
  sendNotificationToMultipleDevices,
  sendNotificationToTopic,
  subscribeToTopic,
  unsubscribeFromTopic,
  verifyToken,
} = require("../services/fcm");

const DEFAULT_NOTIFICATION_SETTINGS = {
  all_notifications: true,
  message_notifications: true,
  call_notifications: true,
  reminder_notifications: true,
  sound_vibration: true,
  in_app_alerts: true,
  activity_status: true,
  listener_reply_notifications: true,
  mood_log_notifications: true,
  reflection_log_notifications: true,
  wellness_nudges: true,
  reminder_time_utc: "20:00:00",
  quiet_hours_start_utc: null,
  quiet_hours_end_utc: null,
};

const UTC_TIME_REGEX = /^([01]\d|2[0-3]):([0-5]\d)(:[0-5]\d)?$/;

function normalizeUtcTime(value) {
  if (!value) {
    return null;
  }

  const cleanValue = value.trim();
  if (!UTC_TIME_REGEX.test(cleanValue)) {
    return null;
  }

  return cleanValue.length === 5 ? `${cleanValue}:00` : cleanValue;
}

function minutesFromTimeString(timeValue) {
  if (!timeValue) {
    return null;
  }

  const [hours, minutes] = timeValue.split(":").map(Number);
  return hours * 60 + minutes;
}

function isWithinQuietHours(startTimeUtc, endTimeUtc) {
  const startMinutes = minutesFromTimeString(startTimeUtc);
  const endMinutes = minutesFromTimeString(endTimeUtc);

  if (startMinutes === null || endMinutes === null) {
    return false;
  }

  if (startMinutes === endMinutes) {
    return false;
  }

  const now = new Date();
  const currentMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();

  if (startMinutes < endMinutes) {
    return currentMinutes >= startMinutes && currentMinutes < endMinutes;
  }

  return currentMinutes >= startMinutes || currentMinutes < endMinutes;
}

function toBooleanIfDefined(value) {
  if (value === undefined) {
    return undefined;
  }

  return typeof value === "boolean" ? value : null;
}

function getNotificationChannelFromPayload(payload = {}) {
  const rawChannel =
    payload.notification_channel ||
    payload.notificationChannel ||
    payload.type ||
    payload.channel;

  if (!rawChannel || typeof rawChannel !== "string") {
    return "message";
  }

  const normalizedChannel = rawChannel.toLowerCase();

  if (["message", "messages"].includes(normalizedChannel)) {
    return "message";
  }

  if (["call", "calls"].includes(normalizedChannel)) {
    return "call";
  }

  if (["reminder", "reminders"].includes(normalizedChannel)) {
    return "reminder";
  }

  if (["in_app", "in-app", "in_app_alert"].includes(normalizedChannel)) {
    return "in_app";
  }

  return "message";
}

function normalizeNotificationSettingsResponse(settings) {
  return {
    allNotifications: settings.all_notifications,
    messageNotifications: settings.message_notifications,
    callNotifications: settings.call_notifications,
    reminderNotifications: settings.reminder_notifications,
    soundVibration: settings.sound_vibration,
    inAppAlerts: settings.in_app_alerts,
    activityStatus: settings.activity_status,
    listenerReplyNotifications: settings.listener_reply_notifications,
    moodLogNotifications: settings.mood_log_notifications,
    reflectionLogNotifications: settings.reflection_log_notifications,
    wellnessNudges: settings.wellness_nudges,
    remindMeAtUtc: settings.reminder_time_utc,
    quietHoursStartUtc: settings.quiet_hours_start_utc,
    quietHoursEndUtc: settings.quiet_hours_end_utc,
  };
}

function getMergedSettings(row) {
  return {
    ...DEFAULT_NOTIFICATION_SETTINGS,
    ...(row || {}),
  };
}

async function getUserNotificationSettings(client, userId) {
  const result = await client.query(
    `SELECT all_notifications, message_notifications, call_notifications,
            reminder_notifications, sound_vibration, in_app_alerts,
            activity_status, listener_reply_notifications,
            mood_log_notifications, reflection_log_notifications,
            wellness_nudges,
            reminder_time_utc::text AS reminder_time_utc,
            quiet_hours_start_utc::text AS quiet_hours_start_utc,
            quiet_hours_end_utc::text AS quiet_hours_end_utc
     FROM user_notification_preferences
     WHERE user_id = $1`,
    [userId],
  );

  return getMergedSettings(result.rows[0]);
}

function isNotificationAllowed(settings, channel) {
  if (!settings.all_notifications) {
    return false;
  }

  if (channel !== "in_app" && !settings.sound_vibration) {
    return false;
  }

  if (channel === "message") {
    return settings.message_notifications;
  }

  if (channel === "call") {
    return settings.call_notifications;
  }

  if (channel === "in_app") {
    return settings.in_app_alerts;
  }

  if (channel === "reminder") {
    if (!settings.reminder_notifications) {
      return false;
    }

    if (
      settings.quiet_hours_start_utc &&
      settings.quiet_hours_end_utc &&
      isWithinQuietHours(
        settings.quiet_hours_start_utc,
        settings.quiet_hours_end_utc,
      )
    ) {
      return false;
    }
  }

  return true;
}

/**
 * Register a device token for push notifications
 * POST /api/v1/notifications/register
 */
const registerDeviceToken = async (req, res) => {
  const client = await pool.connect();
  try {
    const { token, device_type, device_info } = req.body;
    const userId = req.user.id;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Device token is required",
      });
    }

    // Validate token with Firebase
    const isValid = await verifyToken(token);
    if (!isValid) {
      return res.status(400).json({
        success: false,
        message: "Invalid device token",
      });
    }

    // Check if token already exists
    const existingToken = await client.query(
      "SELECT id FROM device_tokens WHERE token = $1",
      [token],
    );

    if (existingToken.rows.length > 0) {
      // Update existing token
      await client.query(
        `UPDATE device_tokens 
         SET user_id = $1, device_type = $2, device_info = $3, 
             is_active = true, updated_at = NOW()
         WHERE token = $4`,
        [userId, device_type || "unknown", device_info || {}, token],
      );

      logger.info(`Device token updated for user ${userId}`);
    } else {
      // Insert new token
      await client.query(
        `INSERT INTO device_tokens (user_id, token, device_type, device_info)
         VALUES ($1, $2, $3, $4)`,
        [userId, token, device_type || "unknown", device_info || {}],
      );

      logger.info(`Device token registered for user ${userId}`);
    }

    res.status(200).json({
      success: true,
      message: "Device token registered successfully",
    });
  } catch (error) {
    logger.error("Error registering device token:", error);
    res.status(500).json({
      success: false,
      message: "Failed to register device token",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Unregister a device token
 * DELETE /api/v1/notifications/register
 */
const unregisterDeviceToken = async (req, res) => {
  const client = await pool.connect();
  try {
    const { token } = req.body;
    const userId = req.user.id;

    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Device token is required",
      });
    }

    await client.query(
      `UPDATE device_tokens 
       SET is_active = false, updated_at = NOW()
       WHERE token = $1 AND user_id = $2`,
      [token, userId],
    );

    logger.info(`Device token unregistered for user ${userId}`);

    res.status(200).json({
      success: true,
      message: "Device token unregistered successfully",
    });
  } catch (error) {
    logger.error("Error unregistering device token:", error);
    res.status(500).json({
      success: false,
      message: "Failed to unregister device token",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Send a dummy push notification without authentication (testing only)
 * POST /api/v1/notifications/test-send
 */
const sendTestNotificationNoAuth = async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      user_id,
      token,
      title = "Test Notification",
      body = "This is a test push notification from Swagger",
      data = {},
      image_url,
    } = req.body || {};

    if (!user_id && !token) {
      return res.status(400).json({
        success: false,
        message: "Provide either user_id or token",
      });
    }

    const notification = { title, body, imageUrl: image_url };

    if (token) {
      const messageId = await sendNotificationToDevice(token, notification, {
        ...data,
        type: data.type || "test_notification",
      });

      return res.status(200).json({
        success: true,
        message: "Test notification sent to device token",
        result: {
          messageId,
          target: "token",
        },
      });
    }

    const tokensResult = await client.query(
      "SELECT token FROM device_tokens WHERE user_id = $1 AND is_active = true",
      [user_id],
    );

    if (tokensResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active device tokens found for this user",
      });
    }

    const tokens = tokensResult.rows.map((row) => row.token);
    const response = await sendNotificationToMultipleDevices(
      tokens,
      notification,
      {
        ...data,
        type: data.type || "test_notification",
      },
    );

    res.status(200).json({
      success: true,
      message: "Test notification sent",
      result: {
        target: "user_id",
        deviceCount: tokens.length,
        successCount: response.successCount,
        failureCount: response.failureCount,
      },
    });
  } catch (error) {
    logger.error("Error sending unauthenticated test notification:", error);
    res.status(500).json({
      success: false,
      message: "Failed to send test notification",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Send a notification to a specific user
 * POST /api/v1/notifications/send
 */
const sendNotification = async (req, res) => {
  const client = await pool.connect();
  try {
    const { user_id, title, body, data, image_url } = req.body;
    const notificationChannel = getNotificationChannelFromPayload({
      ...(data || {}),
      ...req.body,
    });

    if (!user_id || !title || !body) {
      return res.status(400).json({
        success: false,
        message: "user_id, title, and body are required",
      });
    }

    const userSettings = await getUserNotificationSettings(client, user_id);
    const shouldSend = isNotificationAllowed(userSettings, notificationChannel);

    if (!shouldSend) {
      await client.query(
        `INSERT INTO notifications (user_id, title, body, data, type, status)
         VALUES ($1, $2, $3, $4, 'push', 'skipped')`,
        [user_id, title, body, data || {}],
      );

      return res.status(200).json({
        success: true,
        message: "Notification skipped due to user preferences",
        result: {
          skipped: true,
          notificationChannel,
        },
      });
    }

    // Get all active tokens for the user
    const result = await client.query(
      "SELECT token FROM device_tokens WHERE user_id = $1 AND is_active = true",
      [user_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active devices found for this user",
      });
    }

    const tokens = result.rows.map((row) => row.token);
    const notification = { title, body, imageUrl: image_url };

    // Send to multiple devices
    const response = await sendNotificationToMultipleDevices(
      tokens,
      notification,
      data || {},
    );

    // Check if Firebase is not initialized
    if (
      response.successCount === 0 &&
      response.failureCount > 0 &&
      !response.responses.length
    ) {
      // Store notification in database anyway
      await client.query(
        `INSERT INTO notifications (user_id, title, body, data, type, status)
         VALUES ($1, $2, $3, $4, 'push', 'pending')`,
        [user_id, title, body, data || {}],
      );

      return res.status(503).json({
        success: false,
        message:
          "Firebase not configured - notification saved but not sent. Configure Firebase to enable push notifications.",
        result: {
          successCount: 0,
          failureCount: response.failureCount,
          stored: true,
        },
      });
    }

    // Store notification in database
    await client.query(
      `INSERT INTO notifications (user_id, title, body, data, type, status)
       VALUES ($1, $2, $3, $4, 'push', 'sent')`,
      [user_id, title, body, data || {}],
    );

    res.status(200).json({
      success: true,
      message: "Notification sent successfully",
      result: {
        successCount: response.successCount,
        failureCount: response.failureCount,
      },
    });
  } catch (error) {
    logger.error("Error sending notification:", error);
    res.status(500).json({
      success: false,
      message: "Failed to send notification",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Send a notification to multiple users
 * POST /api/v1/notifications/send-bulk
 */
const sendBulkNotification = async (req, res) => {
  const client = await pool.connect();
  try {
    const { user_ids, title, body, data, image_url } = req.body;
    const notificationChannel = getNotificationChannelFromPayload({
      ...(data || {}),
      ...req.body,
    });

    if (!user_ids || !Array.isArray(user_ids) || !title || !body) {
      return res.status(400).json({
        success: false,
        message: "user_ids (array), title, and body are required",
      });
    }

    const settingsResult = await client.query(
      `SELECT user_id, all_notifications, message_notifications, call_notifications,
              reminder_notifications, sound_vibration, in_app_alerts,
              reminder_time_utc::text AS reminder_time_utc,
              quiet_hours_start_utc::text AS quiet_hours_start_utc,
              quiet_hours_end_utc::text AS quiet_hours_end_utc
       FROM user_notification_preferences
       WHERE user_id = ANY($1)`,
      [user_ids],
    );

    const settingsByUserId = new Map(
      settingsResult.rows.map((row) => [row.user_id, row]),
    );

    const allowedUserIds = user_ids.filter((userId) => {
      const userSettings = getMergedSettings(settingsByUserId.get(userId));
      return isNotificationAllowed(userSettings, notificationChannel);
    });

    if (allowedUserIds.length === 0) {
      return res.status(200).json({
        success: true,
        message: "All notifications skipped due to user preferences",
        result: {
          skipped: true,
          targetUsers: user_ids.length,
          skippedUsers: user_ids.length,
        },
      });
    }

    // Get all active tokens for the users
    const result = await client.query(
      "SELECT token FROM device_tokens WHERE user_id = ANY($1) AND is_active = true",
      [allowedUserIds],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active devices found for eligible users",
      });
    }

    const tokens = result.rows.map((row) => row.token);
    const notification = { title, body, imageUrl: image_url };

    // Send to multiple devices
    const response = await sendNotificationToMultipleDevices(
      tokens,
      notification,
      data || {},
    );

    // Check if Firebase is not initialized
    if (
      response.successCount === 0 &&
      response.failureCount > 0 &&
      !response.responses.length
    ) {
      // Store notifications in database anyway
      const notificationInserts = allowedUserIds.map((userId) =>
        client.query(
          `INSERT INTO notifications (user_id, title, body, data, type, status)
           VALUES ($1, $2, $3, $4, 'push', 'pending')`,
          [userId, title, body, data || {}],
        ),
      );
      await Promise.all(notificationInserts);

      return res.status(503).json({
        success: false,
        message:
          "Firebase not configured - notifications saved but not sent. Configure Firebase to enable push notifications.",
        result: {
          successCount: 0,
          failureCount: response.failureCount,
          targetUsers: allowedUserIds.length,
          skippedUsers: user_ids.length - allowedUserIds.length,
          stored: true,
        },
      });
    }

    // Store notifications in database for each user
    const notificationInserts = allowedUserIds.map((userId) =>
      client.query(
        `INSERT INTO notifications (user_id, title, body, data, type, status)
         VALUES ($1, $2, $3, $4, 'push', 'sent')`,
        [userId, title, body, data || {}],
      ),
    );
    await Promise.all(notificationInserts);

    res.status(200).json({
      success: true,
      message: "Bulk notification sent successfully",
      result: {
        successCount: response.successCount,
        failureCount: response.failureCount,
        targetUsers: allowedUserIds.length,
        skippedUsers: user_ids.length - allowedUserIds.length,
      },
    });
  } catch (error) {
    logger.error("Error sending bulk notification:", error);
    res.status(500).json({
      success: false,
      message: "Failed to send bulk notification",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Send a notification to a topic
 * POST /api/v1/notifications/send-topic
 */
const sendTopicNotification = async (req, res) => {
  try {
    const { topic, title, body, data, image_url } = req.body;

    if (!topic || !title || !body) {
      return res.status(400).json({
        success: false,
        message: "topic, title, and body are required",
      });
    }

    const notification = { title, body, imageUrl: image_url };
    const messageId = await sendNotificationToTopic(
      topic,
      notification,
      data || {},
    );

    if (!messageId) {
      return res.status(503).json({
        success: false,
        message:
          "Firebase not configured - cannot send topic notifications. Configure Firebase to enable push notifications.",
      });
    }

    res.status(200).json({
      success: true,
      message: "Topic notification sent successfully",
      messageId,
    });
  } catch (error) {
    logger.error("Error sending topic notification:", error);
    res.status(500).json({
      success: false,
      message: "Failed to send topic notification",
      error: error.message,
    });
  }
};

/**
 * Subscribe user's devices to a topic
 * POST /api/v1/notifications/subscribe
 */
const subscribeUserToTopic = async (req, res) => {
  const client = await pool.connect();
  try {
    const { topic } = req.body;
    const userId = req.user.id;

    if (!topic) {
      return res.status(400).json({
        success: false,
        message: "Topic is required",
      });
    }

    // Get all active tokens for the user
    const result = await client.query(
      "SELECT token FROM device_tokens WHERE user_id = $1 AND is_active = true",
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active devices found for this user",
      });
    }

    const tokens = result.rows.map((row) => row.token);
    const response = await subscribeToTopic(tokens, topic);

    res.status(200).json({
      success: true,
      message: "Subscribed to topic successfully",
      result: {
        successCount: response.successCount,
        failureCount: response.failureCount,
      },
    });
  } catch (error) {
    logger.error("Error subscribing to topic:", error);
    res.status(500).json({
      success: false,
      message: "Failed to subscribe to topic",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Unsubscribe user's devices from a topic
 * POST /api/v1/notifications/unsubscribe
 */
const unsubscribeUserFromTopic = async (req, res) => {
  const client = await pool.connect();
  try {
    const { topic } = req.body;
    const userId = req.user.id;

    if (!topic) {
      return res.status(400).json({
        success: false,
        message: "Topic is required",
      });
    }

    // Get all active tokens for the user
    const result = await client.query(
      "SELECT token FROM device_tokens WHERE user_id = $1 AND is_active = true",
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active devices found for this user",
      });
    }

    const tokens = result.rows.map((row) => row.token);
    const response = await unsubscribeFromTopic(tokens, topic);

    res.status(200).json({
      success: true,
      message: "Unsubscribed from topic successfully",
      result: {
        successCount: response.successCount,
        failureCount: response.failureCount,
      },
    });
  } catch (error) {
    logger.error("Error unsubscribing from topic:", error);
    res.status(500).json({
      success: false,
      message: "Failed to unsubscribe from topic",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Get notification history for the authenticated user
 * GET /api/v1/notifications/history
 */
const getNotificationHistory = async (req, res) => {
  const client = await pool.connect();
  try {
    const userId = req.user.id;
    const { limit = 50, offset = 0 } = req.query;

    const result = await client.query(
      `SELECT id, title, body, data, type, status, created_at, read_at
       FROM notifications
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, limit, offset],
    );

    const countResult = await client.query(
      "SELECT COUNT(*) FROM notifications WHERE user_id = $1",
      [userId],
    );

    res.status(200).json({
      success: true,
      data: result.rows,
      total: parseInt(countResult.rows[0].count),
      limit: parseInt(limit),
      offset: parseInt(offset),
    });
  } catch (error) {
    logger.error("Error fetching notification history:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch notification history",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Mark notification as read
 * PUT /api/v1/notifications/:id/read
 */
const markNotificationAsRead = async (req, res) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const result = await client.query(
      `UPDATE notifications 
       SET read_at = NOW(), updated_at = NOW()
       WHERE id = $1 AND user_id = $2 AND read_at IS NULL
       RETURNING id`,
      [id, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Notification not found or already read",
      });
    }

    res.status(200).json({
      success: true,
      message: "Notification marked as read",
    });
  } catch (error) {
    logger.error("Error marking notification as read:", error);
    res.status(500).json({
      success: false,
      message: "Failed to mark notification as read",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Get unread notification count
 * GET /api/v1/notifications/unread-count
 */
const getUnreadCount = async (req, res) => {
  const client = await pool.connect();
  try {
    const userId = req.user.id;

    const result = await client.query(
      `SELECT COUNT(*) as count 
       FROM notifications 
       WHERE user_id = $1 AND read_at IS NULL`,
      [userId],
    );

    res.status(200).json({
      success: true,
      unreadCount: parseInt(result.rows[0].count),
    });
  } catch (error) {
    logger.error("Error fetching unread count:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch unread count",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Get notification settings for the authenticated user
 * GET /api/v1/notifications/settings
 */
const getNotificationSettings = async (req, res) => {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const settings = await getUserNotificationSettings(client, userId);

    res.status(200).json({
      success: true,
      data: normalizeNotificationSettingsResponse(settings),
    });
  } catch (error) {
    logger.error("Error fetching notification settings:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch notification settings",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

/**
 * Update notification settings for the authenticated user
 * PUT /api/v1/notifications/settings
 */
const updateNotificationSettings = async (req, res) => {
  const client = await pool.connect();

  try {
    const userId = req.user.id;

    const updates = {
      all_notifications:
        req.body.all_notifications ??
        req.body.allNotifications ??
        (typeof req.body.pauseAll === "boolean"
          ? !req.body.pauseAll
          : undefined),
      message_notifications:
        req.body.message_notifications ?? req.body.messageNotifications,
      call_notifications:
        req.body.call_notifications ?? req.body.callNotifications,
      reminder_notifications:
        req.body.reminder_notifications ?? req.body.reminderNotifications,
      sound_vibration: req.body.sound_vibration ?? req.body.soundVibration,
      in_app_alerts: req.body.in_app_alerts ?? req.body.inAppAlerts,
      activity_status: req.body.activity_status ?? req.body.activityStatus,
      listener_reply_notifications:
        req.body.listener_reply_notifications ??
        req.body.listenerReplyNotifications,
      mood_log_notifications:
        req.body.mood_log_notifications ?? req.body.moodLogNotifications,
      reflection_log_notifications:
        req.body.reflection_log_notifications ??
        req.body.reflectionLogNotifications,
      wellness_nudges: req.body.wellness_nudges ?? req.body.wellnessNudges,
    };

    const reminderTimeRaw =
      req.body.reminder_time_utc ??
      req.body.remindMeAtUtc ??
      req.body.remindMeAt;
    const quietStartRaw =
      req.body.quiet_hours_start_utc ??
      req.body.quietHoursStartUtc ??
      req.body.quietHoursStart;
    const quietEndRaw =
      req.body.quiet_hours_end_utc ??
      req.body.quietHoursEndUtc ??
      req.body.quietHoursEnd;

    const invalidBooleanField = Object.entries(updates).find(
      ([, value]) => toBooleanIfDefined(value) === null,
    );

    if (invalidBooleanField) {
      return res.status(400).json({
        success: false,
        message: `${invalidBooleanField[0]} must be a boolean value`,
      });
    }

    const reminderTimeUtc =
      reminderTimeRaw === undefined
        ? undefined
        : reminderTimeRaw === null
          ? null
          : normalizeUtcTime(String(reminderTimeRaw));

    if (reminderTimeRaw !== undefined && reminderTimeUtc === null) {
      return res.status(400).json({
        success: false,
        message: "reminder_time_utc must be in HH:MM or HH:MM:SS UTC format",
      });
    }

    const quietStartUtc =
      quietStartRaw === undefined
        ? undefined
        : quietStartRaw === null
          ? null
          : normalizeUtcTime(String(quietStartRaw));
    const quietEndUtc =
      quietEndRaw === undefined
        ? undefined
        : quietEndRaw === null
          ? null
          : normalizeUtcTime(String(quietEndRaw));

    if (quietStartRaw !== undefined && quietStartUtc === null) {
      return res.status(400).json({
        success: false,
        message:
          "quiet_hours_start_utc must be in HH:MM or HH:MM:SS UTC format",
      });
    }

    if (quietEndRaw !== undefined && quietEndUtc === null) {
      return res.status(400).json({
        success: false,
        message: "quiet_hours_end_utc must be in HH:MM or HH:MM:SS UTC format",
      });
    }

    await client.query("BEGIN");

    await client.query(
      `INSERT INTO user_notification_preferences (user_id)
       VALUES ($1)
       ON CONFLICT (user_id) DO NOTHING`,
      [userId],
    );

    const currentSettings = await getUserNotificationSettings(client, userId);

    const nextSettings = {
      ...currentSettings,
      ...Object.fromEntries(
        Object.entries(updates)
          .filter(([, value]) => value !== undefined)
          .map(([key, value]) => [key, value]),
      ),
      reminder_time_utc:
        reminderTimeUtc === undefined
          ? currentSettings.reminder_time_utc
          : reminderTimeUtc,
      quiet_hours_start_utc:
        quietStartUtc === undefined
          ? currentSettings.quiet_hours_start_utc
          : quietStartUtc,
      quiet_hours_end_utc:
        quietEndUtc === undefined
          ? currentSettings.quiet_hours_end_utc
          : quietEndUtc,
    };

    const hasQuietStart = !!nextSettings.quiet_hours_start_utc;
    const hasQuietEnd = !!nextSettings.quiet_hours_end_utc;

    if (hasQuietStart !== hasQuietEnd) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        success: false,
        message:
          "quiet_hours_start_utc and quiet_hours_end_utc must both be set or both be null",
      });
    }

    const updateResult = await client.query(
      `UPDATE user_notification_preferences
       SET all_notifications = $2,
           message_notifications = $3,
           call_notifications = $4,
           reminder_notifications = $5,
           sound_vibration = $6,
           in_app_alerts = $7,
           activity_status = $8,
           listener_reply_notifications = $9,
           mood_log_notifications = $10,
           reflection_log_notifications = $11,
           wellness_nudges = $12,
           reminder_time_utc = $13,
           quiet_hours_start_utc = $14,
           quiet_hours_end_utc = $15,
           updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $1
       RETURNING all_notifications, message_notifications, call_notifications,
                 reminder_notifications, sound_vibration, in_app_alerts,
                 activity_status, listener_reply_notifications,
                 mood_log_notifications, reflection_log_notifications,
                 wellness_nudges,
                 reminder_time_utc::text AS reminder_time_utc,
                 quiet_hours_start_utc::text AS quiet_hours_start_utc,
                 quiet_hours_end_utc::text AS quiet_hours_end_utc`,
      [
        userId,
        nextSettings.all_notifications,
        nextSettings.message_notifications,
        nextSettings.call_notifications,
        nextSettings.reminder_notifications,
        nextSettings.sound_vibration,
        nextSettings.in_app_alerts,
        nextSettings.activity_status,
        nextSettings.listener_reply_notifications,
        nextSettings.mood_log_notifications,
        nextSettings.reflection_log_notifications,
        nextSettings.wellness_nudges,
        nextSettings.reminder_time_utc,
        nextSettings.quiet_hours_start_utc,
        nextSettings.quiet_hours_end_utc,
      ],
    );

    await client.query("COMMIT");

    res.status(200).json({
      success: true,
      message: "Notification settings updated successfully",
      data: normalizeNotificationSettingsResponse(updateResult.rows[0]),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error updating notification settings:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update notification settings",
      error: error.message,
    });
  } finally {
    client.release();
  }
};

module.exports = {
  registerDeviceToken,
  unregisterDeviceToken,
  sendTestNotificationNoAuth,
  sendNotification,
  sendBulkNotification,
  sendTopicNotification,
  subscribeUserToTopic,
  unsubscribeUserFromTopic,
  getNotificationHistory,
  markNotificationAsRead,
  getUnreadCount,
  getNotificationSettings,
  updateNotificationSettings,
};
