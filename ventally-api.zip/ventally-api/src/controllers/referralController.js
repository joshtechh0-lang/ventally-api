const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Generate a unique 8-char alphanumeric referral code for a user
 * Called internally during registration
 */
async function generateReferralCode(userId, client) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/I/1 for clarity
  let code;
  let attempts = 0;

  while (attempts < 10) {
    code = Array.from({ length: 8 }, () =>
      chars[Math.floor(Math.random() * chars.length)]
    ).join("");

    const existing = await client.query(
      "SELECT id FROM users WHERE referral_code = $1",
      [code]
    );
    if (existing.rows.length === 0) break;
    attempts++;
  }

  await client.query(
    "UPDATE users SET referral_code = $1 WHERE id = $2",
    [code, userId]
  );

  return code;
}

/**
 * GET /referrals/my-stats
 * Returns the authenticated user's referral code, stats, and referral history
 */
async function getMyStats(req, res) {
  const userId = req.user.id;
  const client = await pool.connect();

  try {
    // Get user's referral code (generate one if missing)
    let userRow = await client.query(
      "SELECT referral_code FROM users WHERE id = $1",
      [userId]
    );

    let referralCode = userRow.rows[0]?.referral_code;

    if (!referralCode) {
      // Lazily generate if somehow missing
      referralCode = await generateReferralCode(userId, client);
    }

    // Count referrals and earned rewards
    const statsRow = await client.query(
      `SELECT
         COUNT(*) AS total_referred,
         COUNT(*) FILTER (WHERE status = 'completed' AND reward_granted = true) AS rewarded_count,
         COALESCE(SUM(reward_value) FILTER (WHERE status = 'completed' AND reward_granted = true AND reward_type = 'minutes'), 0) AS earned_minutes
       FROM referrals
       WHERE referrer_id = $1`,
      [userId]
    );

    const stats = statsRow.rows[0];

    // Get referral history (most recent first, cap at 50)
    const historyRows = await client.query(
      `SELECT
         r.id,
         u.display_name AS referred_user,
         r.status,
         r.reward_granted,
         r.created_at
       FROM referrals r
       JOIN users u ON u.id = r.referred_id
       WHERE r.referrer_id = $1
       ORDER BY r.created_at DESC
       LIMIT 50`,
      [userId]
    );

    res.json({
      data: {
        referralCode,
        totalReferred: parseInt(stats.total_referred) || 0,
        pendingRewards: parseInt(stats.rewarded_count) || 0,
        earnedRewards: parseInt(stats.earned_minutes) || 0,
        referrals: historyRows.rows.map((r) => ({
          id: r.id,
          referredUser: r.referred_user || "Anonymous",
          status: r.status,
          rewardGranted: r.reward_granted,
          createdAt: r.created_at,
        })),
      },
    });
  } catch (err) {
    logger.error("Error fetching referral stats:", err);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch referral stats",
    });
  } finally {
    client.release();
  }
}

/**
 * POST /referrals/apply
 * Called after signup to apply a referral code
 * Body: { referralCode: string }
 */
async function applyReferral(req, res) {
  const referredId = req.user.id;
  const { referralCode } = req.body;

  if (!referralCode) {
    return res.status(400).json({
      error: "Missing referral code",
      message: "referralCode is required",
    });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Find the referrer by code
    const referrerRow = await client.query(
      "SELECT id FROM users WHERE UPPER(referral_code) = UPPER($1)",
      [referralCode.trim()]
    );

    if (referrerRow.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Invalid referral code",
        message: "Referral code not found",
      });
    }

    const referrerId = referrerRow.rows[0].id;

    // Prevent self-referral
    if (referrerId === referredId) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Self-referral",
        message: "You cannot use your own referral code",
      });
    }

    // Prevent duplicate referral
    const existingReferral = await client.query(
      "SELECT id FROM referrals WHERE referred_id = $1",
      [referredId]
    );

    if (existingReferral.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Already referred",
        message: "You have already used a referral code",
      });
    }

    // Create the referral record
    await client.query(
      `INSERT INTO referrals (referrer_id, referred_id, status, reward_type, reward_value, reward_granted, referee_discount_pct)
       VALUES ($1, $2, 'pending', 'minutes', 5, false, 20)`,
      [referrerId, referredId]
    );

    await client.query("COMMIT");

    logger.info(`Referral applied: referrer=${referrerId}, referred=${referredId}`);

    res.json({
      success: true,
      message: "Referral code applied successfully! You'll both get rewarded after your first session.",
    });
  } catch (err) {
    await client.query("ROLLBACK");
    logger.error("Error applying referral:", err);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to apply referral code",
    });
  } finally {
    client.release();
  }
}

/**
 * Internal function called when a session completes to grant referral rewards
 * referredId = the user who was referred and just completed a session
 */
async function grantReferralReward(referredId, client) {
  try {
    // Find a pending referral for this referred user
    const referralRow = await client.query(
      `SELECT id, referrer_id, reward_value
       FROM referrals
       WHERE referred_id = $1 AND status = 'pending' AND reward_granted = false`,
      [referredId]
    );

    if (referralRow.rows.length === 0) return; // No pending referral

    const referral = referralRow.rows[0];

    // Grant minutes to referrer
    await client.query(
      `UPDATE user_wallets
       SET balance_minutes = balance_minutes + $1
       WHERE user_id = $2`,
      [referral.reward_value, referral.referrer_id]
    );

    // Mark referral as completed
    await client.query(
      `UPDATE referrals
       SET status = 'completed', reward_granted = true, rewarded_at = NOW()
       WHERE id = $1`,
      [referral.id]
    );

    logger.info(
      `Referral reward granted: referral=${referral.id}, referrer=${referral.referrer_id}, minutes=${referral.reward_value}`
    );
  } catch (err) {
    logger.error("Error granting referral reward:", err);
    // Non-fatal — don't throw, rewards can be retried manually
  }
}

module.exports = {
  getMyStats,
  applyReferral,
  generateReferralCode,
  grantReferralReward,
};
