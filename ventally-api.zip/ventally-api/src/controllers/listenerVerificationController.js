const { pool } = require("../database/connection");
const s3Service = require("../services/s3");
const { sendListenerApprovalEmail, sendListenerDeniedEmail } = require("../services/email");
const logger = require("../utils/logger");

const ADMIN_DECISIONS = ["verified", "rejected"];

function normalizeVerificationStatus(status) {
  return status === "verified" ? "approved" : status;
}

async function submitVerificationDocument(req, res) {
  const client = await pool.connect();

  try {
    const listenerId = req.user.id;
    const file = req.file;

    if (!file) {
      return res.status(400).json({
        error: "No file provided",
        message: "Please upload a verification document",
      });
    }

    await client.query("BEGIN");

    const pendingResult = await client.query(
      `SELECT id FROM listener_verification_documents
       WHERE listener_id = $1 AND status = 'pending'
       LIMIT 1`,
      [listenerId],
    );

    if (pendingResult.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Pending verification exists",
        message:
          "You already have a pending verification document. Please wait for admin review.",
      });
    }

    const uploadResult = await s3Service.uploadListenerVerificationDocument(
      file.buffer,
      file.originalname,
      listenerId,
      file.mimetype,
    );

    const insertResult = await client.query(
      `INSERT INTO listener_verification_documents
        (listener_id, status, s3_key, file_url, original_file_name, mime_type, file_size_bytes)
       VALUES
        ($1, 'pending', $2, $3, $4, $5, $6)
       RETURNING id, status, created_at`,
      [
        listenerId,
        uploadResult.key,
        uploadResult.url,
        file.originalname,
        file.mimetype,
        file.size,
      ],
    );

    await client.query("COMMIT");

    logger.info(
      `Listener ${listenerId} uploaded verification document ${insertResult.rows[0].id}`,
    );

    return res.status(201).json({
      success: true,
      verification: {
        id: insertResult.rows[0].id,
        status: normalizeVerificationStatus(insertResult.rows[0].status),
        createdAt: insertResult.rows[0].created_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error submitting listener verification document", {
      error: error.message,
    });
    return res.status(500).json({
      error: "Submission failed",
      message: "Failed to upload verification document",
    });
  } finally {
    client.release();
  }
}

async function getMyVerificationSubmissions(req, res) {
  try {
    const listenerId = req.user.id;
    const { limit = 10, offset = 0 } = req.query;

    const result = await pool.query(
      `SELECT id, status, admin_notes, reviewed_at, created_at
       FROM listener_verification_documents
       WHERE listener_id = $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`,
      [listenerId, parseInt(limit, 10), parseInt(offset, 10)],
    );

    return res.json({
      success: true,
      submissions: result.rows.map((row) => ({
        ...row,
        status: normalizeVerificationStatus(row.status),
      })),
    });
  } catch (error) {
    logger.error("Error fetching listener verification submissions", {
      error: error.message,
    });
    return res.status(500).json({
      error: "Fetch failed",
      message: "Failed to fetch verification submissions",
    });
  }
}

async function listVerificationSubmissionsAdmin(req, res) {
  try {
    const { status, limit = 50, offset = 0 } = req.query;
    const queryParams = [];

    let query = `
      SELECT
        v.id,
        v.listener_id,
        u.email AS listener_email,
        u.gender_identity,
        u.preferred_language,
        u.ethnicity,
        u.age_group,
        u.lgbtq_identity,
        u.special_topics,
        u.faith_or_belief,
        v.status,
        v.mime_type,
        v.original_file_name,
        v.created_at,
        v.reviewed_at,
        v.reviewed_by
      FROM listener_verification_documents v
      JOIN users u ON u.id = v.listener_id
      WHERE 1 = 1
    `;

    if (status) {
      queryParams.push(status === "approved" ? "verified" : status);
      query += ` AND v.status = $${queryParams.length}`;
    }

    queryParams.push(parseInt(limit, 10));
    queryParams.push(parseInt(offset, 10));

    query += ` ORDER BY v.created_at DESC LIMIT $${queryParams.length - 1} OFFSET $${queryParams.length}`;

    const result = await pool.query(query, queryParams);

    return res.json({
      success: true,
      submissions: result.rows.map((row) => ({
        ...row,
        status: normalizeVerificationStatus(row.status),
      })),
    });
  } catch (error) {
    logger.error("Error listing listener verification submissions (admin)", {
      error: error.message,
    });
    return res.status(500).json({
      error: "Fetch failed",
      message: "Failed to fetch submissions",
    });
  }
}

async function getVerificationSubmissionAdmin(req, res) {
  try {
    const { verificationId } = req.params;

    const result = await pool.query(
      `SELECT
        v.id,
        v.listener_id,
        u.email AS listener_email,
        u.gender_identity,
        u.preferred_language,
        u.ethnicity,
        u.age_group,
        u.lgbtq_identity,
        u.special_topics,
        u.faith_or_belief,
        v.status,
        v.s3_key,
        v.file_url,
        v.mime_type,
        v.original_file_name,
        v.file_size_bytes,
        v.admin_notes,
        v.reviewed_by,
        v.reviewed_at,
        v.s3_deleted_at,
        v.created_at,
        v.updated_at
      FROM listener_verification_documents v
      JOIN users u ON u.id = v.listener_id
      WHERE v.id = $1
      LIMIT 1`,
      [verificationId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Verification submission not found",
      });
    }

    const submission = result.rows[0];
    let presignedUrl = null;

    if (submission.s3_key && !submission.s3_deleted_at) {
      presignedUrl = await s3Service.getPresignedGetUrl(submission.s3_key);
    }

    const documentsResult = await pool.query(
      `SELECT
        id,
        status,
        original_file_name,
        mime_type,
        file_size_bytes,
        created_at,
        reviewed_at,
        admin_notes
       FROM listener_verification_documents
       WHERE listener_id = $1
       ORDER BY created_at DESC`,
      [submission.listener_id],
    );

    return res.json({
      success: true,
      submission: {
        ...submission,
        status: normalizeVerificationStatus(submission.status),
        document_url: presignedUrl,
        verificationDocuments: documentsResult.rows.map((row) => ({
          ...row,
          status: normalizeVerificationStatus(row.status),
        })),
      },
    });
  } catch (error) {
    logger.error("Error fetching verification submission (admin)", {
      error: error.message,
    });
    return res.status(500).json({
      error: "Fetch failed",
      message: "Failed to fetch submission",
    });
  }
}

async function verifySubmissionAdmin(req, res) {
  const client = await pool.connect();

  try {
    const { verificationId } = req.params;
    const { status, adminNotes } = req.body;
    const adminUserId = req.user.id;

    if (!ADMIN_DECISIONS.includes(status)) {
      return res.status(400).json({
        error: "Validation error",
        message: `status must be one of: ${ADMIN_DECISIONS.join(", ")}`,
      });
    }

    await client.query("BEGIN");

    const existingResult = await client.query(
      `SELECT id, listener_id, status, s3_key, s3_deleted_at
       FROM listener_verification_documents
       WHERE id = $1
       FOR UPDATE`,
      [verificationId],
    );

    if (existingResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "Verification submission not found",
      });
    }

    const existing = existingResult.rows[0];

    if (existing.status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Invalid state",
        message: `Only pending submissions can be reviewed. Current status: ${existing.status}`,
      });
    }

    let s3DeletedAt = null;

    if (status === "verified" && existing.s3_key && !existing.s3_deleted_at) {
      await s3Service.deleteFile(existing.s3_key);
      s3DeletedAt = new Date();
    }

    const updateResult = await client.query(
      `UPDATE listener_verification_documents
       SET status = $1,
           admin_notes = $2,
           reviewed_by = $3,
           reviewed_at = NOW(),
           s3_deleted_at = COALESCE($4, s3_deleted_at),
           updated_at = NOW()
       WHERE id = $5
       RETURNING id, listener_id, status, reviewed_at, s3_deleted_at`,
      [status, adminNotes || null, adminUserId, s3DeletedAt, verificationId],
    );

    await client.query("COMMIT");

    // Send SES email notification
    try {
        const userResult = await pool.query(
            "SELECT email, first_name FROM users WHERE id = $1",
            [existing.listener_id]
        );
        if (userResult.rows.length > 0) {
            const { email, first_name } = userResult.rows[0];
            if (status === "verified") {
                sendListenerApprovalEmail(email, first_name || null).catch(e =>
                    logger.error("Failed to send listener approval email:", e.message)
                );
            } else if (status === "rejected") {
                sendListenerDeniedEmail(email, first_name || null).catch(e =>
                    logger.error("Failed to send listener denial email:", e.message)
                );
            }
        }
    } catch (emailError) {
        logger.error("Error sending listener verification email:", emailError.message);
    }

    logger.info(
      `Admin ${adminUserId} reviewed listener verification ${verificationId} with status ${status}`,
    );

    return res.json({
      success: true,
      submission: {
        ...updateResult.rows[0],
        status: normalizeVerificationStatus(updateResult.rows[0].status),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error reviewing listener verification submission", {
      error: error.message,
    });
    return res.status(500).json({
      error: "Review failed",
      message: "Failed to review verification submission",
    });
  } finally {
    client.release();
  }
}

module.exports = {
  submitVerificationDocument,
  getMyVerificationSubmissions,
  listVerificationSubmissionsAdmin,
  getVerificationSubmissionAdmin,
  verifySubmissionAdmin,
};
