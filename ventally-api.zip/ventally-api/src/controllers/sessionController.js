const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const {
  initiateConferenceCall,
  endCall,
  getCallDetails,
} = require("../services/twilio");
const { canMakeCall } = require("./walletController");
const logger = require("../utils/logger");
const {
  getGracePeriodConfig,
  calculateBillableDuration,
  checkGracePeriodRateLimit,
  recordGracePeriodUsage,
  formatTransactionDescription,
} = require("../utils/gracePeriod");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const {
  getSurgeMultiplier,
  calculateSurgeCost,
  formatSurgeDescription,
  getSurgeExplanation,
} = require("../utils/surgePricing");
const {
  getCanonicalPublicBaseUrl,
  buildPublicUrl,
} = require("../utils/publicUrl");
const {
  ACTIVE_CALL_STATUSES,
  ACTIVE_CHAT_STATUSES,
} = require("../utils/sessionHelper");
const { sendCallDropEmail } = require("../services/email");

// Session configuration
const SESSION_RATE_PER_MINUTE =
  parseFloat(process.env.SESSION_RATE_PER_MINUTE) || 0.5;
const MIN_BALANCE_MINUTES = parseInt(process.env.MIN_BALANCE_MINUTES) || 5;
const REDIS_SESSION_PREFIX = "session:";
const REDIS_SESSION_TTL = 24 * 60 * 60; // 24 hours

/**
 * Create a new call session
 */
async function createSession(req, res) {
  const client = await pool.connect();

  try {
    const { listenerId } = req.body;
    const venterId = req.user.id; // From auth middleware

    // Validation
    if (!listenerId) {
      return res.status(400).json({
        error: "Missing listener ID",
        message: "Listener ID is required",
      });
    }

    if (venterId === listenerId) {
      return res.status(400).json({
        error: "Invalid request",
        message: "Cannot create session with yourself",
      });
    }

    await client.query("BEGIN");

    // Check if venter exists and get details
    const venterResult = await client.query(
      "SELECT id, user_type, phone, is_verified FROM users WHERE id = $1",
      [venterId],
    );

    if (venterResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Venter not found",
        message: "Your account was not found",
      });
    }

    const venter = venterResult.rows[0];

    if (venter.user_type !== "venter") {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Invalid user type",
        message: "Only venters can create call sessions",
      });
    }

    if (!venter.is_verified) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Account not verified",
        message: "Please verify your email before making calls",
      });
    }

    if (!venter.phone) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Phone number required",
        message: "Please add a phone number to your profile",
      });
    }

    // Check if listener exists and is available
    const listenerResult = await client.query(
      "SELECT id, user_type, phone, is_verified, is_active FROM users WHERE id = $1",
      [listenerId],
    );

    if (listenerResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Listener not found",
        message: "The selected listener was not found",
      });
    }

    const listener = listenerResult.rows[0];

    if (listener.user_type !== "listener") {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid listener",
        message: "Selected user is not a listener",
      });
    }

    if (!listener.is_active || !listener.is_verified) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Listener unavailable",
        message: "The selected listener is currently unavailable",
      });
    }

    if (!listener.phone) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Listener phone required",
        message: "Listener has not configured a phone number",
      });
    }

    // Check eligibility: subscription first, then prepaid wallet
    const eligibility = await canMakeCall(venterId);

    if (!eligibility.allowed) {
      await client.query("ROLLBACK");
      return res.status(402).json({
        error: "Insufficient balance",
        message: `You don't have an active subscription or sufficient prepaid balance. You need at least ${MIN_BALANCE_MINUTES} minutes to start a call.`,
        requiredMinutes: MIN_BALANCE_MINUTES,
        suggestion: "Subscribe to a plan or add prepaid minutes to your wallet",
      });
    }

    // For prepaid users only: enforce minimum balance and payment method
    if (eligibility.source === "prepaid") {
      if (eligibility.remainingMinutes < MIN_BALANCE_MINUTES) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "Insufficient balance",
          message: `You need at least ${MIN_BALANCE_MINUTES} minutes to start a call. Current balance: ${eligibility.remainingMinutes.toFixed(2)} minutes`,
          requiredMinutes: MIN_BALANCE_MINUTES,
          currentBalance: eligibility.remainingMinutes,
        });
      }

      const walletResult = await client.query(
        "SELECT default_payment_method FROM user_wallets WHERE user_id = $1",
        [venterId],
      );

      if (
        walletResult.rows.length === 0 ||
        !walletResult.rows[0].default_payment_method
      ) {
        await client.query("ROLLBACK");
        return res.status(402).json({
          error: "No payment method",
          message:
            "Please add a payment method to your wallet before starting a call",
        });
      }
    }

    // Check grace period rate limit
    const gracePeriodConfig = getGracePeriodConfig();
    if (gracePeriodConfig.enabled) {
      const rateLimitCheck = await checkGracePeriodRateLimit(venterId, client);
      if (!rateLimitCheck.allowed) {
        await client.query("ROLLBACK");
        return res.status(429).json({
          error: "Rate limit exceeded",
          message: `Grace period rate limit reached. Please wait ${Math.ceil(rateLimitCheck.waitSeconds / 60)} minutes before starting another call.`,
          waitSeconds: rateLimitCheck.waitSeconds,
        });
      }
    }

    // Check for existing active sessions
    const activeSessionResult = await client.query(
      "SELECT id FROM sessions WHERE venter_id = $1 AND status IN ('pending', 'accepted', 'active') LIMIT 1",
      [venterId],
    );

    if (activeSessionResult.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Active session exists",
        message: "You already have an active call session",
      });
    }

    // Create new session
    const estimatedCost = SESSION_RATE_PER_MINUTE * MIN_BALANCE_MINUTES;

    // Get surge pricing information
    const surgeInfo = await getSurgeMultiplier(venterId, client);
    const effectiveRate = SESSION_RATE_PER_MINUTE * surgeInfo.multiplier;

    const sessionResult = await client.query(
      `INSERT INTO sessions (venter_id, listener_id, status, rate_per_minute, estimated_cost, metadata)
       VALUES ($1, $2, 'pending', $3, $4, $5)
       RETURNING id, venter_id, listener_id, status, rate_per_minute, estimated_cost, created_at`,
      [
        venterId,
        listenerId,
        SESSION_RATE_PER_MINUTE,
        estimatedCost,
        JSON.stringify({
          venterPhone: venter.phone,
          listenerPhone: listener.phone,
        }),
      ],
    );

    const session = sessionResult.rows[0];

    // Store session in Redis
    await redisClient.setEx(
      `${REDIS_SESSION_PREFIX}${session.id}`,
      REDIS_SESSION_TTL,
      JSON.stringify({
        id: session.id,
        venterId: session.venter_id,
        listenerId: session.listener_id,
        status: session.status,
        createdAt: session.created_at,
      }),
    );

    await client.query("COMMIT");

    logger.info(
      `Session created: ${session.id} (Venter: ${venterId}, Listener: ${listenerId})`,
    );

    res.status(201).json({
      message: "Call session created successfully",
      session: {
        id: session.id,
        venterId: session.venter_id,
        listenerId: session.listener_id,
        status: session.status,
        ratePerMinute: parseFloat(session.rate_per_minute),
        surgeInfo: getSurgeExplanation(surgeInfo),
        effectiveRate: effectiveRate,
        estimatedCost: parseFloat(session.estimated_cost),
        createdAt: session.created_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Create session error: ${error.message}`, { error });
    res.status(500).json({
      error: "Session creation failed",
      message: "An error occurred while creating the session",
    });
  } finally {
    client.release();
  }
}

/**
 * Accept a call session (listener accepts)
 */
async function acceptSession(req, res) {
  const client = await pool.connect();

  try {
    const { sessionId } = req.params;
    const listenerId = req.user.id; // From auth middleware

    await client.query("BEGIN");

    // Get session details
    const sessionResult = await client.query(
      `SELECT s.*, u1.phone as venter_phone, u2.phone as listener_phone
       FROM sessions s
       JOIN users u1 ON s.venter_id = u1.id
       JOIN users u2 ON s.listener_id = u2.id
       WHERE s.id = $1`,
      [sessionId],
    );

    if (sessionResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Session not found",
        message: "The requested session was not found",
      });
    }

    const session = sessionResult.rows[0];

    // Verify listener is authorized
    if (session.listener_id !== listenerId) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Unauthorized",
        message: "You are not authorized to accept this session",
      });
    }

    // Check session status
    if (session.status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid session status",
        message: `Session cannot be accepted. Current status: ${session.status}`,
      });
    }

    // Update session status to accepted
    await client.query(
      "UPDATE sessions SET status = 'accepted', accepted_at = CURRENT_TIMESTAMP WHERE id = $1",
      [sessionId],
    );

    // Initiate Twilio conference call
    const statusCallback = buildPublicUrl(
      getCanonicalPublicBaseUrl() ||
        `http://localhost:${process.env.PORT || 3000}`,
      `/api/v1/webhooks/twilio/call-status/${sessionId}`,
    );

    let twilioCall;
    try {
      twilioCall = await initiateConferenceCall({
        venterNumber: session.venter_phone,
        listenerNumber: session.listener_phone,
        sessionId: sessionId,
        statusCallback: statusCallback,
      });

      // Update session with Twilio call SID
      await client.query(
        "UPDATE sessions SET twilio_call_sid = $1, status = 'active', started_at = CURRENT_TIMESTAMP WHERE id = $2",
        [twilioCall.venterCallSid, sessionId],
      );

      logger.info(`Session accepted and call initiated: ${sessionId}`);
    } catch (twilioError) {
      logger.error(
        `Twilio call failed for session ${sessionId}: ${twilioError.message}`,
      );
      // Update session to failed
      await client.query(
        "UPDATE sessions SET status = 'failed' WHERE id = $1",
        [sessionId],
      );
      await client.query("COMMIT");

      return res.status(500).json({
        error: "Call initiation failed",
        message: "Failed to initiate call with Twilio",
      });
    }

    // Update Redis
    await redisClient.setEx(
      `${REDIS_SESSION_PREFIX}${sessionId}`,
      REDIS_SESSION_TTL,
      JSON.stringify({
        id: sessionId,
        venterId: session.venter_id,
        listenerId: session.listener_id,
        status: "active",
        twilioCallSid: twilioCall.venterCallSid,
        startedAt: new Date().toISOString(),
      }),
    );

    await client.query("COMMIT");

    res.json({
      message: "Session accepted and call initiated",
      session: {
        id: sessionId,
        status: "active",
        twilioCallSid: twilioCall.venterCallSid,
        startedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Accept session error: ${error.message}`, { error });
    res.status(500).json({
      error: "Session acceptance failed",
      message: "An error occurred while accepting the session",
    });
  } finally {
    client.release();
  }
}

/**
 * End a call session
 */
async function endSession(req, res) {
  const client = await pool.connect();

  try {
    const { sessionId } = req.params;
    const userId = req.user.id; // From auth middleware

    // Stop balance monitoring for this session
    try {
      await stopBalanceMonitoring(sessionId);
      logger.info(`Balance monitoring stopped for session ${sessionId}`);
    } catch (monitorError) {
      logger.error(
        `Error stopping balance monitoring for session ${sessionId}:`,
        monitorError,
      );
      // Non-fatal, continue with session end
    }

    await client.query("BEGIN");

    // Get session details
    const sessionResult = await client.query(
      "SELECT * FROM sessions WHERE id = $1",
      [sessionId],
    );

    if (sessionResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Session not found",
        message: "The requested session was not found",
      });
    }

    const session = sessionResult.rows[0];

    // Verify user is authorized (either venter or listener)
    if (session.venter_id !== userId && session.listener_id !== userId) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Unauthorized",
        message: "You are not authorized to end this session",
      });
    }

    // Check if session can be ended
    if (!["pending", "accepted", "active"].includes(session.status)) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Invalid session status",
        message: `Session cannot be ended. Current status: ${session.status}`,
      });
    }

    let callDuration = 0;
    let finalCost = 0;
    let gracePeriodSeconds = 0;
    let gracePeriodApplied = false;
    let surgeInfo = { multiplier: 1.0, ruleId: null, surgeApplied: false };
    let surgeCost = { baseCost: 0, finalCost: 0 };

    // If call was active, end it on Twilio and get duration
    if (session.twilio_call_sid && session.status === "active") {
      try {
        await endCall(session.twilio_call_sid);

        // Wait a moment for Twilio to update
        await new Promise((resolve) => setTimeout(resolve, 2000));

        const callDetails = await getCallDetails(session.twilio_call_sid);
        callDuration = callDetails.duration || 0;

        // Apply grace period
        const gracePeriodConfig = getGracePeriodConfig();
        const gracePeriodSecs = gracePeriodConfig.enabled
          ? gracePeriodConfig.seconds
          : 0;
        const billingResult = calculateBillableDuration(
          callDuration,
          gracePeriodSecs,
        );

        gracePeriodSeconds = billingResult.gracePeriodSeconds;
        gracePeriodApplied = billingResult.gracePeriodApplied;

        // Calculate cost using billable duration with surge pricing
        const billableMinutes = billingResult.billableMinutes;
        const baseRate = parseFloat(session.rate_per_minute);

        // Get surge pricing
        const surgeInfo = await getSurgeMultiplier(session.venter_id, client);
        const surgeCost = calculateSurgeCost(
          baseRate,
          billableMinutes,
          surgeInfo.multiplier,
        );
        finalCost = surgeCost.finalCost;

        logger.info(
          `Call ended. Duration: ${callDuration}s, Grace: ${gracePeriodSeconds}s, Billable: ${billingResult.billableSeconds}s, Base Cost: $${surgeCost.baseCost.toFixed(4)}, Surge: ${surgeInfo.multiplier}x, Final Cost: $${finalCost.toFixed(4)}`,
        );
      } catch (twilioError) {
        logger.error(`Twilio end call error: ${twilioError.message}`);
        // Continue with session end even if Twilio fails
      }
    }

    // Update session with grace period and surge info
    await client.query(
      `UPDATE sessions 
       SET status = 'ended', ended_at = CURRENT_TIMESTAMP, duration_seconds = $1, final_cost = $2,
           grace_period_seconds = $3, grace_period_applied = $4,
           surge_multiplier = $5, surge_rule_id = $6
       WHERE id = $7`,
      [
        callDuration,
        finalCost,
        gracePeriodSeconds,
        gracePeriodApplied,
        surgeInfo.multiplier,
        surgeInfo.ruleId,
        sessionId,
      ],
    );

    // Deduct cost from venter's wallet
    if (finalCost > 0) {
      // Record grace period usage for rate limiting
      if (gracePeriodApplied) {
        await recordGracePeriodUsage(session.venter_id, client);
      }

      const costInMinutes = finalCost / parseFloat(session.rate_per_minute);
      await client.query(
        `UPDATE user_wallets 
         SET balance_minutes = balance_minutes - $1
         WHERE user_id = $2`,
        [costInMinutes, session.venter_id],
      );

      // Log transaction in call_costs
      const callLogResult = await client.query(
        `INSERT INTO call_logs (user_id, listener_id, twilio_call_sid, duration_seconds, status, started_at, ended_at)
         VALUES ($1, $2, $3, $4, 'completed', $5, CURRENT_TIMESTAMP)
         RETURNING id`,
        [
          session.venter_id,
          session.listener_id,
          session.twilio_call_sid,
          callDuration,
          session.started_at,
        ],
      );

      // Format transaction description with grace period and surge info
      const baseDesc = formatTransactionDescription(
        `Session ${sessionId.substring(0, 8)}`,
        Math.ceil(callDuration / 60),
        Math.ceil(gracePeriodSeconds / 60),
        Math.ceil(costInMinutes),
      );

      const transactionDesc = formatSurgeDescription(
        baseDesc,
        surgeInfo,
        surgeCost,
      );

      await client.query(
        `INSERT INTO call_costs (call_log_id, user_id, duration_seconds, cost_per_minute, total_cost, charged_from)
         VALUES ($1, $2, $3, $4, $5, 'prepaid')`,
        [
          callLogResult.rows[0].id,
          session.venter_id,
          callDuration,
          session.rate_per_minute,
          finalCost,
        ],
      );
    }

    // Remove from Redis
    await redisClient.del(`${REDIS_SESSION_PREFIX}${sessionId}`);

    await client.query("COMMIT");

    // Send session-ended email to venter (fire-and-forget, only for completed calls)
    if (callDuration > 0) {
      try {
        const venterRow = await pool.query(
          "SELECT email, first_name FROM users WHERE id = $1",
          [session.venter_id],
        );
        if (venterRow.rows.length > 0) {
          const { email: vEmail, first_name: vName } = venterRow.rows[0];
          const sessionDate = new Date().toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
          });
          sendCallDropEmail(vEmail, vName, callDuration, sessionDate).catch(
            (err) =>
              logger.error(`Failed to send call-drop email: ${err.message}`),
          );
        }
      } catch (_) {}
    }

    logger.info(
      `Session ended: ${sessionId} (Duration: ${callDuration}s, Cost: $${finalCost.toFixed(4)})`,
    );

    res.json({
      message: "Session ended successfully",
      session: {
        id: sessionId,
        status: "ended",
        durationSeconds: callDuration,
        finalCost: parseFloat(finalCost.toFixed(4)),
        endedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`End session error: ${error.message}`, { error });
    res.status(500).json({
      error: "Session end failed",
      message: "An error occurred while ending the session",
    });
  } finally {
    client.release();
  }
}

/**
 * Get session details
 */
async function getSession(req, res) {
  try {
    const { sessionId } = req.params;
    const userId = req.user.id;

    // Try Redis first
    const cachedSession = await redisClient.get(
      `${REDIS_SESSION_PREFIX}${sessionId}`,
    );

    if (cachedSession) {
      const session = JSON.parse(cachedSession);

      // Verify user is authorized
      if (session.venterId !== userId && session.listenerId !== userId) {
        return res.status(403).json({
          error: "Unauthorized",
          message: "You are not authorized to view this session",
        });
      }

      return res.json({ session });
    }

    // If not in Redis, get from database
    const result = await pool.query("SELECT * FROM sessions WHERE id = $1", [
      sessionId,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Session not found",
        message: "The requested session was not found",
      });
    }

    const session = result.rows[0];

    // Verify user is authorized
    if (session.venter_id !== userId && session.listener_id !== userId) {
      return res.status(403).json({
        error: "Unauthorized",
        message: "You are not authorized to view this session",
      });
    }

    res.json({
      session: {
        id: session.id,
        venterId: session.venter_id,
        listenerId: session.listener_id,
        status: session.status,
        twilioCallSid: session.twilio_call_sid,
        durationSeconds: session.duration_seconds,
        ratePerMinute: parseFloat(session.rate_per_minute),
        estimatedCost: session.estimated_cost
          ? parseFloat(session.estimated_cost)
          : null,
        finalCost: session.final_cost ? parseFloat(session.final_cost) : null,
        createdAt: session.created_at,
        acceptedAt: session.accepted_at,
        startedAt: session.started_at,
        endedAt: session.ended_at,
      },
    });
  } catch (error) {
    logger.error(`Get session error: ${error.message}`, { error });
    res.status(500).json({
      error: "Failed to fetch session",
      message: "An error occurred while fetching the session",
    });
  }
}

/**
 * Get user's active sessions
 */
async function getActiveSessions(req, res) {
  try {
    const userId = req.user.id;

    const [callsResult, chatsResult] = await Promise.all([
      pool.query(
        `SELECT vc.id,
                vc.venter_id,
                vc.listener_id,
                vc.status,
                vc.rate_per_minute,
                vc.created_at,
                vc.started_at,
                u1.email AS venter_email,
                u2.email AS listener_email
         FROM voice_calls vc
         JOIN users u1 ON vc.venter_id = u1.id
         JOIN users u2 ON vc.listener_id = u2.id
         WHERE (vc.venter_id = $1 OR vc.listener_id = $1)
           AND vc.status = ANY($2::text[])
           AND vc.ended_at IS NULL
         ORDER BY vc.created_at DESC`,
        [userId, ACTIVE_CALL_STATUSES],
      ),
      pool.query(
        `SELECT c.id,
                c.venter_id,
                c.listener_id,
                c.status,
                c.rate_per_minute,
                c.created_at,
                c.started_at,
                u1.email AS venter_email,
                u2.email AS listener_email
         FROM conversations c
         JOIN users u1 ON c.venter_id = u1.id
         JOIN users u2 ON c.listener_id = u2.id
         WHERE (c.venter_id = $1 OR c.listener_id = $1)
           AND c.status = ANY($2::text[])
           AND c.ended_at IS NULL
         ORDER BY c.created_at DESC`,
        [userId, ACTIVE_CHAT_STATUSES],
      ),
    ]);

    const sessions = [
      ...callsResult.rows.map((session) => ({
        id: session.id,
        type: "call",
        source: "voice_calls",
        venterId: session.venter_id,
        venterEmail: session.venter_email,
        listenerId: session.listener_id,
        listenerEmail: session.listener_email,
        status: session.status,
        ratePerMinute: parseFloat(session.rate_per_minute),
        createdAt: session.created_at,
        startedAt: session.started_at,
      })),
      ...chatsResult.rows.map((session) => ({
        id: session.id,
        type: "chat",
        source: "conversations",
        venterId: session.venter_id,
        venterEmail: session.venter_email,
        listenerId: session.listener_id,
        listenerEmail: session.listener_email,
        status: session.status,
        ratePerMinute: parseFloat(session.rate_per_minute),
        createdAt: session.created_at,
        startedAt: session.started_at,
      })),
    ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    res.json({
      sessions,
      count: sessions.length,
    });
  } catch (error) {
    logger.error(`Get active sessions error: ${error.message}`, { error });
    res.status(500).json({
      error: "Failed to fetch sessions",
      message: "An error occurred while fetching active sessions",
    });
  }
}

module.exports = {
  createSession,
  acceptSession,
  endSession,
  getSession,
  getActiveSessions,
};
