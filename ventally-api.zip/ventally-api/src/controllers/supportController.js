const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const { sanitizeInput } = require("../utils/validation");
const s3Service = require("../services/s3");

async function submitAppeal(req, res) {
  try {
    const userId = req.user.id;
    const { reason, description, attachments } = req.body;

    if (!reason || typeof reason !== "string") {
      return res.status(400).json({
        error: "Validation error",
        message: "reason is required",
      });
    }

    if (description !== undefined && typeof description !== "string") {
      return res.status(400).json({
        error: "Validation error",
        message: "description must be a string",
      });
    }

    const normalizedAttachments = attachments ?? [];
    if (!Array.isArray(normalizedAttachments)) {
      return res.status(400).json({
        error: "Validation error",
        message: "attachments must be an array",
      });
    }

    const hasInvalidAttachment = normalizedAttachments.some(
      (item) => typeof item !== "string",
    );

    if (hasInvalidAttachment) {
      return res.status(400).json({
        error: "Validation error",
        message: "attachments must contain string values",
      });
    }

    const cleanReason = sanitizeInput(reason);
    const cleanDescription = description ? sanitizeInput(description) : null;

    const result = await pool.query(
      `INSERT INTO user_appeals (user_id, reason, description, attachments)
       VALUES ($1, $2, $3, $4::jsonb)
       RETURNING id, reason, description, attachments, status, created_at`,
      [
        userId,
        cleanReason,
        cleanDescription,
        JSON.stringify(normalizedAttachments),
      ],
    );

    res.status(201).json({
      success: true,
      appeal: {
        id: result.rows[0].id,
        reason: result.rows[0].reason,
        description: result.rows[0].description,
        attachments: result.rows[0].attachments || [],
        status: result.rows[0].status,
        createdAt: result.rows[0].created_at,
      },
    });
  } catch (error) {
    logger.error("Error submitting appeal", { error: error.message });
    res.status(500).json({
      error: "Server error",
      message: "Failed to submit appeal",
    });
  }
}

async function submitFeedback(req, res) {
  try {
    const userId = req.user.id;
    const { rating, comment } = req.body;

    if (typeof rating !== "number" || Number.isNaN(rating)) {
      return res.status(400).json({
        error: "Validation error",
        message: "rating must be a number",
      });
    }

    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({
        error: "Validation error",
        message: "rating must be an integer between 1 and 5",
      });
    }

    if (comment !== undefined && typeof comment !== "string") {
      return res.status(400).json({
        error: "Validation error",
        message: "comment must be a string",
      });
    }

    const cleanComment = comment ? sanitizeInput(comment) : null;

    const result = await pool.query(
      `INSERT INTO user_feedback (user_id, rating, comment)
       VALUES ($1, $2, $3)
       RETURNING id, rating, comment, created_at`,
      [userId, rating, cleanComment],
    );

    res.status(201).json({
      success: true,
      feedback: {
        id: result.rows[0].id,
        rating: result.rows[0].rating,
        comment: result.rows[0].comment,
        createdAt: result.rows[0].created_at,
      },
    });
  } catch (error) {
    logger.error("Error submitting feedback", { error: error.message });
    res.status(500).json({
      error: "Server error",
      message: "Failed to submit feedback",
    });
  }
}

async function submitListenerAppeal(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { contact, reportId, summary } = req.body;
    const file = req.file;

    if (!contact || typeof contact !== "string") {
      return res.status(400).json({
        error: "Validation error",
        message: "contact is required",
      });
    }

    if (!reportId || typeof reportId !== "string") {
      return res.status(400).json({
        error: "Validation error",
        message: "reportId is required",
      });
    }

    if (!summary || typeof summary !== "string") {
      return res.status(400).json({
        error: "Validation error",
        message: "summary is required",
      });
    }

    if (!file) {
      return res.status(400).json({
        error: "Validation error",
        message: "document is required",
      });
    }

    const cleanContact = sanitizeInput(contact);
    const cleanReportId = sanitizeInput(reportId);
    const cleanSummary = sanitizeInput(summary);

    await client.query("BEGIN");

    const uploadResult = await s3Service.uploadListenerAppealDocument(
      file.buffer,
      file.originalname,
      userId,
      file.mimetype,
    );

    const result = await client.query(
      `INSERT INTO user_appeals (
         user_id,
         reason,
         description,
         attachments,
         contact_info,
         report_id,
         summary,
         document_url,
         document_s3_key,
         document_original_file_name,
         document_mime_type,
         document_size_bytes
       )
       VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING id, status, created_at, contact_info, report_id, summary, document_url`,
      [
        userId,
        "role_appeal",
        cleanSummary,
        JSON.stringify([uploadResult.url]),
        cleanContact,
        cleanReportId,
        cleanSummary,
        uploadResult.url,
        uploadResult.key,
        file.originalname,
        file.mimetype,
        file.size,
      ],
    );

    await client.query("COMMIT");

    res.status(201).json({
      success: true,
      appeal: {
        id: result.rows[0].id,
        status: result.rows[0].status,
        contact: result.rows[0].contact_info,
        reportId: result.rows[0].report_id,
        summary: result.rows[0].summary,
        documentUrl: result.rows[0].document_url,
        createdAt: result.rows[0].created_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error submitting role appeal", { error: error.message });
    res.status(500).json({
      error: "Server error",
      message: "Failed to submit appeal",
    });
  } finally {
    client.release();
  }
}

module.exports = {
  submitAppeal,
  submitFeedback,
  submitListenerAppeal,
};
