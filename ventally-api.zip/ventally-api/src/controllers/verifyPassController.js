const { pool } = require("../database/connection");
const logger = require("../utils/logger");

// VerifyPass configuration
const VERIFYPASS_API_KEY = process.env.VERIFYPASS_API_KEY;
const COMMUNITY_DISCOUNT_PCT = 20; // 20% off for verified community members

// The VerifyPass verification URL — user opens this in the WebView to verify
const VERIFYPASS_VERIFY_URL = "https://verifypass.com/auth/1c6225a415";

// Map VerifyPass community group names to our internal types
const COMMUNITY_TYPE_MAP = {
  student: "student_teacher",
  teacher: "student_teacher",
  educator: "student_teacher",
  faculty: "student_teacher",
  military: "military_veteran",
  veteran: "military_veteran",
  "first responder": "military_veteran",
  "first_responder": "military_veteran",
  firefighter: "military_veteran",
  police: "military_veteran",
  healthcare: "healthcare_nonprofit",
  nurse: "healthcare_nonprofit",
  doctor: "healthcare_nonprofit",
  nonprofit: "healthcare_nonprofit",
  "non-profit": "healthcare_nonprofit",
};

/**
 * GET /api/v1/verify-pass/status
 * Returns current user's community verification status
 */
async function getStatus(req, res) {
  const userId = req.user.id;
  const client = await pool.connect();
  try {
    const result = await client.query(
      "SELECT is_community_verified, community_type, community_verified_at FROM users WHERE id = $1",
      [userId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }
    const user = result.rows[0];
    res.json({
      data: {
        isVerified: user.is_community_verified || false,
        communityType: user.community_type || null,
        verifiedAt: user.community_verified_at || null,
        discountPct: user.is_community_verified ? COMMUNITY_DISCOUNT_PCT : 0,
        verifyUrl: buildVerifyUrl(userId),
      },
    });
  } catch (err) {
    logger.error("Error fetching VerifyPass status:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
}

/**
 * GET /api/v1/verify-pass/url
 * Returns the VerifyPass verification URL for the current user to open in WebView
 */
async function getVerifyUrl(req, res) {
  try {
    res.json({ data: { url: VERIFYPASS_VERIFY_URL } });
  } catch (err) {
    logger.error("Error generating VerifyPass URL:", err);
    res.status(500).json({ error: "Internal server error" });
  }
}

/**
 * POST /api/v1/verify-pass/webhook
 * Called by VerifyPass when a user completes verification.
 * VerifyPass sends the verified user's email and community group.
 * We match by email to find the Ventally user and mark them verified.
 *
 * Expected payload (VerifyPass webhook format):
 * { email, group, status, first_name, last_name, ... }
 */
async function handleWebhook(req, res) {
  // Respond 200 immediately so VerifyPass doesn't retry
  res.json({ received: true });

  const { email, group, status } = req.body;

  if (!email) {
    logger.warn("VerifyPass webhook received with no email:", req.body);
    return;
  }

  if (status && status !== "verified" && status !== "approved") {
    logger.info(`VerifyPass webhook: non-verified status "${status}" for ${email} — skipping`);
    return;
  }

  const communityType = resolveCommunityType(group);
  const client = await pool.connect();
  try {
    const result = await client.query(
      `UPDATE users
       SET is_community_verified = true,
           community_type        = $1,
           community_verified_at = NOW()
       WHERE LOWER(email) = LOWER($2)
       RETURNING id`,
      [communityType, email]
    );

    if (result.rowCount === 0) {
      logger.warn(`VerifyPass webhook: no Ventally user found for email ${email}`);
    } else {
      logger.info(
        `VerifyPass webhook: verified user ${result.rows[0].id} (${email}), type=${communityType}`
      );
    }
  } catch (err) {
    logger.error("Error processing VerifyPass webhook:", err);
  } finally {
    client.release();
  }
}

/**
 * POST /api/v1/verify-pass/callback
 * Legacy redirect callback — kept for backward compatibility.
 * Redirects user back to a success page if hit directly.
 */
async function handleCallback(req, res) {
  // VerifyPass may redirect the browser here after verification.
  // The webhook (handleWebhook) does the actual data update.
  // Just return 200 so the WebView detects the URL and closes.
  res.status(200).send("Verification complete. You may close this window.");
}

/**
 * POST /api/v1/verify-pass/verify (mobile deep-link return)
 * Called from the mobile app after the WebView completes
 * Body: { token }
 */
async function verifyFromMobile(req, res) {
  const userId = req.user.id;
  const { token } = req.body;

  if (!token) {
    return res.status(400).json({ error: "Missing verification token" });
  }

  // Verify token with VerifyPass API and get community group
  const result = await verifyTokenWithApi(token, true);
  if (!result || !result.valid) {
    return res.status(401).json({ error: "Invalid or expired verification token" });
  }

  const communityType = resolveCommunityType(result.communityGroup);
  const client = await pool.connect();
  try {
    await client.query(
      `UPDATE users
       SET is_community_verified = true,
           community_type = $1,
           community_verified_at = NOW(),
           verifypass_token = $2
       WHERE id = $3`,
      [communityType, token, userId]
    );
    logger.info(`VerifyPass mobile verify: user=${userId}, type=${communityType}`);
    res.json({
      success: true,
      data: {
        isVerified: true,
        communityType,
        discountPct: COMMUNITY_DISCOUNT_PCT,
      },
    });
  } catch (err) {
    logger.error("Error saving mobile VerifyPass verification:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function resolveCommunityType(communityGroup) {
  if (!communityGroup) return "other";
  const key = communityGroup.toLowerCase().trim();
  return COMMUNITY_TYPE_MAP[key] || "other";
}

module.exports = { getStatus, getVerifyUrl, handleWebhook, handleCallback, verifyFromMobile };
