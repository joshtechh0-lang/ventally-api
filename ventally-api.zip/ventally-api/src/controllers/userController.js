/**
 * User Controller
 * Handles user account management including role switching
 */

const { pool } = require("../database/connection");
const { redisClient } = require("../services/redis");
const { generateAccessToken, generateRefreshToken } = require("../utils/jwt");
const {
  hasActiveSession,
  isListenerOnline,
} = require("../utils/sessionHelper");
const { isValidUserType } = require("../utils/validation");

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Switch user's active role
 * POST /users/switch-role
 */
async function switchRole(req, res) {
  try {
    const { targetRole } = req.body;
    const userId = req.user.id;

    // Validate target role
    if (!targetRole || !isValidUserType(targetRole)) {
      return res.status(400).json({
        error: "Invalid role",
        message: "Please provide a valid target role",
      });
    }

    if (["admin", "sub_admin"].includes(targetRole)) {
      return res.status(403).json({
        error: "Forbidden",
        message: "Cannot switch to privileged roles via this endpoint",
      });
    }

    // Get current user data
    const userResult = await pool.query(
      `SELECT id, email, user_type, available_roles, active_role 
       FROM users WHERE id = $1`,
      [userId],
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
      });
    }

    const user = userResult.rows[0];
    const availableRoles = user.available_roles || [user.user_type];
    const currentRole = user.active_role || user.user_type;

    // Check if user already has this active role
    if (currentRole === targetRole) {
      return res.status(200).json({
        message: "Already using this role",
        user: {
          id: user.id,
          email: user.email,
          activeRole: currentRole,
          availableRoles: availableRoles,
          userType: currentRole, // Backward compatibility
        },
      });
    }

    // Check if target role is in available roles
    if (!availableRoles.includes(targetRole)) {
      return res.status(403).json({
        error: "Role not available",
        message: `You don't have access to the ${targetRole} role. Available roles: ${availableRoles.join(", ")}`,
      });
    }

    // Check for active sessions
    let sessionCheck = await hasActiveSession(userId);

    // A short re-check avoids false 409 responses during end-session commit races.
    if (sessionCheck.hasSession) {
      await delay(400);
      sessionCheck = await hasActiveSession(userId);
    }

    if (sessionCheck.hasSession) {
      console.warn("Role switch blocked by active session", {
        userId,
        targetRole,
        activeSession: sessionCheck,
      });

      return res.status(409).json({
        error: "Active session",
        message: `Cannot switch roles while you have an active ${sessionCheck.sessionType}. Please end your current session first.`,
        activeSession: {
          type: sessionCheck.sessionType,
          id: sessionCheck.sessionId,
          status: sessionCheck.status,
        },
      });
    }

    // If switching FROM listener role, check if online and set offline
    if (currentRole === "listener") {
      const online = await isListenerOnline(userId);
      if (online) {
        // Set listener offline
        await pool.query(
          `UPDATE listener_profiles 
           SET is_online = false, last_online_at = NOW() 
           WHERE listener_id = $1`,
          [userId],
        );

        // Remove from Redis online listeners
        await redisClient.sRem("online_listeners", userId);

        console.log(
          `User ${userId} auto-set offline due to role switch from listener`,
        );
      }
    }

    // Update active_role and user_type (keep them in sync)
    await pool.query(
      `UPDATE users 
       SET active_role = $1, user_type = $1, updated_at = NOW() 
       WHERE id = $2`,
      [targetRole, userId],
    );

    // Invalidate old refresh token
    await redisClient.del(`refresh_token:${userId}`);

    // Generate new tokens with updated role
    const accessToken = generateAccessToken(
      userId,
      targetRole,
      availableRoles,
      targetRole,
    );
    const refreshToken = generateRefreshToken(userId);

    // Store new refresh token in Redis (30 days)
    await redisClient.setEx(
      `refresh_token:${userId}`,
      30 * 24 * 60 * 60,
      refreshToken,
    );

    // Log role switch for audit
    console.log(
      `User ${userId} switched role from ${currentRole} to ${targetRole}`,
    );

    // Emit socket event to notify user's connected clients (if socket.io is available)
    const io = req.app.get("io");
    if (io) {
      io.to(userId).emit("role-switched", {
        newRole: targetRole,
        availableRoles: availableRoles,
        message: `You are now in ${targetRole} mode`,
      });
    }

    return res.status(200).json({
      message: `Successfully switched to ${targetRole} role`,
      tokens: {
        accessToken,
        refreshToken,
      },
      user: {
        id: user.id,
        email: user.email,
        activeRole: targetRole,
        availableRoles: availableRoles,
        userType: targetRole, // Backward compatibility
      },
    });
  } catch (error) {
    console.error("Error switching role:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to switch role",
    });
  }
}

/**
 * Get current user's available roles and active role
 * GET /users/roles
 */
async function getUserRoles(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT available_roles, active_role, user_type 
       FROM users WHERE id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
      });
    }

    const user = result.rows[0];

    return res.status(200).json({
      availableRoles: user.available_roles || [user.user_type],
      activeRole: user.active_role || user.user_type,
      userType: user.user_type, // Backward compatibility
    });
  } catch (error) {
    console.error("Error getting user roles:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to get user roles",
    });
  }
}

/**
 * Update user's available roles
 * PUT /users/available-roles
 * Allows users to add or remove roles from their available roles
 */
async function updateAvailableRoles(req, res) {
  try {
    const { rolesToAdd = [], rolesToRemove = [] } = req.body;
    const userId = req.user.id;

    // Get current user data
    const userResult = await pool.query(
      `SELECT available_roles, active_role, user_type 
       FROM users WHERE id = $1`,
      [userId],
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
      });
    }

    const user = userResult.rows[0];
    let availableRoles = user.available_roles || [user.user_type];
    const activeRole = user.active_role || user.user_type;

    // Validate roles to add
    for (const role of rolesToAdd) {
      if (!isValidUserType(role)) {
        return res.status(400).json({
          error: "Invalid role",
          message: `${role} is not a valid role`,
        });
      }

      if (["admin", "sub_admin"].includes(role)) {
        return res.status(403).json({
          error: "Forbidden",
          message: "Cannot add privileged roles via this endpoint",
        });
      }

      // Add role if not already present
      if (!availableRoles.includes(role)) {
        availableRoles.push(role);
      }
    }

    // Validate roles to remove
    for (const role of rolesToRemove) {
      // Cannot remove currently active role
      if (role === activeRole) {
        return res.status(400).json({
          error: "Invalid operation",
          message:
            "Cannot remove your currently active role. Please switch roles first.",
        });
      }

      // Remove role
      availableRoles = availableRoles.filter((r) => r !== role);
    }

    // Must have at least one role
    if (availableRoles.length === 0) {
      return res.status(400).json({
        error: "Invalid operation",
        message: "User must have at least one available role",
      });
    }

    // Update database
    await pool.query(
      `UPDATE users 
       SET available_roles = $1, updated_at = NOW() 
       WHERE id = $2`,
      [availableRoles, userId],
    );

    // Generate new tokens with updated available roles
    const accessToken = generateAccessToken(
      userId,
      activeRole,
      availableRoles,
      activeRole,
    );
    const refreshToken = generateRefreshToken(userId);

    // Store new refresh token in Redis
    await redisClient.setEx(
      `refresh_token:${userId}`,
      30 * 24 * 60 * 60,
      refreshToken,
    );

    console.log(`User ${userId} updated available roles:`, availableRoles);

    return res.status(200).json({
      message: "Available roles updated successfully",
      tokens: {
        accessToken,
        refreshToken,
      },
      user: {
        availableRoles,
        activeRole,
      },
    });
  } catch (error) {
    console.error("Error updating available roles:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to update available roles",
    });
  }
}

module.exports = {
  switchRole,
  getUserRoles,
  updateAvailableRoles,
};
