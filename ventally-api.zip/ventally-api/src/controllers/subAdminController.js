const bcrypt = require("bcrypt");
const { pool } = require("../database/connection");
const { isValidEmail, isValidPassword } = require("../utils/validation");

const SALT_ROUNDS = 10;
const ALLOWED_PERMISSION_KEYS = [
  "view",
  "edit",
  "delete",
  "suspend",
  "accessAdminPanel",
];
const ALLOWED_STATUSES = ["pending", "active", "suspended"];

function normalizePermissions(input = {}) {
  const permissions = {};
  for (const key of ALLOWED_PERMISSION_KEYS) {
    permissions[key] = Boolean(input[key]);
  }
  return permissions;
}

function mergePermissions(currentPermissions = {}, updates = {}) {
  const normalizedCurrent = normalizePermissions(currentPermissions);

  for (const key of Object.keys(updates)) {
    normalizedCurrent[key] = Boolean(updates[key]);
  }

  return normalizedCurrent;
}

function validatePermissionPayload(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return {
      valid: false,
      message: "permissions must be an object",
    };
  }

  const incomingKeys = Object.keys(input);
  const invalidKeys = incomingKeys.filter(
    (key) => !ALLOWED_PERMISSION_KEYS.includes(key),
  );

  if (invalidKeys.length > 0) {
    return {
      valid: false,
      message: `Invalid permission keys: ${invalidKeys.join(", ")}`,
    };
  }

  return { valid: true };
}

function mapSubAdminRow(row) {
  return {
    id: row.id,
    email: row.email,
    phone: row.phone,
    userType: row.user_type,
    activeRole: row.active_role,
    availableRoles: row.available_roles,
    isVerified: row.is_verified,
    isActive: row.is_active,
    status: row.sub_admin_status,
    permissions: row.sub_admin_permissions,
    createdBy: row.created_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function listSubAdmins(req, res) {
  try {
    const result = await pool.query(
      `SELECT u.id, u.email, u.phone, u.user_type, u.active_role, u.available_roles,
              u.is_verified, u.is_active, u.created_at, u.updated_at,
              p.status AS sub_admin_status, p.permissions AS sub_admin_permissions, p.created_by
       FROM users u
       JOIN sub_admin_permissions p ON p.user_id = u.id
       ORDER BY u.created_at DESC`,
    );

    return res.status(200).json({
      subAdmins: result.rows.map(mapSubAdminRow),
    });
  } catch (error) {
    console.error("Error listing sub-admins:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch sub-admins",
    });
  }
}

async function getSubAdmin(req, res) {
  try {
    const { subAdminId } = req.params;

    const result = await pool.query(
      `SELECT u.id, u.email, u.phone, u.user_type, u.active_role, u.available_roles,
              u.is_verified, u.is_active, u.created_at, u.updated_at,
              p.status AS sub_admin_status, p.permissions AS sub_admin_permissions, p.created_by
       FROM users u
       JOIN sub_admin_permissions p ON p.user_id = u.id
       WHERE u.id = $1`,
      [subAdminId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Sub-admin not found",
      });
    }

    return res.status(200).json({
      subAdmin: mapSubAdminRow(result.rows[0]),
    });
  } catch (error) {
    console.error("Error fetching sub-admin:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch sub-admin",
    });
  }
}

async function listPendingSubAdminRequests(req, res) {
  try {
    const result = await pool.query(
      `SELECT u.id, u.email, u.phone, u.user_type, u.active_role, u.available_roles,
              u.is_verified, u.is_active, u.created_at, u.updated_at,
              p.status AS sub_admin_status, p.permissions AS sub_admin_permissions, p.created_by
       FROM users u
       JOIN sub_admin_permissions p ON p.user_id = u.id
       WHERE p.status = 'pending'
       ORDER BY u.created_at DESC`,
    );

    return res.status(200).json({
      pendingRequests: result.rows.map(mapSubAdminRow),
    });
  } catch (error) {
    console.error("Error fetching pending sub-admin requests:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch pending requests",
    });
  }
}

async function createSubAdmin(req, res) {
  const client = await pool.connect();

  try {
    const { email, password, phone, permissions } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: "Missing required fields",
        message: "email and password are required",
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    if (!isValidEmail(normalizedEmail)) {
      return res.status(400).json({
        error: "Invalid email",
        message: "Please provide a valid email",
      });
    }

    const passwordCheck = isValidPassword(password);
    if (!passwordCheck.valid) {
      return res.status(400).json({
        error: "Invalid password",
        message: passwordCheck.message,
      });
    }

    if (permissions !== undefined) {
      const permissionValidation = validatePermissionPayload(permissions);
      if (!permissionValidation.valid) {
        return res.status(400).json({
          error: "Invalid permissions",
          message: permissionValidation.message,
        });
      }
    }

    const normalizedPermissions = normalizePermissions(permissions);

    await client.query("BEGIN");

    const existing = await client.query(
      `SELECT id FROM users WHERE email = $1`,
      [normalizedEmail],
    );

    if (existing.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Conflict",
        message: "A user with this email already exists",
      });
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const userResult = await client.query(
      `INSERT INTO users (email, password_hash, user_type, available_roles, active_role, phone, is_verified, is_active)
       VALUES ($1, $2, 'sub_admin', ARRAY['sub_admin'], 'sub_admin', $3, true, true)
       RETURNING id, email, phone, user_type, active_role, available_roles, is_verified, is_active, created_at, updated_at`,
      [normalizedEmail, passwordHash, phone || null],
    );

    const user = userResult.rows[0];

    await client.query(
      `INSERT INTO sub_admin_permissions (user_id, status, permissions, created_by)
       VALUES ($1, 'pending', $2, $3)`,
      [user.id, normalizedPermissions, req.user.id],
    );

    await client.query("COMMIT");

    return res.status(201).json({
      message: "Sub-admin created successfully",
      subAdmin: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        userType: user.user_type,
        activeRole: user.active_role,
        availableRoles: user.available_roles,
        isVerified: user.is_verified,
        isActive: user.is_active,
        status: "pending",
        permissions: normalizedPermissions,
        createdBy: req.user.id,
        createdAt: user.created_at,
        updatedAt: user.updated_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error creating sub-admin:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to create sub-admin",
    });
  } finally {
    client.release();
  }
}

async function updateSubAdmin(req, res) {
  const client = await pool.connect();

  try {
    const { subAdminId } = req.params;
    const { permissions } = req.body;

    if (permissions === undefined) {
      return res.status(400).json({
        error: "Invalid payload",
        message: "permissions are required",
      });
    }

    const permissionValidation = validatePermissionPayload(permissions);
    if (!permissionValidation.valid) {
      return res.status(400).json({
        error: "Invalid permissions",
        message: permissionValidation.message,
      });
    }

    await client.query("BEGIN");

    const existing = await client.query(
      `SELECT permissions
       FROM sub_admin_permissions
       WHERE user_id = $1`,
      [subAdminId],
    );

    if (existing.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "Sub-admin not found",
      });
    }

    const mergedPermissions = mergePermissions(
      existing.rows[0].permissions || {},
      permissions,
    );

    await client.query(
      `UPDATE sub_admin_permissions
       SET permissions = $2,
           updated_at = NOW()
       WHERE user_id = $1`,
      [subAdminId, mergedPermissions],
    );

    const result = await client.query(
      `SELECT u.id, u.email, u.phone, u.user_type, u.active_role, u.available_roles,
              u.is_verified, u.is_active, u.created_at, u.updated_at,
              p.status AS sub_admin_status, p.permissions AS sub_admin_permissions, p.created_by
       FROM users u
       JOIN sub_admin_permissions p ON p.user_id = u.id
       WHERE u.id = $1`,
      [subAdminId],
    );

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Sub-admin updated successfully",
      subAdmin: mapSubAdminRow(result.rows[0]),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error updating sub-admin:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to update sub-admin",
    });
  } finally {
    client.release();
  }
}

async function updateSubAdminStatus(req, res) {
  const client = await pool.connect();

  try {
    const { subAdminId } = req.params;
    const { status } = req.body;

    if (!ALLOWED_STATUSES.includes(status)) {
      return res.status(400).json({
        error: "Invalid status",
        message: `status must be one of: ${ALLOWED_STATUSES.join(", ")}`,
      });
    }

    await client.query("BEGIN");

    const updateResult = await client.query(
      `UPDATE sub_admin_permissions
       SET status = $2,
           updated_at = NOW()
       WHERE user_id = $1
       RETURNING user_id`,
      [subAdminId, status],
    );

    if (updateResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "Sub-admin not found",
      });
    }

    await client.query(
      `UPDATE users
       SET is_active = CASE WHEN $2 = 'suspended' THEN false ELSE true END,
           updated_at = NOW()
       WHERE id = $1`,
      [subAdminId, status],
    );

    const result = await client.query(
      `SELECT u.id, u.email, u.phone, u.user_type, u.active_role, u.available_roles,
              u.is_verified, u.is_active, u.created_at, u.updated_at,
              p.status AS sub_admin_status, p.permissions AS sub_admin_permissions, p.created_by
       FROM users u
       JOIN sub_admin_permissions p ON p.user_id = u.id
       WHERE u.id = $1`,
      [subAdminId],
    );

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Sub-admin status updated successfully",
      subAdmin: mapSubAdminRow(result.rows[0]),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error updating sub-admin status:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to update sub-admin status",
    });
  } finally {
    client.release();
  }
}

async function deleteSubAdmin(req, res) {
  const client = await pool.connect();

  try {
    const { subAdminId } = req.params;

    await client.query("BEGIN");

    const existing = await client.query(
      `SELECT 1 FROM sub_admin_permissions WHERE user_id = $1`,
      [subAdminId],
    );

    if (existing.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Not found",
        message: "Sub-admin not found",
      });
    }

    await client.query(`DELETE FROM users WHERE id = $1`, [subAdminId]);

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Sub-admin deleted successfully",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error deleting sub-admin:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete sub-admin",
    });
  } finally {
    client.release();
  }
}

module.exports = {
  listSubAdmins,
  getSubAdmin,
  listPendingSubAdminRequests,
  createSubAdmin,
  updateSubAdmin,
  updateSubAdminStatus,
  deleteSubAdmin,
};
