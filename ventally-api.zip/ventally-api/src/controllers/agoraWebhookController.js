const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const presence = require("../services/presence");

function deriveEventType(body = {}) {
  return String(
    body.eventType ||
      body.noticeType ||
      body.event ||
      body.type ||
      body.payload?.eventType ||
      "unknown",
  )
    .trim()
    .toLowerCase();
}

function deriveChannelName(body = {}) {
  return String(
    body.channelName ||
      body.channel ||
      body.cname ||
      body.payload?.channelName ||
      body.payload?.channel ||
      "",
  ).trim();
}

function deriveSessionSid(body = {}) {
  return String(
    body.sid ||
      body.sessionSid ||
      body.resourceId ||
      body.payload?.sid ||
      body.payload?.resourceId ||
      "",
  ).trim();
}

function deriveCallId(channelName) {
  const normalized = String(channelName || "").trim();
  if (!normalized) {
    return "";
  }

  if (normalized.startsWith("ventally-call-")) {
    return normalized.replace(/^ventally-call-/, "");
  }

  return normalized;
}

function isStartEvent(eventType) {
  return [
    "channel_started",
    "channel-created",
    "channel_start",
    "first-user-joined",
    "user_joined",
  ].includes(eventType);
}

function isEndEvent(eventType) {
  return [
    "channel_ended",
    "channel-destroyed",
    "channel_end",
    "last-user-left",
    "all-users-left",
  ].includes(eventType);
}

function isJoinEvent(eventType) {
  return ["user_joined", "participant_joined", "join"].includes(eventType);
}

async function recordEventIdempotent(
  client,
  eventId,
  eventType,
  channelName,
  sessionSid,
  payload,
) {
  const result = await client.query(
    `INSERT INTO agora_webhook_events
      (event_id, event_type, channel_name, session_id, payload, processed_at)
     VALUES ($1, $2, $3, $4, $5, NOW())
     ON CONFLICT (event_id) DO NOTHING
     RETURNING id`,
    [
      eventId,
      eventType,
      channelName || null,
      sessionSid || null,
      JSON.stringify(payload || {}),
    ],
  );

  return result.rows.length > 0;
}

async function handleAgoraEvent(req, res) {
  const client = await pool.connect();

  try {
    const body = req.body || {};
    const eventType = deriveEventType(body);
    const channelName = deriveChannelName(body);
    const sessionSid = deriveSessionSid(body);
    const callId = deriveCallId(channelName);
    const eventTs = Number(body.timestamp || body.ts || Date.now());
    const seq = String(body.sequence || body.seq || "0");
    const eventId = String(
      body.eventId || `${channelName}-${eventType}-${eventTs}-${seq}`,
    );

    logger.info("[minutes-debug] Agora webhook received", {
      eventType,
      channelName,
      callId,
      sessionSid,
      isStart: isStartEvent(eventType),
      isEnd: isEndEvent(eventType),
    });

    const inserted = await recordEventIdempotent(
      client,
      eventId,
      eventType,
      channelName,
      sessionSid,
      body,
    );

    if (!inserted) {
      return res.status(200).json({ success: true, duplicate: true });
    }

    if (!callId) {
      logger.warn("Agora webhook event without call ID", {
        eventType,
        channelName,
      });
      return res.status(200).json({ success: true, ignored: true });
    }

    if (isStartEvent(eventType)) {
      const updated = await client.query(
        `UPDATE voice_calls
         SET call_provider = 'agora',
             voice_channel_name = COALESCE(voice_channel_name, $1),
             voice_session_sid = COALESCE(voice_session_sid, $2),
             status = CASE WHEN status = 'ringing' THEN 'active' ELSE status END,
             started_at = CASE WHEN started_at IS NULL THEN NOW() ELSE started_at END
         WHERE id = $3 AND status IN ('ringing', 'active')
         RETURNING id, venter_id, listener_id, started_at, voice_channel_name, twilio_room_name`,
        [channelName, sessionSid || null, callId],
      );

      if (updated.rows.length > 0) {
        const call = updated.rows[0];
        logger.info("[minutes-debug] Agora start event set call active", {
          callId: call.id,
          venterId: call.venter_id,
          startedAt: call.started_at,
        });
        const io = req.app.get("io");
        if (io) {
          const payload = {
            callId: call.id,
            id: call.id,
            status: "active",
            roomName: call.voice_channel_name || call.twilio_room_name,
            channelName: call.voice_channel_name || call.twilio_room_name,
            provider: "agora",
            startedAt: call.started_at?.toISOString?.() || null,
          };

          io.to(String(call.venter_id)).emit("call:active", payload);
          io.to(String(call.listener_id)).emit("call:active", payload);
          io.to(String(call.venter_id)).emit("call:connected", payload);
          io.to(String(call.listener_id)).emit("call:connected", payload);
          io.to(`call:${call.id}`).emit("call:active", payload);
        }
      }
    } else if (isJoinEvent(eventType)) {
      await client.query(
        `UPDATE voice_calls
         SET call_provider = 'agora',
             voice_channel_name = COALESCE(voice_channel_name, $1),
             voice_session_sid = COALESCE(voice_session_sid, $2)
         WHERE id = $3`,
        [channelName || null, sessionSid || null, callId],
      );
    } else if (isEndEvent(eventType)) {
      const ended = await client.query(
        `UPDATE voice_calls
         SET status = 'ended', ended_at = COALESCE(ended_at, NOW())
         WHERE id = $1 AND status IN ('active', 'ringing')
         RETURNING id, venter_id, listener_id, started_at, ended_at`,
        [callId],
      );

      if (ended.rows.length > 0) {
        const call = ended.rows[0];
        const durationSeconds =
          call.started_at && call.ended_at
            ? Math.max(0, Math.floor((call.ended_at - call.started_at) / 1000))
            : 0;

        logger.warn(
          "[minutes-debug] Agora webhook ended call WITHOUT billing (endCall must run to deduct)",
          {
            callId: call.id,
            venterId: call.venter_id,
            eventType,
            startedAt: call.started_at,
            endedAt: call.ended_at,
            durationSeconds,
          },
        );

        try {
          await stopBalanceMonitoring(call.id);
        } catch (monitorError) {
          logger.error(
            `Error stopping balance monitoring for call ${call.id}:`,
            monitorError,
          );
        }

        await presence.clearListenerBusy(call.listener_id);

        const io = req.app.get("io");
        if (io) {
          io.to(`call:${call.id}`).emit("call:ended", {
            callId: call.id,
            reason: "agora_channel_ended",
            durationSeconds,
          });
        }
      }
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    logger.error(`Agora webhook event error: ${error.message}`, {
      error: error.stack,
    });
    return res.status(200).json({ success: true });
  } finally {
    client.release();
  }
}

async function handleAgoraRecordingWebhook(req, res) {
  const client = await pool.connect();

  try {
    const body = req.body || {};
    const eventType = deriveEventType(body) || "recording";
    const channelName = deriveChannelName(body);
    const sessionSid = deriveSessionSid(body);
    const callId = deriveCallId(channelName);

    const recordingUrl = String(
      body.recordingUrl ||
        body.fileUrl ||
        body.payload?.recordingUrl ||
        body.payload?.fileUrl ||
        "",
    ).trim();

    const eventId = String(
      body.eventId ||
        `${channelName}-${eventType}-${String(body.timestamp || Date.now())}`,
    );

    const inserted = await recordEventIdempotent(
      client,
      eventId,
      eventType,
      channelName,
      sessionSid,
      body,
    );

    if (!inserted) {
      return res.status(200).json({ success: true, duplicate: true });
    }

    if (recordingUrl && callId) {
      await client.query(
        `UPDATE call_logs
         SET recording_url = $1
         WHERE id IN (
            SELECT cl.id
            FROM call_logs cl
            JOIN voice_calls vc ON vc.id = $2
            WHERE cl.user_id = vc.venter_id
              AND cl.listener_id = vc.listener_id
            ORDER BY cl.created_at DESC
            LIMIT 1
         )`,
        [recordingUrl, callId],
      );
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    logger.error(`Agora recording webhook error: ${error.message}`, {
      error: error.stack,
    });
    return res.status(200).json({ success: true });
  } finally {
    client.release();
  }
}

module.exports = {
  handleAgoraEvent,
  handleAgoraRecordingWebhook,
};
