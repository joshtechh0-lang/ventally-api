const admin = require("firebase-admin");
const logger = require("../utils/logger");

/**
 * Get Firebase initialization status
 * GET /api/v1/notifications/status
 */
const getFirebaseStatus = async (req, res) => {
  try {
    let isInitialized = false;
    let hasCredentials = false;

    // Check if Firebase app is initialized
    try {
      const apps = admin.apps;
      isInitialized = apps && apps.length > 0;
    } catch (error) {
      isInitialized = false;
    }

    // Check if credentials are configured
    hasCredentials = !!(
      process.env.FIREBASE_SERVICE_ACCOUNT_PATH ||
      (process.env.FIREBASE_PROJECT_ID &&
        process.env.FIREBASE_PRIVATE_KEY &&
        process.env.FIREBASE_CLIENT_EMAIL)
    );

    res.status(200).json({
      success: true,
      firebase: {
        initialized: isInitialized,
        credentialsConfigured: hasCredentials,
        status: isInitialized
          ? "active"
          : hasCredentials
            ? "credentials_found_but_not_initialized"
            : "not_configured",
        message: isInitialized
          ? "Firebase Cloud Messaging is active and ready"
          : hasCredentials
            ? "Firebase credentials found but not initialized - restart server"
            : "Firebase not configured - push notifications disabled",
      },
      features: {
        pushNotifications: isInitialized,
        deviceTokenRegistration: true, // Always available
        notificationHistory: true, // Always available
      },
      documentation: {
        setup: "See FCM_SETUP.md for configuration instructions",
        api: "Visit /api-docs for API documentation",
      },
    });
  } catch (error) {
    logger.error("Error checking Firebase status:", error);
    res.status(500).json({
      success: false,
      message: "Failed to check Firebase status",
      error: error.message,
    });
  }
};

module.exports = {
  getFirebaseStatus,
};
