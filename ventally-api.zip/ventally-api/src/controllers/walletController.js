const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Validate pagination parameters
 */
function validatePagination(limit, offset) {
  const parsedLimit = parseInt(limit) || 50;
  const parsedOffset = parseInt(offset) || 0;

  return {
    limit: Math.min(Math.max(parsedLimit, 1), 100), // Between 1 and 100
    offset: Math.max(parsedOffset, 0),
  };
}

/**
 * Compute a user's true available callable minutes across both ledgers:
 * prepaid wallet balance + active-subscription remaining minutes.
 *
 * Subscription minutes live in user_subscriptions (included_minutes / used_minutes),
 * a separate ledger that user_wallets never reflects — buying a plan or consuming
 * minutes on a call only touches user_subscriptions. Recomputing from the source
 * tables on every read keeps the reported balance correct after purchases, calls
 * (used_minutes ↑ → remaining ↓), and overage. Mirrors the billing priority in
 * canMakeCall (subscription first, then prepaid).
 */
async function getAvailableMinutes(userId) {
  const [walletResult, subResult] = await Promise.all([
    pool.query(
      "SELECT balance_minutes FROM user_wallets WHERE user_id = $1",
      [userId],
    ),
    pool.query(
      `SELECT included_minutes, used_minutes
       FROM user_subscriptions
       WHERE user_id = $1 AND status IN ('active', 'trialing')
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId],
    ),
  ]);

  const prepaidMinutes =
    walletResult.rows.length > 0
      ? parseFloat(walletResult.rows[0].balance_minutes) || 0
      : 0;

  const hasSubscription = subResult.rows.length > 0;
  const subscriptionIncludedMinutes = hasSubscription
    ? parseFloat(subResult.rows[0].included_minutes) || 0
    : 0;
  const subscriptionUsedMinutes = hasSubscription
    ? parseFloat(subResult.rows[0].used_minutes) || 0
    : 0;
  const subscriptionRemainingMinutes = Math.max(
    0,
    subscriptionIncludedMinutes - subscriptionUsedMinutes,
  );

  return {
    prepaidMinutes,
    hasSubscription,
    subscriptionIncludedMinutes,
    subscriptionUsedMinutes,
    subscriptionRemainingMinutes,
    availableMinutes: prepaidMinutes + subscriptionRemainingMinutes,
  };
}

/**
 * Get user wallet balance
 */
async function getBalance(req, res) {
  try {
    const userId = req.user.id;

    logger.info("Fetching wallet balance", { userId });

    const result = await pool.query(
      `SELECT balance_minutes, balance_currency, currency_code, 
              auto_recharge_enabled, auto_recharge_threshold, auto_recharge_amount
       FROM user_wallets
       WHERE user_id = $1`,
      [userId],
    );

    if (result.rows.length === 0) {
      logger.warn("Wallet not found for user", { userId });
      return res.status(404).json({
        error: "Wallet not found",
        message: "User wallet not initialized",
      });
    }

    const wallet = result.rows[0];

    // Aggregate prepaid wallet minutes with active-subscription remaining minutes
    // so the reported balance is the user's true available callable minutes.
    // balance.minutes / balance.currency stay wallet-only for backward
    // compatibility; clients should display `availableMinutes` as the headline.
    const available = await getAvailableMinutes(userId);

    res.json({
      balance: {
        minutes: parseFloat(wallet.balance_minutes),
        currency: parseFloat(wallet.balance_currency),
        currencyCode: wallet.currency_code,
      },
      subscription: {
        active: available.hasSubscription,
        includedMinutes: available.subscriptionIncludedMinutes,
        usedMinutes: available.subscriptionUsedMinutes,
        remainingMinutes: available.subscriptionRemainingMinutes,
      },
      availableMinutes: available.availableMinutes,
      autoRecharge: {
        enabled: wallet.auto_recharge_enabled,
        threshold: wallet.auto_recharge_threshold,
        amount: parseFloat(wallet.auto_recharge_amount) || 0,
      },
    });
  } catch (error) {
    logger.error("Get balance error", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
    });
    res.status(500).json({
      error: "Failed to fetch balance",
      message: "An error occurred fetching wallet balance",
    });
  }
}

/**
 * Get wallet transaction history
 */
async function getTransactions(req, res) {
  try {
    const userId = req.user.id;
    const { limit, offset } = validatePagination(
      req.query.limit,
      req.query.offset,
    );

    logger.info("Fetching wallet transactions", { userId, limit, offset });

    const result = await pool.query(
      `SELECT id, transaction_type, amount_minutes, amount_currency,
              balance_after_minutes, balance_after_currency,
              description, created_at
       FROM wallet_transactions
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, limit, offset],
    );

    // Get total count
    const countResult = await pool.query(
      "SELECT COUNT(*) FROM wallet_transactions WHERE user_id = $1",
      [userId],
    );

    res.json({
      transactions: result.rows.map((t) => ({
        id: t.id,
        type: t.transaction_type,
        amountMinutes: parseFloat(t.amount_minutes) || 0,
        amountCurrency: parseFloat(t.amount_currency) || 0,
        balanceAfterMinutes: parseFloat(t.balance_after_minutes) || 0,
        balanceAfterCurrency: parseFloat(t.balance_after_currency) || 0,
        description: t.description,
        createdAt: t.created_at,
      })),
      pagination: {
        total: parseInt(countResult.rows[0].count),
        limit: limit,
        offset: offset,
      },
    });
  } catch (error) {
    logger.error("Get transactions error", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
    });
    res.status(500).json({
      error: "Failed to fetch transactions",
      message: "An error occurred fetching transaction history",
    });
  }
}

/**
 * Update auto-recharge settings
 */
async function updateAutoRecharge(req, res) {
  try {
    const userId = req.user.id;
    const { enabled, threshold, amount } = req.body;

    // Validate input
    if (enabled === undefined) {
      return res.status(400).json({
        error: "Missing required field",
        message: "'enabled' field is required",
      });
    }

    if (enabled && (!threshold || !amount)) {
      return res.status(400).json({
        error: "Missing fields",
        message:
          "Threshold and amount are required when enabling auto-recharge",
      });
    }

    // Validate threshold and amount ranges
    if (enabled) {
      if (threshold < 1 || threshold > 500) {
        return res.status(400).json({
          error: "Invalid threshold",
          message: "Threshold must be between 1 and 500 minutes",
        });
      }
      if (amount < 5 || amount > 500) {
        return res.status(400).json({
          error: "Invalid amount",
          message: "Amount must be between $5 and $500",
        });
      }
    }

    logger.info("Updating auto-recharge settings", {
      userId,
      enabled,
      threshold,
      amount,
    });

    const result = await pool.query(
      `UPDATE user_wallets
       SET auto_recharge_enabled = $1,
           auto_recharge_threshold = $2,
           auto_recharge_amount = $3,
           updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $4
       RETURNING auto_recharge_enabled, auto_recharge_threshold, auto_recharge_amount`,
      [enabled, threshold || null, amount || null, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Wallet not found",
        message: "User wallet not found",
      });
    }

    res.json({
      message: "Auto-recharge settings updated successfully",
      autoRecharge: {
        enabled: result.rows[0].auto_recharge_enabled,
        threshold: result.rows[0].auto_recharge_threshold,
        amount: parseFloat(result.rows[0].auto_recharge_amount) || 0,
      },
    });
  } catch (error) {
    logger.error("Update auto-recharge error", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
    });
    res.status(500).json({
      error: "Failed to update settings",
      message: "An error occurred updating auto-recharge settings",
    });
  }
}

/**
 * Add credits to wallet (internal method, used by payment webhook)
 */
async function addCredits(
  userId,
  minutes,
  amountPaid,
  paymentIntentId,
  description,
) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    logger.info("Adding credits to wallet", {
      userId,
      minutes,
      amountPaid,
      paymentIntentId,
    });

    // Get current balance
    const walletResult = await client.query(
      "SELECT balance_minutes, balance_currency FROM user_wallets WHERE user_id = $1",
      [userId],
    );

    if (walletResult.rows.length === 0) {
      throw new Error(`Wallet not found for user ${userId}`);
    }

    const currentMinutes = parseFloat(walletResult.rows[0].balance_minutes);
    const currentCurrency = parseFloat(walletResult.rows[0].balance_currency);
    const newMinutes = currentMinutes + minutes;
    const newCurrency = currentCurrency + amountPaid;

    // Update wallet
    await client.query(
      `UPDATE user_wallets 
       SET balance_minutes = $1, 
           balance_currency = $2,
           updated_at = NOW()
       WHERE user_id = $3`,
      [newMinutes, newCurrency, userId],
    );

    // Create transaction record
    await client.query(
      `INSERT INTO wallet_transactions 
       (user_id, transaction_type, amount_minutes, amount_currency,
        balance_after_minutes, balance_after_currency, stripe_payment_intent_id, description)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        userId,
        "credit_purchase",
        minutes,
        amountPaid,
        newMinutes,
        newCurrency,
        paymentIntentId,
        description || `Added ${minutes} calling minutes`,
      ],
    );

    await client.query("COMMIT");

    logger.info("Credits added successfully", {
      userId,
      newBalance: newMinutes,
      minutesAdded: minutes,
    });

    return { success: true, newBalance: newMinutes };
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error adding credits", {
      error: error.message,
      stack: error.stack,
      userId,
    });
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Deduct minutes from wallet (used when call ends)
 */
async function deductMinutes(userId, minutes, callId, description) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Get current balance
    const walletResult = await client.query(
      "SELECT balance_minutes FROM user_wallets WHERE user_id = $1 FOR UPDATE",
      [userId],
    );

    if (walletResult.rows.length === 0) {
      throw new Error(`Wallet not found for user ${userId}`);
    }

    const currentMinutes = parseFloat(walletResult.rows[0].balance_minutes);
    const newMinutes = Math.max(0, currentMinutes - minutes);

    // Update wallet
    await client.query(
      `UPDATE user_wallets 
       SET balance_minutes = $1,
           updated_at = NOW()
       WHERE user_id = $2`,
      [newMinutes, userId],
    );

    // Create transaction record
    await client.query(
      `INSERT INTO wallet_transactions 
       (user_id, transaction_type, amount_minutes, balance_after_minutes, related_call_id, description)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        userId,
        "call_deduction",
        -minutes,
        newMinutes,
        callId,
        description || `Call duration: ${minutes.toFixed(2)} minutes`,
      ],
    );

    await client.query("COMMIT");
    return {
      success: true,
      newBalance: newMinutes,
      wasNegative: currentMinutes < minutes,
    };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Get user subscription status
 */
async function getSubscriptionStatus(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT us.*, sp.name as plan_name, sp.price_monthly, sp.features
       FROM user_subscriptions us
       JOIN subscription_plans sp ON us.plan_id = sp.id
       WHERE us.user_id = $1 AND us.status IN ('active', 'trialing')
       ORDER BY us.created_at DESC
       LIMIT 1`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.json({
        hasSubscription: false,
        message: "No active subscription",
      });
    }

    const sub = result.rows[0];

    res.json({
      hasSubscription: true,
      subscription: {
        id: sub.id,
        planName: sub.plan_name,
        status: sub.status,
        includedMinutes: sub.included_minutes,
        usedMinutes: parseFloat(sub.used_minutes),
        remainingMinutes: sub.included_minutes - parseFloat(sub.used_minutes),
        includedMessages: sub.included_messages,
        usedMessages: parseInt(sub.used_messages || 0, 10),
        remainingMessages:
          sub.included_messages - parseInt(sub.used_messages || 0, 10),
        overageRate: parseFloat(sub.overage_rate),
        billingCycleStart: sub.billing_cycle_start,
        billingCycleEnd: sub.billing_cycle_end,
        monthlyPrice: parseFloat(sub.price_monthly),
        features: sub.features,
      },
    });
  } catch (error) {
    console.error("Get subscription status error:", error);
    res.status(500).json({
      error: "Failed to fetch subscription",
      message: "An error occurred fetching subscription status",
    });
  }
}

/**
 * Check if user can make a call (has sufficient balance)
 */
async function canMakeCall(userId) {
  try {
    // Check subscription first
    const subResult = await pool.query(
      `SELECT included_minutes, used_minutes 
       FROM user_subscriptions 
       WHERE user_id = $1 AND status IN ('active', 'trialing')
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId],
    );

    if (subResult.rows.length > 0) {
      const sub = subResult.rows[0];
      const remainingMinutes =
        sub.included_minutes - parseFloat(sub.used_minutes);

      if (remainingMinutes >= 1) {
        return { allowed: true, source: "subscription", remainingMinutes };
      }
      // Subscribers can use overage
      return { allowed: true, source: "overage" };
    }

    // Check prepaid balance
    const walletResult = await pool.query(
      "SELECT balance_minutes FROM user_wallets WHERE user_id = $1",
      [userId],
    );

    if (walletResult.rows.length > 0) {
      const balance = parseFloat(walletResult.rows[0].balance_minutes);

      if (balance >= 1) {
        logger.info("[minutes-debug] canMakeCall — prepaid allowed", {
          userId,
          source: "prepaid",
          remainingMinutes: balance,
        });
        return { allowed: true, source: "prepaid", remainingMinutes: balance };
      }
    }

    logger.warn("[minutes-debug] canMakeCall — insufficient balance", {
      userId,
      walletBalanceMinutes: walletResult.rows[0]?.balance_minutes ?? null,
    });
    return { allowed: false, reason: "insufficient_balance" };
  } catch (error) {
    console.error("Error checking call eligibility:", error);
    return { allowed: false, reason: "error", error: error.message };
  }
}

/**
 * Check if user can use PAYG (opted in, card on file, not locked, active rates)
 */
async function canUsePayg(userId) {
  try {
    const walletResult = await pool.query(
      `SELECT payg_enabled, default_payment_method, payg_locked_at, stripe_customer_id
       FROM user_wallets WHERE user_id = $1`,
      [userId],
    );
    if (walletResult.rows.length === 0) {
      return { allowed: false, reason: "wallet_missing" };
    }
    const w = walletResult.rows[0];
    if (!w.payg_enabled) return { allowed: false, reason: "not_enrolled" };
    if (w.payg_locked_at) return { allowed: false, reason: "payg_locked" };
    if (!w.default_payment_method)
      return { allowed: false, reason: "no_payment_method" };
    if (!w.stripe_customer_id)
      return { allowed: false, reason: "no_stripe_customer" };

    const { getPaygRates } = require("../services/paygService");
    const rates = await getPaygRates();
    if (!rates.isActive)
      return { allowed: false, reason: "rates_inactive" };

    return { allowed: true, source: "payg", rates };
  } catch (error) {
    console.error("Error checking PAYG eligibility:", error);
    return { allowed: false, reason: "error", error: error.message };
  }
}

module.exports = {
  getBalance,
  getAvailableMinutes,
  getTransactions,
  updateAutoRecharge,
  addCredits,
  deductMinutes,
  getSubscriptionStatus,
  canMakeCall,
  canUsePayg,
};
