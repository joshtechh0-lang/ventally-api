const auditLog = require("../services/moderationAuditLog");
const logger   = require("../utils/logger");

async function getLog(req, res) {
  try {
    const minLevel = Math.min(Math.max(parseInt(req.query.minLevel, 10) || 1, 1), 4);
    const page     = Math.max(parseInt(req.query.page,  10) || 1, 1);
    const limit    = Math.min(parseInt(req.query.limit, 10) || 50, 200);

    const [{ entries, pagination }, summary] = await Promise.all([
      auditLog.query({ minLevel, page, limit }),
      auditLog.stats(),
    ]);

    return res.json({ success: true, stats: summary, entries, pagination });
  } catch (error) {
    logger.error(`moderationController.getLog error: ${error.message}`);
    return res.status(500).json({ success: false, message: "Failed to fetch moderation log" });
  }
}

module.exports = { getLog };
