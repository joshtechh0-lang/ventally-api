const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Log mood for the current day
 * Only one mood entry per user per day is allowed
 * If an entry exists for today, it will return a conflict error
 */
async function logMood(req, res) {
  const client = await pool.connect();

  try {
    const { mood_type, category, notes } = req.body;
    const userId = req.user.id;

    // Validate required fields
    if (!mood_type) {
      return res.status(400).json({
        error: "Validation error",
        message: "mood_type is required",
      });
    }

    // Validate mood_type
    const validMoods = ["Happy", "Neutral", "Sad", "Anxious", "Mad"];
    if (!validMoods.includes(mood_type)) {
      return res.status(400).json({
        error: "Validation error",
        message: `mood_type must be one of: ${validMoods.join(", ")}`,
      });
    }

    // Validate category if provided
    if (category) {
      const validCategories = ["Work", "Family", "Health", "Unknown"];
      if (!validCategories.includes(category)) {
        return res.status(400).json({
          error: "Validation error",
          message: `category must be one of: ${validCategories.join(", ")}`,
        });
      }
    }

    // Check if user is a venter
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can log moods",
      });
    }

    // Check if mood already logged today
    const existingMood = await client.query(
      `SELECT id FROM mood_logs 
       WHERE user_id = $1 AND logged_date = CURRENT_DATE`,
      [userId],
    );

    if (existingMood.rows.length > 0) {
      return res.status(409).json({
        error: "Conflict",
        message:
          "Mood already logged for today. Use the update endpoint to modify it.",
        mood_id: existingMood.rows[0].id,
      });
    }

    // Insert mood log
    const result = await client.query(
      `INSERT INTO mood_logs (user_id, mood_type, category, notes, logged_date)
       VALUES ($1, $2, $3, $4, CURRENT_DATE)
       RETURNING id, user_id, mood_type, category, notes, logged_date, created_at`,
      [userId, mood_type, category || null, notes || null],
    );

    logger.info(`Mood logged for user ${userId}: ${mood_type}`);

    res.status(201).json({
      message: "Mood logged successfully",
      mood: result.rows[0],
    });
  } catch (error) {
    logger.error("Error logging mood:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to log mood",
    });
  } finally {
    client.release();
  }
}

/**
 * Get today's mood entry for the logged-in user
 */
async function getTodayMood(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT id, user_id, mood_type, category, notes, logged_date, created_at, updated_at
       FROM mood_logs
       WHERE user_id = $1 AND logged_date = CURRENT_DATE`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "No mood logged for today",
        logged: false,
      });
    }

    res.json({
      message: "Today's mood retrieved successfully",
      logged: true,
      mood: result.rows[0],
    });
  } catch (error) {
    logger.error("Error fetching today's mood:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch mood",
    });
  }
}

/**
 * Get mood history for the logged-in user
 * Supports pagination and date filtering
 */
async function getMoodHistory(req, res) {
  try {
    const userId = req.user.id;
    const { limit = 30, offset = 0, start_date, end_date } = req.query;

    let query = `
      SELECT id, user_id, mood_type, category, notes, logged_date, created_at, updated_at
      FROM mood_logs
      WHERE user_id = $1
    `;
    const params = [userId];
    let paramIndex = 2;

    // Add date filters if provided
    if (start_date) {
      query += ` AND logged_date >= $${paramIndex}`;
      params.push(start_date);
      paramIndex++;
    }

    if (end_date) {
      query += ` AND logged_date <= $${paramIndex}`;
      params.push(end_date);
      paramIndex++;
    }

    query += ` ORDER BY logged_date DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Get total count
    let countQuery = "SELECT COUNT(*) FROM mood_logs WHERE user_id = $1";
    const countParams = [userId];
    let countParamIndex = 2;

    if (start_date) {
      countQuery += ` AND logged_date >= $${countParamIndex}`;
      countParams.push(start_date);
      countParamIndex++;
    }

    if (end_date) {
      countQuery += ` AND logged_date <= $${countParamIndex}`;
      countParams.push(end_date);
      countParamIndex++;
    }

    const countResult = await pool.query(countQuery, countParams);
    const totalCount = parseInt(countResult.rows[0].count);

    res.json({
      message: "Mood history retrieved successfully",
      moods: result.rows,
      pagination: {
        total: totalCount,
        limit: parseInt(limit),
        offset: parseInt(offset),
        has_more: parseInt(offset) + result.rows.length < totalCount,
      },
    });
  } catch (error) {
    logger.error("Error fetching mood history:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch mood history",
    });
  }
}

/**
 * Update today's mood entry
 * Only allows updating the mood logged for today
 */
async function updateTodayMood(req, res) {
  const client = await pool.connect();

  try {
    const { mood_type, category, notes } = req.body;
    const userId = req.user.id;

    // Check if user is a venter
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can update moods",
      });
    }

    // Validate mood_type if provided
    if (mood_type) {
      const validMoods = ["Happy", "Neutral", "Sad", "Anxious", "Mad"];
      if (!validMoods.includes(mood_type)) {
        return res.status(400).json({
          error: "Validation error",
          message: `mood_type must be one of: ${validMoods.join(", ")}`,
        });
      }
    }

    // Validate category if provided
    if (category) {
      const validCategories = ["Work", "Family", "Health", "Unknown"];
      if (!validCategories.includes(category)) {
        return res.status(400).json({
          error: "Validation error",
          message: `category must be one of: ${validCategories.join(", ")}`,
        });
      }
    }

    // Build update query dynamically based on provided fields
    const updates = [];
    const params = [userId];
    let paramIndex = 2;

    if (mood_type !== undefined) {
      updates.push(`mood_type = $${paramIndex}`);
      params.push(mood_type);
      paramIndex++;
    }

    if (category !== undefined) {
      updates.push(`category = $${paramIndex}`);
      params.push(category);
      paramIndex++;
    }

    if (notes !== undefined) {
      updates.push(`notes = $${paramIndex}`);
      params.push(notes);
      paramIndex++;
    }

    if (updates.length === 0) {
      return res.status(400).json({
        error: "Validation error",
        message: "No fields provided to update",
      });
    }

    const query = `
      UPDATE mood_logs
      SET ${updates.join(", ")}
      WHERE user_id = $1 AND logged_date = CURRENT_DATE
      RETURNING id, user_id, mood_type, category, notes, logged_date, created_at, updated_at
    `;

    const result = await client.query(query, params);

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "No mood logged for today to update",
      });
    }

    logger.info(`Mood updated for user ${userId}`);

    res.json({
      message: "Mood updated successfully",
      mood: result.rows[0],
    });
  } catch (error) {
    logger.error("Error updating mood:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update mood",
    });
  } finally {
    client.release();
  }
}

/**
 * Delete a mood entry
 * Users can only delete their own mood entries
 */
async function deleteMood(req, res) {
  const client = await pool.connect();

  try {
    const { moodId } = req.params;
    const userId = req.user.id;

    // Check if user is a venter
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can delete moods",
      });
    }

    const result = await client.query(
      `DELETE FROM mood_logs
       WHERE id = $1 AND user_id = $2
       RETURNING id`,
      [moodId, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message:
          "Mood entry not found or you don't have permission to delete it",
      });
    }

    logger.info(`Mood deleted: ${moodId} by user ${userId}`);

    res.json({
      message: "Mood deleted successfully",
      mood_id: moodId,
    });
  } catch (error) {
    logger.error("Error deleting mood:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete mood",
    });
  } finally {
    client.release();
  }
}

/**
 * Get mood statistics for the logged-in user
 * Provides summary of mood trends
 */
async function getMoodStats(req, res) {
  try {
    const userId = req.user.id;
    const { days = 30 } = req.query;

    // Get mood distribution
    const distributionResult = await pool.query(
      `SELECT mood_type, COUNT(*) as count
       FROM mood_logs
       WHERE user_id = $1 AND logged_date >= CURRENT_DATE - INTERVAL '${parseInt(days)} days'
       GROUP BY mood_type
       ORDER BY count DESC`,
      [userId],
    );

    // Get category distribution
    const categoryResult = await pool.query(
      `SELECT category, COUNT(*) as count
       FROM mood_logs
       WHERE user_id = $1 AND logged_date >= CURRENT_DATE - INTERVAL '${parseInt(days)} days'
       AND category IS NOT NULL
       GROUP BY category
       ORDER BY count DESC`,
      [userId],
    );

    // Get total entries
    const totalResult = await pool.query(
      `SELECT COUNT(*) as total
       FROM mood_logs
       WHERE user_id = $1 AND logged_date >= CURRENT_DATE - INTERVAL '${parseInt(days)} days'`,
      [userId],
    );

    // Get streak (consecutive days with mood logged)
    const streakResult = await pool.query(
      `WITH date_series AS (
        SELECT logged_date, 
               logged_date - (ROW_NUMBER() OVER (ORDER BY logged_date))::integer AS grp
        FROM mood_logs
        WHERE user_id = $1 AND logged_date <= CURRENT_DATE
      ),
      streaks AS (
        SELECT COUNT(*) as streak_length, MAX(logged_date) as end_date
        FROM date_series
        GROUP BY grp
      )
      SELECT MAX(streak_length) as longest_streak, 
             COALESCE((
               SELECT streak_length 
               FROM streaks 
               WHERE end_date = CURRENT_DATE
             ), 0) as current_streak
      FROM streaks`,
      [userId],
    );

    res.json({
      message: "Mood statistics retrieved successfully",
      period_days: parseInt(days),
      total_entries: parseInt(totalResult.rows[0].total),
      mood_distribution: distributionResult.rows,
      category_distribution: categoryResult.rows,
      streaks: {
        current: parseInt(streakResult.rows[0]?.current_streak || 0),
        longest: parseInt(streakResult.rows[0]?.longest_streak || 0),
      },
    });
  } catch (error) {
    logger.error("Error fetching mood stats:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch mood statistics",
    });
  }
}

module.exports = {
  logMood,
  getTodayMood,
  getMoodHistory,
  updateTodayMood,
  deleteMood,
  getMoodStats,
};
