const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Submit a report against a user
 * POST /api/v1/reports
 */
async function submitReport(req, res) {
  try {
    const { reportedId, sessionType, sessionId, reason, description } =
      req.body;
    const reporterId = req.user.id;
    let sessionVenterId;
    let sessionListenerId;

    // Validate input
    if (!reportedId || !reason) {
      return res.status(400).json({
        error: "Validation error",
        message: "reportedId and reason are required",
      });
    }

    const validReasons = [
      "disruptive_behavior",
      "bullying_or_harassment",
      "danger_to_self_or_others",
      "inappropriate_or_unsafe_response",
    ];

    if (!validReasons.includes(reason)) {
      return res.status(400).json({
        error: "Validation error",
        message: `Reason must be one of: ${validReasons.join(", ")}`,
      });
    }

    if (!sessionType || !sessionId) {
      return res.status(400).json({
        error: "Validation error",
        message: "sessionType and sessionId are required",
      });
    }

    if (!["call", "chat"].includes(sessionType)) {
      return res.status(400).json({
        error: "Validation error",
        message: "Session type must be 'call' or 'chat'",
      });
    }

    if (reporterId === reportedId) {
      return res.status(400).json({
        error: "Validation error",
        message: "Cannot report yourself",
      });
    }

    // Check if reported user exists
    const userCheck = await pool.query("SELECT id FROM users WHERE id = $1", [
      reportedId,
    ]);

    if (userCheck.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Reported user not found",
      });
    }

    // Resolve session participants and verify reporter/reported pair matches.
    let sessionCheck;
    if (sessionType === "call") {
      sessionCheck = await pool.query(
        `SELECT venter_id, listener_id 
         FROM voice_calls 
         WHERE id = $1`,
        [sessionId],
      );
    } else {
      sessionCheck = await pool.query(
        `SELECT venter_id, listener_id 
         FROM conversations 
         WHERE id = $1`,
        [sessionId],
      );
    }

    if (sessionCheck.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Session not found",
      });
    }

    sessionVenterId = sessionCheck.rows[0].venter_id;
    sessionListenerId = sessionCheck.rows[0].listener_id;

    const participants = [sessionVenterId, sessionListenerId];
    if (
      !participants.includes(reporterId) ||
      !participants.includes(reportedId)
    ) {
      return res.status(403).json({
        error: "Forbidden",
        message:
          "Both users must have been participants in the specified session",
      });
    }

    // Insert report
    const result = await pool.query(
      `INSERT INTO user_reports 
       (reporter_id, reported_id, session_type, session_id, session_venter_id, session_listener_id, reason, description, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
       RETURNING id, created_at`,
      [
        reporterId,
        reportedId,
        sessionType,
        sessionId,
        sessionVenterId,
        sessionListenerId,
        reason,
        description || null,
      ],
    );

    logger.info(
      `Report submitted by ${reporterId} against ${reportedId} for reason: ${reason}`,
    );

    // TODO: Notify admins of new report (could implement push notification or email)

    res.status(201).json({
      success: true,
      report: {
        id: result.rows[0].id,
        reportedId,
        sessionType,
        sessionId,
        sessionVenterId,
        sessionListenerId,
        reason,
        description,
        status: "pending",
        createdAt: result.rows[0].created_at,
      },
    });
  } catch (error) {
    logger.error(`Error submitting report: ${error.message}`, { error });
    res.status(500).json({
      error: "Server error",
      message: "Failed to submit report",
    });
  }
}

/**
 * Get user's submitted reports
 * GET /api/v1/reports/my-reports
 */
async function getMyReports(req, res) {
  try {
    const reporterId = req.user.id;
    const { limit = 20, offset = 0, status } = req.query;

    let query = `
      SELECT 
        r.id,
        r.reported_id,
        r.session_type,
        r.session_id,
        r.session_venter_id,
        r.session_listener_id,
        r.reason,
        r.description,
        r.status,
        r.created_at,
        r.reviewed_at
      FROM user_reports r
      WHERE r.reporter_id = $1
    `;

    const params = [reporterId];

    if (status) {
      query += ` AND r.status = $${params.length + 1}`;
      params.push(status);
    }

    query += ` ORDER BY r.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Get total count
    let countQuery = "SELECT COUNT(*) FROM user_reports WHERE reporter_id = $1";
    const countParams = [reporterId];

    if (status) {
      countQuery += " AND status = $2";
      countParams.push(status);
    }

    const countResult = await pool.query(countQuery, countParams);

    res.json({
      success: true,
      reports: result.rows,
      pagination: {
        limit: parseInt(limit),
        offset: parseInt(offset),
        total: parseInt(countResult.rows[0].count),
      },
    });
  } catch (error) {
    logger.error(`Error fetching user reports: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch reports",
    });
  }
}

/**
 * Get all reports (Admin only)
 * GET /api/v1/reports/admin/all
 */
async function getAllReports(req, res) {
  try {
    const { limit = 50, offset = 0, status, reason } = req.query;

    let query = `
      SELECT 
        r.id,
        r.reporter_id,
        r.reported_id,
        r.session_type,
        r.session_id,
        r.session_venter_id,
        r.session_listener_id,
        r.reason,
        r.description,
        r.status,
        r.admin_notes,
        r.reviewed_by,
        r.reviewed_at,
        r.created_at,
        reporter.email as reporter_email,
        reported.email as reported_email
      FROM user_reports r
      JOIN users reporter ON r.reporter_id = reporter.id
      JOIN users reported ON r.reported_id = reported.id
      WHERE 1=1
    `;

    const params = [];

    if (status) {
      query += ` AND r.status = $${params.length + 1}`;
      params.push(status);
    }

    if (reason) {
      query += ` AND r.reason = $${params.length + 1}`;
      params.push(reason);
    }

    query += ` ORDER BY 
      CASE 
        WHEN r.status = 'pending' THEN 0
        WHEN r.status = 'reviewing' THEN 1
        WHEN r.status = 'resolved' THEN 2
        WHEN r.status = 'dismissed' THEN 3
      END,
      r.created_at DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;

    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Get total count
    let countQuery = "SELECT COUNT(*) FROM user_reports WHERE 1=1";
    const countParams = [];

    if (status) {
      countQuery += " AND status = $1";
      countParams.push(status);
    }

    if (reason && status) {
      countQuery += " AND reason = $2";
      countParams.push(reason);
    } else if (reason) {
      countQuery += " AND reason = $1";
      countParams.push(reason);
    }

    const countResult = await pool.query(countQuery, countParams);

    // Get statistics
    const statsResult = await pool.query(`
      SELECT 
        status,
        COUNT(*) as count
      FROM user_reports
      GROUP BY status
    `);

    const stats = {
      pending: 0,
      reviewing: 0,
      resolved: 0,
      dismissed: 0,
    };

    statsResult.rows.forEach((row) => {
      stats[row.status] = parseInt(row.count);
    });

    res.json({
      success: true,
      reports: result.rows,
      stats,
      pagination: {
        limit: parseInt(limit),
        offset: parseInt(offset),
        total: parseInt(countResult.rows[0].count),
      },
    });
  } catch (error) {
    logger.error(`Error fetching all reports: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch reports",
    });
  }
}

/**
 * Update report status (Admin only)
 * PUT /api/v1/reports/admin/:reportId
 */
async function updateReportStatus(req, res) {
  try {
    const { reportId } = req.params;
    const { status, adminNotes } = req.body;
    const adminId = req.user.id;

    const validStatuses = ["pending", "reviewing", "resolved", "dismissed"];

    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        error: "Validation error",
        message: `Status must be one of: ${validStatuses.join(", ")}`,
      });
    }

    // Check if report exists
    const reportCheck = await pool.query(
      "SELECT id FROM user_reports WHERE id = $1",
      [reportId],
    );

    if (reportCheck.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Report not found",
      });
    }

    // Update report
    const result = await pool.query(
      `UPDATE user_reports 
       SET status = $1, 
           admin_notes = COALESCE($2, admin_notes),
           reviewed_by = $3,
           reviewed_at = NOW()
       WHERE id = $4
       RETURNING *`,
      [status, adminNotes || null, adminId, reportId],
    );

    logger.info(
      `Report ${reportId} updated to status '${status}' by admin ${adminId}`,
    );

    res.json({
      success: true,
      report: result.rows[0],
    });
  } catch (error) {
    logger.error(`Error updating report: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to update report",
    });
  }
}

/**
 * Get report details (Admin only)
 * GET /api/v1/reports/admin/:reportId
 */
async function getReportDetails(req, res) {
  try {
    const { reportId } = req.params;

    const result = await pool.query(
      `SELECT 
        r.*,
        reporter.email as reporter_email,
        reporter.user_type as reporter_type,
        reported.email as reported_email,
        reported.user_type as reported_type,
        reviewer.email as reviewer_email
      FROM user_reports r
      JOIN users reporter ON r.reporter_id = reporter.id
      JOIN users reported ON r.reported_id = reported.id
      LEFT JOIN users reviewer ON r.reviewed_by = reviewer.id
      WHERE r.id = $1`,
      [reportId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Report not found",
      });
    }

    res.json({
      success: true,
      report: result.rows[0],
    });
  } catch (error) {
    logger.error(`Error fetching report details: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch report details",
    });
  }
}

/**
 * Get reports statistics (Admin only)
 * GET /api/v1/reports/admin/stats
 */
async function getReportsStats(req, res) {
  try {
    const calculatePercentChange = (current, previous) => {
      if (previous === 0) {
        return current === 0 ? 0 : 100;
      }

      return parseFloat((((current - previous) / previous) * 100).toFixed(2));
    };

    // Status breakdown
    const statusStats = await pool.query(`
      SELECT 
        status,
        COUNT(*) as count
      FROM user_reports
      GROUP BY status
    `);

    // Reason breakdown
    const reasonStats = await pool.query(`
      SELECT 
        reason,
        COUNT(*) as count
      FROM user_reports
      GROUP BY reason
      ORDER BY count DESC
    `);

    // Recent trends (last 30 days)
    const reportTrendsStats = await pool.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as count
      FROM user_reports
      WHERE created_at >= NOW() - INTERVAL '30 days'
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `);

    // Top reported users (last 90 days)
    const topReported = await pool.query(`
      SELECT 
        r.reported_id,
        u.email,
        u.user_type,
        COUNT(*) as report_count
      FROM user_reports r
      JOIN users u ON r.reported_id = u.id
      WHERE r.created_at >= NOW() - INTERVAL '90 days'
      GROUP BY r.reported_id, u.email, u.user_type
      ORDER BY report_count DESC
      LIMIT 10
    `);

    const activeUsersStats = await pool.query(`
      SELECT
        (
          SELECT COUNT(DISTINCT user_id)
          FROM (
            SELECT venter_id AS user_id
            FROM sessions
            WHERE created_at >= NOW() - INTERVAL '24 hours'
            UNION ALL
            SELECT listener_id AS user_id
            FROM sessions
            WHERE created_at >= NOW() - INTERVAL '24 hours'
              AND listener_id IS NOT NULL
          ) current_users
        ) AS current_count,
        (
          SELECT COUNT(DISTINCT user_id)
          FROM (
            SELECT venter_id AS user_id
            FROM sessions
            WHERE created_at >= NOW() - INTERVAL '48 hours'
              AND created_at < NOW() - INTERVAL '24 hours'
            UNION ALL
            SELECT listener_id AS user_id
            FROM sessions
            WHERE created_at >= NOW() - INTERVAL '48 hours'
              AND created_at < NOW() - INTERVAL '24 hours'
              AND listener_id IS NOT NULL
          ) previous_users
        ) AS previous_count
    `);

    const sessionsStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (
          WHERE created_at >= NOW() - INTERVAL '24 hours'
        ) AS current_count,
        COUNT(*) FILTER (
          WHERE created_at >= NOW() - INTERVAL '48 hours'
            AND created_at < NOW() - INTERVAL '24 hours'
        ) AS previous_count
      FROM sessions
    `);

    const signupsStats = await pool.query(`
      SELECT
        COUNT(*) FILTER (
          WHERE created_at >= NOW() - INTERVAL '24 hours'
        ) AS current_count,
        COUNT(*) FILTER (
          WHERE created_at >= NOW() - INTERVAL '48 hours'
            AND created_at < NOW() - INTERVAL '24 hours'
        ) AS previous_count
      FROM users
    `);

    const listenerMinutesStats = await pool.query(`
      SELECT
        COALESCE(
          (
            SELECT SUM(
              CASE
                WHEN duration_seconds > 0 THEN duration_seconds
                WHEN started_at IS NOT NULL AND ended_at IS NOT NULL
                  THEN EXTRACT(EPOCH FROM (ended_at - started_at))
                ELSE 0
              END
            )
            FROM sessions
            WHERE listener_id IS NOT NULL
              AND created_at >= NOW() - INTERVAL '24 hours'
          ),
          0
        ) AS current_seconds,
        COALESCE(
          (
            SELECT SUM(
              CASE
                WHEN duration_seconds > 0 THEN duration_seconds
                WHEN started_at IS NOT NULL AND ended_at IS NOT NULL
                  THEN EXTRACT(EPOCH FROM (ended_at - started_at))
                ELSE 0
              END
            )
            FROM sessions
            WHERE listener_id IS NOT NULL
              AND created_at >= NOW() - INTERVAL '48 hours'
              AND created_at < NOW() - INTERVAL '24 hours'
          ),
          0
        ) AS previous_seconds
    `);

    const engagementTrendStats = await pool.query(`
      WITH hourly_windows AS (
        SELECT generate_series(
          date_trunc('hour', NOW()) - INTERVAL '23 hours',
          date_trunc('hour', NOW()),
          INTERVAL '1 hour'
        ) AS hour_bucket
      ),
      session_rows AS (
        SELECT
          date_trunc('hour', created_at) AS hour_bucket,
          venter_id,
          listener_id
        FROM sessions
        WHERE created_at >= NOW() - INTERVAL '24 hours'
      ),
      participant_rows AS (
        SELECT hour_bucket, venter_id AS user_id
        FROM session_rows
        UNION ALL
        SELECT hour_bucket, listener_id AS user_id
        FROM session_rows
        WHERE listener_id IS NOT NULL
      ),
      session_counts AS (
        SELECT hour_bucket, COUNT(*) AS session_count
        FROM session_rows
        GROUP BY hour_bucket
      ),
      participant_counts AS (
        SELECT hour_bucket, COUNT(DISTINCT user_id) AS active_users
        FROM participant_rows
        GROUP BY hour_bucket
      )
      SELECT
        h.hour_bucket,
        COALESCE(s.session_count, 0) AS session_count,
        COALESCE(p.active_users, 0) AS active_users,
        CASE
          WHEN COALESCE(s.session_count, 0) = 0 THEN 0
          ELSE ROUND((COALESCE(p.active_users, 0)::numeric / s.session_count::numeric) * 100, 2)
        END AS engagement_ratio
      FROM hourly_windows h
      LEFT JOIN session_counts s ON h.hour_bucket = s.hour_bucket
      LEFT JOIN participant_counts p ON h.hour_bucket = p.hour_bucket
      ORDER BY h.hour_bucket ASC
    `);

    const activeUsersCurrent =
      parseInt(activeUsersStats.rows[0]?.current_count || 0, 10) || 0;
    const activeUsersPrevious =
      parseInt(activeUsersStats.rows[0]?.previous_count || 0, 10) || 0;

    const sessionsCurrent =
      parseInt(sessionsStats.rows[0]?.current_count || 0, 10) || 0;
    const sessionsPrevious =
      parseInt(sessionsStats.rows[0]?.previous_count || 0, 10) || 0;

    const signupsCurrent =
      parseInt(signupsStats.rows[0]?.current_count || 0, 10) || 0;
    const signupsPrevious =
      parseInt(signupsStats.rows[0]?.previous_count || 0, 10) || 0;

    const listenerSecondsCurrent =
      parseFloat(listenerMinutesStats.rows[0]?.current_seconds || 0) || 0;
    const listenerSecondsPrevious =
      parseFloat(listenerMinutesStats.rows[0]?.previous_seconds || 0) || 0;

    const listenerMinutesCurrent = Math.round(listenerSecondsCurrent / 60);
    const listenerMinutesPrevious = Math.round(listenerSecondsPrevious / 60);

    const stats = {
      byStatus: {},
      byReason: {},
      last30Days: reportTrendsStats.rows,
      topReportedUsers: topReported.rows,
      applicationStatus24h: {
        window: "last_24_hours",
        generatedAt: new Date().toISOString(),
        cards: {
          activeUsers: {
            value: activeUsersCurrent,
            changePercent: calculatePercentChange(
              activeUsersCurrent,
              activeUsersPrevious,
            ),
          },
          monthlySessions: {
            value: sessionsCurrent,
            changePercent: calculatePercentChange(
              sessionsCurrent,
              sessionsPrevious,
            ),
          },
          newSignups: {
            value: signupsCurrent,
            changePercent: calculatePercentChange(
              signupsCurrent,
              signupsPrevious,
            ),
          },
          listenerOnlineMinutes: {
            value: listenerMinutesCurrent,
            changePercent: calculatePercentChange(
              listenerMinutesCurrent,
              listenerMinutesPrevious,
            ),
          },
        },
        userProgressEngagementRatio: engagementTrendStats.rows.map((row) => ({
          hour: row.hour_bucket,
          activeUsers: parseInt(row.active_users, 10),
          sessions: parseInt(row.session_count, 10),
          engagementRatio: parseFloat(row.engagement_ratio),
        })),
      },
    };

    statusStats.rows.forEach((row) => {
      stats.byStatus[row.status] = parseInt(row.count);
    });

    reasonStats.rows.forEach((row) => {
      stats.byReason[row.reason] = parseInt(row.count);
    });

    res.json({
      success: true,
      stats,
    });
  } catch (error) {
    logger.error(`Error fetching reports stats: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch reports statistics",
    });
  }
}

module.exports = {
  submitReport,
  getMyReports,
  getAllReports,
  updateReportStatus,
  getReportDetails,
  getReportsStats,
};
