const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Render success page for credit purchase
 */
exports.creditPurchaseSuccess = async (req, res) => {
  try {
    const { session_id } = req.query;

    if (!session_id) {
      return res.status(400).send(renderErrorPage("Missing session ID"));
    }

    // Retrieve session from Stripe
    const session = await stripe.checkout.sessions.retrieve(session_id);

    if (session.payment_status !== "paid") {
      return res.send(renderPendingPage(session.payment_status, session_id));
    }

    const creditsMinutes = session.metadata?.credits_minutes || 0;
    const amountPaid = session.amount_total / 100;
    const packType = session.metadata?.pack_type || "custom";

    logger.info("Rendering credit purchase success page", {
      sessionId: session_id,
      creditsMinutes,
      amountPaid,
    });

    res.send(
      renderCreditSuccessPage({
        creditsMinutes,
        amountPaid,
        packType,
        sessionId: session_id,
        currency: session.currency.toUpperCase(),
      }),
    );
  } catch (error) {
    logger.error("Error rendering credit purchase success page", {
      error: error.message,
      sessionId: req.query?.session_id,
    });
    res.status(500).send(renderErrorPage("Failed to load payment details"));
  }
};

/**
 * Render success page for subscription
 */
exports.subscriptionSuccess = async (req, res) => {
  try {
    const { session_id } = req.query;

    if (!session_id) {
      return res.status(400).send(renderErrorPage("Missing session ID"));
    }

    // Retrieve session from Stripe
    const session = await stripe.checkout.sessions.retrieve(session_id);

    if (session.payment_status !== "paid") {
      return res.send(renderPendingPage(session.payment_status, session_id));
    }

    const planId = session.metadata?.plan_id;
    let planDetails = { name: "Subscription Plan", price: 0, minutes: 0 };

    if (planId) {
      const planResult = await pool.query(
        "SELECT name, price_monthly, included_minutes FROM subscription_plans WHERE id = $1",
        [planId],
      );
      if (planResult.rows.length > 0) {
        planDetails = {
          name: planResult.rows[0].name,
          price: planResult.rows[0].price_monthly,
          minutes: planResult.rows[0].included_minutes,
        };
      }
    }

    // Get subscription details
    const subscription = await stripe.subscriptions.retrieve(
      session.subscription,
    );

    logger.info("Rendering subscription success page", {
      sessionId: session_id,
      planId,
      subscriptionId: session.subscription,
    });

    res.send(
      renderSubscriptionSuccessPage({
        planName: planDetails.name,
        monthlyPrice: planDetails.price,
        includedMinutes: planDetails.minutes,
        nextBillingDate: new Date(
          subscription.current_period_end * 1000,
        ).toLocaleDateString(),
        sessionId: session_id,
        subscriptionId: session.subscription,
      }),
    );
  } catch (error) {
    logger.error("Error rendering subscription success page", {
      error: error.message,
      sessionId: req.query?.session_id,
    });
    res
      .status(500)
      .send(renderErrorPage("Failed to load subscription details"));
  }
};

/**
 * Render cancel/failure page
 */
exports.paymentCancel = async (req, res) => {
  if (req.query.flow === "bank_link") {
    const result = req.query.result === "refresh" ? "refresh" : "return";
    logger.info("Rendering bank-link return page", { result });
    res.send(renderBankLinkReturnPage(result));
    return;
  }

  logger.info("Rendering payment cancel page");
  res.send(renderCancelPage());
};

/**
 * HTML template for credit purchase success
 */
function renderCreditSuccessPage(data) {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Payment Successful - Ventally</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          max-width: 500px;
          width: 100%;
          overflow: hidden;
        }
        .header {
          background: linear-gradient(135deg, #10B981 0%, #059669 100%);
          color: white;
          padding: 40px 30px;
          text-align: center;
        }
        .success-icon {
          width: 80px;
          height: 80px;
          background: white;
          border-radius: 50%;
          margin: 0 auto 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 48px;
        }
        h1 { font-size: 28px; margin-bottom: 10px; }
        .subtitle { opacity: 0.9; font-size: 16px; }
        .content {
          padding: 30px;
        }
        .detail-box {
          background: #F3F4F6;
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 20px;
        }
        .detail-row {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid #E5E7EB;
        }
        .detail-row:last-child { border-bottom: none; }
        .detail-label {
          color: #6B7280;
          font-weight: 500;
        }
        .detail-value {
          color: #111827;
          font-weight: 600;
        }
        .highlight {
          background: linear-gradient(135deg, #DCFCE7 0%, #BBF7D0 100%);
          border-radius: 12px;
          padding: 20px;
          text-align: center;
          margin: 20px 0;
        }
        .highlight-label {
          color: #166534;
          font-size: 14px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
        }
        .highlight-value {
          color: #15803D;
          font-size: 36px;
          font-weight: 700;
        }
        .button {
          display: block;
          width: 100%;
          padding: 16px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          text-align: center;
          text-decoration: none;
          border-radius: 8px;
          font-weight: 600;
          font-size: 16px;
          margin-top: 20px;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .button:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .info-text {
          color: #6B7280;
          font-size: 14px;
          text-align: center;
          margin-top: 20px;
          line-height: 1.6;
        }
        .session-id {
          background: #F9FAFB;
          border: 1px solid #E5E7EB;
          border-radius: 6px;
          padding: 12px;
          font-size: 12px;
          color: #6B7280;
          word-break: break-all;
          margin-top: 20px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="success-icon">✓</div>
          <h1>Payment Successful!</h1>
          <p class="subtitle">Your credits have been added to your account</p>
        </div>
        <div class="content">
          <div class="highlight">
            <div class="highlight-label">Credits Added</div>
            <div class="highlight-value">${data.creditsMinutes} minutes</div>
          </div>
          
          <div class="detail-box">
            <div class="detail-row">
              <span class="detail-label">Pack Type</span>
              <span class="detail-value">${data.packType.charAt(0).toUpperCase() + data.packType.slice(1)}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Amount Paid</span>
              <span class="detail-value">${data.currency} $${data.amountPaid.toFixed(2)}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Price per Minute</span>
              <span class="detail-value">$${(data.amountPaid / data.creditsMinutes).toFixed(3)}</span>
            </div>
          </div>

          <a href="${process.env.CLIENT_URL || "/"}" class="button">
            Return to App
          </a>

          <p class="info-text">
            A confirmation email has been sent to your registered email address.
            You can start making calls immediately with your new credits.
          </p>

          <div class="session-id">
            <strong>Transaction ID:</strong><br>${data.sessionId}
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * HTML template for subscription success
 */
function renderSubscriptionSuccessPage(data) {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Subscription Activated - Ventally</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          max-width: 500px;
          width: 100%;
          overflow: hidden;
        }
        .header {
          background: linear-gradient(135deg, #4F46E5 0%, #6366F1 100%);
          color: white;
          padding: 40px 30px;
          text-align: center;
        }
        .success-icon {
          width: 80px;
          height: 80px;
          background: white;
          border-radius: 50%;
          margin: 0 auto 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 48px;
        }
        h1 { font-size: 28px; margin-bottom: 10px; }
        .subtitle { opacity: 0.9; font-size: 16px; }
        .content {
          padding: 30px;
        }
        .plan-card {
          background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%);
          border: 2px solid #4F46E5;
          border-radius: 12px;
          padding: 24px;
          margin-bottom: 20px;
        }
        .plan-name {
          color: #4F46E5;
          font-size: 24px;
          font-weight: 700;
          margin-bottom: 16px;
          text-align: center;
        }
        .detail-row {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid #C7D2FE;
        }
        .detail-row:last-child { border-bottom: none; }
        .detail-label {
          color: #6366F1;
          font-weight: 600;
        }
        .detail-value {
          color: #312E81;
          font-weight: 700;
        }
        .features {
          background: #F9FAFB;
          border-radius: 12px;
          padding: 20px;
          margin: 20px 0;
        }
        .features h3 {
          color: #111827;
          font-size: 16px;
          margin-bottom: 12px;
        }
        .features ul {
          list-style: none;
        }
        .features li {
          color: #4B5563;
          padding: 8px 0;
          padding-left: 24px;
          position: relative;
        }
        .features li:before {
          content: "✓";
          position: absolute;
          left: 0;
          color: #10B981;
          font-weight: bold;
        }
        .button {
          display: block;
          width: 100%;
          padding: 16px;
          background: linear-gradient(135deg, #4F46E5 0%, #6366F1 100%);
          color: white;
          text-align: center;
          text-decoration: none;
          border-radius: 8px;
          font-weight: 600;
          font-size: 16px;
          margin-top: 20px;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .button:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(79, 70, 229, 0.4);
        }
        .info-text {
          color: #6B7280;
          font-size: 14px;
          text-align: center;
          margin-top: 20px;
          line-height: 1.6;
        }
        .session-id {
          background: #F9FAFB;
          border: 1px solid #E5E7EB;
          border-radius: 6px;
          padding: 12px;
          font-size: 12px;
          color: #6B7280;
          word-break: break-all;
          margin-top: 20px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="success-icon">🎊</div>
          <h1>Subscription Activated!</h1>
          <p class="subtitle">Welcome to ${data.planName}</p>
        </div>
        <div class="content">
          <div class="plan-card">
            <div class="plan-name">${data.planName}</div>
            <div class="detail-row">
              <span class="detail-label">Monthly Price</span>
              <span class="detail-value">$${parseFloat(data.monthlyPrice).toFixed(2)}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Included Minutes</span>
              <span class="detail-value">${data.includedMinutes} min/month</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Next Billing Date</span>
              <span class="detail-value">${data.nextBillingDate}</span>
            </div>
          </div>

          <div class="features">
            <h3>What's Included:</h3>
            <ul>
              <li>${data.includedMinutes} minutes of calling time per month</li>
              <li>24/7 access to trained listeners</li>
              <li>Priority support</li>
              <li>Automatic monthly renewal</li>
            </ul>
          </div>

          <a href="${process.env.CLIENT_URL || "/"}" class="button">
            Start Your First Call
          </a>

          <p class="info-text">
            A confirmation email has been sent to your registered email address.
            You can manage your subscription anytime from your account settings.
          </p>

          <div class="session-id">
            <strong>Subscription ID:</strong><br>${data.subscriptionId}
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * HTML template for payment cancel
 */
function renderCancelPage() {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Payment Cancelled - Ventally</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          max-width: 500px;
          width: 100%;
          overflow: hidden;
        }
        .header {
          background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
          color: white;
          padding: 40px 30px;
          text-align: center;
        }
        .icon {
          width: 80px;
          height: 80px;
          background: white;
          border-radius: 50%;
          margin: 0 auto 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 48px;
        }
        h1 { font-size: 28px; margin-bottom: 10px; }
        .subtitle { opacity: 0.9; font-size: 16px; }
        .content {
          padding: 30px;
          text-align: center;
        }
        .message {
          color: #4B5563;
          font-size: 16px;
          line-height: 1.6;
          margin-bottom: 24px;
        }
        .button {
          display: inline-block;
          padding: 16px 32px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          text-align: center;
          text-decoration: none;
          border-radius: 8px;
          font-weight: 600;
          font-size: 16px;
          margin: 10px;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .button:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .button-secondary {
          background: #F3F4F6;
          color: #374151;
        }
        .button-secondary:hover {
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .info-box {
          background: #FEF3C7;
          border: 1px solid #FCD34D;
          border-radius: 8px;
          padding: 16px;
          margin-top: 24px;
          text-align: left;
        }
        .info-box strong {
          color: #92400E;
          display: block;
          margin-bottom: 8px;
        }
        .info-box p {
          color: #78350F;
          font-size: 14px;
          line-height: 1.5;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="icon">⚠️</div>
          <h1>Payment Cancelled</h1>
          <p class="subtitle">Your payment was not processed</p>
        </div>
        <div class="content">
          <p class="message">
            You've cancelled the payment process. No charges have been made to your account.
          </p>

          <div>
            <a href="${process.env.CLIENT_URL || "/"}" class="button">
              Return to App
            </a>
            <a href="${process.env.CLIENT_URL || "/"}/billing" class="button button-secondary">
              Try Again
            </a>
          </div>

          <div class="info-box">
            <strong>Need Help?</strong>
            <p>
              If you experienced any issues during checkout or have questions about our pricing,
              please contact our support team at support@ventally.co
            </p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}

function renderBankLinkReturnPage(result) {
  const isReturn = result === "return";
  const headerGradient = isReturn
    ? "linear-gradient(135deg, #10B981 0%, #059669 100%)"
    : "linear-gradient(135deg, #F59E0B 0%, #D97706 100%)";
  const icon = isReturn ? "✅" : "🔄";
  const title = isReturn ? "Bank Linking Complete" : "Bank Linking Refresh";
  const subtitle = isReturn
    ? "We've received your information"
    : "This session has expired";
  const message = isReturn
    ? "Thanks — return to the Ventally app to check your payout status. Stripe may take a moment to finish verifying your account; your status will update automatically once approved."
    : "Your bank linking session expired before it could be completed. Open the Ventally app and start the bank-linking flow again.";

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${title} - Ventally</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          max-width: 500px;
          width: 100%;
          overflow: hidden;
        }
        .header {
          background: ${headerGradient};
          color: white;
          padding: 40px 30px;
          text-align: center;
        }
        .icon {
          width: 80px; height: 80px; background: white; border-radius: 50%;
          margin: 0 auto 20px; display: flex; align-items: center;
          justify-content: center; font-size: 48px;
        }
        h1 { font-size: 28px; margin-bottom: 10px; }
        .subtitle { opacity: 0.9; font-size: 16px; }
        .content { padding: 30px; text-align: center; }
        .message { color: #4B5563; font-size: 16px; line-height: 1.6; margin-bottom: 24px; }
        .button {
          display: inline-block; padding: 16px 32px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white; text-decoration: none; border-radius: 8px;
          font-weight: 600; font-size: 16px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="icon">${icon}</div>
          <h1>${title}</h1>
          <p class="subtitle">${subtitle}</p>
        </div>
        <div class="content">
          <p class="message">${message}</p>
          <a href="${process.env.CLIENT_URL || "/"}" class="button">Return to App</a>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * HTML template for pending payment
 */
function renderPendingPage(status, sessionId) {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Payment Pending - Ventally</title>
      <meta http-equiv="refresh" content="5">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          max-width: 500px;
          width: 100%;
          padding: 40px 30px;
          text-align: center;
        }
        .spinner {
          width: 60px;
          height: 60px;
          border: 4px solid #E5E7EB;
          border-top-color: #667eea;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin: 0 auto 20px;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        h1 {
          color: #111827;
          font-size: 24px;
          margin-bottom: 12px;
        }
        p {
          color: #6B7280;
          font-size: 16px;
          line-height: 1.6;
        }
        .status {
          background: #F3F4F6;
          border-radius: 8px;
          padding: 12px;
          margin-top: 20px;
          font-size: 14px;
          color: #4B5563;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="spinner"></div>
        <h1>Payment Processing</h1>
        <p>Please wait while we confirm your payment...</p>
        <div class="status">
          Status: ${status}<br>
          Session: ${sessionId}
        </div>
        <p style="margin-top: 20px; font-size: 14px;">
          This page will refresh automatically.
        </p>
      </div>
    </body>
    </html>
  `;
}

/**
 * HTML template for error page
 */
function renderErrorPage(message) {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Error - Ventally</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          max-width: 500px;
          width: 100%;
          overflow: hidden;
        }
        .header {
          background: linear-gradient(135deg, #DC2626 0%, #B91C1C 100%);
          color: white;
          padding: 40px 30px;
          text-align: center;
        }
        .icon {
          width: 80px;
          height: 80px;
          background: white;
          border-radius: 50%;
          margin: 0 auto 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 48px;
        }
        h1 { font-size: 28px; margin-bottom: 10px; }
        .content {
          padding: 30px;
          text-align: center;
        }
        .message {
          color: #4B5563;
          font-size: 16px;
          margin-bottom: 24px;
        }
        .button {
          display: inline-block;
          padding: 16px 32px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          text-decoration: none;
          border-radius: 8px;
          font-weight: 600;
          transition: transform 0.2s;
        }
        .button:hover {
          transform: translateY(-2px);
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="icon">❌</div>
          <h1>Oops! Something went wrong</h1>
        </div>
        <div class="content">
          <p class="message">${message}</p>
          <a href="${process.env.CLIENT_URL || "/"}" class="button">
            Return to App
          </a>
        </div>
      </div>
    </body>
    </html>
  `;
}

module.exports = exports;
