const { pool } = require("../database/connection");
const s3Service = require("../services/s3");
const logger = require("../utils/logger");

/**
 * Upload or update user signature
 * POST /api/v1/signatures
 */
async function uploadSignature(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const file = req.file;

    if (!file) {
      return res.status(400).json({
        error: "No file provided",
        message: "Please upload a signature file",
      });
    }

    // Check if user already has a signature
    const userResult = await client.query(
      "SELECT signature_url FROM users WHERE id = $1",
      [userId],
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "User does not exist",
      });
    }

    const oldSignatureUrl = userResult.rows[0].signature_url;

    // Upload new signature to S3
    const uploadResult = await s3Service.uploadSignature(
      file.buffer,
      file.originalname,
      userId,
      file.mimetype,
    );

    // Start transaction
    await client.query("BEGIN");

    // Update user's signature_url in database
    const updateResult = await client.query(
      `UPDATE users 
       SET signature_url = $1, updated_at = NOW() 
       WHERE id = $2 
       RETURNING id, signature_url`,
      [uploadResult.url, userId],
    );

    // Commit transaction
    await client.query("COMMIT");

    // Delete old signature from S3 if it exists
    if (oldSignatureUrl) {
      try {
        // Extract key from URL
        const urlParts = oldSignatureUrl.split("/");
        const keyIndex = urlParts.indexOf("signatures");
        if (keyIndex !== -1) {
          const key = urlParts.slice(keyIndex).join("/");
          await s3Service.deleteFile(key);
          logger.info(`Deleted old signature: ${key}`);
        }
      } catch (deleteError) {
        // Log error but don't fail the request
        logger.error("Failed to delete old signature from S3:", deleteError);
      }
    }

    logger.info(`User ${userId} uploaded signature: ${uploadResult.key}`);

    res.json({
      message: "Signature uploaded successfully",
      signature: {
        url: updateResult.rows[0].signature_url,
        fileName: uploadResult.fileName,
        uploadedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    // Rollback transaction on error
    await client.query("ROLLBACK");

    logger.error("Error uploading signature:", error);
    res.status(500).json({
      error: "Upload failed",
      message: "Failed to upload signature. Please try again.",
    });
  } finally {
    client.release();
  }
}

/**
 * Get user signature
 * GET /api/v1/signatures/:userId
 */
async function getSignature(req, res) {
  try {
    const requestedUserId = req.params.userId;
    const requestingUserId = req.user.id;
    const requestingUserType = req.user.user_type;

    // Access control: Only owner or admin can view signature
    if (
      requestedUserId !== requestingUserId &&
      requestingUserType !== "admin"
    ) {
      return res.status(403).json({
        error: "Access denied",
        message: "You do not have permission to view this signature",
      });
    }

    // Get signature from database
    const result = await pool.query(
      "SELECT id, signature_url, updated_at FROM users WHERE id = $1",
      [requestedUserId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "User does not exist",
      });
    }

    const user = result.rows[0];

    if (!user.signature_url) {
      return res.status(404).json({
        error: "Signature not found",
        message: "User has not uploaded a signature",
      });
    }

    res.json({
      signature: {
        url: user.signature_url,
        updatedAt: user.updated_at,
      },
    });
  } catch (error) {
    logger.error("Error getting signature:", error);
    res.status(500).json({
      error: "Retrieval failed",
      message: "Failed to retrieve signature. Please try again.",
    });
  }
}

/**
 * Delete user signature
 * DELETE /api/v1/signatures
 */
async function deleteSignature(req, res) {
  const client = await pool.connect();

  try {
    const userId = req.user.id;

    // Get current signature URL
    const userResult = await client.query(
      "SELECT signature_url FROM users WHERE id = $1",
      [userId],
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        error: "User not found",
        message: "User does not exist",
      });
    }

    const signatureUrl = userResult.rows[0].signature_url;

    if (!signatureUrl) {
      return res.status(404).json({
        error: "Signature not found",
        message: "No signature to delete",
      });
    }

    // Start transaction
    await client.query("BEGIN");

    // Remove signature URL from database
    await client.query(
      `UPDATE users 
       SET signature_url = NULL, updated_at = NOW() 
       WHERE id = $1`,
      [userId],
    );

    // Commit transaction
    await client.query("COMMIT");

    // Delete file from S3
    try {
      // Extract key from URL
      const urlParts = signatureUrl.split("/");
      const keyIndex = urlParts.indexOf("signatures");
      if (keyIndex !== -1) {
        const key = urlParts.slice(keyIndex).join("/");
        await s3Service.deleteFile(key);
        logger.info(`Deleted signature: ${key}`);
      }
    } catch (deleteError) {
      // Log error but don't fail the request (DB already updated)
      logger.error("Failed to delete signature from S3:", deleteError);
    }

    logger.info(`User ${userId} deleted signature`);

    res.json({
      message: "Signature deleted successfully",
    });
  } catch (error) {
    // Rollback transaction on error
    await client.query("ROLLBACK");

    logger.error("Error deleting signature:", error);
    res.status(500).json({
      error: "Deletion failed",
      message: "Failed to delete signature. Please try again.",
    });
  } finally {
    client.release();
  }
}

module.exports = {
  uploadSignature,
  getSignature,
  deleteSignature,
};
