const agoraService = require("../services/agora");
const logger = require("../utils/logger");

async function generateToken(req, res) {
  try {
    const body = req.body || {};
    const channelName = body.channelName;
    const uid = body.uid;
    const tokenExpireTs = body.tokenExpireTs ?? 3600;
    const privilegeExpireTs = body.privilegeExpireTs ?? tokenExpireTs;
    const serviceRtc = body.serviceRtc || {};

    if (serviceRtc.enable === false) {
      return res.status(400).json({
        error: "Invalid request",
        message: "serviceRtc.enable must be true for RTC token generation",
      });
    }

    const role = serviceRtc.role ?? 1;

    const generated = agoraService.generateTokenWithUid({
      channelName,
      uid,
      role,
      tokenExpireTs,
      privilegeExpireTs,
    });

    return res.json({
      success: true,
      key: generated.token,
      token: generated.token,
      channelName: generated.channelName,
      uid: generated.uid,
      tokenExpireTs: generated.tokenExpireTs,
      privilegeExpireTs: generated.privilegeExpireTs,
      serviceRtc: {
        enable: true,
        role: generated.role,
      },
    });
  } catch (error) {
    logger.error(`Error generating Agora token: ${error.message}`);

    const isValidationError =
      error.message.includes("Agora") ||
      error.message.includes("channel") ||
      error.message.includes("uid") ||
      error.message.includes("Expire") ||
      error.message.includes("configured");

    return res.status(isValidationError ? 400 : 500).json({
      error: isValidationError ? "Invalid request" : "Server error",
      message: error.message,
    });
  }
}

module.exports = {
  generateToken,
};
