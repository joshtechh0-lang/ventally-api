const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Create or update reflection for today
 * Only one reflection per user per day is allowed
 * Automatically links to today's mood if available
 */
async function saveReflection(req, res) {
  const client = await pool.connect();

  try {
    const { reflection_text } = req.body;
    const userId = req.user.id;

    // Validate required fields
    if (!reflection_text || reflection_text.trim() === "") {
      return res.status(400).json({
        error: "Validation error",
        message: "reflection_text is required and cannot be empty",
      });
    }

    // Check if user is a venter
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can save reflections",
      });
    }

    // Get today's mood log if it exists
    const moodResult = await client.query(
      `SELECT id FROM mood_logs 
       WHERE user_id = $1 AND logged_date = CURRENT_DATE`,
      [userId],
    );

    const moodLogId = moodResult.rows.length > 0 ? moodResult.rows[0].id : null;

    // Check if reflection already exists for today
    const existingReflection = await client.query(
      `SELECT id FROM reflections 
       WHERE user_id = $1 AND reflection_date = CURRENT_DATE`,
      [userId],
    );

    let result;
    let isUpdate = false;

    if (existingReflection.rows.length > 0) {
      // Update existing reflection
      result = await client.query(
        `UPDATE reflections 
         SET reflection_text = $1, mood_log_id = $2, updated_at = CURRENT_TIMESTAMP
         WHERE user_id = $3 AND reflection_date = CURRENT_DATE
         RETURNING id, user_id, mood_log_id, reflection_text, reflection_date, created_at, updated_at`,
        [reflection_text, moodLogId, userId],
      );
      isUpdate = true;
    } else {
      // Insert new reflection
      result = await client.query(
        `INSERT INTO reflections (user_id, mood_log_id, reflection_text, reflection_date)
         VALUES ($1, $2, $3, CURRENT_DATE)
         RETURNING id, user_id, mood_log_id, reflection_text, reflection_date, created_at, updated_at`,
        [userId, moodLogId, reflection_text],
      );
    }

    logger.info(
      `Reflection ${isUpdate ? "updated" : "created"} for user ${userId}`,
    );

    res.status(isUpdate ? 200 : 201).json({
      message: `Reflection ${isUpdate ? "updated" : "saved"} successfully`,
      reflection: result.rows[0],
    });
  } catch (error) {
    logger.error("Error saving reflection:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to save reflection",
    });
  } finally {
    client.release();
  }
}

/**
 * Get today's reflection for the logged-in user
 */
async function getTodayReflection(req, res) {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT r.id, r.user_id, r.mood_log_id, r.reflection_text, 
              r.reflection_date, r.created_at, r.updated_at,
              m.mood_type, m.category
       FROM reflections r
       LEFT JOIN mood_logs m ON r.mood_log_id = m.id
       WHERE r.user_id = $1 AND r.reflection_date = CURRENT_DATE`,
      [userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "No reflection saved for today",
        saved: false,
      });
    }

    res.json({
      message: "Today's reflection retrieved successfully",
      saved: true,
      reflection: result.rows[0],
    });
  } catch (error) {
    logger.error("Error fetching today's reflection:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch reflection",
    });
  }
}

/**
 * Get reflection history for the logged-in user
 * Supports pagination and date filtering
 */
async function getReflectionHistory(req, res) {
  try {
    const userId = req.user.id;
    const { limit = 30, offset = 0, start_date, end_date } = req.query;

    let query = `
      SELECT r.id, r.user_id, r.mood_log_id, r.reflection_text, 
             r.reflection_date, r.created_at, r.updated_at,
             m.mood_type, m.category
      FROM reflections r
      LEFT JOIN mood_logs m ON r.mood_log_id = m.id
      WHERE r.user_id = $1
    `;
    const params = [userId];
    let paramIndex = 2;

    // Add date filters if provided
    if (start_date) {
      query += ` AND r.reflection_date >= $${paramIndex}`;
      params.push(start_date);
      paramIndex++;
    }

    if (end_date) {
      query += ` AND r.reflection_date <= $${paramIndex}`;
      params.push(end_date);
      paramIndex++;
    }

    // Add ordering and pagination
    query += ` ORDER BY r.reflection_date DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Get total count for pagination
    let countQuery = `SELECT COUNT(*) FROM reflections WHERE user_id = $1`;
    const countParams = [userId];
    let countParamIndex = 2;

    if (start_date) {
      countQuery += ` AND reflection_date >= $${countParamIndex}`;
      countParams.push(start_date);
      countParamIndex++;
    }

    if (end_date) {
      countQuery += ` AND reflection_date <= $${countParamIndex}`;
      countParams.push(end_date);
    }

    const countResult = await pool.query(countQuery, countParams);

    res.json({
      message: "Reflection history retrieved successfully",
      reflections: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        limit: parseInt(limit),
        offset: parseInt(offset),
      },
    });
  } catch (error) {
    logger.error("Error fetching reflection history:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch reflection history",
    });
  }
}

/**
 * Update a specific reflection by ID
 */
async function updateReflection(req, res) {
  const client = await pool.connect();

  try {
    const { reflectionId } = req.params;
    const { reflection_text } = req.body;
    const userId = req.user.id;

    // Validate required fields
    if (!reflection_text || reflection_text.trim() === "") {
      return res.status(400).json({
        error: "Validation error",
        message: "reflection_text is required and cannot be empty",
      });
    }

    // Check if user is a venter
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can update reflections",
      });
    }

    const result = await client.query(
      `UPDATE reflections
       SET reflection_text = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2 AND user_id = $3
       RETURNING id, user_id, mood_log_id, reflection_text, reflection_date, created_at, updated_at`,
      [reflection_text, reflectionId, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message:
          "Reflection not found or you don't have permission to update it",
      });
    }

    logger.info(`Reflection updated: ${reflectionId} by user ${userId}`);

    res.json({
      message: "Reflection updated successfully",
      reflection: result.rows[0],
    });
  } catch (error) {
    logger.error("Error updating reflection:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update reflection",
    });
  } finally {
    client.release();
  }
}

/**
 * Delete a reflection entry
 * Users can only delete their own reflections
 */
async function deleteReflection(req, res) {
  const client = await pool.connect();

  try {
    const { reflectionId } = req.params;
    const userId = req.user.id;

    // Check if user is a venter
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can delete reflections",
      });
    }

    const result = await client.query(
      `DELETE FROM reflections
       WHERE id = $1 AND user_id = $2
       RETURNING id`,
      [reflectionId, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message:
          "Reflection not found or you don't have permission to delete it",
      });
    }

    logger.info(`Reflection deleted: ${reflectionId} by user ${userId}`);

    res.json({
      message: "Reflection deleted successfully",
      reflection_id: reflectionId,
    });
  } catch (error) {
    logger.error("Error deleting reflection:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete reflection",
    });
  } finally {
    client.release();
  }
}

module.exports = {
  saveReflection,
  getTodayReflection,
  getReflectionHistory,
  updateReflection,
  deleteReflection,
};
