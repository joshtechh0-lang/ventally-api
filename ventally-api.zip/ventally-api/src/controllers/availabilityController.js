const { pool } = require("../database/connection");
const presence = require("../services/presence");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const { getSetting } = require("../services/settings");
const {
  ACTIVE_CALL_STATUSES,
  ACTIVE_CHAT_STATUSES,
} = require("../utils/sessionHelper");
const logger = require("../utils/logger");

async function endActiveSessionsForListener(listenerId, io) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const callsResult = await client.query(
      `SELECT id, venter_id, listener_id
       FROM voice_calls
       WHERE listener_id = $1
         AND status = ANY($2::text[])
         AND ended_at IS NULL
       FOR UPDATE`,
      [listenerId, ACTIVE_CALL_STATUSES],
    );

    const conversationsResult = await client.query(
      `SELECT id, venter_id, listener_id
       FROM conversations
       WHERE listener_id = $1
         AND status = ANY($2::text[])
         AND ended_at IS NULL
       FOR UPDATE`,
      [listenerId, ACTIVE_CHAT_STATUSES],
    );

    const callIds = callsResult.rows.map((row) => row.id);
    const conversationIds = conversationsResult.rows.map((row) => row.id);

    if (callIds.length > 0) {
      await client.query(
        `UPDATE voice_calls
         SET status = 'ended',
             ended_at = COALESCE(ended_at, NOW())
         WHERE id = ANY($1::uuid[])`,
        [callIds],
      );
    }

    if (conversationIds.length > 0) {
      await client.query(
        `UPDATE conversations
         SET status = 'ended',
             ended_at = COALESCE(ended_at, NOW())
         WHERE id = ANY($1::uuid[])`,
        [conversationIds],
      );
    }

    await client.query("COMMIT");

    const endedAt = new Date().toISOString();

    for (const call of callsResult.rows) {
      try {
        await stopBalanceMonitoring(call.id);
      } catch (monitorError) {
        logger.warn("Failed stopping call monitor while going offline", {
          callId: call.id,
          listenerId,
          error: monitorError.message,
        });
      }

      if (io) {
        const payload = {
          callId: call.id,
          reason: "listener_offline",
          message: "Call ended because listener went offline",
          endedAt,
        };
        io.to(String(call.venter_id)).emit("call:ended", payload);
        io.to(String(call.listener_id)).emit("call:ended", payload);
      }
    }

    for (const conversation of conversationsResult.rows) {
      if (io) {
        const payload = {
          conversationId: conversation.id,
          reason: "listener_offline",
          message: "Chat ended because listener went offline",
          endedAt,
        };
        io.to(String(conversation.venter_id)).emit("chat:ended", payload);
        io.to(String(conversation.listener_id)).emit("chat:ended", payload);
      }
    }

    return {
      endedCalls: callsResult.rows.length,
      endedChats: conversationsResult.rows.length,
    };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Mark listener as online
 * POST /api/v1/availability/online
 */
async function goOnline(req, res) {
  try {
    const listenerId = req.user.id;

    // Verify user is in listener role (check active_role first, fallback to user_type)
    const currentRole =
      req.user.activeRole || req.user.active_role || req.user.user_type;

    if (currentRole !== "listener") {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "You must be in listener role to go online. Your current role is " +
          currentRole,
      });
    }

    // Ensure listener profile exists
    const profileResult = await pool.query(
      "SELECT listener_id FROM listener_profiles WHERE listener_id = $1",
      [listenerId],
    );

    if (profileResult.rows.length === 0) {
      // Create listener profile with defaults
      const defaultRate = await getSetting("listener_default_rate", 0.5);

      await pool.query(
        `INSERT INTO listener_profiles (listener_id, rate_per_minute, is_online)
         VALUES ($1, $2, true)
         ON CONFLICT (listener_id) DO UPDATE SET is_online = true`,
        [listenerId, defaultRate],
      );
    }

    // Mark as online in presence system
    await presence.setListenerOnline(listenerId);

    logger.info(`Listener ${listenerId} went online`);

    res.json({
      success: true,
      message: "You are now online and available for sessions",
    });
  } catch (error) {
    logger.error(`Error in goOnline: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to go online",
    });
  }
}

/**
 * Mark listener as offline
 * POST /api/v1/availability/offline
 */
async function goOffline(req, res) {
  try {
    const listenerId = req.user.id;

    // Verify user is in listener role (check active_role first, fallback to user_type)
    const currentRole =
      req.user.activeRole || req.user.active_role || req.user.user_type;

    if (currentRole !== "listener") {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "You must be in listener role to go offline. Your current role is " +
          currentRole,
      });
    }

    const io = req.app.get("io");

    // Force-end any active sessions before setting offline status.
    const endedSessions = await endActiveSessionsForListener(listenerId, io);

    // Ensure listener busy state is cleared after forced end operations.
    await presence.clearListenerBusy(listenerId);

    // Mark as offline
    await presence.setListenerOffline(listenerId);

    logger.info(`Listener ${listenerId} went offline`, endedSessions);

    res.json({
      success: true,
      message: "You are now offline",
      endedSessions,
    });
  } catch (error) {
    logger.error(`Error in goOffline: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to go offline",
    });
  }
}

/**
 * Send heartbeat to maintain online status
 * POST /api/v1/availability/heartbeat
 */
async function heartbeat(req, res) {
  try {
    const listenerId = req.user.id;

    if (req.user.user_type !== "listener") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only listeners can send heartbeat",
      });
    }

    const result = await presence.heartbeat(listenerId);

    res.json({
      success: true,
      timestamp: result.timestamp,
    });
  } catch (error) {
    logger.error(`Error in heartbeat: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to update heartbeat",
    });
  }
}

/**
 * Get available listeners (for venters)
 * GET /api/v1/availability/listeners
 */
async function getAvailableListeners(req, res) {
  try {
    const venterId = req.user.id;

    const listeners = await presence.getAvailableListeners(venterId);

    res.json({
      success: true,
      count: listeners.length,
      listeners: listeners,
    });
  } catch (error) {
    logger.error(`Error in getAvailableListeners: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch available listeners",
    });
  }
}

/**
 * Update listener rate per minute
 * PUT /api/v1/availability/rate
 */
async function updateRate(req, res) {
  try {
    const listenerId = req.user.id;
    const { ratePerMinute } = req.body;

    if (req.user.user_type !== "listener") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only listeners can update their rate",
      });
    }

    // Validation
    if (!ratePerMinute || isNaN(ratePerMinute)) {
      return res.status(400).json({
        error: "Invalid rate",
        message: "Rate per minute must be a valid number",
      });
    }

    const rate = parseFloat(ratePerMinute);

    if (rate < 0 || rate > 10) {
      return res.status(400).json({
        error: "Invalid rate",
        message: "Rate must be between $0.00 and $10.00 per minute",
      });
    }

    // Update rate
    await pool.query(
      `UPDATE listener_profiles 
       SET rate_per_minute = $1, updated_at = NOW()
       WHERE listener_id = $2`,
      [rate, listenerId],
    );

    logger.info(`Listener ${listenerId} updated rate to $${rate}/min`);

    res.json({
      success: true,
      message: "Rate updated successfully",
      ratePerMinute: rate,
    });
  } catch (error) {
    logger.error(`Error in updateRate: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to update rate",
    });
  }
}

/**
 * Get own listener status and profile
 * GET /api/v1/availability/status
 */
async function getStatus(req, res) {
  try {
    const listenerId = req.user.id;

    if (req.user.user_type !== "listener") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only listeners can check their status",
      });
    }

    const result = await pool.query(
      `SELECT 
        is_online,
        is_busy,
        rate_per_minute,
        total_sessions,
        average_rating,
        bio_anonymous,
        specialties,
        last_online_at,
        stripe_account_status,
        payout_enabled
       FROM listener_profiles
       WHERE listener_id = $1`,
      [listenerId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Profile not found",
        message: "Listener profile not found",
      });
    }

    const profile = result.rows[0];
    const currentSession = await presence.getListenerCurrentSession(listenerId);

    res.json({
      success: true,
      status: {
        isOnline: profile.is_online,
        isBusy: profile.is_busy,
        currentSessionId: currentSession,
        ratePerMinute: parseFloat(profile.rate_per_minute),
        totalSessions: profile.total_sessions,
        averageRating: parseFloat(profile.average_rating),
        bioAnonymous: profile.bio_anonymous,
        specialties: profile.specialties || [],
        lastOnlineAt: profile.last_online_at,
        stripeAccountStatus: profile.stripe_account_status,
        payoutEnabled: profile.payout_enabled,
      },
    });
  } catch (error) {
    logger.error(`Error in getStatus: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch status",
    });
  }
}

/**
 * Update listener bio and specialties
 * PUT /api/v1/availability/profile
 */
async function updateProfile(req, res) {
  try {
    const listenerId = req.user.id;
    const { bioAnonymous, specialties } = req.body;

    if (req.user.user_type !== "listener") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only listeners can update their profile",
      });
    }

    // Validation
    if (bioAnonymous && bioAnonymous.length > 500) {
      return res.status(400).json({
        error: "Bio too long",
        message: "Bio must be 500 characters or less",
      });
    }

    if (specialties && !Array.isArray(specialties)) {
      return res.status(400).json({
        error: "Invalid specialties",
        message: "Specialties must be an array",
      });
    }

    // Update profile
    await pool.query(
      `UPDATE listener_profiles 
       SET bio_anonymous = COALESCE($1, bio_anonymous),
           specialties = COALESCE($2, specialties),
           updated_at = NOW()
       WHERE listener_id = $3`,
      [bioAnonymous || null, specialties || null, listenerId],
    );

    logger.info(`Listener ${listenerId} updated profile`);

    res.json({
      success: true,
      message: "Profile updated successfully",
    });
  } catch (error) {
    logger.error(`Error in updateProfile: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to update profile",
    });
  }
}

module.exports = {
  goOnline,
  goOffline,
  heartbeat,
  getAvailableListeners,
  updateRate,
  getStatus,
  updateProfile,
};
