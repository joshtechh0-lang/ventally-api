const { pool } = require("../database/connection");
const presence = require("../services/presence");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const logger = require("../utils/logger");

const CALL_AUTO_END_STATUSES = [
  "requesting",
  "ringing",
  "active",
  "initiated",
  "in-progress",
];
const CHAT_AUTO_END_STATUSES = ["active", "requesting", "ringing"];

function normalizeReviewComment(rawComment) {
  if (rawComment === undefined || rawComment === null) {
    return null;
  }

  if (typeof rawComment === "string") {
    const trimmedComment = rawComment.trim();
    return trimmedComment.length > 0 ? trimmedComment : null;
  }

  if (
    typeof rawComment === "object" &&
    rawComment !== null &&
    typeof rawComment.text === "string"
  ) {
    const trimmedComment = rawComment.text.trim();
    return trimmedComment.length > 0 ? trimmedComment : null;
  }

  return undefined;
}

function withCommentCompatibility(review) {
  const commentText = review.comment ?? null;

  return {
    ...review,
    comment: commentText,
    commentText,
    commentObject: commentText === null ? null : { text: commentText },
  };
}

/**
 * Submit a review after a call or chat session
 * POST /api/v1/reviews
 */
async function submitReview(req, res) {
  const client = await pool.connect();

  try {
    const { sessionType, sessionId, revieweeId, rating, comment } = req.body;
    const reviewerId = req.user.id;
    const normalizedComment = normalizeReviewComment(comment);

    // Validate input
    if (!["call", "chat"].includes(sessionType)) {
      return res.status(400).json({
        error: "Validation error",
        message: "Session type must be 'call' or 'chat'",
      });
    }

    if (!sessionId || !revieweeId || !rating) {
      return res.status(400).json({
        error: "Validation error",
        message: "sessionId, revieweeId, and rating are required",
      });
    }

    if (normalizedComment === undefined) {
      return res.status(400).json({
        error: "Validation error",
        message: "Comment must be a string or an object with a text field",
      });
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({
        error: "Validation error",
        message: "Rating must be between 1 and 5",
      });
    }

    if (reviewerId === revieweeId) {
      return res.status(400).json({
        error: "Validation error",
        message: "Cannot review yourself",
      });
    }

    await client.query("BEGIN");

    // Verify session exists and reviewer was a participant.
    let participantCheck;
    let autoEndedSession = false;

    if (sessionType === "call") {
      participantCheck = await client.query(
        `SELECT id, venter_id, listener_id, status 
         FROM voice_calls 
         WHERE id = $1 AND (venter_id = $2 OR listener_id = $2)
         FOR UPDATE`,
        [sessionId, reviewerId],
      );
    } else {
      participantCheck = await client.query(
        `SELECT id, venter_id, listener_id, status 
         FROM conversations 
         WHERE id = $1 AND (venter_id = $2 OR listener_id = $2)
         FOR UPDATE`,
        [sessionId, reviewerId],
      );
    }

    if (participantCheck.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message:
          "You can only review sessions you participated in that have ended",
      });
    }

    let session = participantCheck.rows[0];

    if (session.status !== "ended") {
      const autoEndStatuses =
        sessionType === "call"
          ? CALL_AUTO_END_STATUSES
          : CHAT_AUTO_END_STATUSES;

      if (autoEndStatuses.includes(session.status)) {
        const updateQuery =
          sessionType === "call"
            ? `UPDATE voice_calls
               SET status = 'ended', ended_at = COALESCE(ended_at, NOW())
               WHERE id = $1
               RETURNING id, venter_id, listener_id, status`
            : `UPDATE conversations
               SET status = 'ended', ended_at = COALESCE(ended_at, NOW())
               WHERE id = $1
               RETURNING id, venter_id, listener_id, status`;

        const updateResult = await client.query(updateQuery, [sessionId]);
        session = updateResult.rows[0];
        autoEndedSession = true;
      }
    }

    if (session.status !== "ended") {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Forbidden",
        message:
          "You can only review sessions you participated in that have ended",
      });
    }

    // Verify reviewee was also in the session
    if (
      revieweeId !== session.venter_id &&
      revieweeId !== session.listener_id
    ) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Validation error",
        message: "Reviewee must be a participant in the session",
      });
    }

    // Check if review already exists
    const existingReview = await client.query(
      `SELECT id FROM session_reviews 
       WHERE session_id = $1 AND reviewer_id = $2 AND reviewee_id = $3`,
      [sessionId, reviewerId, revieweeId],
    );

    if (existingReview.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Conflict",
        message: "You have already reviewed this user for this session",
      });
    }

    // Insert review
    const result = await client.query(
      `INSERT INTO session_reviews 
       (session_type, session_id, reviewer_id, reviewee_id, rating, comment)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, created_at`,
      [
        sessionType,
        sessionId,
        reviewerId,
        revieweeId,
        rating,
        normalizedComment,
      ],
    );

    // Update reviewee's average rating
    const avgResult = await client.query(
      `SELECT AVG(rating)::DECIMAL(3,2) as avg_rating,
              COUNT(*)::INTEGER as total_reviews
       FROM session_reviews 
       WHERE reviewee_id = $1`,
      [revieweeId],
    );

    const { avg_rating, total_reviews } = avgResult.rows[0];

    // Update listener_profiles if reviewee is a listener
    await client.query(
      `UPDATE listener_profiles 
       SET average_rating = $1,
           total_reviews = $2
       WHERE listener_id = $3`,
      [avg_rating || 0, total_reviews || 0, revieweeId],
    );

    await client.query("COMMIT");

    if (autoEndedSession) {
      if (sessionType === "call") {
        try {
          await stopBalanceMonitoring(sessionId);
        } catch (monitorError) {
          logger.warn("Failed stopping balance monitor after review auto-end", {
            sessionId,
            error: monitorError.message,
          });
        }
      }

      await presence.clearListenerBusy(session.listener_id);
    }

    logger.info(
      `Review submitted by ${reviewerId} for ${revieweeId} on ${sessionType} ${sessionId}`,
    );

    res.status(201).json({
      success: true,
      review: withCommentCompatibility({
        id: result.rows[0].id,
        sessionType,
        sessionId,
        revieweeId,
        rating,
        comment: normalizedComment,
        createdAt: result.rows[0].created_at,
      }),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error(`Error submitting review: ${error.message}`, { error });
    res.status(500).json({
      error: "Server error",
      message: "Failed to submit review",
    });
  } finally {
    client.release();
  }
}

/**
 * Get reviews received by a user (listener profile)
 * GET /api/v1/reviews/:userId
 */
async function getUserReviews(req, res) {
  try {
    const { userId } = req.params;
    const { limit = 20, offset = 0 } = req.query;

    // Get reviews
    const result = await pool.query(
      `SELECT 
         sr.id,
         sr.session_type,
         sr.session_id,
         sr.rating,
         sr.comment,
         sr.created_at
       FROM session_reviews sr
       WHERE sr.reviewee_id = $1
       ORDER BY sr.created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, parseInt(limit), parseInt(offset)],
    );

    // Get summary stats
    const statsResult = await pool.query(
      `SELECT 
         AVG(rating)::DECIMAL(3,2) as average_rating,
         COUNT(*) as total_reviews,
         COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star,
         COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star,
         COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star,
         COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star,
         COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star
       FROM session_reviews 
       WHERE reviewee_id = $1`,
      [userId],
    );

    const stats = statsResult.rows[0];
    const statsPayload = {
      averageRating: parseFloat(stats.average_rating) || 0,
      totalReviews: parseInt(stats.total_reviews) || 0,
      distribution: {
        5: parseInt(stats.five_star) || 0,
        4: parseInt(stats.four_star) || 0,
        3: parseInt(stats.three_star) || 0,
        2: parseInt(stats.two_star) || 0,
        1: parseInt(stats.one_star) || 0,
      },
    };
    const reviews = result.rows.map(withCommentCompatibility);

    res.json({
      success: true,
      reviews,
      stats: statsPayload,
      statistics: statsPayload,
      pagination: {
        limit: parseInt(limit),
        offset: parseInt(offset),
        total: parseInt(stats.total_reviews) || 0,
      },
    });
  } catch (error) {
    logger.error(`Error fetching user reviews: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch reviews",
    });
  }
}

/**
 * Get review for a specific session
 * GET /api/v1/reviews/session/:sessionType/:sessionId
 */
async function getSessionReviews(req, res) {
  try {
    const { sessionType, sessionId } = req.params;
    const userId = req.user.id;

    if (!["call", "chat"].includes(sessionType)) {
      return res.status(400).json({
        error: "Validation error",
        message: "Session type must be 'call' or 'chat'",
      });
    }

    // Get reviews for this session (both directions if mutual)
    const result = await pool.query(
      `SELECT 
         sr.id,
         sr.reviewer_id,
         sr.reviewee_id,
         sr.rating,
         sr.comment,
         sr.created_at,
         CASE WHEN sr.reviewer_id = $2 THEN true ELSE false END as is_my_review
       FROM session_reviews sr
       WHERE sr.session_type = $1 AND sr.session_id = $3
       ORDER BY sr.created_at DESC`,
      [sessionType, userId, sessionId],
    );

    const reviews = result.rows.map(withCommentCompatibility);

    res.json({
      success: true,
      reviews,
    });
  } catch (error) {
    logger.error(`Error fetching session reviews: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch session reviews",
    });
  }
}

/**
 * Check if user can review a session
 * GET /api/v1/reviews/can-review/:sessionType/:sessionId
 */
async function canReviewSession(req, res) {
  try {
    const { sessionType, sessionId } = req.params;
    const userId = req.user.id;

    if (!["call", "chat"].includes(sessionType)) {
      return res.status(400).json({
        error: "Validation error",
        message: "Session type must be 'call' or 'chat'",
      });
    }

    // Check if session exists and user was participant
    let sessionQuery;
    if (sessionType === "call") {
      sessionQuery = await pool.query(
        `SELECT venter_id, listener_id, status 
         FROM voice_calls 
         WHERE id = $1 AND (venter_id = $2 OR listener_id = $2)`,
        [sessionId, userId],
      );
    } else {
      sessionQuery = await pool.query(
        `SELECT venter_id, listener_id, status 
         FROM conversations 
         WHERE id = $1 AND (venter_id = $2 OR listener_id = $2)`,
        [sessionId, userId],
      );
    }

    if (sessionQuery.rows.length === 0) {
      return res.json({
        canReview: false,
        reason: "Session not found or you were not a participant",
      });
    }

    const session = sessionQuery.rows[0];

    if (session.status !== "ended") {
      return res.json({
        canReview: false,
        reason: "Session must be ended before you can review",
      });
    }

    // Determine the other participant
    const otherUserId =
      userId === session.venter_id ? session.listener_id : session.venter_id;

    // Check if already reviewed
    const existingReview = await pool.query(
      `SELECT id FROM session_reviews 
       WHERE session_id = $1 AND reviewer_id = $2 AND reviewee_id = $3`,
      [sessionId, userId, otherUserId],
    );

    if (existingReview.rows.length > 0) {
      return res.json({
        canReview: false,
        reason: "You have already reviewed this session",
      });
    }

    res.json({
      canReview: true,
      otherUserId: otherUserId,
    });
  } catch (error) {
    logger.error(`Error checking review eligibility: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to check review eligibility",
    });
  }
}

module.exports = {
  submitReview,
  getUserReviews,
  getSessionReviews,
  canReviewSession,
};
