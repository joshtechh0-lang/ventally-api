const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const {
  ListenerPayoutError,
  createBankAccountOnboardingLink,
  createBankAccountSession: createListenerBankAccountSession,
  getBankAccountStatus: getListenerBankAccountStatus,
  requestWithdrawal: requestListenerWithdrawal,
} = require("../services/listenerPayoutService");

function getCurrentRole(user) {
  return user.activeRole || user.active_role || user.user_type;
}

function hasListenerRole(user) {
  const currentRole = getCurrentRole(user);
  if (currentRole === "listener") {
    return true;
  }

  const availableRoles = user.availableRoles || user.available_roles;
  if (Array.isArray(availableRoles)) {
    return availableRoles.includes("listener");
  }

  return false;
}

/**
 * Get listener earnings summary
 * GET /api/v1/earnings/summary
 */
async function getEarningsSummary(req, res) {
  try {
    const listenerId = req.user.id;

    // Verify user is in listener role (check active_role first, fallback to user_type)
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can view earnings. Your current role is " +
          currentRole,
      });
    }

    const result = await pool.query(
      `SELECT 
        COALESCE(SUM(CASE WHEN status = 'pending' THEN net_amount - COALESCE(paid_amount, 0) ELSE 0 END), 0) as pending_balance,
        COALESCE(SUM(CASE WHEN status = 'available' THEN net_amount - COALESCE(paid_amount, 0) ELSE 0 END), 0) as available_balance,
        COALESCE(SUM(COALESCE(paid_amount, 0)), 0) as total_paid,
        COALESCE(SUM(net_amount), 0) as lifetime_earnings,
        COUNT(*) FILTER (
          WHERE status IN ('pending', 'available')
            AND (net_amount - COALESCE(paid_amount, 0)) > 0
        ) as pending_sessions,
        COUNT(*) as total_sessions
       FROM listener_earnings
       WHERE listener_id = $1`,
      [listenerId],
    );

    const summary = result.rows[0];

    res.json({
      pendingBalance: parseFloat(summary.pending_balance),
      availableBalance: parseFloat(summary.available_balance),
      totalPaid: parseFloat(summary.total_paid),
      lifetimeEarnings: parseFloat(summary.lifetime_earnings),
      pendingSessions: parseInt(summary.pending_sessions),
      totalSessions: parseInt(summary.total_sessions),
    });
  } catch (error) {
    logger.error(`Error in getEarningsSummary: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch earnings summary",
    });
  }
}

/**
 * Get listener earnings transactions
 * GET /api/v1/earnings
 */
async function getEarnings(req, res) {
  try {
    const listenerId = req.user.id;
    const { limit = 50, offset = 0, status, sessionType } = req.query;

    // Verify user is in listener role (check active_role first, fallback to user_type)
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can view earnings. Your current role is " +
          currentRole,
      });
    }

    // Build query with filters
    let query = `
      SELECT 
        id,
        session_type,
        session_id,
        gross_amount,
        platform_fee,
        net_amount,
        COALESCE(paid_amount, 0) AS paid_amount,
        platform_fee_percentage,
        status,
        payout_id,
        created_at
      FROM listener_earnings
      WHERE listener_id = $1
    `;
    const params = [listenerId];
    let paramCount = 1;

    if (status) {
      paramCount++;
      query += ` AND status = $${paramCount}`;
      params.push(status);
    }

    if (sessionType) {
      paramCount++;
      query += ` AND session_type = $${paramCount}`;
      params.push(sessionType);
    }

    query += ` ORDER BY created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Get total count
    let countQuery = `
      SELECT COUNT(*) as total
      FROM listener_earnings
      WHERE listener_id = $1
    `;
    const countParams = [listenerId];
    let countParamCount = 1;

    if (status) {
      countParamCount++;
      countQuery += ` AND status = $${countParamCount}`;
      countParams.push(status);
    }

    if (sessionType) {
      countParamCount++;
      countQuery += ` AND session_type = $${countParamCount}`;
      countParams.push(sessionType);
    }

    const countResult = await pool.query(countQuery, countParams);
    const total = parseInt(countResult.rows[0].total);

    const earnings = result.rows.map((row) => ({
      id: row.id,
      sessionType: row.session_type,
      sessionId: row.session_id,
      grossAmount: parseFloat(row.gross_amount),
      platformFee: parseFloat(row.platform_fee),
      netAmount: parseFloat(row.net_amount),
      paidAmount: parseFloat(row.paid_amount),
      remainingAmount: parseFloat(row.net_amount) - parseFloat(row.paid_amount),
      platformFeePercentage: parseFloat(row.platform_fee_percentage),
      status: row.status,
      payoutId: row.payout_id,
      createdAt: row.created_at,
    }));

    res.json({
      earnings,
      pagination: {
        total,
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: offset + earnings.length < total,
      },
    });
  } catch (error) {
    logger.error(`Error in getEarnings: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch earnings",
    });
  }
}

/**
 * Get listener payout history
 * GET /api/v1/earnings/payouts
 */
async function getPayouts(req, res) {
  try {
    const listenerId = req.user.id;
    const { limit = 50, offset = 0, status } = req.query;

    // Verify user is in listener role (check active_role first, fallback to user_type)
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can view payouts. Your current role is " +
          currentRole,
      });
    }

    // Build query with filters
    let query = `
      SELECT 
        id,
        amount,
        stripe_transfer_id,
        status,
        failure_reason,
        processed_at,
        created_at
      FROM listener_payouts
      WHERE listener_id = $1
    `;
    const params = [listenerId];
    let paramCount = 1;

    if (status) {
      paramCount++;
      query += ` AND status = $${paramCount}`;
      params.push(status);
    }

    query += ` ORDER BY created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Get total count
    let countQuery = `
      SELECT COUNT(*) as total
      FROM listener_payouts
      WHERE listener_id = $1
    `;
    const countParams = [listenerId];

    if (status) {
      countQuery += ` AND status = $2`;
      countParams.push(status);
    }

    const countResult = await pool.query(countQuery, countParams);
    const total = parseInt(countResult.rows[0].total);

    const payouts = result.rows.map((row) => ({
      id: row.id,
      amount: parseFloat(row.amount),
      stripeTransferId: row.stripe_transfer_id,
      status: row.status,
      failureReason: row.failure_reason,
      processedAt: row.processed_at,
      createdAt: row.created_at,
    }));

    res.json({
      payouts,
      pagination: {
        total,
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: offset + payouts.length < total,
      },
    });
  } catch (error) {
    logger.error(`Error in getPayouts: ${error.message}`);
    res.status(500).json({
      error: "Server error",
      message: "Failed to fetch payouts",
    });
  }
}

/**
 * Request withdrawal for listener earnings
 * POST /api/v1/earnings/withdraw
 */
async function requestWithdrawal(req, res) {
  try {
    const listenerId = req.user.id;
    const requestedAmount = req.body?.amount;
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can request withdrawals. Your current role is " +
          currentRole,
      });
    }

    const payout = await requestListenerWithdrawal(listenerId, requestedAmount);

    return res.status(201).json({
      success: true,
      payout: {
        id: payout.payoutId,
        amount: payout.amount,
        requestedAmount: payout.requestedAmount,
        processedAmount: payout.processedAmount,
        status: payout.status,
        stripeTransferId: payout.stripeTransferId,
        createdAt: payout.createdAt,
        processedAt: payout.processedAt,
        earningsCount: payout.earningsCount,
        allocationCount: payout.allocationCount,
      },
    });
  } catch (error) {
    if (error instanceof ListenerPayoutError) {
      return res.status(error.statusCode).json({
        error: error.code,
        message: error.message,
        details: error.details || undefined,
      });
    }

    logger.error(`Error in requestWithdrawal: ${error.message}`);
    return res.status(500).json({
      error: "Server error",
      message: "Failed to process withdrawal request",
    });
  }
}

/**
 * Create Stripe onboarding link for listener bank account
 * POST /api/v1/earnings/bank-account/link
 */
async function createBankAccountLink(req, res) {
  try {
    const listenerId = req.user.id;
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can setup payout accounts. Your current role is " +
          currentRole,
      });
    }

    const bankLink = await createBankAccountOnboardingLink(listenerId, {
      platform: req.body?.platform,
      returnUrl: req.body?.returnUrl,
      refreshUrl: req.body?.refreshUrl,
    });

    return res.json({
      success: true,
      bankLink,
    });
  } catch (error) {
    if (error instanceof ListenerPayoutError) {
      return res.status(error.statusCode).json({
        error: error.code,
        message: error.message,
        details: error.details || undefined,
      });
    }

    logger.error(`Error in createBankAccountLink: ${error.message}`);
    return res.status(500).json({
      error: "Server error",
      message: "Failed to create bank-account onboarding link",
    });
  }
}

/**
 * Create a Stripe Account Session for embedded bank-account onboarding.
 * POST /api/v1/earnings/bank-account/session
 *
 * Returns a client_secret the mobile app feeds to Stripe's embedded Account
 * Onboarding component. The mobile client excludes the business_type
 * requirement client-side so individual listeners skip the "Business type"
 * screen that hosted onboarding can't hide.
 */
async function createBankAccountSession(req, res) {
  try {
    const listenerId = req.user.id;
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can setup payout accounts. Your current role is " +
          currentRole,
      });
    }

    const session = await createListenerBankAccountSession(listenerId);

    return res.json({
      success: true,
      session,
    });
  } catch (error) {
    if (error instanceof ListenerPayoutError) {
      return res.status(error.statusCode).json({
        error: error.code,
        message: error.message,
        details: error.details || undefined,
      });
    }

    logger.error(`Error in createBankAccountSession: ${error.message}`);
    return res.status(500).json({
      error: "Server error",
      message: "Failed to create bank-account onboarding session",
    });
  }
}

/**
 * Get listener bank account status
 * GET /api/v1/earnings/bank-account/status
 */
async function getBankAccountStatus(req, res) {
  try {
    const listenerId = req.user.id;
    const currentRole = getCurrentRole(req.user);

    if (!hasListenerRole(req.user)) {
      return res.status(403).json({
        error: "Permission denied",
        message:
          "Only listeners can view bank-account status. Your current role is " +
          currentRole,
      });
    }

    const status = await getListenerBankAccountStatus(listenerId);

    return res.json({
      success: true,
      status,
    });
  } catch (error) {
    if (error instanceof ListenerPayoutError) {
      return res.status(error.statusCode).json({
        error: error.code,
        message: error.message,
        details: error.details || undefined,
      });
    }

    logger.error(`Error in getBankAccountStatus: ${error.message}`);
    return res.status(500).json({
      error: "Server error",
      message: "Failed to fetch bank-account status",
    });
  }
}

module.exports = {
  createBankAccountLink,
  createBankAccountSession,
  getBankAccountStatus,
  getEarningsSummary,
  getEarnings,
  getPayouts,
  requestWithdrawal,
};
