const { pool } = require("../database/connection");
const logger = require("../utils/logger");
const {
  getAchievements,
  getDaysSoberFromDate,
} = require("./sobrietyController");

async function getVenterHomeSummary(req, res) {
  try {
    if (req.user.user_type !== "venter") {
      return res.status(403).json({
        error: "Permission denied",
        message: "Only venter profiles can access home summary",
      });
    }

    const userId = req.user.id;
    const { limit = 10 } = req.query;

    const [sobrietyResult, latestMoodResult, entriesResult] = await Promise.all(
      [
        pool.query(
          `SELECT sober_start_date, last_relapse_date, notes, created_at, updated_at
         FROM sobriety_profiles
         WHERE user_id = $1`,
          [userId],
        ),
        pool.query(
          `SELECT mood_type, category, notes, logged_date
         FROM mood_logs
         WHERE user_id = $1
         ORDER BY logged_date DESC, created_at DESC
         LIMIT 1`,
          [userId],
        ),
        pool.query(
          `SELECT * FROM (
          SELECT
            m.id::text AS id,
            'mood'::text AS entry_type,
            m.logged_date AS entry_date,
            m.created_at,
            m.mood_type AS title,
            m.notes AS content,
            m.category,
            m.mood_type,
            NULL::uuid AS mood_log_id
          FROM mood_logs m
          WHERE m.user_id = $1

          UNION ALL

          SELECT
            r.id::text AS id,
            'reflection'::text AS entry_type,
            r.reflection_date AS entry_date,
            r.created_at,
            COALESCE(m.mood_type, 'Reflection') AS title,
            r.reflection_text AS content,
            m.category,
            m.mood_type,
            r.mood_log_id
          FROM reflections r
          LEFT JOIN mood_logs m ON m.id = r.mood_log_id
          WHERE r.user_id = $1
        ) merged
        ORDER BY entry_date DESC, created_at DESC
        LIMIT $2`,
          [userId, parseInt(limit)],
        ),
      ],
    );

    const profile = sobrietyResult.rows[0] || null;
    const daysSober = profile
      ? getDaysSoberFromDate(profile.sober_start_date)
      : 0;
    const achievements = getAchievements(daysSober);

    const latestMood = latestMoodResult.rows[0] || null;
    const feelingSummary = latestMood
      ? `Feeling ${latestMood.mood_type}`
      : null;

    res.json({
      message: "Venter home summary retrieved successfully",
      progress: {
        tracking_enabled: !!profile,
        days_sober: daysSober,
        sober_start_date: profile?.sober_start_date || null,
        last_relapse_date: profile?.last_relapse_date || null,
      },
      highlights: {
        feeling: feelingSummary,
        latest_mood_date: latestMood?.logged_date || null,
        achievements_count: achievements.length,
      },
      achievements,
      recent_entries: entriesResult.rows,
    });
  } catch (error) {
    logger.error("Error fetching venter home summary:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch venter home summary",
    });
  }
}

module.exports = {
  getVenterHomeSummary,
};
