const {
  getSetting,
  setSetting,
  clearSettingsCache,
} = require("../services/settings");
const logger = require("../utils/logger");

const AI_SETTINGS_SCHEMA = {
  ai_enabled: {
    type: "boolean",
    defaultValue: false,
    description: "Enable or disable AI features platform-wide",
  },
  ai_crisis_detection_enabled: {
    type: "boolean",
    defaultValue: false,
    description: "Enable AI-assisted crisis signal detection",
  },
  ai_crisis_sensitivity: {
    type: "number",
    defaultValue: 0.7,
    min: 0,
    max: 1,
    description: "AI crisis detection sensitivity threshold from 0.0 to 1.0",
  },
  ai_auto_escalation_enabled: {
    type: "boolean",
    defaultValue: false,
    description:
      "Enable automatic escalation when AI detects high-risk content",
  },
  ai_moderation_enabled: {
    type: "boolean",
    defaultValue: false,
    description: "Enable AI-assisted content moderation for chat messages",
  },
  ai_moderation_level_threshold: {
    type: "number",
    defaultValue: 2,
    min: 1,
    max: 4,
    description: "Minimum moderation level (1–4) to log to the audit trail",
  },
};

function normalizeValue(key, value) {
  const config = AI_SETTINGS_SCHEMA[key];

  if (!config) {
    return { valid: false, message: `Unsupported setting key: ${key}` };
  }

  if (config.type === "boolean") {
    if (typeof value !== "boolean") {
      return { valid: false, message: `${key} must be a boolean` };
    }

    return { valid: true, normalizedValue: value };
  }

  if (config.type === "number") {
    if (typeof value !== "number" || Number.isNaN(value)) {
      return { valid: false, message: `${key} must be a number` };
    }

    if (config.min !== undefined && value < config.min) {
      return {
        valid: false,
        message: `${key} must be greater than or equal to ${config.min}`,
      };
    }

    if (config.max !== undefined && value > config.max) {
      return {
        valid: false,
        message: `${key} must be less than or equal to ${config.max}`,
      };
    }

    return { valid: true, normalizedValue: value };
  }

  return { valid: false, message: `Unsupported setting type for ${key}` };
}

async function getAiSettings(req, res) {
  try {
    const settings = {};

    for (const [key, config] of Object.entries(AI_SETTINGS_SCHEMA)) {
      settings[key] = await getSetting(key, config.defaultValue);
    }

    return res.status(200).json({
      success: true,
      settings,
    });
  } catch (error) {
    logger.error("Failed to fetch AI settings", { error: error.message });
    return res.status(500).json({
      error: "Server error",
      message: "Failed to fetch AI settings",
    });
  }
}

async function updateAiSettings(req, res) {
  try {
    const payload = req.body;

    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
      return res.status(400).json({
        error: "Validation error",
        message: "Request body must be a JSON object",
      });
    }

    const incomingKeys = Object.keys(payload);

    if (incomingKeys.length === 0) {
      return res.status(400).json({
        error: "Validation error",
        message: "At least one setting is required",
      });
    }

    const updates = [];

    for (const key of incomingKeys) {
      const normalized = normalizeValue(key, payload[key]);

      if (!normalized.valid) {
        return res.status(400).json({
          error: "Validation error",
          message: normalized.message,
        });
      }

      updates.push({
        key,
        value: normalized.normalizedValue,
        description: AI_SETTINGS_SCHEMA[key].description,
      });
    }

    for (const update of updates) {
      const saved = await setSetting(
        update.key,
        update.value,
        update.description,
      );

      if (!saved) {
        return res.status(500).json({
          error: "Server error",
          message: `Failed to update ${update.key}`,
        });
      }
    }

    await clearSettingsCache();

    const settings = {};
    for (const [key, config] of Object.entries(AI_SETTINGS_SCHEMA)) {
      settings[key] = await getSetting(key, config.defaultValue);
    }

    return res.status(200).json({
      success: true,
      message: "AI settings updated successfully",
      settings,
    });
  } catch (error) {
    logger.error("Failed to update AI settings", { error: error.message });
    return res.status(500).json({
      error: "Server error",
      message: "Failed to update AI settings",
    });
  }
}

module.exports = {
  getAiSettings,
  updateAiSettings,
};
