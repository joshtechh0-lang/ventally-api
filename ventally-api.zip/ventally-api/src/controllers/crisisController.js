const { pool } = require("../database/connection");
const crisisService = require("../services/crisisService");
const { stopBalanceMonitoring } = require("../services/balanceMonitor");
const logger = require("../utils/logger");

const VALID_RISK_CATEGORIES = [
  "self_harm",
  "suicide",
  "harm_to_others",
  "severe_distress",
  "other",
];

function getRoleFromRequest(req) {
  return req.user.activeRole || req.user.active_role || req.user.user_type;
}

function getVoiceCallIdFromBody(req) {
  return req.body.voiceCallId || req.body.callLogId;
}

function getVoiceCallIdFromParams(req) {
  return req.params.voiceCallId || req.params.callLogId;
}

/**
 * Escalate a call to crisis status (manual trigger by listener)
 * POST /api/v1/crisis/escalate
 */
async function escalateCall(req, res) {
  const client = await pool.connect();

  try {
    const voiceCallId = getVoiceCallIdFromBody(req);
    const { riskCategory, notes } = req.body;
    const listenerId = req.user.id;

    // Validate required fields
    if (!voiceCallId || !riskCategory) {
      return res.status(400).json({
        error: "Missing required fields",
        message: "voiceCallId and riskCategory are required",
      });
    }

    // Validate risk category
    if (!VALID_RISK_CATEGORIES.includes(riskCategory)) {
      return res.status(400).json({
        error: "Invalid risk category",
        message: `Must be one of: ${VALID_RISK_CATEGORIES.join(", ")}`,
      });
    }

    await client.query("BEGIN");

    // Get call details
    const callResult = await client.query(
      `SELECT vc.*, vc.venter_id, vc.listener_id, vc.status as call_status
       FROM voice_calls vc
       WHERE vc.id = $1`,
      [voiceCallId],
    );

    if (callResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Call not found",
        message: "Voice call does not exist",
      });
    }

    const call = callResult.rows[0];

    // Verify requester is the listener on this call
    if (call.listener_id !== listenerId) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Unauthorized",
        message: "Only the listener on this call can escalate to crisis",
      });
    }

    // Check if already escalated
    const isEscalated = await crisisService.isCallEscalated(voiceCallId);
    if (isEscalated) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Already escalated",
        message: "This call has already been escalated to crisis status",
      });
    }

    // Mark call as crisis escalated
    await crisisService.markCallAsCrisisEscalated(voiceCallId);

    // Log crisis event
    const crisisEvent = await crisisService.logCrisisEvent({
      voiceCallId,
      sessionType: "call",
      sessionId: voiceCallId,
      userId: call.venter_id,
      triggerType: "manual",
      riskCategory,
      detectedPhrases: notes ? [notes] : [],
      actionTaken: "escalated",
      manualTrigger: true,
      triggeredBy: listenerId,
    });

    await client.query("COMMIT");

    logger.info(
      `Crisis escalation triggered by listener ${listenerId} for call ${voiceCallId}`,
      { riskCategory },
    );

    // Emit socket event to both parties
    const io = req.app.get("io");
    const roomName = `call:${voiceCallId}`;

    io.to(roomName).emit("crisis:escalated", {
      voiceCallId,
      riskCategory,
      escalatedAt: crisisEvent.created_at,
      message: "Call has been escalated to crisis status",
    });

    res.json({
      success: true,
      message: "Call escalated to crisis status",
      crisisEvent: {
        id: crisisEvent.id,
        riskCategory: crisisEvent.risk_category,
        escalatedAt: crisisEvent.created_at,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error escalating call to crisis:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to escalate call",
    });
  } finally {
    client.release();
  }
}

/**
 * Handoff call to 988 crisis line
 * POST /api/v1/crisis/handoff-988
 */
async function handoff988(req, res) {
  const client = await pool.connect();

  try {
    const voiceCallId = getVoiceCallIdFromBody(req);
    const { reason } = req.body;
    const listenerId = req.user.id;

    // Validate required fields
    if (!voiceCallId) {
      return res.status(400).json({
        error: "Missing required field",
        message: "voiceCallId is required",
      });
    }

    await client.query("BEGIN");

    // Get call details
    const callResult = await client.query(
      `SELECT id, venter_id, listener_id, status, 
              twilio_room_name, twilio_call_sid, crisis_escalated
       FROM voice_calls
       WHERE id = $1`,
      [voiceCallId],
    );

    if (callResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        error: "Call not found",
        message: "Voice call does not exist",
      });
    }

    const call = callResult.rows[0];

    // Verify requester is the listener on this call
    if (call.listener_id !== listenerId) {
      await client.query("ROLLBACK");
      return res.status(403).json({
        error: "Unauthorized",
        message: "Only the listener on this call can initiate 988 handoff",
      });
    }

    // Verify call has been escalated first
    const isEscalated = await crisisService.isCallEscalated(voiceCallId);
    if (!isEscalated) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        error: "Crisis not escalated",
        message:
          "Call must be escalated to crisis status before 988 handoff can be initiated",
      });
    }

    // Check if 988 handoff already occurred
    const hasHandoffOccurred =
      await crisisService.hasHandoff988Occurred(voiceCallId);
    if (hasHandoffOccurred) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: "Already transferred",
        message: "This call has already been transferred to 988",
      });
    }

    // Log 988 handoff event
    const crisisEvent = await crisisService.logCrisisEvent({
      voiceCallId,
      sessionType: "call",
      sessionId: voiceCallId,
      userId: call.venter_id,
      triggerType: "manual",
      riskCategory: "988_transfer",
      detectedPhrases: reason ? [reason] : [],
      actionTaken: "988_handoff",
      manualTrigger: true,
      triggeredBy: listenerId,
    });

    // Update call status
    await client.query(
      `UPDATE voice_calls 
       SET status = 'transferred_988' 
       WHERE id = $1`,
      [call.id],
    );

    // Stop balance monitoring (no charge during crisis transfer)
    stopBalanceMonitoring(call.id);

    await client.query("COMMIT");

    logger.info(
      `988 handoff initiated by listener ${listenerId} for call ${voiceCallId}`,
    );

    // In a production environment, you would integrate with Twilio to transfer the call
    // For now, we'll emit a socket event to notify the parties
    const io = req.app.get("io");
    const roomName = `call:${call.id}`;

    io.to(roomName).emit("crisis:988-handoff", {
      voiceCallId,
      handoffAt: crisisEvent.created_at,
      message:
        "Call is being transferred to 988 Suicide & Crisis Lifeline. Please hold.",
    });

    res.json({
      success: true,
      message: "Call transfer to 988 initiated",
      handoff: {
        id: crisisEvent.id,
        handoffAt: crisisEvent.created_at,
        crisis988Number: "988",
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    logger.error("Error initiating 988 handoff:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to initiate 988 handoff",
    });
  } finally {
    client.release();
  }
}

/**
 * Get crisis events for a call
 * GET /api/v1/crisis/events/:voiceCallId
 */
async function getCrisisEvents(req, res) {
  try {
    const voiceCallId = getVoiceCallIdFromParams(req);
    const userId = req.user.id;

    // Get call details to verify access
    const callResult = await pool.query(
      `SELECT venter_id, listener_id
       FROM voice_calls
       WHERE id = $1`,
      [voiceCallId],
    );

    if (callResult.rows.length === 0) {
      return res.status(404).json({
        error: "Call not found",
        message: "Voice call does not exist",
      });
    }

    const call = callResult.rows[0];

    // Verify user is part of this call or is admin
    if (
      call.venter_id !== userId &&
      call.listener_id !== userId &&
      !["admin", "sub_admin"].includes(getRoleFromRequest(req))
    ) {
      return res.status(403).json({
        error: "Unauthorized",
        message: "You do not have access to this call's crisis events",
      });
    }

    const events = await crisisService.getCrisisEvents(voiceCallId);

    res.json({
      success: true,
      voiceCallId,
      events,
    });
  } catch (error) {
    logger.error("Error fetching crisis events:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to fetch crisis events",
    });
  }
}

/**
 * Record a crisis-help escalation event for a call/chat session (listener only)
 * POST /api/v1/crisis/escalation-event
 */
async function recordEscalationEvent(req, res) {
  try {
    const { sessionType, sessionId, riskCategory, notes } = req.body;
    const listenerId = req.user.id;

    if (!sessionType || !sessionId || !riskCategory) {
      return res.status(400).json({
        error: "Missing required fields",
        message: "sessionType, sessionId, and riskCategory are required",
      });
    }

    if (!["call", "chat"].includes(sessionType)) {
      return res.status(400).json({
        error: "Invalid session type",
        message: "sessionType must be one of: call, chat",
      });
    }

    if (!VALID_RISK_CATEGORIES.includes(riskCategory)) {
      return res.status(400).json({
        error: "Invalid risk category",
        message: `Must be one of: ${VALID_RISK_CATEGORIES.join(", ")}`,
      });
    }

    const session = await crisisService.getSessionParticipants(
      sessionType,
      sessionId,
    );

    if (!session) {
      return res.status(404).json({
        error: "Session not found",
        message: "Referenced session does not exist",
      });
    }

    if (session.listener_id !== listenerId) {
      return res.status(403).json({
        error: "Unauthorized",
        message: "Only the listener on this session can record escalation",
      });
    }

    const hasEscalation = await crisisService.hasHelpEscalationOccurred(
      sessionType,
      sessionId,
    );

    if (hasEscalation) {
      return res.status(409).json({
        error: "Already escalated",
        message:
          "A crisis help escalation event already exists for this session",
      });
    }

    if (sessionType === "call") {
      await crisisService.markCallAsCrisisEscalated(sessionId);
    }

    const crisisEvent = await crisisService.logCrisisEvent({
      voiceCallId: sessionType === "call" ? sessionId : null,
      sessionType,
      sessionId,
      userId: session.venter_id,
      triggerType: "manual",
      riskCategory,
      detectedPhrases: notes ? [notes] : [],
      actionTaken: "help_escalated",
      manualTrigger: true,
      triggeredBy: listenerId,
    });

    logger.info("Crisis help escalation event recorded", {
      sessionType,
      sessionId,
      listenerId,
      riskCategory,
    });

    const io = req.app.get("io");
    const roomName = `${sessionType === "call" ? "call" : "chat"}:${sessionId}`;

    io.to(roomName).emit("crisis:help-escalated", {
      sessionType,
      sessionId,
      riskCategory,
      escalatedAt: crisisEvent.created_at,
      message: "Crisis help escalation has been recorded",
    });

    return res.status(201).json({
      success: true,
      message: "Crisis help escalation recorded",
      crisisEvent: {
        id: crisisEvent.id,
        sessionType: crisisEvent.session_type,
        sessionId: crisisEvent.session_id,
        riskCategory: crisisEvent.risk_category,
        actionTaken: crisisEvent.action_taken,
        createdAt: crisisEvent.created_at,
      },
    });
  } catch (error) {
    logger.error("Error recording crisis escalation event:", error);
    return res.status(500).json({
      error: "Internal server error",
      message: "Failed to record crisis escalation event",
    });
  }
}

/**
 * Get crisis event analytics for admin reporting
 * GET /api/v1/crisis/admin/stats
 */
async function getCrisisAdminStats(req, res) {
  try {
    const { from, to, sessionType, actionTaken, riskCategory } = req.query;

    if (sessionType && !["call", "chat"].includes(sessionType)) {
      return res.status(400).json({
        error: "Validation error",
        message: "sessionType must be one of: call, chat",
      });
    }

    if (riskCategory && !VALID_RISK_CATEGORIES.includes(riskCategory)) {
      return res.status(400).json({
        error: "Validation error",
        message: `riskCategory must be one of: ${VALID_RISK_CATEGORIES.join(", ")}`,
      });
    }

    const stats = await crisisService.getCrisisAdminStats({
      from: from || null,
      to: to || null,
      sessionType: sessionType || null,
      actionTaken: actionTaken || null,
      riskCategory: riskCategory || null,
    });

    return res.json({
      success: true,
      filters: {
        from: from || null,
        to: to || null,
        sessionType: sessionType || null,
        actionTaken: actionTaken || null,
        riskCategory: riskCategory || null,
      },
      stats,
    });
  } catch (error) {
    logger.error("Error fetching crisis admin stats:", error);
    return res.status(500).json({
      error: "Server error",
      message: "Failed to fetch crisis analytics",
    });
  }
}

module.exports = {
  escalateCall,
  handoff988,
  recordEscalationEvent,
  getCrisisEvents,
  getCrisisAdminStats,
};
