const logger = require("../utils/logger");
const {
  TipError,
  createTip,
  getTipsForUser,
  getTipById,
} = require("../services/tipService");

function mapTipRow(tip) {
  const sessionType = tip.session_type || (tip.call_id ? "call" : null);
  const sessionId = tip.session_id || tip.call_id || null;

  return {
    id: tip.id,
    sessionId,
    sessionType,
    callId: tip.call_id || null,
    venterId: tip.venter_id,
    listenerId: tip.listener_id,
    amountCurrency: parseFloat(tip.amount_currency),
    currency: tip.currency,
    message: tip.message,
    paymentSource: tip.payment_source,
    status: tip.status,
    failureReason: tip.failure_reason,
    createdAt: tip.created_at,
    completedAt: tip.completed_at,
  };
}

async function sendTip(req, res) {
  try {
    const { sessionId } = req.params;
    const { amountCurrency, message } = req.body;
    const venterId = req.user.id;
    const io = req.app.get("io");

    if (amountCurrency === undefined || amountCurrency === null) {
      return res.status(400).json({
        error: "Validation error",
        message: "amountCurrency is required",
      });
    }

    const result = await createTip({
      venterId,
      sessionId,
      amountRaw: amountCurrency,
      message,
      io,
    });

    return res.status(result.status === "completed" ? 201 : 202).json({
      success: true,
      status: result.status,
      paymentSource: result.paymentSource,
      tip: mapTipRow(result.tip),
      paymentIntent: result.paymentIntent || null,
    });
  } catch (error) {
    if (error instanceof TipError) {
      return res.status(error.statusCode).json({
        error: error.code || "tip_error",
        message: error.message,
      });
    }

    logger.error("Error sending tip", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
      sessionId: req.params?.sessionId,
    });

    return res.status(500).json({
      error: "server_error",
      message: "Failed to send tip",
    });
  }
}

async function getSentTips(req, res) {
  try {
    const data = await getTipsForUser({
      userId: req.user.id,
      direction: "sent",
      limit: req.query.limit,
      offset: req.query.offset,
    });

    return res.json({
      tips: data.tips.map(mapTipRow),
      pagination: data.pagination,
    });
  } catch (error) {
    logger.error("Error fetching sent tips", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
    });

    return res.status(500).json({
      error: "server_error",
      message: "Failed to fetch sent tips",
    });
  }
}

async function getReceivedTips(req, res) {
  try {
    const data = await getTipsForUser({
      userId: req.user.id,
      direction: "received",
      limit: req.query.limit,
      offset: req.query.offset,
    });

    return res.json({
      tips: data.tips.map(mapTipRow),
      pagination: data.pagination,
    });
  } catch (error) {
    logger.error("Error fetching received tips", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
    });

    return res.status(500).json({
      error: "server_error",
      message: "Failed to fetch received tips",
    });
  }
}

async function getTipDetails(req, res) {
  try {
    const tip = await getTipById({
      tipId: req.params.id,
      userId: req.user.id,
    });

    return res.json({ tip: mapTipRow(tip) });
  } catch (error) {
    if (error instanceof TipError) {
      return res.status(error.statusCode).json({
        error: error.code || "tip_error",
        message: error.message,
      });
    }

    logger.error("Error fetching tip details", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
      tipId: req.params?.id,
    });

    return res.status(500).json({
      error: "server_error",
      message: "Failed to fetch tip details",
    });
  }
}

module.exports = {
  sendTip,
  getSentTips,
  getReceivedTips,
  getTipDetails,
};
