const { pool } = require("../database/connection");
const logger = require("../utils/logger");

/**
 * Block a user
 * POST /api/v1/users/:userId/block
 */
async function blockUser(req, res) {
  try {
    const blockerId = req.user.id;
    const { userId: blockedId } = req.params;

    if (blockerId === blockedId) {
      return res.status(400).json({
        error: "Validation error",
        message: "Cannot block yourself",
      });
    }

    // Check if blocked user exists
    const userCheck = await pool.query("SELECT id FROM users WHERE id = $1", [
      blockedId,
    ]);

    if (userCheck.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "User not found",
      });
    }

    // Check if already blocked
    const existingBlock = await pool.query(
      "SELECT id FROM blocked_users WHERE blocker_id = $1 AND blocked_id = $2",
      [blockerId, blockedId],
    );

    if (existingBlock.rows.length > 0) {
      return res.status(409).json({
        error: "Conflict",
        message: "User is already blocked",
      });
    }

    // Create block record
    const result = await pool.query(
      `INSERT INTO blocked_users (blocker_id, blocked_id) 
       VALUES ($1, $2) 
       RETURNING *`,
      [blockerId, blockedId],
    );

    logger.info(`User ${blockerId} blocked user ${blockedId}`);

    res.status(201).json({
      message: "User blocked successfully",
      block: {
        id: result.rows[0].id,
        blockedAt: result.rows[0].created_at,
      },
    });
  } catch (error) {
    logger.error("Error blocking user:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to block user",
    });
  }
}

/**
 * Unblock a user
 * DELETE /api/v1/users/:userId/block
 */
async function unblockUser(req, res) {
  try {
    const blockerId = req.user.id;
    const { userId: blockedId } = req.params;

    const result = await pool.query(
      "DELETE FROM blocked_users WHERE blocker_id = $1 AND blocked_id = $2 RETURNING id",
      [blockerId, blockedId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Not found",
        message: "Block relationship not found",
      });
    }

    logger.info(`User ${blockerId} unblocked user ${blockedId}`);

    res.status(200).json({
      message: "User unblocked successfully",
    });
  } catch (error) {
    logger.error("Error unblocking user:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to unblock user",
    });
  }
}

/**
 * Get list of blocked users
 * GET /api/v1/users/blocked
 */
async function getBlockedUsers(req, res) {
  try {
    const userId = req.user.id;
    const { page = 1, limit = 20 } = req.query;

    const offset = (page - 1) * limit;

    // Get blocked users with basic profile info
    const result = await pool.query(
      `SELECT 
        bu.id,
        bu.blocked_id,
        u.email,
        u.user_type as role,
        bu.created_at AS blocked_at
       FROM blocked_users bu
       JOIN users u ON u.id = bu.blocked_id
       WHERE bu.blocker_id = $1
       ORDER BY bu.created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, limit, offset],
    );

    // Get total count
    const countResult = await pool.query(
      "SELECT COUNT(*) FROM blocked_users WHERE blocker_id = $1",
      [userId],
    );

    const totalCount = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalCount / limit);

    res.status(200).json({
      blockedUsers: result.rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    logger.error("Error fetching blocked users:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to retrieve blocked users",
    });
  }
}

/**
 * Check if a user is blocked
 * GET /api/v1/users/:userId/blocked
 */
async function checkIfBlocked(req, res) {
  try {
    const userId = req.user.id;
    const { userId: targetUserId } = req.params;

    // Check both directions (I blocked them, or they blocked me)
    const result = await pool.query(
      `SELECT 
        CASE 
          WHEN blocker_id = $1 THEN 'you_blocked'
          WHEN blocked_id = $1 THEN 'blocked_by_them'
        END AS block_type,
        created_at AS blocked_at
       FROM blocked_users 
       WHERE (blocker_id = $1 AND blocked_id = $2) 
          OR (blocker_id = $2 AND blocked_id = $1)`,
      [userId, targetUserId],
    );

    if (result.rows.length === 0) {
      return res.status(200).json({
        isBlocked: false,
      });
    }

    res.status(200).json({
      isBlocked: true,
      blockType: result.rows[0].block_type,
      blockedAt: result.rows[0].blocked_at,
    });
  } catch (error) {
    logger.error("Error checking block status:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to check block status",
    });
  }
}

module.exports = {
  blockUser,
  unblockUser,
  getBlockedUsers,
  checkIfBlocked,
};
