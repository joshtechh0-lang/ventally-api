const stripe = require("../config/stripe");
const { pool } = require("../database/connection");
const { v4: uuidv4 } = require("uuid");
const logger = require("../utils/logger");
const stripeLogger = require("../utils/stripeLogger");
const { ensureStripePriceForPlan } = require("../services/stripe-sync");
const promoService = require("../services/promoService");
const { getBestCouponForUser, recordUserDiscount } = require("../services/discountService");

const CATALOG_VERSION = "2026-03-mobile-v3";
const STRIPE_CHECKOUT_REDIRECT_URL =
  process.env.STRIPE_CHECKOUT_REDIRECT_URL ||
  "https://ventally.app/venter/home";

const SUBSCRIPTION_SCREEN_COPY = {
  header: {
    title: "Choose Your Plan",
    titleAlignment: "center",
    backArrowAlignment: "left",
  },
  planToggle: {
    defaultCycle: "annual",
    tabs: [
      {
        id: "annual",
        label: "Annual",
        badge: {
          text: "Save 20%",
          color: "pale_pink",
          textColor: "white",
          shape: "pill",
          size: "small",
        },
      },
      {
        id: "monthly",
        label: "Monthly",
      },
    ],
  },
  promo: {
    label: "Promo Code",
    placeholder: "Add promo code",
    size: "small",
  },
  advancedPlansLink: {
    text: "See advanced plans",
    placement: "below_plan_cards",
    style: "subtle",
  },
  continueButton: {
    color: "ventally_pink",
    alignment: "center",
    textOptions: ["Continue to Secure Checkout", "Start My Support Plan"],
  },
  trustText: "Cancel anytime. Conversations remain private.",
  layoutOrder: [
    "back_arrow",
    "choose_your_plan",
    "annual_monthly_toggle",
    "plan_cards",
    "see_advanced_plans",
    "promo_code",
    "continue_button",
    "privacy_reassurance_text",
  ],
};

const ANNUAL_DISCOUNT_RATE = 0.2;

async function getPayPerUseRates() {
  const { getPaygRates } = require("../services/paygService");
  const rates = await getPaygRates();
  return {
    voiceCall: {
      ratePerMinute: rates.voiceRatePerMinute,
      notes: "Premium emotional processing",
    },
    textChat: {
      ratePerMinute: rates.chatRatePerMinute,
      notes: "Discreet written support",
    },
    minChargeCents: rates.minChargeCents,
    active: rates.isActive,
  };
}

const FREE_TRIAL_OFFER = {
  voiceMinutes: 10,
  textMessages: 30,
  summary: "10 voice minutes + 30 text messages for all new users",
  badge: "Free Trial",
};

const PLAN_MOBILE_METADATA = {
  "Light Support": {
    bestFor: "Casual users, first-timers, situational stress",
    valueIfPurchasedSeparately: "$83.75-$93.75",
    sessionEquivalents: {
      voice: "1-2 short calls (15-30 minutes each)",
      text: "3-4 light text vents (40-50 messages each)",
    },
    planTypeLabel: "light_support",
  },
  "Balanced Support": {
    bestFor:
      "Regular users, alternating between text and voice, weekly support",
    valueIfPurchasedSeparately: "$167.50-$187.50",
    sessionEquivalents: {
      voice: "2-4 average calls (15-30 minutes each)",
      text: "5-7 moderate text vents (40-70 messages each)",
    },
    planTypeLabel: "balanced_support",
  },
  "Consistent Care": {
    bestFor:
      "Weekly users, consistent emotional processing, regular support seekers",
    valueIfPurchasedSeparately: "$335.00-$375.00",
    sessionEquivalents: {
      voice: "4-8 voice call sessions",
      text: "10-15 text vent sessions",
    },
    planTypeLabel: "consistent_care",
  },
  "High Support": {
    bestFor: "Heavy users, therapeutic-level support, daily check-ins",
    valueIfPurchasedSeparately: "$670.00-$750.00",
    sessionEquivalents: {
      voice: "8-16 voice call sessions",
      text: "20+ text vent sessions",
    },
    planTypeLabel: "high_support",
  },
  "Free Trial": {
    bestFor: "All new users",
    valueIfPurchasedSeparately: "$28.00",
    sessionEquivalents: {
      voice: "1 short voice call (up to 10 minutes)",
      text: "1 light text vent (up to 30 messages)",
    },
    planTypeLabel: "free_trial",
  },
};

const PLAN_DISPLAY_OVERRIDES = {
  "Light Support": {
    annualPrice: 379,
  },
  "Balanced Support": {
    annualPrice: 699,
    badgeText: "Most Popular",
    badgeColor: "pale_pink",
  },
  "Consistent Care": {
    annualPrice: 1088,
  },
  "High Support": {
    annualPrice: 2099,
  },
};

function toCurrencyAmount(value) {
  return Number(Number(value).toFixed(2));
}

function resolveAnnualPrice(monthlyPrice, annualOverridePrice) {
  if (monthlyPrice <= 0) {
    return 0;
  }

  if (typeof annualOverridePrice === "number") {
    return toCurrencyAmount(annualOverridePrice);
  }

  return toCurrencyAmount(monthlyPrice * 12 * (1 - ANNUAL_DISCOUNT_RATE));
}

function resolveAnnualDiscountPercent(monthlyPrice, annualPrice) {
  if (monthlyPrice <= 0) {
    return 0;
  }

  const yearlyTotal = monthlyPrice * 12;
  return Math.round(((yearlyTotal - annualPrice) / yearlyTotal) * 100);
}

function resolveBillingCycle(inputValue) {
  const cycle = String(inputValue || "monthly").toLowerCase();
  if (cycle !== "monthly" && cycle !== "annual") {
    return null;
  }
  return cycle;
}

function formatSubscriptionPlanForScreen(plan, payPerUseRates = null) {
  const monthlyPrice = toCurrencyAmount(Number(plan.price_monthly || 0));
  const overageRate = Number(plan.overage_rate);
  const includedMessages = Number(plan.included_messages_monthly || 0);
  const yearlyTotal = toCurrencyAmount(monthlyPrice * 12);
  const override = PLAN_DISPLAY_OVERRIDES[plan.name] || {};
  const planMetadata = PLAN_MOBILE_METADATA[plan.name] || {};
  const annualPrice = resolveAnnualPrice(monthlyPrice, override.annualPrice);
  const annualSavings = toCurrencyAmount(
    Math.max(0, yearlyTotal - annualPrice),
  );
  const annualDiscountPercent = resolveAnnualDiscountPercent(
    monthlyPrice,
    annualPrice,
  );
  const hasTrialOffer =
    Number(plan.trial_days || 0) > 0 || plan.name === "Free Trial";

  return {
    ...plan,
    annual_price: annualPrice,
    annual_savings: annualSavings,
    display: {
      minuteText: `${plan.included_minutes} minutes`,
      includedMessagesText: `${includedMessages} texts per month`,
      annualPrice,
      annualPriceLabel: `$${annualPrice.toFixed(2)} / year`,
      annualSavings,
      annualSavingsLabel:
        annualSavings > 0 ? `Save $${annualSavings.toFixed(2)} yearly` : null,
      annualDiscountPercent,
      monthlyPriceLabel: `$${monthlyPrice.toFixed(2)} / month`,
      overageText: `$${overageRate.toFixed(2)} per additional minute`,
      bestFor: planMetadata.bestFor || null,
      valueIfPurchasedSeparately:
        planMetadata.valueIfPurchasedSeparately || null,
      sessionEquivalents: planMetadata.sessionEquivalents || null,
      planTypeLabel:
        planMetadata.planTypeLabel ||
        (hasTrialOffer ? "free_trial" : "support_package"),
      trialText: hasTrialOffer ? FREE_TRIAL_OFFER.summary : null,
      trialBadge: hasTrialOffer ? FREE_TRIAL_OFFER.badge : null,
      payPerUseRates,
      isMostPopular: Boolean(override.badgeText),
      mostPopularBadge: override.badgeText
        ? {
            text: override.badgeText,
            color: override.badgeColor,
          }
        : null,
      selectedCardStyle: {
        highlight: true,
        radioStyle: "clear_circle",
        cornerStyle: "rounded",
      },
    },
  };
}

// Credit pack pricing (can be moved to database later)
const CREDIT_PACKS = {
  voice_top_up: {
    minutes: 15,
    price: 1999, // $19.99 in cents
    name: "Pay as you go — Voice",
    included_minutes: 15,
    included_messages: null,
    description: "$0.69/min · 15 voice minutes",
  },
  text_top_up: {
    minutes: 0,
    price: 1499, // $14.99 in cents
    name: "Pay as you go — Chat",
    included_minutes: null,
    included_messages: 50,
    description: "$0.39/min · 50 chat messages",
  },
  support_boost: {
    minutes: 30,
    price: 3499, // $34.99 in cents
    name: "Pay as you go — Bundle",
    included_minutes: 30,
    included_messages: 50,
    description: "Voice + chat · best value",
  },
};

/**
 * Validate Stripe configuration
 */
function validateStripeConfig() {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY is not configured");
  }
  if (!stripe) {
    throw new Error("Stripe client is not initialized");
  }
}

async function getOrCreateStripeCustomer(userId) {
  const walletResult = await pool.query(
    "SELECT stripe_customer_id FROM user_wallets WHERE user_id = $1",
    [userId],
  );

  if (walletResult.rows.length > 0 && walletResult.rows[0].stripe_customer_id) {
    return walletResult.rows[0].stripe_customer_id;
  }

  const userResult = await pool.query(
    "SELECT email FROM users WHERE id = $1",
    [userId],
  );

  if (userResult.rows.length === 0) {
    const err = new Error("User not found");
    err.code = "USER_NOT_FOUND";
    throw err;
  }

  let customer;
  try {
    stripeLogger.attempt("customers.create:venter", { userId });
    customer = await stripe.customers.create({
      email: userResult.rows[0].email,
      metadata: { user_id: userId },
    });
    stripeLogger.success("customers.create:venter", customer, { userId });
  } catch (stripeErr) {
    stripeLogger.failure("customers.create:venter", stripeErr, { userId });
    throw stripeErr;
  }

  await pool.query(
    `INSERT INTO user_wallets (user_id, stripe_customer_id)
     VALUES ($1, $2)
     ON CONFLICT (user_id) DO UPDATE
       SET stripe_customer_id = EXCLUDED.stripe_customer_id,
           updated_at = NOW()`,
    [userId, customer.id],
  );

  return customer.id;
}
exports.getOrCreateStripeCustomer = getOrCreateStripeCustomer;

/**
 * Create Stripe checkout session for prepaid credits
 */
exports.createCheckoutSession = async (req, res) => {
  try {
    // Validate Stripe is configured
    validateStripeConfig();

    const userId = req.user.id; // From auth middleware
    const { packType, customMinutes, customPrice, promoCode } = req.body;

    // Validate input
    if (!packType && (!customMinutes || !customPrice)) {
      return res.status(400).json({
        error: "Invalid request",
        message:
          "Either packType or both customMinutes and customPrice are required",
      });
    }

    // Validate pack type or custom pricing
    let creditPack;

    if (customMinutes && customPrice) {
      // Validate custom values
      if (customMinutes <= 0 || customMinutes > 10000) {
        return res.status(400).json({
          error: "Invalid custom minutes",
          message: "Custom minutes must be between 1 and 10000",
        });
      }
      if (customPrice <= 0 || customPrice > 1000) {
        return res.status(400).json({
          error: "Invalid custom price",
          message: "Custom price must be between $0.01 and $1000",
        });
      }

      // Custom credit purchase (for admin or special offers)
      creditPack = {
        minutes: customMinutes,
        price: Math.round(customPrice * 100), // Convert to cents
        name: `Custom Pack - ${customMinutes} Minutes`,
      };
    } else if (CREDIT_PACKS[packType]) {
      creditPack = CREDIT_PACKS[packType];
    } else {
      return res.status(400).json({
        error: "Invalid pack type",
        message: "Choose: voice_top_up, text_top_up, or support_boost",
      });
    }

    // Handle promo code if provided
    let promoData = null;
    let discount = null;
    let bonusMinutes = 0;
    let finalPrice = creditPack.price;

    if (promoCode) {
      const promoValidation = await promoService.validatePromoCode(
        promoCode,
        userId,
      );

      if (!promoValidation.valid) {
        return res.status(400).json({
          error: "Invalid promo code",
          message: promoValidation.error,
        });
      }

      promoData = promoValidation.promo;
      discount = promoService.calculateDiscount(promoData, creditPack.price);
      finalPrice = discount.finalPrice;
      bonusMinutes = discount.freeMinutes;

      logger.info("Promo code applied to checkout", {
        userId,
        promoCode,
        discountType: promoData.discountType,
        originalPrice: creditPack.price / 100,
        finalPrice: finalPrice / 100,
        bonusMinutes,
      });
    }

    // Apply VerifyPass community discount (20%) if user is verified
    // VerifyPass discount stacks after promo discounts
    let verifyPassDiscount = null;
    try {
      const vpResult = await pool.query(
        "SELECT is_community_verified, community_type FROM users WHERE id = $1",
        [userId]
      );
      if (vpResult.rows.length > 0 && vpResult.rows[0].is_community_verified) {
        const COMMUNITY_DISCOUNT_PCT = 20;
        const vpDiscountAmount = Math.round(finalPrice * COMMUNITY_DISCOUNT_PCT / 100);
        finalPrice = finalPrice - vpDiscountAmount;
        verifyPassDiscount = {
          pct: COMMUNITY_DISCOUNT_PCT,
          amount: vpDiscountAmount,
          communityType: vpResult.rows[0].community_type,
        };
        logger.info("VerifyPass community discount applied", {
          userId,
          communityType: vpResult.rows[0].community_type,
          discountPct: COMMUNITY_DISCOUNT_PCT,
          discountAmount: vpDiscountAmount / 100,
          finalPrice: finalPrice / 100,
        });
      }
    } catch (vpErr) {
      logger.error("Error checking VerifyPass status for discount:", vpErr);
      // Non-fatal: continue without discount
    }

    logger.info("Creating checkout session", {
      userId,
      packType: packType || "custom",
      minutes: creditPack.minutes + bonusMinutes,
      price: finalPrice / 100,
      hasPromo: !!promoCode,
    });

    // Check for existing pending checkout session for same pack type
    const existingSessionResult = await pool.query(
      `SELECT stripe_session_id, checkout_url, expires_at, created_at
       FROM checkout_sessions
       WHERE user_id = $1 
         AND mode = 'payment'
         AND status = 'pending'
         AND pack_type = $2
         AND credits_minutes = $3
         AND expires_at > NOW()
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId, packType || "custom", creditPack.minutes],
    );

    if (existingSessionResult.rows.length > 0) {
      const existingSession = existingSessionResult.rows[0];
      const now = new Date();
      const expiresAt = new Date(existingSession.expires_at);

      // Check if session has actually expired (double-check since database query should handle this)
      if (now > expiresAt) {
        // Session expired, mark it and create a new one
        await pool.query(
          "UPDATE checkout_sessions SET status = 'expired', updated_at = NOW() WHERE stripe_session_id = $1",
          [existingSession.stripe_session_id],
        );

        logger.info("Existing session expired, creating new one", {
          userId,
          expiredSessionId: existingSession.stripe_session_id,
          expiresAt: existingSession.expires_at,
        });
        // Continue to create new session below
      } else {
        // Session is still valid, return it
        logger.info("Returning existing pending checkout session", {
          userId,
          sessionId: existingSession.stripe_session_id,
          createdAt: existingSession.created_at,
          expiresAt: existingSession.expires_at,
        });

        return res.json({
          sessionId: existingSession.stripe_session_id,
          url: existingSession.checkout_url,
          credits: creditPack.minutes,
          amount: creditPack.price / 100,
          existing: true,
          message: "Resuming existing checkout session",
        });
      }
    }

    let stripeCustomerId;
    try {
      stripeCustomerId = await getOrCreateStripeCustomer(userId);
    } catch (err) {
      if (err.code === "USER_NOT_FOUND") {
        return res.status(404).json({ error: "User not found" });
      }
      throw err;
    }

    // Generate idempotency key
    const idempotencyKey = uuidv4();

    // Build metadata with promo info
    const metadata = {
      user_id: userId,
      credits_minutes: creditPack.minutes,
      pack_type: packType || "custom",
    };

    if (promoData) {
      metadata.promo_code = promoData.code;
      metadata.promo_code_id = promoData.id;
      metadata.promo_discount_type = promoData.discountType;
      metadata.bonus_minutes = bonusMinutes.toString();
      metadata.original_price = (creditPack.price / 100).toString();
      metadata.discount_amount = (discount.discountAmount / 100).toString();
    }

    // Create line items with final price
    const lineItems = [
      {
        price_data: {
          currency: "usd",
          tax_behavior: "inclusive", // Stripe Tax: price already includes tax
          product_data: {
            name: promoData
              ? `${creditPack.name} (with ${promoData.code} discount)`
              : creditPack.name,
            description: bonusMinutes
              ? `Prepaid calling minutes for Ventally + ${bonusMinutes} bonus minutes`
              : `Prepaid calling minutes for Ventally`,
            images: ["https://yourdomain.com/logo.png"], // Update with actual logo
          },
          unit_amount: finalPrice, // Use final price after discount
        },
        quantity: 1,
      },
    ];

    // Create checkout session
    stripeLogger.attempt("checkout.sessions.create:credits", {
      userId,
      packType: packType || "custom",
      amount: finalPrice,
    });
    const session = await stripe.checkout.sessions.create(
      {
        customer: stripeCustomerId,
        payment_method_types: ["card"],
        line_items: lineItems,
        mode: "payment",
        // Stripe Tax: auto-calculate tax and collect/persist the customer
        // address it needs to determine the jurisdiction.
        automatic_tax: { enabled: true },
        billing_address_collection: "required",
        customer_update: { address: "auto" },
        success_url: STRIPE_CHECKOUT_REDIRECT_URL,
        cancel_url: STRIPE_CHECKOUT_REDIRECT_URL,
        metadata: metadata,
      },
      {
        idempotencyKey,
      },
    );
    stripeLogger.success("checkout.sessions.create:credits", session, {
      userId,
    });

    // Save checkout session to database for tracking and webhook mapping
    const expiresAt = new Date(session.expires_at * 1000); // Convert Unix timestamp to JS Date
    await pool.query(
      `INSERT INTO checkout_sessions 
       (stripe_session_id, user_id, checkout_url, mode, status, amount_total, 
        currency, metadata, credits_minutes, pack_type, success_url, cancel_url, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
      [
        session.id,
        userId,
        session.url,
        session.mode,
        "pending",
        session.amount_total,
        session.currency,
        JSON.stringify(session.metadata),
        creditPack.minutes,
        packType || "custom",
        session.success_url,
        session.cancel_url,
        expiresAt,
      ],
    );

    res.json({
      sessionId: session.id,
      url: session.url,
      credits: creditPack.minutes,
      amount: creditPack.price / 100,
    });

    logger.info("Checkout session created successfully", {
      userId,
      sessionId: session.id,
      credits: creditPack.minutes,
    });
  } catch (error) {
    stripeLogger.failure("checkout.sessions.create:credits", error, {
      userId: req.user?.id,
      stack: error.stack,
    });
    res.status(500).json({
      error: "Failed to create checkout session",
      message: error.message,
    });
  }
};

/**
 * Resolve Stripe proration_behavior for an in-place plan change.
 * Upgrades charge the prorated difference immediately; downgrades apply with no
 * credit; trial changes never proration-charge (proration is $0 during a trial).
 */
function resolveProrationBehavior({ isUpgrade, isTrialing }) {
  if (isTrialing) return "none";
  return isUpgrade
    ? process.env.SUBSCRIPTION_UPGRADE_PRORATION || "always_invoice"
    : process.env.SUBSCRIPTION_DOWNGRADE_PRORATION || "none";
}

/**
 * Change an existing Stripe subscription in place (upgrade/downgrade) instead of
 * forcing the user to cancel and re-subscribe. Swaps the subscription's single
 * price item to the newly selected plan/billing cycle and lets the
 * customer.subscription.updated webhook reconcile entitlements in the DB.
 *
 * Sends the HTTP response directly. Throws on unexpected errors so the caller's
 * try/catch can log via stripeLogger.
 */
async function performSubscriptionChange({
  res,
  userId,
  plan,
  formattedPlan,
  billingCycle,
  existingSub,
}) {
  const stripeSubscriptionId = existingSub.stripe_subscription_id;

  if (!stripeSubscriptionId) {
    return res.status(500).json({
      error: "Invalid subscription state",
      message: "Subscription missing Stripe ID. Please contact support.",
    });
  }

  // Retrieve the live subscription to find its single price item + current cycle
  const sub = await stripe.subscriptions.retrieve(stripeSubscriptionId);

  if (!["active", "trialing"].includes(sub.status)) {
    return res.status(409).json({
      error: "Subscription not changeable",
      message:
        "Your subscription is not in a state that can be changed. Please contact support.",
    });
  }

  if (!sub.items || sub.items.data.length !== 1) {
    logger.error("Cannot change subscription with unexpected item count", {
      userId,
      stripeSubscriptionId,
      itemCount: sub.items?.data?.length,
    });
    return res.status(409).json({
      error: "Subscription not changeable",
      message:
        "Your subscription has an unexpected configuration. Please contact support.",
    });
  }

  const item = sub.items.data[0];
  const currentPriceId = item.price.id;
  const currentCycle = sub.metadata?.billing_cycle || "monthly";

  // Resolve the Stripe price for the newly selected plan + billing cycle
  let newPriceId =
    billingCycle === "annual"
      ? plan.stripe_price_id_annual
      : plan.stripe_price_id;

  if (!newPriceId) {
    newPriceId = await ensureStripePriceForPlan(plan.id, {
      billingCycle,
      annualPrice:
        billingCycle === "annual" ? formattedPlan.display.annualPrice : null,
    });
  }

  // No-op: already on this plan + billing cycle
  if (
    newPriceId === currentPriceId ||
    (existingSub.plan_id === plan.id && currentCycle === billingCycle)
  ) {
    return res.status(409).json({
      error: "No change required",
      message: "You are already subscribed to this plan and billing cycle.",
    });
  }

  // Determine direction by comparing monthly-equivalent plan price.
  // (A same-plan monthly -> annual switch is treated as an upgrade/prepay.)
  const currentPlanResult = await pool.query(
    "SELECT price_monthly FROM subscription_plans WHERE id = $1",
    [existingSub.plan_id],
  );
  const currentPriceMonthly = Number(
    currentPlanResult.rows[0]?.price_monthly || 0,
  );
  const targetPriceMonthly = Number(plan.price_monthly || 0);
  const isUpgrade = targetPriceMonthly >= currentPriceMonthly;
  const isTrialing = sub.status === "trialing";

  // Require a card on file before moving to a paid plan
  if (targetPriceMonthly > 0) {
    const walletResult = await pool.query(
      "SELECT default_payment_method FROM user_wallets WHERE user_id = $1",
      [userId],
    );
    const hasCard = Boolean(walletResult.rows[0]?.default_payment_method);

    if (!hasCard) {
      return res.status(402).json({
        error: "payment_method_required",
        message: "Add a payment method to change your plan.",
      });
    }
  }

  const prorationBehavior = resolveProrationBehavior({ isUpgrade, isTrialing });

  stripeLogger.attempt("subscriptions.update:plan_change", {
    userId,
    stripeSubscriptionId,
    planId: plan.id,
    billingCycle,
    prorationBehavior,
  });
  const updated = await stripe.subscriptions.update(
    stripeSubscriptionId,
    {
      // Swap the price on the single existing item; do NOT add a second item.
      items: [{ id: item.id, price: newPriceId }],
      proration_behavior: prorationBehavior,
      payment_behavior: "allow_incomplete",
      metadata: {
        // CRITICAL: must point at the NEW plan so handleSubscriptionUpdate
        // reconciles the correct entitlements (it reads metadata.plan_id).
        user_id: userId,
        plan_id: plan.id,
        billing_cycle: billingCycle,
        catalog_version: CATALOG_VERSION,
      },
    },
    {
      idempotencyKey: `chgsub:${userId}:${stripeSubscriptionId}:${plan.id}:${billingCycle}`,
    },
  );
  stripeLogger.success("subscriptions.update:plan_change", updated, {
    userId,
    stripeSubscriptionId,
    planId: plan.id,
  });

  logger.info("Subscription plan changed", {
    userId,
    stripeSubscriptionId,
    planId: plan.id,
    billingCycle,
    status: updated.status,
    prorationBehavior,
  });

  // DB is reconciled by the customer.subscription.updated webhook.
  return res.json({
    type: "updated",
    status: updated.status,
    planId: plan.id,
    planName: plan.name,
    billingCycle,
    includedMinutes: plan.included_minutes,
    includedMessages: plan.included_messages_monthly,
    requiresPaymentMethod: ["past_due", "incomplete"].includes(updated.status),
    catalogVersion: CATALOG_VERSION,
  });
}

/**
 * Create subscription checkout session
 */
exports.createSubscriptionCheckout = async (req, res) => {
  try {
    // Validate Stripe is configured
    validateStripeConfig();

    const userId = req.user.id;
    const { planId, billingCycle: requestedBillingCycle } = req.body;
    const billingCycle = resolveBillingCycle(requestedBillingCycle);

    // Validate input
    if (!planId) {
      return res.status(400).json({
        error: "Missing required field",
        message: "Plan ID is required",
      });
    }

    // Validate UUID format
    const uuidRegex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(planId)) {
      return res.status(400).json({
        error: "Invalid plan ID",
        message: "Plan ID must be a valid UUID",
      });
    }

    if (!billingCycle) {
      return res.status(400).json({
        error: "Invalid billing cycle",
        message: "billingCycle must be either 'monthly' or 'annual'",
      });
    }

    logger.info("Creating subscription checkout", {
      userId,
      planId,
      billingCycle,
    });

    // Get plan details
    const planResult = await pool.query(
      "SELECT * FROM subscription_plans WHERE id = $1 AND is_active = true",
      [planId],
    );

    if (planResult.rows.length === 0) {
      return res.status(404).json({
        error: "Subscription plan not found",
        message: "The requested plan does not exist or is not active",
      });
    }

    const plan = planResult.rows[0];
    const payPerUseRates = await getPayPerUseRates();
    const formattedPlan = formatSubscriptionPlanForScreen(plan, payPerUseRates);

    // If the user already has an active/trialing subscription, change it in
    // place (upgrade/downgrade) instead of forcing a cancel + re-subscribe.
    const existingSubResult = await pool.query(
      `SELECT id, status, plan_id, stripe_subscription_id
       FROM user_subscriptions
       WHERE user_id = $1 AND status IN ('active', 'trialing')
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId],
    );

    if (existingSubResult.rows.length > 0) {
      return await performSubscriptionChange({
        res,
        userId,
        plan,
        formattedPlan,
        billingCycle,
        existingSub: existingSubResult.rows[0],
      });
    }

    // Check for existing pending checkout session for same plan
    const existingSessionResult = await pool.query(
      `SELECT stripe_session_id, checkout_url, expires_at, created_at
       FROM checkout_sessions
       WHERE user_id = $1 
         AND mode = 'subscription'
         AND status = 'pending'
         AND plan_id = $2
         AND COALESCE(billing_cycle, 'monthly') = $3
         AND expires_at > NOW()
       ORDER BY created_at DESC
       LIMIT 1`,
      [userId, planId, billingCycle],
    );

    if (existingSessionResult.rows.length > 0) {
      const existingSession = existingSessionResult.rows[0];
      const now = new Date();
      const expiresAt = new Date(existingSession.expires_at);

      // Check if session has actually expired (double-check since database query should handle this)
      if (now > expiresAt) {
        // Session expired, mark it and create a new one
        await pool.query(
          "UPDATE checkout_sessions SET status = 'expired', updated_at = NOW() WHERE stripe_session_id = $1",
          [existingSession.stripe_session_id],
        );

        logger.info("Existing subscription session expired, creating new one", {
          userId,
          planId,
          expiredSessionId: existingSession.stripe_session_id,
          expiresAt: existingSession.expires_at,
        });
        // Continue to create new session below
      } else {
        // Session is still valid, return it
        logger.info(
          "Returning existing pending subscription checkout session",
          {
            userId,
            planId,
            sessionId: existingSession.stripe_session_id,
            createdAt: existingSession.created_at,
            expiresAt: existingSession.expires_at,
          },
        );

        return res.json({
          type: "checkout",
          sessionId: existingSession.stripe_session_id,
          url: existingSession.checkout_url,
          planName: plan.name,
          monthlyPrice: plan.price_monthly,
          includedMinutes: plan.included_minutes,
          includedMessages: plan.included_messages_monthly,
          annualPrice: formattedPlan.display.annualPrice,
          annualPriceLabel: formattedPlan.display.annualPriceLabel,
          annualSavings: formattedPlan.display.annualSavings,
          annualSavingsLabel: formattedPlan.display.annualSavingsLabel,
          includedMessagesText: formattedPlan.display.includedMessagesText,
          planTypeLabel: formattedPlan.display.planTypeLabel,
          bestFor: formattedPlan.display.bestFor,
          trialSummary: formattedPlan.display.trialText,
          billingSummary: {
            minuteText: formattedPlan.display.minuteText,
            messageText: formattedPlan.display.includedMessagesText,
            overageText: formattedPlan.display.overageText,
          },
          billingCycle,
          catalogVersion: CATALOG_VERSION,
          existing: true,
          message: "Resuming existing checkout session",
        });
      }
    }

    let stripeCustomerId;
    try {
      stripeCustomerId = await getOrCreateStripeCustomer(userId);
    } catch (err) {
      if (err.code === "USER_NOT_FOUND") {
        return res.status(404).json({ error: "User not found" });
      }
      throw err;
    }

    // Create or get Stripe price for subscription
    let stripePriceId =
      billingCycle === "annual"
        ? plan.stripe_price_id_annual
        : plan.stripe_price_id;

    if (!stripePriceId) {
      // Use the stripe-sync service to create Stripe price for the selected billing cycle
      stripePriceId = await ensureStripePriceForPlan(planId, {
        billingCycle,
        annualPrice:
          billingCycle === "annual" ? formattedPlan.display.annualPrice : null,
      });
    }

    const hasTrial = Number(plan.trial_days || 0) > 0;
    const isFreePlan = Number(plan.price_monthly || 0) === 0;

    // Resolve best discount coupon for this user (community verified, referral, etc.)
    let appliedDiscount = null;
    if (!isFreePlan) {
      try {
        appliedDiscount = await getBestCouponForUser(userId, "subscription");
      } catch (discountErr) {
        logger.warn("Failed to resolve discount for user, continuing without:", discountErr.message);
      }
    }

    const sessionPayload = {
      customer: stripeCustomerId,
      payment_method_types: ["card"],
      payment_method_collection:
        hasTrial || isFreePlan ? "if_required" : "always",
      line_items: [
        {
          price: stripePriceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      // Stripe Tax: auto-calculate tax and collect/persist the customer
      // address it needs to determine the jurisdiction.
      automatic_tax: { enabled: true },
      billing_address_collection: "required",
      customer_update: { address: "auto" },
      success_url: STRIPE_CHECKOUT_REDIRECT_URL,
      cancel_url: STRIPE_CHECKOUT_REDIRECT_URL,
      metadata: {
        user_id: userId,
        plan_id: planId,
        billing_cycle: billingCycle,
        catalog_version: CATALOG_VERSION,
      },
      subscription_data: {
        ...(hasTrial ? { trial_period_days: Number(plan.trial_days) } : {}),
        metadata: {
          user_id: userId,
          plan_id: planId,
          billing_cycle: billingCycle,
          catalog_version: CATALOG_VERSION,
        },
      },
      // Apply discount coupon if user qualifies (community verified, etc.)
      ...(appliedDiscount ? { discounts: [{ coupon: appliedDiscount.couponId }] } : {}),
    };

    // Create subscription checkout session
    stripeLogger.attempt("checkout.sessions.create:subscription", {
      userId,
      planId,
      billingCycle,
    });
    const session = await stripe.checkout.sessions.create(sessionPayload);
    stripeLogger.success("checkout.sessions.create:subscription", session, {
      userId,
      planId,
    });

    // Save checkout session to database for tracking and webhook mapping
    const expiresAt = new Date(session.expires_at * 1000); // Convert Unix timestamp to JS Date
    await pool.query(
      `INSERT INTO checkout_sessions 
       (stripe_session_id, user_id, checkout_url, mode, status, amount_total, 
        currency, metadata, plan_id, billing_cycle, success_url, cancel_url, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
      [
        session.id,
        userId,
        session.url,
        session.mode,
        "pending",
        session.amount_total,
        session.currency,
        JSON.stringify(session.metadata),
        planId,
        billingCycle,
        session.success_url,
        session.cancel_url,
        expiresAt,
      ],
    );

    // Record discount application (non-blocking)
    if (appliedDiscount) {
      recordUserDiscount(userId, appliedDiscount.discount.id, {
        couponId: appliedDiscount.couponId,
        appliedTo: "subscription",
        sessionId: session.id,
      }).catch((err) => logger.warn("Failed to record user discount:", err.message));
    }

    res.json({
      type: "checkout",
      sessionId: session.id,
      url: session.url,
      planName: plan.name,
      monthlyPrice: plan.price_monthly,
      includedMinutes: plan.included_minutes,
      includedMessages: plan.included_messages_monthly,
      planMinuteText: `${plan.included_minutes} minutes`,
      overageText: `$${Number(plan.overage_rate).toFixed(2)} per additional minute`,
      annualPrice: formattedPlan.display.annualPrice,
      annualPriceLabel: formattedPlan.display.annualPriceLabel,
      annualSavings: formattedPlan.display.annualSavings,
      annualSavingsLabel: formattedPlan.display.annualSavingsLabel,
      includedMessagesText: formattedPlan.display.includedMessagesText,
      planTypeLabel: formattedPlan.display.planTypeLabel,
      bestFor: formattedPlan.display.bestFor,
      trialSummary: formattedPlan.display.trialText,
      billingSummary: {
        minuteText: formattedPlan.display.minuteText,
        messageText: formattedPlan.display.includedMessagesText,
        overageText: formattedPlan.display.overageText,
      },
      billingCycle,
      catalogVersion: CATALOG_VERSION,
    });

    logger.info("Subscription checkout created successfully", {
      userId,
      sessionId: session.id,
      planId,
    });
  } catch (error) {
    stripeLogger.failure("checkout.sessions.create:subscription", error, {
      userId: req.user?.id,
      stack: error.stack,
    });
    res.status(500).json({
      error: "Failed to create subscription checkout",
      message: error.message,
    });
  }
};

/**
 * Get available credit packs
 */
exports.getCreditPacks = async (req, res) => {
  try {
    const packs = Object.entries(CREDIT_PACKS).map(([key, pack]) => ({
      id: key,
      minutes: pack.minutes,
      price: pack.price / 100,
      name: pack.name,
      pricePerMinute:
        pack.minutes > 0 ? (pack.price / 100 / pack.minutes).toFixed(3) : null,
      included_minutes: pack.included_minutes ?? null,
      included_messages: pack.included_messages ?? null,
      description: pack.description || null,
    }));

    res.json({ packs });
  } catch (error) {
    logger.error("Error getting credit packs", {
      error: error.message,
      stack: error.stack,
    });
    res.status(500).json({ error: "Failed to fetch credit packs" });
  }
};

/**
 * Get subscription plans
 */
exports.getSubscriptionPlans = async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM subscription_plans WHERE is_active = true ORDER BY price_monthly ASC",
    );

    const payPerUseRates = await getPayPerUseRates();
    const plans = result.rows.map((plan) =>
      formatSubscriptionPlanForScreen(plan, payPerUseRates),
    );

    let paygUserState = { paygEnabled: false, hasSavedCard: false };
    if (req.user?.id) {
      const walletResult = await pool.query(
        `SELECT payg_enabled, default_payment_method
         FROM user_wallets WHERE user_id = $1`,
        [req.user.id],
      );
      const wallet = walletResult.rows[0];
      if (wallet) {
        paygUserState = {
          paygEnabled: Boolean(wallet.payg_enabled),
          hasSavedCard: Boolean(wallet.default_payment_method),
        };
      }
    }

    res.json({
      plans,
      catalogVersion: CATALOG_VERSION,
      screenCopy: {
        ...SUBSCRIPTION_SCREEN_COPY,
        annualDiscountRate: ANNUAL_DISCOUNT_RATE,
        payPerUseRates,
        freeTrialOffer: FREE_TRIAL_OFFER,
      },
      payg: paygUserState,
    });
  } catch (error) {
    logger.error("Error getting subscription plans", {
      error: error.message,
      stack: error.stack,
    });
    res.status(500).json({ error: "Failed to fetch subscription plans" });
  }
};

/**
 * Verify checkout session (called after successful payment)
 */
exports.verifyCheckoutSession = async (req, res) => {
  try {
    // Validate Stripe is configured
    validateStripeConfig();

    const { sessionId } = req.query;

    if (!sessionId) {
      return res.status(400).json({
        error: "Missing required parameter",
        message: "Session ID is required",
      });
    }

    logger.info("Verifying checkout session", {
      userId: req.user.id,
      sessionId,
    });

    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (session.payment_status === "paid") {
      res.json({
        success: true,
        status: "paid",
        amountPaid: session.amount_total / 100,
        credits: session.metadata.credits_minutes || 0,
      });
    } else {
      res.json({
        success: false,
        status: session.payment_status,
      });
    }
  } catch (error) {
    logger.error("Error verifying checkout session", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
      sessionId: req.query?.sessionId,
    });
    res.status(500).json({
      error: "Failed to verify checkout session",
      message: error.message,
    });
  }
};

/**
 * Cancel subscription
 */
exports.cancelSubscription = async (req, res) => {
  try {
    // Validate Stripe is configured
    validateStripeConfig();

    const userId = req.user.id;

    logger.info("Cancelling subscription", { userId });

    // Get user's active subscription
    const subResult = await pool.query(
      "SELECT stripe_subscription_id FROM user_subscriptions WHERE user_id = $1 AND status = $2",
      [userId, "active"],
    );

    if (subResult.rows.length === 0) {
      return res.status(404).json({
        error: "No active subscription found",
        message: "You do not have an active subscription to cancel",
      });
    }

    const stripeSubscriptionId = subResult.rows[0].stripe_subscription_id;

    if (!stripeSubscriptionId) {
      return res.status(500).json({
        error: "Invalid subscription state",
        message: "Subscription missing Stripe ID. Please contact support.",
      });
    }

    // Cancel immediately (no proration/refund)
    stripeLogger.attempt("subscriptions.cancel:user_request", {
      userId,
      stripeSubscriptionId,
    });
    const subscription =
      await stripe.subscriptions.cancel(stripeSubscriptionId);
    stripeLogger.success("subscriptions.cancel:user_request", subscription, {
      userId,
      stripeSubscriptionId,
    });

    res.json({
      message: "Subscription canceled immediately",
      canceledAt: new Date(subscription.canceled_at * 1000),
    });
  } catch (error) {
    stripeLogger.failure("subscriptions.cancel:user_request", error, {
      userId: req.user?.id,
      stack: error.stack,
    });
    res.status(500).json({
      error: "Failed to cancel subscription",
      message: error.message,
    });
  }
};

/**
 * Get checkout session details by session ID
 * Returns checkout URL and status for user redirection
 */
exports.getCheckoutSession = async (req, res) => {
  try {
    const userId = req.user.id;
    const { sessionId } = req.params;

    if (!sessionId) {
      return res.status(400).json({
        error: "Missing required parameter",
        message: "Session ID is required",
      });
    }

    logger.info("Retrieving checkout session", { userId, sessionId });

    // Query checkout session from database
    const result = await pool.query(
      `SELECT 
         stripe_session_id, 
         checkout_url, 
         mode, 
         status, 
         amount_total, 
         currency,
         credits_minutes,
         pack_type,
         plan_id,
         expires_at,
         completed_at,
         created_at
       FROM checkout_sessions 
       WHERE stripe_session_id = $1 AND user_id = $2`,
      [sessionId, userId],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: "Checkout session not found",
        message:
          "The requested checkout session does not exist or does not belong to you",
      });
    }

    const session = result.rows[0];

    // Check if session has expired
    const now = new Date();
    const expiresAt = new Date(session.expires_at);
    const isExpired = now > expiresAt && session.status === "pending";

    if (isExpired) {
      // Update status to expired in database
      await pool.query(
        "UPDATE checkout_sessions SET status = 'expired', updated_at = NOW() WHERE stripe_session_id = $1",
        [sessionId],
      );
      session.status = "expired";
    }

    // Get plan name if this is a subscription checkout
    let planName = null;
    if (session.plan_id) {
      const planResult = await pool.query(
        "SELECT name FROM subscription_plans WHERE id = $1",
        [session.plan_id],
      );
      if (planResult.rows.length > 0) {
        planName = planResult.rows[0].name;
      }
    }

    res.json({
      sessionId: session.stripe_session_id,
      checkoutUrl: session.checkout_url,
      mode: session.mode,
      status: session.status,
      amount: session.amount_total ? session.amount_total / 100 : null,
      currency: session.currency,
      creditsMinutes: session.credits_minutes,
      packType: session.pack_type,
      planName: planName,
      expiresAt: session.expires_at,
      completedAt: session.completed_at,
      createdAt: session.created_at,
      requiresAction: session.status === "pending" && !isExpired,
    });

    logger.info("Checkout session retrieved successfully", {
      userId,
      sessionId,
      status: session.status,
    });
  } catch (error) {
    logger.error("Error retrieving checkout session", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
      sessionId: req.params?.sessionId,
    });
    res.status(500).json({
      error: "Failed to retrieve checkout session",
      message: error.message,
    });
  }
};

/**
 * Get all checkout sessions for the current user
 */
exports.getUserCheckoutSessions = async (req, res) => {
  try {
    const userId = req.user.id;
    const { status, limit = 20, offset = 0 } = req.query;

    logger.info("Retrieving user checkout sessions", { userId, status });

    let query = `
      SELECT 
        cs.stripe_session_id, 
        cs.mode, 
        cs.status, 
        cs.amount_total, 
        cs.currency,
        cs.credits_minutes,
        cs.pack_type,
        cs.completed_at,
        cs.created_at,
        sp.name as plan_name
      FROM checkout_sessions cs
      LEFT JOIN subscription_plans sp ON cs.plan_id = sp.id
      WHERE cs.user_id = $1
    `;

    const params = [userId];
    let paramIndex = 2;

    // Filter by status if provided
    if (
      status &&
      ["pending", "completed", "expired", "failed"].includes(status)
    ) {
      query += ` AND cs.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    query += ` ORDER BY cs.created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await pool.query(query, params);

    // Also get total count
    let countQuery = `SELECT COUNT(*) FROM checkout_sessions WHERE user_id = $1`;
    const countParams = [userId];
    if (
      status &&
      ["pending", "completed", "expired", "failed"].includes(status)
    ) {
      countQuery += ` AND status = $2`;
      countParams.push(status);
    }
    const countResult = await pool.query(countQuery, countParams);

    res.json({
      sessions: result.rows.map((row) => ({
        sessionId: row.stripe_session_id,
        mode: row.mode,
        status: row.status,
        amount: row.amount_total ? row.amount_total / 100 : null,
        currency: row.currency,
        creditsMinutes: row.credits_minutes,
        packType: row.pack_type,
        planName: row.plan_name,
        completedAt: row.completed_at,
        createdAt: row.created_at,
      })),
      total: parseInt(countResult.rows[0].count),
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    logger.info("User checkout sessions retrieved successfully", {
      userId,
      count: result.rows.length,
    });
  } catch (error) {
    logger.error("Error retrieving user checkout sessions", {
      error: error.message,
      stack: error.stack,
      userId: req.user?.id,
    });
    res.status(500).json({
      error: "Failed to retrieve checkout sessions",
      message: error.message,
    });
  }
};

/**
 * PAYG: status for current user
 */
exports.getPaygStatus = async (req, res) => {
  try {
    const userId = req.user.id;
    const { getPaygRates } = require("../services/paygService");

    const [walletResult, rates] = await Promise.all([
      pool.query(
        `SELECT payg_enabled, default_payment_method, payg_locked_at, stripe_customer_id
         FROM user_wallets WHERE user_id = $1`,
        [userId],
      ),
      getPaygRates(),
    ]);

    const wallet = walletResult.rows[0] || {};
    res.json({
      paygEnabled: Boolean(wallet.payg_enabled),
      hasSavedCard: Boolean(wallet.default_payment_method),
      hasStripeCustomer: Boolean(wallet.stripe_customer_id),
      lockedAt: wallet.payg_locked_at || null,
      voiceRatePerMinute: rates.voiceRatePerMinute,
      chatRatePerMinute: rates.chatRatePerMinute,
      minChargeCents: rates.minChargeCents,
      ratesActive: rates.isActive,
    });
  } catch (error) {
    logger.error("Error getting PAYG status", {
      error: error.message,
      userId: req.user?.id,
    });
    res.status(500).json({ error: "Failed to load PAYG status" });
  }
};

/**
 * PAYG: create SetupIntent to capture a card for off-session charging
 */
exports.createPaygSetupIntent = async (req, res) => {
  try {
    validateStripeConfig();
    const userId = req.user.id;
    const { address } = req.body || {};

    const stripeCustomerId = await getOrCreateStripeCustomer(userId);

    // Stripe Tax needs a customer address to determine the jurisdiction for the
    // later off-session PAYG/tip charges. Persist it now if the client supplies
    // one; otherwise tax silently falls back to untaxed until an address exists
    // (e.g. from a Checkout session). Best-effort — never block card setup.
    if (address && typeof address === "object") {
      try {
        await stripe.customers.update(stripeCustomerId, { address });
      } catch (addrErr) {
        stripeLogger.failure("customers.update:payg_address", addrErr, {
          userId,
        });
      }
    }

    stripeLogger.attempt("setupIntents.create:payg", { userId });
    const setupIntent = await stripe.setupIntents.create({
      customer: stripeCustomerId,
      usage: "off_session",
      payment_method_types: ["card"],
      metadata: { user_id: userId, kind: "payg_setup" },
    });
    stripeLogger.success("setupIntents.create:payg", setupIntent, { userId });

    res.json({
      clientSecret: setupIntent.client_secret,
      setupIntentId: setupIntent.id,
      customerId: stripeCustomerId,
    });
  } catch (error) {
    if (error.code === "USER_NOT_FOUND") {
      return res.status(404).json({ error: "User not found" });
    }
    stripeLogger.failure("setupIntents.create:payg", error, {
      userId: req.user?.id,
    });
    res.status(500).json({ error: "Failed to create SetupIntent" });
  }
};

/**
 * PAYG: confirm enrollment — attaches PM to customer, sets as default, flips payg_enabled.
 * Also used to re-confirm an existing default_payment_method (no paymentMethodId required in that case).
 */
exports.confirmPaygEnrollment = async (req, res) => {
  try {
    validateStripeConfig();
    const userId = req.user.id;
    const { paymentMethodId } = req.body || {};

    const stripeCustomerId = await getOrCreateStripeCustomer(userId);

    let pmId = paymentMethodId;
    if (pmId) {
      await stripe.paymentMethods.attach(pmId, { customer: stripeCustomerId });
      await stripe.customers.update(stripeCustomerId, {
        invoice_settings: { default_payment_method: pmId },
      });
    } else {
      const existing = await pool.query(
        "SELECT default_payment_method FROM user_wallets WHERE user_id = $1",
        [userId],
      );
      pmId = existing.rows[0]?.default_payment_method || null;
      if (!pmId) {
        return res.status(400).json({
          error: "NO_PAYMENT_METHOD",
          message: "Provide paymentMethodId or save a card first",
        });
      }
    }

    await pool.query(
      `UPDATE user_wallets
       SET default_payment_method = $2,
           payg_enabled = true,
           payg_locked_at = NULL,
           updated_at = NOW()
       WHERE user_id = $1`,
      [userId, pmId],
    );

    logger.info("PAYG enrollment confirmed", { userId, paymentMethodId: pmId });
    res.json({ paygEnabled: true, defaultPaymentMethod: pmId });
  } catch (error) {
    if (error.code === "USER_NOT_FOUND") {
      return res.status(404).json({ error: "User not found" });
    }
    logger.error("Error confirming PAYG enrollment", {
      error: error.message,
      userId: req.user?.id,
    });
    res.status(500).json({ error: "Failed to confirm PAYG enrollment" });
  }
};


/**
 * Create a Stripe PaymentIntent for iOS native payment sheet top-up
 * POST /api/v1/payments/top-up-intent
 */
exports.topUpIntent = async (req, res) => {
  try {
    validateStripeConfig();
    const userId = req.user.id;
    const { packType } = req.body;

    if (!packType || !CREDIT_PACKS[packType]) {
      return res.status(400).json({
        error: "Invalid pack type",
        message: "Choose: voice_top_up, text_top_up, or support_boost",
      });
    }

    const pack = CREDIT_PACKS[packType];
    const customerId = await getOrCreateStripeCustomer(userId);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: pack.price,
      currency: "usd",
      customer: customerId,
      automatic_payment_methods: { enabled: true },
      metadata: {
        userId,
        packType,
        minutes: pack.minutes,
        source: "ios_top_up",
      },
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    logger.error("Error creating top-up intent", {
      error: error.message,
      stack: error.stack,
    });
    res.status(500).json({ error: "Failed to create payment intent" });
  }
};

module.exports = exports;

exports.activateFreeTier = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const userId = req.user.id;

    // Check if user already has an active subscription
    const existingSub = await client.query(
      `SELECT id FROM user_subscriptions 
       WHERE user_id = $1 AND status IN ('active', 'trialing')
       LIMIT 1`,
      [userId]
    );

    if (existingSub.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ 
        error: "Already subscribed",
        message: "You already have an active subscription." 
      });
    }

    // Get the free tier plan
    const planResult = await client.query(
      `SELECT * FROM subscription_plans 
       WHERE (LOWER(name) LIKE '%free%' OR price_monthly = 0) 
       AND is_active = true
       LIMIT 1`
    );

    if (planResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ 
        error: "Free plan not found",
        message: "No free tier plan is available." 
      });
    }

    const plan = planResult.rows[0];
    const now = new Date();
    const periodEnd = new Date(now);
    periodEnd.setDate(periodEnd.getDate() + 30);

    // Create subscription record directly
    await client.query(
      `INSERT INTO user_subscriptions
      (user_id, plan_id, status, included_minutes, used_minutes, 
       included_messages, used_messages, overage_rate,
       billing_cycle_start, billing_cycle_end)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        userId,
        plan.id,
        'active',
        plan.included_minutes,
        0,
        plan.included_messages_monthly || 0,
        0,
        plan.overage_rate,
        now,
        periodEnd,
      ]
    );

    // Create transaction record
    await client.query(
      `INSERT INTO wallet_transactions
      (user_id, transaction_type, amount_currency, description, metadata)
      VALUES ($1, $2, $3, $4, $5)`,
      [
        userId,
        'subscription_payment',
        0,
        `Free Tier activated: ${plan.included_minutes} minutes included`,
        JSON.stringify({
          plan_id: plan.id,
          included_minutes: plan.included_minutes,
          included_messages: plan.included_messages_monthly || 0,
          activation_type: 'free_tier_direct',
        }),
      ]
    );

    await client.query("COMMIT");

    return res.json({
      success: true,
      message: "Free tier activated successfully",
      plan: {
        name: plan.name,
        includedMinutes: plan.included_minutes,
        includedMessages: plan.included_messages_monthly || 0,
      }
    });

  } catch (error) {
    try { await client.query("ROLLBACK"); } catch {}
    logger.error("Error activating free tier", { error: error.message });
    // Return 200 if user already has subscription (silent fail - they can proceed)
    if (error.message && error.message.includes('already')) {
      return res.json({ success: true, message: "Subscription already active" });
    }
    return res.status(400).json({ 
      error: "Failed to activate free tier",
      message: error.message 
    });
  } finally {
    client.release();
  }
};

exports.activateFreeTier = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const userId = req.user.id;
    const existingSub = await client.query(
      "SELECT id FROM user_subscriptions WHERE user_id = $1 AND status IN (active, trialing) LIMIT 1",
      [userId]
    );
    if (existingSub.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "Already subscribed" });
    }
    const planResult = await client.query(
      "SELECT * FROM subscription_plans WHERE (LOWER(name) LIKE '%free%' OR price_monthly = 0) AND is_active = true LIMIT 1"
    );
    if (planResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Free plan not found" });
    }
    const plan = planResult.rows[0];
    const now = new Date();
    const periodEnd = new Date(now);
    periodEnd.setDate(periodEnd.getDate() + 30);
    await client.query(
      "INSERT INTO user_subscriptions (user_id, plan_id, status, included_minutes, used_minutes, included_messages, used_messages, overage_rate, billing_cycle_start, billing_cycle_end) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)",
      [userId, plan.id, "active", plan.included_minutes, 0, plan.included_messages_monthly || 0, 0, plan.overage_rate, now, periodEnd]
    );
    await client.query("COMMIT");
    return res.json({ success: true, message: "Free tier activated", plan: { name: plan.name, includedMinutes: plan.included_minutes } });
  } catch (error) {
    await client.query("ROLLBACK");
    return res.status(500).json({ error: "Failed to activate free tier" });
  } finally {
    client.release();
  }
};
