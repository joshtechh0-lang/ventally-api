const { pool } = require("../database/connection");
const logger = require("../utils/logger");

const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

async function generateAffiliateCode(client) {
  let code;
  let attempts = 0;
  while (attempts < 10) {
    code = Array.from({ length: 10 }, () =>
      CHARS[Math.floor(Math.random() * CHARS.length)]
    ).join("");
    const existing = await client.query(
      "SELECT id FROM affiliates WHERE code = $1",
      [code]
    );
    if (existing.rows.length === 0) break;
    attempts++;
  }
  return code;
}

/**
 * POST /affiliates/register  (admin only)
 * Body: { name, email, commissionType, commissionValue, notes }
 */
async function registerAffiliate(req, res) {
  const { name, email, commissionType = "percentage", commissionValue = 10, notes } = req.body;

  if (!name || !email) {
    return res.status(400).json({ error: "Missing fields", message: "name and email are required" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const existing = await client.query(
      "SELECT id FROM affiliates WHERE LOWER(email) = LOWER($1)",
      [email.trim()]
    );
    if (existing.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Already registered", message: "An affiliate with this email already exists" });
    }

    const code = await generateAffiliateCode(client);

    const result = await client.query(
      `INSERT INTO affiliates (name, email, code, commission_type, commission_value, status, total_clicks, total_conversions, total_earnings)
       VALUES ($1, $2, $3, $4, $5, 'active', 0, 0, 0)
       RETURNING id, name, email, code, commission_type, commission_value, status, created_at`,
      [name.trim(), email.trim().toLowerCase(), code, commissionType, commissionValue]
    );

    await client.query("COMMIT");

    const aff = result.rows[0];
    logger.info(`Affiliate registered: id=${aff.id}, code=${aff.code}`);

    res.status(201).json({
      success: true,
      data: {
        id: aff.id,
        name: aff.name,
        email: aff.email,
        affiliateCode: aff.code,
        commissionType: aff.commission_type,
        commissionValue: parseFloat(aff.commission_value),
        status: aff.status,
        createdAt: aff.created_at,
        trackingLink: `https://ventally.app/signup?aff=${aff.code}`,
      },
    });
  } catch (err) {
    await client.query("ROLLBACK");
    logger.error("Error registering affiliate:", err);
    res.status(500).json({ error: "Internal server error", message: "Failed to register affiliate" });
  } finally {
    client.release();
  }
}

/**
 * GET /affiliates/my-stats
 * Authenticated affiliate sees their own stats (matched by email)
 */
async function getMyStats(req, res) {
  const userId = req.user.id;
  const client = await pool.connect();
  try {
    const userRow = await client.query("SELECT email FROM users WHERE id = $1", [userId]);
    const email = userRow.rows[0]?.email;
    if (!email) return res.status(404).json({ error: "User not found" });

    const affRow = await client.query(
      "SELECT * FROM affiliates WHERE LOWER(email) = LOWER($1)",
      [email]
    );
    if (affRow.rows.length === 0) {
      return res.status(404).json({ error: "Not an affiliate", message: "No affiliate account linked to your email" });
    }

    const aff = affRow.rows[0];

    const recentConversions = await client.query(
      `SELECT ac.id, u.display_name AS user_name, ac.commission_amount, ac.status, ac.created_at
       FROM affiliate_conversions ac
       LEFT JOIN users u ON u.id = ac.user_id
       WHERE ac.affiliate_id = $1
       ORDER BY ac.created_at DESC
       LIMIT 20`,
      [aff.id]
    );

    res.json({
      data: {
        id: aff.id,
        name: aff.name,
        affiliateCode: aff.code,
        commissionType: aff.commission_type,
        commissionValue: parseFloat(aff.commission_value),
        status: aff.status,
        trackingLink: `https://ventally.app/signup?aff=${aff.code}`,
        stats: {
          totalClicks: aff.total_clicks || 0,
          totalConversions: aff.total_conversions || 0,
          totalEarnings: parseFloat(aff.total_earnings) || 0,
        },
        recentConversions: recentConversions.rows.map((c) => ({
          id: c.id,
          userName: c.user_name || "Anonymous",
          commissionAmount: parseFloat(c.commission_amount) || 0,
          status: c.status,
          date: c.created_at,
        })),
      },
    });
  } catch (err) {
    logger.error("Error fetching affiliate stats:", err);
    res.status(500).json({ error: "Internal server error", message: "Failed to fetch affiliate stats" });
  } finally {
    client.release();
  }
}

/**
 * GET /affiliates/track/:code  (public)
 * Increments click counter when someone visits a tracking link
 */
async function trackClick(req, res) {
  const { code } = req.params;
  if (!code) return res.status(400).json({ error: "Missing affiliate code" });

  const client = await pool.connect();
  try {
    const result = await client.query(
      "UPDATE affiliates SET total_clicks = total_clicks + 1 WHERE UPPER(code) = UPPER($1) AND status = 'active' RETURNING id",
      [code.trim()]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Invalid affiliate code" });
    }

    res.json({ success: true });
  } catch (err) {
    logger.error("Error tracking affiliate click:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
}

/**
 * Internal — called during signup when affiliateCode is provided
 * Records conversion and increments counters on the affiliates row
 */
async function recordConversion(affiliateCode, userId, client) {
  try {
    if (!affiliateCode) return;

    const affRow = await client.query(
      "SELECT id, commission_type, commission_value FROM affiliates WHERE UPPER(code) = UPPER($1) AND status = 'active'",
      [affiliateCode.trim()]
    );
    if (affRow.rows.length === 0) return;

    const aff = affRow.rows[0];

    // Prevent duplicate attribution
    const existing = await client.query(
      "SELECT id FROM affiliate_conversions WHERE affiliate_id = $1 AND user_id = $2",
      [aff.id, userId]
    );
    if (existing.rows.length > 0) return;

    // Commission is calculated when a session is paid — store 0 for now
    await client.query(
      `INSERT INTO affiliate_conversions (affiliate_id, user_id, commission_amount, status)
       VALUES ($1, $2, 0, 'pending')`,
      [aff.id, userId]
    );

    // Increment conversion counter on the affiliate row
    await client.query(
      "UPDATE affiliates SET total_conversions = total_conversions + 1 WHERE id = $1",
      [aff.id]
    );

    logger.info(`Affiliate conversion recorded: affiliate=${aff.id}, user=${userId}`);
  } catch (err) {
    logger.error("Error recording affiliate conversion:", err);
    // Non-fatal
  }
}

/**
 * GET /affiliates/list  (admin only)
 */
async function listAffiliates(req, res) {
  const client = await pool.connect();
  try {
    const rows = await client.query(
      `SELECT id, name, email, code, commission_type, commission_value, status,
              total_clicks, total_conversions, total_earnings, created_at
       FROM affiliates
       ORDER BY created_at DESC`
    );

    res.json({
      data: rows.rows.map((a) => ({
        id: a.id,
        name: a.name,
        email: a.email,
        affiliateCode: a.code,
        commissionType: a.commission_type,
        commissionValue: parseFloat(a.commission_value),
        status: a.status,
        totalClicks: a.total_clicks || 0,
        totalConversions: a.total_conversions || 0,
        totalEarnings: parseFloat(a.total_earnings) || 0,
        trackingLink: `https://ventally.app/signup?aff=${a.code}`,
        createdAt: a.created_at,
      })),
    });
  } catch (err) {
    logger.error("Error listing affiliates:", err);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
}

/**
 * POST /affiliates/application  (authenticated)
 * Body: { name, email, website, reason }
 * Stores an affiliate application for admin review.
 */
async function submitApplication(req, res) {
  const userId = req.user.id;
  const {
    name,
    email,
    website,
    reason,
    instagram_followers,
    tiktok_followers,
    facebook_followers,
    x_followers,
    other_platforms,
  } = req.body;

  if (!name || !email || !reason) {
    return res.status(400).json({
      error: "Missing fields",
      message: "name, email and reason are required",
    });
  }

  // Sanitise optional social fields
  const igFollowers   = instagram_followers != null ? parseInt(instagram_followers, 10) || null : null;
  const ttFollowers   = tiktok_followers    != null ? parseInt(tiktok_followers,    10) || null : null;
  const fbFollowers   = facebook_followers  != null ? parseInt(facebook_followers,  10) || null : null;
  const xFollowers    = x_followers         != null ? parseInt(x_followers,         10) || null : null;
  const otherPlatforms = Array.isArray(other_platforms)
    ? other_platforms.filter(p => p && p.platform).map(p => ({
        platform: String(p.platform).trim(),
        link: String(p.link || "").trim(),
      }))
    : [];

  try {
    // Check if user already has an affiliate account
    const existing = await pool.query(
      "SELECT id FROM affiliates WHERE LOWER(email) = LOWER($1)",
      [email.trim()]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({
        error: "Already registered",
        message: "An affiliate account already exists for this email",
      });
    }

    // Upsert application (allow resubmit if previously rejected)
    await pool.query(
      `INSERT INTO affiliate_applications
         (user_id, name, email, website, reason,
          instagram_followers, tiktok_followers, facebook_followers, x_followers, other_platforms,
          status, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'pending', NOW(), NOW())
       ON CONFLICT (user_id) DO UPDATE
         SET name                = EXCLUDED.name,
             email               = EXCLUDED.email,
             website             = EXCLUDED.website,
             reason              = EXCLUDED.reason,
             instagram_followers = EXCLUDED.instagram_followers,
             tiktok_followers    = EXCLUDED.tiktok_followers,
             facebook_followers  = EXCLUDED.facebook_followers,
             x_followers         = EXCLUDED.x_followers,
             other_platforms     = EXCLUDED.other_platforms,
             status              = 'pending',
             updated_at          = NOW()`,
      [
        userId,
        name.trim(),
        email.trim().toLowerCase(),
        (website || "").trim(),
        reason.trim(),
        igFollowers,
        ttFollowers,
        fbFollowers,
        xFollowers,
        JSON.stringify(otherPlatforms),
      ]
    );

    logger.info(`Affiliate application submitted: userId=${userId}, email=${email}`);

    res.status(201).json({
      success: true,
      message: "Application submitted successfully. We'll review it shortly.",
    });
  } catch (err) {
    logger.error("Error submitting affiliate application:", err);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to submit application",
    });
  }
}

/**
 * GET /affiliates/application/status  (authenticated)
 * Returns the current user's application status, or null if none exists.
 */
async function getApplicationStatus(req, res) {
  const userId = req.user.id;
  try {
    const result = await pool.query(
      `SELECT status, created_at, updated_at FROM affiliate_applications WHERE user_id = $1`,
      [userId]
    );
    if (result.rows.length === 0) {
      return res.json({ data: null });
    }
    const row = result.rows[0];
    res.json({
      data: {
        status: row.status,
        submittedAt: row.created_at,
        updatedAt: row.updated_at,
      },
    });
  } catch (err) {
    logger.error("Error fetching application status:", err);
    res.status(500).json({ error: "Internal server error" });
  }
}

module.exports = {
  registerAffiliate,
  getMyStats,
  trackClick,
  recordConversion,
  listAffiliates,
  submitApplication,
  getApplicationStatus,
};
